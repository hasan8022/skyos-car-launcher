# HasanLauncher (tr.hasan.et5)

SkyOS esdegeri, sifirdan yazilmis arac head-unit launcher.

## 15 Menu
Ekran | Arac | 3D Arac | Radyo | Medya | Telefon | Harita | Klima | Sarj | Tema | Koltuk | Sesli | Gosterge | Ayna | Ayarlar

## Derleme
Android Studio -> Build -> Build APK(s) -> app-debug.apk
