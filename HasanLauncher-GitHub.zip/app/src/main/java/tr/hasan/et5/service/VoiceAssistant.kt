package tr.hasan.et5.service

import android.content.Context
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class VoiceAssistant(private val ctx: Context) : RecognitionListener {
    private val recognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
    private var tts: TextToSpeech? = null
    var onResult: ((String) -> Unit)? = null
    var isListening = false

    init {
        recognizer.setRecognitionListener(this)
        tts = TextToSpeech(ctx) { }
    }

    fun startListening() {
        if (isListening) return
        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, Locale("tr", "TR").toString())
            putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        try {
            recognizer.startListening(intent)
            isListening = true
        } catch (e: Exception) { Log.e("Et5Sesli", "Dinleme baslatilamadi", e) }
    }

    fun stopListening() { recognizer.stopListening(); isListening = false }
    fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "et5_tts") }

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (matches.isNotEmpty()) onResult?.invoke(matches[0])
    }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { isListening = false }
    override fun onError(error: Int) { isListening = false }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
