package tr.hasan.et5.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus
import kotlinx.coroutines.delay

@Composable
fun ChargeScreen() {
    val context = LocalContext.current
    var values by remember { mutableStateOf(VehicleBus.readHvac(context)) }
    var limit by remember { mutableIntStateOf(80) }
    var scheduled by remember { mutableStateOf(false) }
    var scheduleTime by remember { mutableStateOf("08:00") }
    var status by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { values = VehicleBus.readHvac(context); delay(3000) } }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sarj & Batarya", style = MaterialTheme.typography.headlineMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Batarya: ${values["pil"] ?: "--"}%", style = MaterialTheme.typography.titleLarge)
                Text("Menzil: ${values["menzil"] ?: "--"} km", style = MaterialTheme.typography.titleMedium)
                Text("Sarj: ${values["sarj"] ?: "--"}", style = MaterialTheme.typography.bodyMedium)
                Text("Ic: ${values["ic"] ?: "--"} C | Dis: ${values["dis"] ?: "--"} C", style = MaterialTheme.typography.bodySmall)
            }
        }
        HorizontalDivider()
        Text("Sarj Limiti (%)", style = MaterialTheme.typography.titleMedium)
        Slider(value = limit.toFloat(), onValueChange = { limit = it.toInt() }, valueRange = 50f..100f, steps = 49)
        Text("Limit: %$limit")
        Button(onClick = { status = VehicleBus.writeSetting(context, "sarj_limit", limit.toString()).toString() }) { Text("Limiti Yaz") }
        HorizontalDivider()
        Text("Randevulu Sarj", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = scheduled, onCheckedChange = { scheduled = it })
            Spacer(Modifier.width(8.dp))
            Text(if (scheduled) "Aktif" else "Kapali")
        }
        if (scheduled) {
            TextField(value = scheduleTime, onValueChange = { scheduleTime = it }, label = { Text("Saat (08:00)") })
            Button(onClick = { status = VehicleBus.writeSetting(context, "sarj_randevu", scheduleTime).toString() }) { Text("Kaydet") }
        } else {
            Button(onClick = { status = VehicleBus.writeSetting(context, "sarj_randevu", "").toString() }) { Text("Kaldir") }
        }
        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
