package tr.hasan.et5.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

data class CarApp(val label: String, val pkg: String, val desc: String)

val carApps = listOf(
    CarApp("Radyo", "com.skyworth.car.carradio", "Arac radyosu"),
    CarApp("EV / Batarya", "com.skyworth.car.evs", "Elektrikli arac bilgileri"),
    CarApp("Klima", "com.coolwell.ai.skyhvac", "Iklimlendirme kontrolu"),
    CarApp("BT Muzik", "com.skyworth.car.carbtmusic", "Bluetooth ses akisi"),
    CarApp("Yerel Medya", "com.skyworth.car.localmedia", "USB / yerel dosyalar"),
    CarApp("Telefon", "com.skyworth.car.skycommunication", "Arama gecmisi / kontaklar"),
)

@Composable
fun CarPanel() {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Arac Sistemleri", style = MaterialTheme.typography.headlineMedium)
        Text("Skyworth sistem uygulamalarina dogrudan baglanir.", style = MaterialTheme.typography.bodySmall)
        carApps.forEach { app ->
            Card(Modifier.fillMaxWidth().clickable {
                context.packageManager.getLaunchIntentForPackage(app.pkg)?.let { context.startActivity(it) } ?: toast(context, app.label + " yuklu degil")
            }) {
                Column(Modifier.padding(14.dp)) {
                    Text(app.label, style = MaterialTheme.typography.titleLarge)
                    Text(app.desc, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
