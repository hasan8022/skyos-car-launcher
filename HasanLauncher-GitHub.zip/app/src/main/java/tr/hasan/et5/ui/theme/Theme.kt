package tr.hasan.et5.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CarDarkColors = darkColorScheme()

@Composable
fun HasanLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CarDarkColors, content = content)
}
