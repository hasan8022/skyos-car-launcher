package tr.hasan.et5.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.service.HomeGate

fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("Ekran", "Arac", "3D", "Radyo", "Medya", "Telefon", "Harita", "Klima", "Sarj", "Tema", "Koltuk", "Sesli", "Gosterge", "Ayna", "Ayarlar")
    var unlocked by remember { mutableStateOf(!HomeGate.hasPin(context)) }

    if (!unlocked) {
        var input by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Guvenlik Kilidi", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))
            Text(if (error) "Yanlis PIN" else "PIN girin", color = if (error) MaterialTheme.colorScheme.error else LocalContentColor.current)
            Text("*".repeat(input.length), style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(12.dp))
            val keys = listOf(listOf("1","2","3"), listOf("4","5","6"), listOf("7","8","9"), listOf("C","0","OK"))
            keys.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { k ->
                        Button(onClick = {
                            when (k) { "C" -> { input = ""; error = false }
                                "OK" -> if (HomeGate.unlock(context, input)) unlocked = true else { error = true; input = "" }
                                else -> if (input.length < 8) input += k
                            }
                        }) { Text(k, modifier = Modifier.padding(8.dp)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        return
    }

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                tabs.forEachIndexed { i, label ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) })
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab()
                1 -> CarPanel()
                2 -> Car3DScreen()
                3 -> RadioScreen()
                4 -> MediaTab()
                5 -> PhoneScreen()
                6 -> MapScreen()
                7 -> ClimateScreen()
                8 -> ChargeScreen()
                9 -> ThemeScreen()
                10 -> SeatScreen()
                11 -> VoiceScreen()
                12 -> DashboardScreen()
                13 -> MirrorScreen()
                14 -> SettingsScreen()
            }
        }
    }
}
