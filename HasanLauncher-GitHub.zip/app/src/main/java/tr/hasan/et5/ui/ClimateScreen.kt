package tr.hasan.et5.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus

@Composable
fun ClimateScreen() {
    val context = LocalContext.current
    var values by remember { mutableStateOf(VehicleBus.readHvac(context)) }
    var zone by remember { mutableStateOf("0") }
    var temp by remember { mutableFloatStateOf(21f) }
    var status by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val obs = VehicleBus.observeHvac(context) { values = VehicleBus.readHvac(context) }
        onDispose { obs?.let { context.contentResolver.unregisterContentObserver(it) } }
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Klima", style = MaterialTheme.typography.headlineMedium)
        Text("Skyworth HVAC: content://com.coolwell.ai.skyhvac.database", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = zone == "0", onClick = { zone = "0" }, label = { Text("Surucu") })
            FilterChip(selected = zone == "1", onClick = { zone = "1" }, label = { Text("Yolcu") })
        }
        Text("Hedef: %.1f C".format(temp), style = MaterialTheme.typography.titleLarge)
        Slider(value = temp, onValueChange = { temp = it }, valueRange = 15f..30f, steps = 29)
        Button(onClick = { status = VehicleBus.setTemperature(context, zone, temp) }, modifier = Modifier.fillMaxWidth()) { Text("Sicakligi Yaz") }
        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
        HorizontalDivider()
        Text("Aractan Okunanlar", style = MaterialTheme.typography.titleMedium)
        if (values.isEmpty()) Text("Veri gelmedi")
        values.forEach { (k, v) -> Text("$k = $v", style = MaterialTheme.typography.bodySmall) }
    }
}
