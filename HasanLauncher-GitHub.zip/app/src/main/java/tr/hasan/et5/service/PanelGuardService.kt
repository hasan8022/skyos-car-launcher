package tr.hasan.et5.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.view.*
import android.view.accessibility.AccessibilityEvent

class PanelGuardService : AccessibilityService() {
    private var leftView: View? = null
    private var rightView: View? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.packageName == "com.android.systemui" && event.className?.contains("VolumeDialog") == true) {
            ensureOverlays()
        }
    }
    override fun onInterrupt() {}

    private fun ensureOverlays() {
        if (leftView != null) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            12, WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.START or Gravity.TOP
        leftView = View(this).apply { setBackgroundColor(0x40000000) }
        wm.addView(leftView, params)
        params.gravity = Gravity.END or Gravity.TOP
        rightView = View(this).apply { setBackgroundColor(0x40000000) }
        wm.addView(rightView, params)
        Log.i("Et5Kenar", "Kenar seritleri eklendi")
    }

    override fun onDestroy() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        leftView?.let { wm.removeView(it) }
        rightView?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
