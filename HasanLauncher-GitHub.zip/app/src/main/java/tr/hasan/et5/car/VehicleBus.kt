package tr.hasan.et5.car

import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper

object VehicleBus {
    const val HVAC_URI = "content://com.coolwell.ai.skyhvac.database/airconditioner"
    const val HVAC_TEMP_URI = "content://com.coolwell.ai.skyhvac.database/airconditioner/temperature"
    const val RECOVERY_URI = "content://com.skyworth.car.aisettings.vehiclecontrol.database/recovery"
    const val HVAC_PKG = "com.coolwell.ai.skyhvac"

    val CACHE_KEYS = listOf(
        "klima", "pil", "menzil", "ic", "dis", "sicaklik", "fan", "ac", "oto",
        "ichava", "sHeat", "sVent", "yHeat", "yVent", "bagaj", "sarj", "sessiz", "durum"
    )

    fun readHvac(context: Context): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        try {
            val c = context.contentResolver.query(Uri.parse(HVAC_URI), null, null, null, null)
            c?.use { cur ->
                if (cur.moveToFirst()) {
                    for (i in 0 until cur.columnCount) out[cur.getColumnName(i)] = cur.getString(i) ?: ""
                }
            }
        } catch (e: Exception) { out["hata"] = e.message ?: "okunamadi" }
        return out
    }

    fun observeHvac(context: Context, onChange: () -> Unit): ContentObserver? {
        return try {
            val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) { onChange() }
            }
            context.contentResolver.registerContentObserver(Uri.parse(HVAC_URI), true, obs)
            obs
        } catch (e: Exception) { null }
    }

    fun setTemperature(context: Context, zone: String, value: Float): String {
        try {
            val cv = android.content.ContentValues().apply { put("zone", zone); put("value", value); put("f", value) }
            val u = Uri.parse(HVAC_TEMP_URI)
            val n = context.contentResolver.update(u, cv, null, null)
            if (n != null && n > 0) return "provider update OK ($n)"
            context.contentResolver.insert(u, cv)
            return "provider insert OK"
        } catch (e: Exception) {
            try {
                val i = Intent().apply {
                    setDataAndType(Uri.parse(HVAC_TEMP_URI), "vnd.android.cursor.item/zone")
                    putExtra("zone", zone); putExtra("value", value); putExtra("f", value)
                    `package` = HVAC_PKG
                    addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                }
                context.sendBroadcast(i)
                return "intent gonderildi"
            } catch (e2: Exception) { return "yazilamadi: ${e2.message}" }
        }
    }

    fun writeSetting(context: Context, key: String, value: String): Boolean {
        return try {
            val cv = android.content.ContentValues().apply { put("key", key); put("value", value) }
            val u = Uri.parse(RECOVERY_URI)
            val n = context.contentResolver.update(u, cv, "key=?", arrayOf(key))
            if (n != null && n > 0) true else context.contentResolver.insert(u, cv) != null
        } catch (e: Exception) { false }
    }

    fun readSettings(context: Context): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        try {
            val c = context.contentResolver.query(Uri.parse(RECOVERY_URI), null, null, null, null)
            c?.use { cur ->
                if (cur.moveToFirst()) { for (i in 0 until cur.columnCount) out[cur.getColumnName(i)] = cur.getString(i) ?: "" }
            }
        } catch (e: Exception) { out["hata"] = e.message ?: "okunamadi" }
        return out
    }

    fun setDashboard(context: Context, key: String, value: String): Boolean {
        return writeSetting(context, "dashboard_$key", value)
    }
}
