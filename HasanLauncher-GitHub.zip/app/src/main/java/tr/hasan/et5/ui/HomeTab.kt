package tr.hasan.et5.ui

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("QueryAllPackagesPermission")
fun loadApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val resolved = pm.queryIntentActivities(intent, 0)
    return resolved.mapNotNull { r ->
        val pkg = r.activityInfo.packageName
        if (pkg == context.packageName) null
        else AppEntry(r.loadLabel(pm).toString(), pkg, drawableToBitmap(r.loadIcon(pm)))
    }.sortedBy { it.label.lowercase(Locale("tr")) }
}

fun drawableToBitmap(d: Drawable): Bitmap {
    if (d is BitmapDrawable && d.bitmap != null) return d.bitmap
    val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else 1
    val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else 1
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, w, h)
    d.draw(Canvas(bmp))
    return bmp
}

data class AppEntry(val label: String, val pkg: String, val icon: Bitmap)

fun btAdapter(): BluetoothAdapter? = try { BluetoothAdapter.getDefaultAdapter() } catch (e: Exception) { null }
fun hasBtConnect(context: Context): Boolean =
    context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
fun toggleBt(context: Context, onState: (Boolean) -> Unit) {
    val adapter = btAdapter() ?: return toast(context, "Bluetooth bulunamadi")
    try {
        if (adapter.isEnabled) { adapter.disable(); onState(false) }
        else { adapter.enable(); onState(true) }
    } catch (e: SecurityException) { toast(context, "Bluetooth izni gerekli") }
}

@Composable
fun HomeTab() {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        StatusBar()
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f)) { AppsGrid() }
    }
}

@Composable
fun StatusBar() {
    val context = LocalContext.current
    var time by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            time = SimpleDateFormat("HH:mm", Locale("tr")).format(Date())
            date = SimpleDateFormat("EEEE, d MMMM", Locale("tr")).format(Date())
            delay(1000)
        }
    }
    var enabled by remember { mutableStateOf(btAdapter()?.isEnabled == true) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column { Text(time, style = MaterialTheme.typography.displayMedium); Text(date) }
        Spacer(Modifier.weight(1f))
        Button(onClick = { context.startActivity(Intent(Settings.Panel.ACTION_WIFI)) }) { Text("WiFi") }
        Spacer(Modifier.width(8.dp))
        BluetoothButton { enabled = it }
    }
}

@Composable
fun BluetoothButton(onState: (Boolean) -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(btAdapter()?.isEnabled == true) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) toggleBt(context) { enabled = it; onState(it) } }
    Button(onClick = {
        if (hasBtConnect(context)) toggleBt(context) { enabled = it; onState(it) }
        else perm.launch(android.Manifest.permission.BLUETOOTH_CONNECT)
    }) { Text(if (enabled) "BT: Acik" else "BT: Kapali") }
}

@Composable
fun AppsGrid() {
    val context = LocalContext.current
    val apps = remember { loadApps(context) }
    LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 110.dp)) {
        items(apps, key = { it.pkg }) { app ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp).clickable {
                context.packageManager.getLaunchIntentForPackage(app.pkg)?.let { context.startActivity(it) }
            }) {
                Image(bitmap = app.icon.asImageBitmap(), contentDescription = app.label, modifier = Modifier.size(56.dp))
                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }
    }
}
