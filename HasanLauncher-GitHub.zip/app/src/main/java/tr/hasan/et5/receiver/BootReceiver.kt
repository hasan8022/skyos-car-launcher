package tr.hasan.et5.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import tr.hasan.et5.MainActivity

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                try {
                    val i = Intent(context, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(i)
                    Log.i("Et5Acilis", "HasanLauncher oncelendirildi: ${intent.action}")
                } catch (e: Exception) {
                    Log.w("Et5Acilis", "Acilista oncelendirilemedi: ${e.message}")
                }
            }
        }
    }
}
