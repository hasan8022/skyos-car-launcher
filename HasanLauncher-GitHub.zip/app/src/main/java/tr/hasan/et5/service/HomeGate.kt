package tr.hasan.et5.service

import android.content.Context
import android.content.SharedPreferences

object HomeGate {
    private const val PREF = "homegate"
    private const val KEY_PIN = "pin"
    private const val KEY_FAILS = "kapi_acilislar"
    private const val KEY_LAST_DRAW = "son_cizim"

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun pin(ctx: Context): String = prefs(ctx).getString(KEY_PIN, "") ?: ""
    fun setPin(ctx: Context, p: String) = prefs(ctx).edit().putString(KEY_PIN, p).apply()
    fun hasPin(ctx: Context) = pin(ctx).isNotEmpty()
    fun unlock(ctx: Context, entered: String) = entered == pin(ctx)
    fun recordFail(ctx: Context) { val c = prefs(ctx).getInt(KEY_FAILS, 0) + 1; prefs(ctx).edit().putInt(KEY_FAILS, c).apply() }
    fun resetFails(ctx: Context) = prefs(ctx).edit().putInt(KEY_FAILS, 0).apply()
    fun failCount(ctx: Context) = prefs(ctx).getInt(KEY_FAILS, 0)
}
