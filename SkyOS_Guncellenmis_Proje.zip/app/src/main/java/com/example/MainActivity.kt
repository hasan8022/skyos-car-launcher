package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.example.data.VehicleRepository
import com.example.data.VoiceAssistantManager
import com.example.ui.components.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var repository: VehicleRepository
    private lateinit var assistantManager: VoiceAssistantManager
    private var speechRecognizer: SpeechRecognizer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Handle audio / location permissions
        if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
            setupSpeechRecognizer()
        }
        // Konum izni verildiyse GPS güncellemelerini şimdi başlat
        // (ilk açılışta izin yokken başlatma sessizce başarısız oluyordu)
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            repository.telemetryHelper.startLocationUpdates()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on in automotive dashboard
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()

        repository = VehicleRepository(this)
        assistantManager = VoiceAssistantManager(this, repository)

        // Check incoming intent (e.g. shared location from Google Maps: "Paylaş > SkyOS")
        handleIncomingIntent(intent)

        // Request runtime permissions gracefully
        requestRequiredPermissions()

        setContent {
            val vehicleState by repository.vehicleState.collectAsState()
            val isDark = repository.isDarkModeEffective(vehicleState)
            var setupDone by remember { mutableStateOf(repository.isSetupCompleted()) }

            MyApplicationTheme(darkTheme = isDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (!setupDone) {
                        // İlk açılış: kurulum sihirbazı (izinler + Ev/İş adresi)
                        com.example.ui.components.SetupWizardScreen(
                            repository = repository,
                            speechAvailable = assistantManager.isRecognitionSupported(),
                            onDeviceRecognition = assistantManager.isOnDeviceRecognition(),
                            onRequestPermissions = { requestRequiredPermissions() },
                            onFinish = { setupDone = true }
                        )
                    } else {
                        HomeScreen(
                            repository = repository,
                            assistantManager = assistantManager
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                repository.setSearchQuery(sharedText)
                repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
                assistantManager.speak("Paylaşılan konum araca aktarıldı: $sharedText")
            }
        }
    }

    private fun requestRequiredPermissions() {
        val needed = mutableListOf<String>()

        // Sesli asistan
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        // Navigasyon / GPS
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        // Bluetooth (Android 12+ runtime izni gerektirir)
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        }
        // Bildirimler (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        // Telefon ve rehber
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_CONTACTS)
        }
        // Arama kaydı (Son aramalar sekmesi gerçek veri okur)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_CALL_LOG)
        }
        // Medya/depolama (API 32 ve altı için gerçek runtime izni; 33+ otomatik izinlidir)
        if (android.os.Build.VERSION.SDK_INT <= 32) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        // Kamera (geri görüş)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }

        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            setupSpeechRecognizer()
            repository.telemetryHelper.startLocationUpdates()
        }
    }

    private fun setupSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        assistantManager.stopListening()
                    }
                    override fun onError(error: Int) {
                        assistantManager.stopListening()
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            assistantManager.processVoiceCommand(text)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    /**
     * Direksiyon tuşları ve donanım tuşları (ET5 head unit).
     *
     * Bu ünitede direksiyon tuşları standart Android KeyEvent olarak gelir:
     *  - İleri/geri tuşu  → KEYCODE_MEDIA_NEXT / MEDIA_PREVIOUS
     *  - Orta/OK tuşu     → KEYCODE_MEDIA_PLAY_PAUSE veya DPAD_CENTER
     *  - Ses +/-          → KEYCODE_VOLUME_UP / DOWN
     *  - Arama cevapla    → KEYCODE_MEDIA_PLAY (uzun basışta kapatma HEADSETHOOK)
     *  - Sesli asistan    → KEYCODE_VOICE_ASSIST
     *
     * Compose tarafında özel bir tuş yakalayıcı olmadığı için Activity seviyesinde
     * merkezi olarak işliyoruz; ekran geçişleri repository üzerinden yapılır.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            when (event.keyCode) {
                // Direksiyon ileri/geri → sonraki/önceki radyo istasyonu
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    repository.radioManager.nextStation()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    repository.radioManager.previousStation()
                    return true
                }
                // Direksiyon OK → çal/duraklat
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    repository.radioManager.togglePlayPause()
                    return true
                }
                // Direksiyon sesli asistan tuşu → dinlemeyi başlat
                KeyEvent.KEYCODE_VOICE_ASSIST -> {
                    startListeningVoice()
                    return true
                }
                // DPAD merkez/enter → mevcut odaktaki eylem (Compose focus'a bırak)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    return super.dispatchKeyEvent(event) // Compose focus halletsin
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** Cihazda sesli tanıma servisi gerçekten var mı (head unit'lerde olmayabilir). */
    fun isSpeechRecognitionAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(this)

    fun startListeningVoice() {
        // Mikrofon izni yoksa tekrar iste — sessizce yutmak yerine
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        // Recognizer henüz kurulmadıysa kurmayı dene
        if (speechRecognizer == null) {
            setupSpeechRecognizer()
        }
        val recognizer = speechRecognizer
        if (recognizer == null) {
            // Cihazda sesli tanıma servisi YOK — sahte dinleme yapma, dürüstçe bildir
            assistantManager.speak("Bu cihazda sesli tanıma servisi bulunamadı. Sesli asistan desteklenmiyor.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("tr", "TR"))
        }
        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            assistantManager.speak("Sesli dinleme başlatılamadı.")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        assistantManager.release()
        repository.release()
    }
}
