package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CameraPreviewScreen(
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCam by remember { mutableStateOf("Ön Kamera (ADAS / Yol Kaydı)") }
    // Sahte "REC" durumu ve sahte kayıt butonu kaldırıldı — gerçek kayıt hattı yok

    // Gerçek kamera donanımı tespiti (Camera2 API — uydurma durum yok)
    val context = androidx.compose.ui.platform.LocalContext.current
    val cameraHardwarePresent = remember {
        try {
            val cm = context.getSystemService(android.content.Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
            (cm?.cameraIdList?.isNotEmpty() == true)
        } catch (_: Exception) { false }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090B0E))
    ) {
        // Simulated Camera Feed with grid guidelines and status
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Camera top status bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FiberManualRecord,
                        contentDescription = null,
                        tint = if (cameraHardwarePresent) Color(0xFF22C55E) else Color(0xFF6B7280),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (cameraHardwarePresent) "Kamera Donanımı Algılandı" else "Kamera Bağlı Değil",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Ön Kamera (ADAS)", "Geri Görüş", "360° Çevre").forEach { cam ->
                        val isSelected = selectedCam.startsWith(cam.take(5))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF00D2FF) else Color(0xFF1E2638))
                                .clickable { selectedCam = cam }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cam,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2638))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                    }
                }
            }

            // Center Camera HUD & Parking Guidelines
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF131720)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = if (cameraHardwarePresent) Icons.Default.Videocam else Icons.Default.Close,
                        contentDescription = null,
                        tint = if (cameraHardwarePresent) Color(0xFF00D2FF) else Color(0xFFF59E0B),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (cameraHardwarePresent) "$selectedCam — donanım algılandı" else "Kamera Bulunamadı",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (cameraHardwarePresent)
                            "Canlı önizleme için UVC/Camera2 akış entegrasyonu gerekli"
                        else
                            "USB ADAS / UVC kamera takılı değil — simüle görüntü gösterilmiyor",
                        fontSize = 12.sp,
                        color = Color(0xFF9CA3AF)
                    )
                }
            }

            // Bottom camera options
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (cameraHardwarePresent)
                        "Durum: Kamera donanımı mevcut (Camera2) — canlı akış ve kayıt henüz entegre edilmedi"
                    else
                        "Durum: Kamera donanımı algılanmadı",
                    fontSize = 12.sp,
                    color = if (cameraHardwarePresent) Color(0xFF22C55E) else Color(0xFFF59E0B),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
