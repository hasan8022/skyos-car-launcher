package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SmartScreenMode
import com.example.model.VehicleState

@Composable
fun SmartModeOverlays(
    smartMode: SmartScreenMode,
    vehicleState: VehicleState,
    temporaryNote: String,
    onNoteChange: (String) -> Unit,
    onExitMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (smartMode == SmartScreenMode.NONE) return

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when (smartMode) {
            SmartScreenMode.PET_MODE -> {
                // Matching 72-evcil-hayvan_c26d046a.webp
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(28.dp)
                ) {
                    // Paw icon top left
                    Icon(
                        imageVector = Icons.Default.Pets,
                        contentDescription = "Evcil Hayvan",
                        tint = Color(0xFFD1D5DB),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .size(48.dp)
                    )

                    // Exit button top right
                    IconButton(
                        onClick = onExitMode,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF222938))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                    }

                    // Huge Temperature and message in center
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = vehicleState.insideTempC?.let { "$it°" } ?: "—",
                            fontSize = 110.sp,
                            fontWeight = FontWeight.ExtraLight,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Sahibim birazdan dönecek.",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = vehicleState.insideTempC?.let { "Endişelenmeyin! Klima açık ve araç içi $it°C." }
                                ?: "Endişelenmeyin! Klima açık. (İç sıcaklık sensörü okunamıyor)",
                            fontSize = 18.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }

                    // Bottom info
                    Text(
                        text = "Klima ${String.format(java.util.Locale.US, "%.1f°", vehicleState.driverTemp).replace(".", ",")} · " +
                                (if (vehicleState.batteryPercent >= 0) "Batarya %${vehicleState.batteryPercent}" else "Batarya: Veri Yok"),
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280),
                        modifier = Modifier.align(Alignment.BottomStart)
                    )
                }
            }

            SmartScreenMode.CAR_WASH -> {
                // Matching 75-oto-yikama_335a96ab.webp
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(40.dp),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LocalCarWash, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp))
                        Text("Oto yıkama modu", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    CarWashCheckItem("Aynalar katlandı")
                    CarWashCheckItem("Klima iç havaya alındı")
                    CarWashCheckItem("Ön park radarı susturuldu")
                    CarWashCheckItem("Cam tavan kapatıldı")

                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = "Yıkama bitince \"Bitir\"e basın; 15 km/sa üstünde kendiliğinden biter. Her şey eski haline döner.",
                        fontSize = 14.sp,
                        color = Color(0xFF9CA3AF)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onExitMode,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .width(260.dp)
                            .height(50.dp)
                    ) {
                        Text("Bitir", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            SmartScreenMode.TEMP_NOTE -> {
                // Temporary Note Overlay — not gerçekten kullanıcı tarafından yazılır, hazır uydurma numara gösterilmez
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Note, contentDescription = null, tint = Color(0xFF00D2FF), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("ARAÇ SAHİBİ NOTU", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8F9CAE))
                    Spacer(modifier = Modifier.height(14.dp))
                    if (temporaryNote.isBlank()) {
                        Text(
                            text = "Henüz not girilmedi",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF6B7280)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        var draft by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            placeholder = { Text("Örn: 0532 ... — Lütfen arayınız", color = Color(0xFF6B7280)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00D2FF),
                                unfocusedBorderColor = Color(0xFF374151)
                            ),
                            modifier = Modifier.fillMaxWidth(0.6f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { if (draft.isNotBlank()) onNoteChange(draft.trim()) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF))
                        ) {
                            Text("Notu Kaydet", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Text(text = temporaryNote, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(onClick = { onNoteChange("") }) {
                            Text("Notu Temizle", color = Color(0xFF9CA3AF))
                        }
                    }
                    Spacer(modifier = Modifier.height(30.dp))
                    Button(
                        onClick = onExitMode,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2638))
                    ) {
                        Text("Kapat", color = Color.White)
                    }
                }
            }

            SmartScreenMode.SCREEN_CLEAN -> {
                // Screen clean mode: long press 3s to exit
                var progress by remember { mutableFloatStateOf(0f) }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { onExitMode() }
                            )
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.CleaningServices, contentDescription = null, tint = Color(0xFF6B7280), modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Ekran Temizleme Modu", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Çıkmak için ekrana 3 saniye basılı tutun", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                }
            }

            else -> {
                // Fallback exit button
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Button(onClick = onExitMode) { Text("Moddan Çık") }
                }
            }
        }
    }
}

@Composable
fun CarWashCheckItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF059669)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
        }
        Text(text = text, fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Medium)
    }
}
