package com.example.ui.components

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.VehicleRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Contact(val name: String, val phone: String, val isFavorite: Boolean = false)

data class CallLogEntry(
    val name: String?,
    val number: String,
    val type: Int,
    val dateMillis: Long,
    val durationSec: Long
)

private fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

private fun loadDeviceContacts(context: Context): List<Contact> {
    // Sadece gerçek rehber verisi okunur; hiçbir uydurma kişi eklenmez.
    val result = LinkedHashMap<String, Contact>()
    val projection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.STARRED
    )
    context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        projection, null, null,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
    )?.use { cursor ->
        val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val starredIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED)
        while (cursor.moveToNext()) {
            val name = if (nameIdx >= 0) cursor.getString(nameIdx) else null
            val number = if (numberIdx >= 0) cursor.getString(numberIdx) else null
            if (name.isNullOrBlank() || number.isNullOrBlank()) continue
            val starred = starredIdx >= 0 && cursor.getInt(starredIdx) == 1
            val key = "${name.trim()}|${number.trim()}"
            val existing = result[key]
            if (existing == null || (starred && !existing.isFavorite)) {
                result[key] = Contact(name.trim(), number.trim(), starred)
            }
        }
    }
    return result.values.toList()
}

private fun loadDeviceCallLog(context: Context): List<CallLogEntry> {
    // Sadece gerçek arama kaydı okunur.
    val result = mutableListOf<CallLogEntry>()
    val projection = arrayOf(
        CallLog.Calls.CACHED_NAME,
        CallLog.Calls.NUMBER,
        CallLog.Calls.TYPE,
        CallLog.Calls.DATE,
        CallLog.Calls.DURATION
    )
    context.contentResolver.query(
        CallLog.Calls.CONTENT_URI,
        projection, null, null,
        CallLog.Calls.DATE + " DESC"
    )?.use { cursor ->
        val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
        val numberIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
        val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)
        val dateIdx = cursor.getColumnIndex(CallLog.Calls.DATE)
        val durationIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
        while (cursor.moveToNext() && result.size < 50) {
            val number = if (numberIdx >= 0) cursor.getString(numberIdx) else null
            if (number.isNullOrBlank()) continue
            result.add(
                CallLogEntry(
                    name = if (nameIdx >= 0) cursor.getString(nameIdx) else null,
                    number = number.trim(),
                    type = if (typeIdx >= 0) cursor.getInt(typeIdx) else CallLog.Calls.OUTGOING_TYPE,
                    dateMillis = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L,
                    durationSec = if (durationIdx >= 0) cursor.getLong(durationIdx) else 0L
                )
            )
        }
    }
    return result
}

private fun formatCallDate(millis: Long): String {
    if (millis <= 0L) return ""
    return SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date(millis))
}

private fun formatCallDuration(seconds: Long): String {
    if (seconds <= 0L) return ""
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "$m dk $s sn" else "$s sn"
}

private fun callTypeLabel(type: Int): String = when (type) {
    CallLog.Calls.INCOMING_TYPE -> "Gelen"
    CallLog.Calls.OUTGOING_TYPE -> "Giden"
    CallLog.Calls.MISSED_TYPE -> "Cevapsız"
    CallLog.Calls.REJECTED_TYPE -> "Reddedilen"
    CallLog.Calls.BLOCKED_TYPE -> "Engellenen"
    else -> "Arama"
}

private fun callTypeColor(type: Int): Color = when (type) {
    CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> Color(0xFFEF4444)
    CallLog.Calls.INCOMING_TYPE -> Color(0xFF22C55E)
    else -> Color(0xFF00D2FF)
}

@Composable
fun PhoneScreen(
    repository: VehicleRepository,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vehicleState by repository.vehicleState.collectAsState()
    val context = LocalContext.current

    var selectedTab by remember { mutableStateOf("Tuşlar") }
    var dialedNumber by remember { mutableStateOf("") }
    var callError by remember { mutableStateOf<String?>(null) }

    // Gerçek izin durumları — uydurma rehber/arama kaydı asla gösterilmez
    var contactsGranted by remember { mutableStateOf(hasPermission(context, Manifest.permission.READ_CONTACTS)) }
    var callLogGranted by remember { mutableStateOf(hasPermission(context, Manifest.permission.READ_CALL_LOG)) }

    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var contactsLoaded by remember { mutableStateOf(false) }
    var callLog by remember { mutableStateOf<List<CallLogEntry>>(emptyList()) }
    var callLogLoaded by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        contactsGranted = hasPermission(context, Manifest.permission.READ_CONTACTS)
        callLogGranted = hasPermission(context, Manifest.permission.READ_CALL_LOG)
    }

    LaunchedEffect(contactsGranted) {
        if (contactsGranted) {
            contactsLoaded = false
            contacts = withContext(Dispatchers.IO) { loadDeviceContacts(context) }
            contactsLoaded = true
        } else {
            contacts = emptyList()
            contactsLoaded = false
        }
    }

    LaunchedEffect(callLogGranted) {
        if (callLogGranted) {
            callLogLoaded = false
            callLog = withContext(Dispatchers.IO) { loadDeviceCallLog(context) }
            callLogLoaded = true
        } else {
            callLog = emptyList()
            callLogLoaded = false
        }
    }

    fun placeCall(number: String) {
        callError = null
        val canCall = hasPermission(context, Manifest.permission.CALL_PHONE)
        val intent = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            callError = "Bu cihazda arama uygulaması bulunamadı."
        } catch (e: SecurityException) {
            callError = "Arama izni verilmedi."
        }
    }

    fun requestPhonePermissions() {
        val needed = mutableListOf<String>()
        if (!contactsGranted) needed.add(Manifest.permission.READ_CONTACTS)
        if (!callLogGranted) needed.add(Manifest.permission.READ_CALL_LOG)
        if (!hasPermission(context, Manifest.permission.CALL_PHONE)) needed.add(Manifest.permission.CALL_PHONE)
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1217))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Telefon",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = if (vehicleState.bluetoothConnected) "Bluetooth: ${vehicleState.bluetoothDeviceName} bağlı" else "Bluetooth telefonu bağlı değil",
                    fontSize = 12.sp,
                    color = if (vehicleState.bluetoothConnected) Color(0xFF22C55E) else Color(0xFF8F9CAE)
                )
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E2638))
            ) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
            }
        }

        // Hata mesajı (gerçek arama başlatılamazsa)
        callError?.let { error ->
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF7F1D1D))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = error, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { callError = null }, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs: [Favoriler] [Son aramalar] [Rehber] [Tuşlar]
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF161C26))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("Favoriler", "Son aramalar", "Rehber", "Tuşlar").forEach { tab ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF252E3E) else Color.Transparent)
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = tab,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else Color(0xFF8F9CAE)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tab Contents
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                "Tuşlar" -> {
                    // Full Dialpad UI
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Dialed Number Display
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .height(46.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF171D27))
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (dialedNumber.isEmpty()) "Numara girin..." else dialedNumber,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (dialedNumber.isEmpty()) Color(0xFF6B7280) else Color.White
                            )

                            if (dialedNumber.isNotEmpty()) {
                                IconButton(onClick = { dialedNumber = dialedNumber.dropLast(1) }) {
                                    Icon(imageVector = Icons.Default.Backspace, contentDescription = "Sil", tint = Color(0xFF9CA3AF))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Dialpad Buttons (3x4 grid)
                        val keypad = listOf(
                            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                            listOf("*" to "", "0" to "+", "#" to "")
                        )

                        keypad.forEach { row ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                row.forEach { (digit, letters) ->
                                    Box(
                                        modifier = Modifier
                                            .size(width = 72.dp, height = 48.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF1E2638))
                                            .clickable { dialedNumber += digit },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = digit, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            if (letters.isNotEmpty()) {
                                                Text(text = letters, fontSize = 9.sp, color = Color(0xFF8F9CAE))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Green Call Button — gerçek arama başlatır (sistem arayıcısı)
                        Box(
                            modifier = Modifier
                                .size(width = 160.dp, height = 46.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF10B981))
                                .clickable {
                                    if (dialedNumber.isNotEmpty()) {
                                        placeCall(dialedNumber)
                                        dialedNumber = ""
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(imageVector = Icons.Default.Phone, contentDescription = "Ara", tint = Color.White)
                                Text(text = "Ara", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                "Rehber" -> {
                    when {
                        !contactsGranted -> PermissionNeededPanel(
                            message = "Rehberi göstermek için kişi erişim izni gerekli. İzin verilmezse rehber boş gösterilir; uydurma kişi listesi kullanılmaz.",
                            onRequest = { requestPhonePermissions() }
                        )
                        !contactsLoaded -> LoadingPanel("Rehber okunuyor…")
                        contacts.isEmpty() -> EmptyPanel("Rehberde kişi bulunamadı.")
                        else -> ContactList(contacts = contacts, onCall = { placeCall(it.phone) })
                    }
                }

                "Favoriler" -> {
                    when {
                        !contactsGranted -> PermissionNeededPanel(
                            message = "Favorileri göstermek için kişi erişim izni gerekli.",
                            onRequest = { requestPhonePermissions() }
                        )
                        !contactsLoaded -> LoadingPanel("Rehber okunuyor…")
                        else -> {
                            val favorites = contacts.filter { it.isFavorite }
                            if (favorites.isEmpty()) {
                                EmptyPanel("Favori kişi yok. Telefonunuzun rehberinde yıldızladığınız kişiler burada görünür.")
                            } else {
                                ContactList(contacts = favorites, onCall = { placeCall(it.phone) })
                            }
                        }
                    }
                }

                "Son aramalar" -> {
                    when {
                        !callLogGranted -> PermissionNeededPanel(
                            message = "Son aramaları göstermek için arama kaydı izni gerekli.",
                            onRequest = { requestPhonePermissions() }
                        )
                        !callLogLoaded -> LoadingPanel("Arama kaydı okunuyor…")
                        callLog.isEmpty() -> EmptyPanel("Arama kaydı yok.")
                        else -> CallLogList(entries = callLog, onRedial = { placeCall(it.number) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactList(contacts: List<Contact>, onCall: (Contact) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(contacts) { c ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF161C26))
                    .clickable { onCall(c) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0284C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = c.name.take(1).uppercase(Locale("tr", "TR")), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(text = c.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                            if (c.isFavorite) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Favori",
                                    tint = Color(0xFFFBBF24),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Text(text = c.phone, color = Color(0xFF8F9CAE), fontSize = 12.sp)
                    }
                }

                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Ara",
                    tint = Color(0xFF10B981)
                )
            }
        }
    }
}

@Composable
private fun CallLogList(entries: List<CallLogEntry>, onRedial: (CallLogEntry) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(entries) { entry ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF161C26))
                    .clickable { onRedial(entry) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF222938)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (entry.type) {
                                CallLog.Calls.INCOMING_TYPE -> Icons.Default.CallReceived
                                CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Icons.Default.CallMissed
                                else -> Icons.Default.CallMade
                            },
                            contentDescription = callTypeLabel(entry.type),
                            tint = callTypeColor(entry.type),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = entry.name?.takeIf { it.isNotBlank() } ?: entry.number,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = buildString {
                                append(callTypeLabel(entry.type))
                                formatCallDate(entry.dateMillis).takeIf { it.isNotEmpty() }?.let { append(" · $it") }
                                formatCallDuration(entry.durationSec).takeIf { it.isNotEmpty() }?.let { append(" · $it") }
                            },
                            color = Color(0xFF8F9CAE),
                            fontSize = 12.sp
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Tekrar ara",
                    tint = Color(0xFF10B981)
                )
            }
        }
    }
}

@Composable
private fun PermissionNeededPanel(message: String, onRequest: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = Color(0xFFF59E0B),
            modifier = Modifier.size(44.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = message,
            color = Color(0xFFD1D5DB),
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onRequest,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("İzin Ver", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LoadingPanel(message: String) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = Color(0xFF00D2FF), modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = message, color = Color(0xFF8F9CAE), fontSize = 13.sp)
    }
}

@Composable
private fun EmptyPanel(message: String) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.PersonOff,
            contentDescription = null,
            tint = Color(0xFF6B7280),
            modifier = Modifier.size(44.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = message,
            color = Color(0xFF8F9CAE),
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
    }
}
