package com.example.ui.components

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.VehicleRepository
import com.example.data.VoiceAssistantManager
import com.example.model.*

@Composable
fun HomeScreen(
    repository: VehicleRepository,
    assistantManager: VoiceAssistantManager,
    modifier: Modifier = Modifier
) {
    val vehicleState by repository.vehicleState.collectAsState()
    val activeScreen by repository.activeScreen.collectAsState()
    val smartMode by repository.smartScreenMode.collectAsState()
    val isFullScreen by repository.isFullScreen.collectAsState()
    val tempNote by repository.temporaryNote.collectAsState()
    val searchQuery by repository.searchQuery.collectAsState()
    val isPlayingMusic by repository.radioManager.isPlaying.collectAsState()
    val currentStation by repository.radioManager.currentStation.collectAsState()
    val webBrowserState by repository.webBrowserState.collectAsState()

    var showProfileModal by remember { mutableStateOf(false) }
    var showVoiceOrb by remember { mutableStateOf(false) }
    var showAutoParkDialog by remember { mutableStateOf(false) }
    var showSosDialog by remember { mutableStateOf(false) }
    var sosCallError by remember { mutableStateOf<String?>(null) }
    var showRemainingKm by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val currentProfile = remember(vehicleState.activeDriverProfileId) {
        repository.driverProfiles.find { it.id == vehicleState.activeDriverProfileId }
            ?: repository.driverProfiles.first()
    }

    val isDark = repository.isDarkModeEffective(vehicleState)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(if (isDark) Color(0xFF0A0C10) else Color(0xFFF1F5F9))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Persistent Top Status Bar
            TopStatusBar(
                vehicleState = vehicleState,
                onGearSelected = { repository.setGear(it) },
                onSosClicked = { showSosDialog = true },
                onBatteryToggleRemaining = { showRemainingKm = !showRemainingKm },
                showRemainingKm = showRemainingKm,
                isDark = isDark,
                onCycleTheme = { repository.cycleThemeMode() }
            )

            // Main Content Area (Split Left Car Panel and Right Workspace)
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Left Vehicle Panel (visible unless user swiped to full screen)
                AnimatedVisibility(
                    visible = !isFullScreen,
                    enter = expandHorizontally() + fadeIn(),
                    exit = shrinkHorizontally() + fadeOut()
                ) {
                    Box(modifier = Modifier.width(360.dp).fillMaxHeight()) {
                        LeftCarCard(
                            vehicleState = vehicleState,
                            currentProfile = currentProfile,
                            currentStationName = currentStation?.name,
                            isPlayingMusic = isPlayingMusic,
                            onToggleDoor = { repository.toggleDoor(it) },
                            onToggleTrunk = { repository.toggleTrunk() },
                            onToggleHood = { repository.toggleHood() },
                            onToggleChargePort = { repository.toggleChargePort() },
                            onToggle2D3D = { repository.toggle3DView() },
                            onOpenVoiceAssistant = {
                                assistantManager.startListening()
                                showVoiceOrb = true
                            },
                            onOpenProfileSelector = { showProfileModal = true },
                            onPlayPauseMusic = { repository.radioManager.togglePlayPause() },
                            onNextMusic = { repository.radioManager.nextStation() },
                            onPrevMusic = { repository.radioManager.previousStation() },
                            onOpenMusicScreen = { repository.setActiveScreen(ActiveScreen.MUSIC) },
                            onToggle220V = { repository.toggle220V() },
                            onToggleDefrostFront = { repository.toggleDefrostFront() },
                            onToggleDefrostRear = { repository.toggleDefrostRear() },
                            onToggleMirrors = { repository.toggleMirrors() },
                            isDark = isDark,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Right Content Area (Map, Climate, Music, Apps, Settings, Visual Drive, etc.)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    // Base Map is always running in background for fast instant toggle
                    MapNavigationScreen(
                        vehicleState = vehicleState,
                        repository = repository,
                        searchQuery = searchQuery,
                        onSearchQueryChanged = { repository.setSearchQuery(it) },
                        onVoiceSearchClicked = {
                            assistantManager.startListening()
                            showVoiceOrb = true
                        },
                        onToggleFullScreen = { repository.toggleFullScreen() },
                        isFullScreen = isFullScreen,
                        isDark = isDark,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Secondary App Windows & Overlays
                    if (webBrowserState != null) {
                        InCarWebBrowserScreen(
                            title = webBrowserState!!.title,
                            initialUrl = webBrowserState!!.url,
                            onClose = { repository.closeWebBrowser() },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        when (activeScreen) {
                            ActiveScreen.MAP -> {
                                // Map is already shown
                            }
                            ActiveScreen.SETTINGS, ActiveScreen.ENERGY, ActiveScreen.OBD -> {
                                SettingsScreen(
                                    repository = repository,
                                    onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.CLIMATE -> {
                                ClimateModal(
                                    vehicleState = vehicleState,
                                    onAdjustDriverTemp = { repository.adjustDriverTemp(it) },
                                    onSetFanSpeed = { repository.setFanSpeed(it) },
                                    onToggleAC = { repository.toggleAC() },
                                    onToggleAuto = { repository.toggleAutoClimate() },
                                    onToggleRecirc = { repository.toggleRecirc() },
                                    onToggleVentFace = { repository.toggleVentFace() },
                                    onToggleVentFoot = { repository.toggleVentFoot() },
                                    onToggleDefrostFront = { repository.toggleDefrostFront() },
                                    onTogglePower = { repository.toggleClimatePower() },
                                    onCycleDriverSeatHeat = { repository.cycleDriverSeatHeat() },
                                    onCycleDriverSeatVent = { repository.cycleDriverSeatVent() },
                                    onCyclePassengerSeatHeat = { repository.cyclePassengerSeatHeat() },
                                    onCyclePassengerSeatVent = { repository.cyclePassengerSeatVent() },
                                    onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.PHONE -> {
                                PhoneScreen(
                                    repository = repository,
                                    onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.MUSIC -> {
                                MusicScreen(
                                    repository = repository,
                                    onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.APPS -> {
                                AppsScreen(
                                    onNavigate = { screen -> repository.setActiveScreen(screen) },
                                    onOpenWebBrowser = { title, url -> repository.openWebBrowser(title, url) },
                                    onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.VISUAL_DRIVE -> {
                                VisualDriveScreen(
                                    vehicleState = vehicleState,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.CAMERA -> {
                                CameraPreviewScreen(
                                    onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            ActiveScreen.AUTO_PARK -> {
                                showAutoParkDialog = true
                            }
                        }
                    }
                }
            }

            // Persistent Bottom Control Bar
            BottomControlBar(
                vehicleState = vehicleState,
                activeScreen = activeScreen,
                onScreenSelected = { screen ->
                    if (screen == ActiveScreen.AUTO_PARK) {
                        showAutoParkDialog = true
                    } else if (activeScreen == screen && screen != ActiveScreen.MAP) {
                        repository.setActiveScreen(ActiveScreen.MAP)
                    } else {
                        repository.setActiveScreen(screen)
                    }
                },
                onAdjustDriverTemp = { repository.adjustDriverTemp(it) },
                onCycleDriverSeatHeat = { repository.cycleDriverSeatHeat() },
                onCyclePassengerSeatHeat = { repository.cyclePassengerSeatHeat() },
                onToggleDefrostFront = { repository.toggleDefrostFront() },
                onToggleDefrostRear = { repository.toggleDefrostRear() },
                onToggleRecirc = { repository.toggleRecirc() },
                onAdjustVolume = { repository.setVolume(it) },
                isDark = isDark
            )
        }

        // Voice Assistant Orb Overlay (Animated floating Siri/Gemini style orb with waveforms)
        if (showVoiceOrb) {
            VoiceAssistantOrb(
                assistantManager = assistantManager,
                isDark = isDark,
                onDismiss = {
                    showVoiceOrb = false
                    assistantManager.stopListening()
                }
            )
        }

        // Profile Selector Popup
        if (showProfileModal) {
            ProfileSelectorModal(
                profiles = repository.driverProfiles,
                activeProfileId = vehicleState.activeDriverProfileId,
                onProfileSelected = { repository.selectDriverProfile(it) },
                onOpenProfileSettings = { repository.setActiveScreen(ActiveScreen.SETTINGS) },
                onDismiss = { showProfileModal = false }
            )
        }

        // Auto Park Dialog
        if (showAutoParkDialog) {
            AutoParkDialog(
                onDismiss = { showAutoParkDialog = false }
            )
        }

        // SOS Emergency Dialog — buton gerçekten 112'yi arar (sistem arayıcısı)
        if (showSosDialog) {
            AlertDialog(
                onDismissRequest = { showSosDialog = false },
                confirmButton = {
                    Button(
                        onClick = {
                            sosCallError = null
                            val canCall = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.CALL_PHONE
                            ) == PackageManager.PERMISSION_GRANTED
                            val intent = Intent(
                                if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL,
                                Uri.parse("tel:112")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            try {
                                context.startActivity(intent)
                                showSosDialog = false
                            } catch (e: ActivityNotFoundException) {
                                sosCallError = "Bu cihazda arama uygulaması bulunamadı."
                            } catch (e: SecurityException) {
                                sosCallError = "Arama izni verilmedi."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                    ) {
                        Text("112 Acil Ara", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSosDialog = false }) {
                        Text("Vazgeç", color = Color.White)
                    }
                },
                title = { Text("Acil Durum (SOS)", color = Color.White) },
                text = {
                    // Gerçek GPS konumu; fix yoksa sabit koordinat UYDURULMAZ
                    val gps = repository.telemetryHelper.telemetry.collectAsState().value
                    Text(
                        buildString {
                            append(
                                if (gps.hasGpsFix)
                                    "Konumunuz: ${"%.4f".format(gps.currentLatitude)}° K, ${"%.4f".format(gps.currentLongitude)}° D\n"
                                else
                                    "Konum alınamıyor (GPS sinyali yok).\n"
                            )
                            append("Onaylarsanız cihazın arama uygulaması ile 112 aranır.")
                            sosCallError?.let { append("\n\nHata: $it") }
                        },
                        color = Color(0xFFD1D5DB)
                    )
                },
                containerColor = Color(0xFF1E2638)
            )
        }

        // Smart Screen Mode Overlays (Pet mode, Car wash, Temp note, Clean screen)
        SmartModeOverlays(
            smartMode = smartMode,
            vehicleState = vehicleState,
            temporaryNote = tempNote,
            onNoteChange = { repository.setTemporaryNote(it) },
            onExitMode = { repository.setSmartMode(SmartScreenMode.NONE) }
        )
    }
}
