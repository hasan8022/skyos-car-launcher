package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.model.*

@Composable
fun SettingsScreen(
    repository: VehicleRepository,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vehicleState by repository.vehicleState.collectAsState()
    val telemetry by repository.obdManager.telemetry.collectAsState()
    val cellVoltages by repository.obdManager.cellVoltages.collectAsState()
    val adbConnected by repository.adbBridge.isConnected.collectAsState()
    val adbStatus by repository.adbBridge.connectionStatus.collectAsState()

    val isDark = repository.isDarkModeEffective(vehicleState)
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    val tabs = listOf(
        SettingsTabItem("Hızlı Kontroller", Icons.Default.DirectionsCar),
        SettingsTabItem("Ekran ve Tema", Icons.Default.BrightnessMedium),
        SettingsTabItem("Profiller", Icons.Default.Person),
        SettingsTabItem("Akıllı Mod", Icons.Default.Nightlight),
        SettingsTabItem("Klima", Icons.Default.Air),
        SettingsTabItem("Sürüş", Icons.Default.Speed),
        SettingsTabItem("Navigasyon", Icons.Default.Navigation),
        SettingsTabItem("Koltuklar ve Aynalar", Icons.Default.AirlineSeatReclineNormal),
        SettingsTabItem("Işıklar", Icons.Default.Highlight),
        SettingsTabItem("Kilitler", Icons.Default.Lock),
        SettingsTabItem("Şarj ve Batarya", Icons.Default.Bolt),
        SettingsTabItem("Enerji", Icons.Default.ShowChart),
        SettingsTabItem("OBD & Servis", Icons.Default.Build),
        SettingsTabItem("Yazılım", Icons.Default.SystemUpdate)
    )

    val filteredTabs = remember(searchQuery) {
        if (searchQuery.isBlank()) tabs
        else tabs.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(if (isDark) Color(0xFF0E1116) else Color(0xFFF1F5F9))
    ) {
        // Left Settings Navigation Sidebar (~240dp)
        Column(
            modifier = Modifier
                .width(230.dp)
                .fillMaxHeight()
                .background(if (isDark) Color(0xFF141820) else Color(0xFFFFFFFF))
                .padding(vertical = 12.dp, horizontal = 10.dp)
        ) {
            // Search Field
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text("Ayarlarda ara", color = if (isDark) Color(0xFF6B7280) else Color(0xFF94A3B8), fontSize = 13.sp)
                },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Ara", tint = if (isDark) Color(0xFF9CA3AF) else Color(0xFF64748B), modifier = Modifier.size(18.dp))
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = if (isDark) Color(0xFF1F2633) else Color(0xFFF1F5F9),
                    unfocusedContainerColor = if (isDark) Color(0xFF1B212D) else Color(0xFFF8FAFC),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = if (isDark) Color.White else Color(0xFF0F172A),
                    unfocusedTextColor = if (isDark) Color.White else Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredTabs.indices.toList()) { idx ->
                    val tab = filteredTabs[idx]
                    val isSelected = selectedTabIndex == idx
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) (if (isDark) Color(0xFF252E3D) else Color(0xFFE0F2FE))
                                else Color.Transparent
                            )
                            .clickable { selectedTabIndex = idx }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) Color(0xFF0284C7) else (if (isDark) Color(0xFF9CA3AF) else Color(0xFF64748B)),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = tab.title,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) (if (isDark) Color.White else Color(0xFF0284C7)) else (if (isDark) Color(0xFFD1D5DB) else Color(0xFF334155))
                        )
                    }
                }
            }
        }

        // Right Settings Content Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(20.dp)
        ) {
            // Header with Title and Close (X)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = filteredTabs.getOrNull(selectedTabIndex)?.title ?: "Ayarlar",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF0F172A)
                )

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF1F2633) else Color(0xFFE2E8F0))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Kapat",
                        tint = if (isDark) Color.White else Color(0xFF0F172A)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> QuickControlsContent(repository, vehicleState)
                    1 -> DisplayAndThemeContent(repository, vehicleState, isDark)
                    2 -> ProfilesContent(repository, vehicleState)
                    3 -> SmartModesContent(repository)
                    4 -> ClimateSettingsContent(repository, vehicleState)
                    5 -> DriveDynamicsContent(repository, vehicleState)
                    6 -> NavigationSettingsContent(repository, vehicleState)
                    7 -> SeatsAndMirrorsContent(repository, vehicleState)
                    8 -> LightsContent(repository, vehicleState)
                    9 -> LocksContent(repository, vehicleState)
                    10 -> BatteryChargingContent(repository, vehicleState)
                    11 -> EnergyAnalyticsContent(repository, vehicleState)
                    12 -> ObdServiceContent(repository, telemetry, cellVoltages, adbConnected, adbStatus)
                    13 -> SoftwareUpdateContent(repository)
                }
            }
        }
    }
}

data class SettingsTabItem(val title: String, val icon: ImageVector)

// --- SUB-CONTENTS ---

@Composable
fun QuickControlsContent(repository: VehicleRepository, state: VehicleState) {
    Column {
        Text("Sık kullanılanlar tek dokunuşta", color = Color(0xFF8F9CAE), fontSize = 13.sp)
        Spacer(modifier = Modifier.height(14.dp))

        val items = listOf(
            QuickControlCardData("Bagaj", if (state.trunk) "Açık - kapat" else "Kapalı - aç", Icons.Default.DirectionsCar, state.trunk) { repository.toggleTrunk() },
            QuickControlCardData("Ön cam buğu", if (state.ventDefrostFront) "Açık" else "Kapalı", Icons.Default.VerticalAlignTop, state.ventDefrostFront) { repository.toggleDefrostFront() },
            QuickControlCardData("Arka cam buğu", if (state.ventDefrostRear) "Açık" else "Kapalı", Icons.Default.VerticalAlignBottom, state.ventDefrostRear) { repository.toggleDefrostRear() },
            QuickControlCardData("220 V priz", if (state.outlet220V) "Açık" else "Kapalı", Icons.Default.Power, state.outlet220V) { repository.toggle220V() },
            QuickControlCardData("Evcil hayvan", "Klima açık kalır", Icons.Default.Pets, false) { repository.setSmartMode(SmartScreenMode.PET_MODE) },
            QuickControlCardData("Geçici not", "Ekranda not göster", Icons.Default.Note, false) { repository.setSmartMode(SmartScreenMode.TEMP_NOTE) },
            QuickControlCardData("Oto yıkama", "Aynalar, radar, iç hava", Icons.Default.LocalCarWash, false) { repository.setSmartMode(SmartScreenMode.CAR_WASH) },
            QuickControlCardData("Cam tavan", if (state.sunroofOpen) "Açık" else "Kapalı", Icons.Default.Window, state.sunroofOpen) { repository.toggleSunroof() },
            QuickControlCardData("Aynalar", if (state.mirrorsFolded) "Katlı" else "Açık", Icons.Default.CompareArrows, state.mirrorsFolded) { repository.toggleMirrors() }
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items) { item ->
                Box(
                    modifier = Modifier
                        .height(105.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (item.isActive) Color(0xFF0284C7).copy(alpha = 0.25f) else Color(0xFF171D27))
                        .clickable(onClick = item.onClick)
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(imageVector = item.icon, contentDescription = item.title, tint = if (item.isActive) Color(0xFF00D2FF) else Color.White, modifier = Modifier.size(24.dp))
                        Column {
                            Text(text = item.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = item.subtitle, fontSize = 11.sp, color = Color(0xFF8F9CAE))
                        }
                    }
                }
            }
        }
    }
}

data class QuickControlCardData(val title: String, val subtitle: String, val icon: ImageVector, val isActive: Boolean, val onClick: () -> Unit)

@Composable
fun DisplayAndThemeContent(
    repository: VehicleRepository,
    state: VehicleState,
    isDark: Boolean
) {
    var brightness by remember { mutableFloatStateOf(0.85f) }
    var selectedUiSize by remember { mutableIntStateOf(0) } // 0: Orta, 1: Büyük, 2: Çok Büyük
    var selectedTextSize by remember { mutableIntStateOf(0) } // 0: Klasik, 1: Büyük

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "Görünüm, renk teması, parlaklık ve arayüz boyutlandırması",
                color = if (isDark) Color(0xFF8F9CAE) else Color(0xFF64748B),
                fontSize = 13.sp
            )
        }

        // Theme Mode Selection
        item {
            Text(
                text = "Renk Teması",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF0F172A)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val themeOptions = listOf(
                    Triple(ThemeMode.DARK, "Siyah Tema", Icons.Default.DarkMode),
                    Triple(ThemeMode.LIGHT, "Beyaz Tema", Icons.Default.LightMode),
                    Triple(ThemeMode.AUTO, "Otomatik", Icons.Default.BrightnessAuto)
                )

                themeOptions.forEach { (mode, title, icon) ->
                    val isSelected = state.themeMode == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isSelected) Color(0xFF0284C7).copy(alpha = if (isDark) 0.35f else 0.2f)
                                else if (isDark) Color(0xFF171D27) else Color(0xFFFFFFFF)
                            )
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color(0xFF0284C7) else (if (isDark) Color(0xFF263248) else Color(0xFFCBD5E1)),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { repository.setThemeMode(mode) }
                            .padding(14.dp)
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = if (isSelected) Color(0xFF0284C7) else (if (isDark) Color(0xFF9CA3AF) else Color(0xFF64748B)),
                                modifier = Modifier.size(26.dp)
                            )
                            Text(
                                text = title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) (if (isDark) Color.White else Color(0xFF0284C7)) else (if (isDark) Color.White else Color(0xFF0F172A))
                            )
                            Text(
                                text = when (mode) {
                                    ThemeMode.DARK -> "Gece sürüşü ve göz konforu için derin siyahlar"
                                    ThemeMode.LIGHT -> "Güneş altında yüksek kontrastlı beyaz arayüz"
                                    ThemeMode.AUTO -> "Güneş batınca koyu, doğunca açık tema"
                                },
                                fontSize = 11.sp,
                                color = if (isDark) Color(0xFF8F9CAE) else Color(0xFF64748B)
                            )
                        }
                    }
                }
            }
        }

        // Screen Brightness Slider
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isDark) Color(0xFF171D27) else Color(0xFFFFFFFF))
                    .border(1.dp, if (isDark) Color(0xFF263248) else Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Brightness6, contentDescription = "Parlaklık", tint = Color(0xFF0284C7))
                            Text(
                                text = "Ekran Parlaklığı",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color.White else Color(0xFF0F172A)
                            )
                        }
                        Text(
                            text = "%${(brightness * 100).toInt()}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0284C7)
                        )
                    }

                    Slider(
                        value = brightness,
                        onValueChange = { brightness = it },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF0284C7),
                            activeTrackColor = Color(0xFF0284C7),
                            inactiveTrackColor = if (isDark) Color(0xFF2A3446) else Color(0xFFE2E8F0)
                        )
                    )
                }
            }
        }

        // UI & Text Scaling
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // UI Size
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isDark) Color(0xFF171D27) else Color(0xFFFFFFFF))
                        .border(1.dp, if (isDark) Color(0xFF263248) else Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Arayüz Boyutu",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Orta", "Büyük", "Çok Büyük").forEachIndexed { index, label ->
                                val sel = selectedUiSize == index
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (sel) Color(0xFF0284C7) else (if (isDark) Color(0xFF222B3D) else Color(0xFFF1F5F9)))
                                        .clickable { selectedUiSize = index }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (sel) Color.White else (if (isDark) Color(0xFF9CA3AF) else Color(0xFF475569))
                                    )
                                }
                            }
                        }
                    }
                }

                // Text Size
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isDark) Color(0xFF171D27) else Color(0xFFFFFFFF))
                        .border(1.dp, if (isDark) Color(0xFF263248) else Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Yazı Boyutu",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Klasik", "Büyük").forEachIndexed { index, label ->
                                val sel = selectedTextSize == index
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (sel) Color(0xFF0284C7) else (if (isDark) Color(0xFF222B3D) else Color(0xFFF1F5F9)))
                                        .clickable { selectedTextSize = index }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (sel) Color.White else (if (isDark) Color(0xFF9CA3AF) else Color(0xFF475569))
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Voice Assistant & Visual Effects
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isDark) Color(0xFF171D27) else Color(0xFFFFFFFF))
                    .border(1.dp, if (isDark) Color(0xFF263248) else Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Sesli Asistan Neon Dalgası ve Efektleri",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Konuşurken ve dinlerken dinamik dalga formu ve holografik halka animasyonu",
                            fontSize = 12.sp,
                            color = if (isDark) Color(0xFF8F9CAE) else Color(0xFF64748B)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0284C7).copy(alpha = 0.2f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Aktif",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0284C7)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfilesContent(repository: VehicleRepository, state: VehicleState) {
    Column {
        Text("Her sürücüye özel ayna, koltuk, sıcaklık ve sürüş ayarları", color = Color(0xFF8F9CAE), fontSize = 13.sp)
        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(repository.driverProfiles) { profile ->
                val isSelected = state.activeDriverProfileId == profile.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) Color(0xFF0284C7).copy(alpha = 0.2f) else Color(0xFF171D27))
                        .clickable { repository.selectDriverProfile(profile.id) }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(profile.avatarColorHex))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = profile.initial, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        Column {
                            Text(text = profile.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "Bağlı telefon: ${profile.connectedPhoneName} · ${profile.preferredTemp}°C", fontSize = 12.sp, color = Color(0xFF8F9CAE))
                        }
                    }

                    if (isSelected) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Aktif", tint = Color(0xFF00D2FF))
                    }
                }
            }
        }
    }
}

@Composable
fun SmartModesContent(repository: VehicleRepository) {
    Column {
        Text("Akıllı Durum ve Ekran Modları", color = Color(0xFF8F9CAE), fontSize = 13.sp)
        Spacer(modifier = Modifier.height(14.dp))

        val modes = listOf(
            Triple(SmartScreenMode.PET_MODE, "Evcil Hayvan Modu", "Klima açık kalır, ekranda mesaj ve derece gösterilir"),
            Triple(SmartScreenMode.CAR_WASH, "Oto Yıkama Modu", "Aynalar katlanır, cam tavan kapanır, park sensörü susar"),
            Triple(SmartScreenMode.CAMP_MODE, "Kamp Modu", "Klima gece boyunca açık kalır, ekran kısılır"),
            Triple(SmartScreenMode.TEMP_NOTE, "Geçici Not Modu", "Ekranda büyük iletişim notu gösterilir"),
            Triple(SmartScreenMode.SCREEN_CLEAN, "Ekran Temizleme", "Ekran kararır, dokunuşları almaz (çıkış: 3 sn basılı tut)"),
            Triple(SmartScreenMode.SLEEP_MODE, "Uyku Modu", "Ekran kararır, koltuk uyku konumuna yatar"),
            Triple(SmartScreenMode.WATCH_MODE, "İzleme Modu", "Büyük batarya yüzdesi ve şarj durumu görünür")
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(modes) { (mode, title, desc) ->
                Box(
                    modifier = Modifier
                        .height(100.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF171D27))
                        .clickable { repository.setSmartMode(mode) }
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                        Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(text = desc, fontSize = 11.sp, color = Color(0xFF8F9CAE))
                    }
                }
            }
        }
    }
}

@Composable
fun DriveDynamicsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SettingsRowWithSegmented(
            title = "Sürüş Modu",
            desc = "Aracın hızlanma ve dinamik tepkisini belirler",
            options = listOf("Normal", "Eko", "Kış", "Spor"),
            selectedIndex = when (state.driveMode) {
                DriveMode.NORMAL -> 0
                DriveMode.ECO -> 1
                DriveMode.WINTER -> 2
                DriveMode.SPORT -> 3
            },
            onSelect = {
                val mode = when (it) {
                    0 -> DriveMode.NORMAL
                    1 -> DriveMode.ECO
                    2 -> DriveMode.WINTER
                    else -> DriveMode.SPORT
                }
                repository.setDriveMode(mode)
            }
        )

        SettingsRowWithSegmented(
            title = "Direksiyon Modu",
            desc = "Direksiyon sertliğini ve yol geri bildirimini ayarlar",
            options = listOf("Konfor", "Standart", "Spor"),
            selectedIndex = when (state.steeringMode) {
                SteeringMode.COMFORT -> 0
                SteeringMode.STANDARD -> 1
                SteeringMode.SPORT -> 2
            },
            onSelect = {
                val m = when (it) { 0 -> SteeringMode.COMFORT 1 -> SteeringMode.STANDARD else -> SteeringMode.SPORT }
                repository.setSteeringMode(m)
            }
        )

        SettingsToggleRow(
            title = "Emekleme (Creep)",
            desc = "Fren bırakıldığında araç kendiliğinden yavaşça ilerler",
            checked = state.creepEnabled,
            onCheckedChange = { repository.toggleCreep() }
        )

        SettingsToggleRow(
            title = "Yokuş İniş Desteği (HDC)",
            desc = "Dik yokuşlarda hızı otomatik sınırlandırır",
            checked = state.hillDescentEnabled,
            onCheckedChange = { repository.toggleHillDescent() }
        )
    }
}

@Composable
fun NavigationSettingsContent(repository: VehicleRepository, state: VehicleState) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Harita katmanları, hız radarları ve rota filtreleri (30 FPS)",
                color = Color(0xFF8F9CAE),
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        item {
            SettingsToggleRow("Canlı Trafik", "Yollardaki yoğunluğu yeşil, turuncu, kırmızı renklerle gösterir", state.navTrafficEnabled) {
                repository.toggleNavTraffic()
            }
        }
        item {
            SettingsToggleRow("Radar ve Hız Kameraları", "EDS ve sabit hız kameralarını haritada gösterir", state.navSpeedCamerasEnabled) {
                repository.toggleNavSpeedCameras()
            }
        }
        item {
            SettingsToggleRow("Şarj İstasyonları", "Rota üstündeki ve yakındaki Trugo, Eşarj ve ZES şarj noktaları", state.navShowChargingStations) {
                repository.toggleNavChargingStations()
            }
        }
        item {
            SettingsToggleRow("Yakın Otoparklar", "Çevredeki otoparkları haritada gösterir", state.navShowParking) {
                repository.toggleNavParking()
            }
        }
        item {
            SettingsToggleRow("Ücretli Yollardan Kaçın", "Köprü ve otoyollar yerine ücretsiz alternatif güzergah çizer", state.navAvoidTolls) {
                repository.toggleNavAvoidTolls()
            }
        }
        item {
            SettingsToggleRow("Feribotlardan Kaçın", "Araba vapuru ve feribot seferlerini rota dışı bırakır", state.navAvoidFerries) {
                repository.toggleNavAvoidFerries()
            }
        }
        item {
            SettingsToggleRow("Otoyollardan Kaçın", "Otoyol yerine ana arter ve çevre yollarını tercih eder", state.navAvoidHighways) {
                repository.toggleNavAvoidHighways()
            }
        }
        item {
            SettingsToggleRow("3D Binalar ve Eğik Kamera", "Sürüş esnasında 30° perspektif açısı ve 3D binalar", state.nav3DTilt) {
                repository.toggleNav3DTilt()
            }
        }
        item {
            SettingsToggleRow("Sesli Yönlendirme", "Dönüş anonsları esnasında medya sesini otomatik kısar", state.navVoiceGuidance) {
                repository.toggleNavVoiceGuidance()
            }
        }
        item {
            SettingsToggleRow("Şerit Rehberi", "Dönüş ve kavşaklardan önce geçilmesi gereken şeridi gösterir", state.navLaneGuidance) {
                repository.toggleNavLaneGuidance()
            }
        }
        item {
            SettingsToggleRow("Hız Sınırı Uyarısı", "Yol hız sınırı aşıldığında görsel ve sesli uyarı verir", state.navSpeedLimitWarning) {
                repository.toggleNavSpeedLimitWarning()
            }
        }
        item {
            SettingsToggleRow("Trafik Işıkları", "Kavşaklardaki ışık durumunu ve bekleme süresini haritada gösterir", state.navTrafficLights) {
                repository.toggleNavTrafficLights()
            }
        }
        item {
            SettingsToggleRow("Otomatik Yakınlaştırma", "Araç hızına göre harita yakınlaştırma seviyesini ayarlar", state.navAutoZoom) {
                repository.toggleNavAutoZoom()
            }
        }
        item {
            SettingsToggleRow("Çevrimdışı Harita Ön Belleği", "İnternet kesintisi ve tüneller için harita karelerini kaydeder", state.navOfflineCache) {
                repository.toggleNavOfflineCache()
            }
        }
        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun SeatsAndMirrorsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsToggleRow("Otomatik Ayna Katlama", "Kilitlendiğinde aynaları otomatik katlar", !state.mirrorsFolded) { repository.toggleMirrors() }
        SettingsToggleRow("Kolay Giriş/Çıkış", "Araç kapanınca koltuk geri çekilir", true) {}
        SettingsToggleRow("Ayna Isıtma", "Arka cam buğuyla birlikte aynaları ısıtır", state.ventDefrostRear) { repository.toggleDefrostRear() }
    }
}

@Composable
fun LightsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsRowWithSegmented(
            title = "Far Yüksekliği",
            desc = "Yük durumuna göre far seviyesi ayarı (0 - 3)",
            options = listOf("0", "1", "2", "3"),
            selectedIndex = state.headlightHeight,
            onSelect = { repository.setHeadlightHeight(it) }
        )

        Text("Ambiyans Işığı Rengi", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
        val colors = listOf("#00D2FF", "#22C55E", "#EAB308", "#EF4444", "#EC4899", "#8B5CF6", "#FFFFFF")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            colors.forEach { hex ->
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(android.graphics.Color.parseColor(hex)))
                        .clickable { repository.setAmbientColor(hex) }
                )
            }
        }
    }
}

@Composable
fun LocksContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsToggleRow("Yaklaşınca Kilit Aç", "Anahtar yaklaştığında kilitleri otomatik açar", true) {}
        SettingsToggleRow("Uzaklaşınca Otomatik Kilitle", "Aracın yanından ayrılınca otomatik kilitler", true) {}
        SettingsToggleRow("Çocuk Güvenlik Kilidi", "Arka kapı ve cam kontrolünü kilitler", false) {}
    }
}

@Composable
fun BatteryChargingContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Şarj Sınırı: %${state.chargeLimitPercent}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Günlük kullanım için %80 önerilir. Uzun yolda %100 yapabilirsiniz.", fontSize = 12.sp, color = Color(0xFF8F9CAE))

        Slider(
            value = state.chargeLimitPercent.toFloat(),
            onValueChange = { repository.setChargeLimit(it.toInt()) },
            valueRange = 50f..100f,
            steps = 49,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color(0xFF00D2FF))
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { if (state.isCharging) repository.stopCharging() else repository.startCharging() },
                colors = ButtonDefaults.buttonColors(containerColor = if (state.isCharging) Color(0xFFEF4444) else Color(0xFF00D2FF)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (state.isCharging) "Şarjı Bitir" else "Şarjı Başlat", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}

@Composable
fun EnergyAnalyticsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${state.powerKw.toInt()} kW", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Anlık Güç", fontSize = 12.sp, color = Color(0xFF8F9CAE))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (state.avgConsumptionKwhPer100Km >= 0f) "${state.avgConsumptionKwhPer100Km} kWh" else "—",
                    fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00D2FF)
                )
                Text("Ortalama /100 km", fontSize = 12.sp, color = Color(0xFF8F9CAE))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (state.rangeKm >= 0) "${state.rangeKm} km" else "Veri Yok",
                    fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    color = if (state.rangeKm >= 0) Color(0xFF22C55E) else Color(0xFFF59E0B)
                )
                Text("Akıllı Menzil", fontSize = 12.sp, color = Color(0xFF8F9CAE))
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF141A24))
                .padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (state.avgConsumptionKwhPer100Km >= 0f)
                    "Tüketim Grafiği (ortalama: ${state.avgConsumptionKwhPer100Km} kWh/100km)"
                else
                    "Tüketim Grafiği — gerçek araç verisi bekleniyor (car_service bağlı değil)",
                color = Color(0xFF8F9CAE), fontSize = 13.sp
            )
        }
    }
}

@Composable
fun ClimateSettingsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsToggleRow("Kilidi Açınca Otomatik İklim", "Soğukta ısıtır, sıcakta soğutur", true) {}
        SettingsToggleRow("İklim Planlama", "Her sabah 08:00'de aracı 22°C'ye hazırlar", true) {}
    }
}

@Composable
fun ObdServiceContent(
    repository: VehicleRepository,
    telemetry: ObdTelemetry,
    cellVoltages: List<ObdCellData>,
    adbConnected: Boolean,
    adbStatus: String
) {
    val isUsbDebug by repository.adbBridge.isUsbDebuggingEnabled.collectAsState()
    val realTelemetry by repository.telemetryHelper.telemetry.collectAsState()
    val liveCarProps by repository.carPropertyReader.liveProperties.collectAsState()
    val carReachable by repository.carPropertyReader.carServiceReachable.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // ADB & USB Debugging Status Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF161C26))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "USB Hata Ayıklama:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (isUsbDebug) "AÇIK" else "KAPALI",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isUsbDebug) Color(0xFF22C55E) else Color(0xFFEF4444)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ADB Soketi (127.0.0.1:5555): $adbStatus",
                    fontSize = 11.sp,
                    color = if (adbConnected) Color(0xFF22C55E) else Color(0xFFF59E0B)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { repository.adbBridge.openDeveloperSettings() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Geliştirici Ayarlarını Aç", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { repository.adbBridge.start() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222938)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("5555 Portunu Yenile", color = Color.White, fontSize = 11.sp)
                }
            }
        }

        // --- Geliştirici Modu Kapısı (APK akışı: ADB açılmadan devam edilmez) ---
        val gateAdbEnabled by repository.developerModeGate.adbEnabled.collectAsState()
        val gatePassword by repository.developerModeGate.developerPassword.collectAsState()
        if (!gateAdbEnabled) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF2A1518))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    "GELİŞTİRİCİ MODU KAPALI — DEVAM EDİLEMEZ",
                    fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFFEF4444)
                )
                Text(
                    "Araç verisi (vites/hız/SoC) yalnızca ADB üzerinden okunur. Geliştirici modu açılmadan kurulum devam etmez.",
                    fontSize = 11.sp, color = Color(0xFFFCA5A5)
                )
                Text(
                    "Geliştirici Şifresi: ${gatePassword ?: "— (VIN okunamadı, ADB kapalı)"}",
                    fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B)
                )
                repository.developerModeGate.setupInstructions.forEachIndexed { i, step ->
                    Text("${i + 1}. $step", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                }
            }
        } else {
            Text(
                "Geliştirici modu aktif — ADB açık, araç verisi okunabilir.",
                fontSize = 11.sp, color = Color(0xFF22C55E)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Hardware Diagnostics Row (Real System Sensors)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF11151E))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text(
                "Ünite Gerilimi: ${if (realTelemetry.batteryVoltageMv >= 0) "${realTelemetry.batteryVoltageMv} mV" else "Veri Yok"}",
                color = Color(0xFF9CA3AF), fontSize = 11.sp
            )
            Text(
                "Ünite Sıcaklık: ${if (realTelemetry.batteryTempC >= 0f) "${realTelemetry.batteryTempC} °C" else "Veri Yok"}",
                color = Color(0xFF9CA3AF), fontSize = 11.sp
            )
            Text(
                "GPS Hızı: ${if (realTelemetry.hasGpsFix) "${realTelemetry.gpsSpeedKmh} km/sa" else "GPS Yok"}",
                color = Color(0xFF00D2FF), fontSize = 11.sp, fontWeight = FontWeight.Bold
            )
            Text("12V Akü: ${if (telemetry.isConnected && telemetry.battery12vVoltage > 0f) "${telemetry.battery12vVoltage} V" else "Bağlantı Yok"}", color = Color.White, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Cell Stats: Min, Max, Delta, Temps
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text("Min: ${if (telemetry.isConnected && telemetry.minCellMv > 0) "${telemetry.minCellMv} mV" else "—"}", color = Color.White, fontSize = 13.sp)
            Text("Maks: ${if (telemetry.isConnected && telemetry.maxCellMv > 0) "${telemetry.maxCellMv} mV" else "—"}", color = Color.White, fontSize = 13.sp)
            Text("Delta: ${if (telemetry.isConnected && telemetry.deltaCellMv >= 0) "${telemetry.deltaCellMv} mV" else "—"}", color = Color(0xFF00D2FF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("OBD Durumu: ${if (telemetry.isConnected) "Bağlı" else "Bağlı Değil"}", color = if (telemetry.isConnected) Color(0xFF22C55E) else Color(0xFF8F9CAE), fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 103 Cell Voltage Grid — yalnızca gerçek OBD oturumu varken dolar
        Text("Batarya Hücre Gerilimleri:", fontSize = 12.sp, color = Color(0xFF8F9CAE))
        Spacer(modifier = Modifier.height(6.dp))

        if (cellVoltages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF11151E)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Bağlantı Yok — OBD adaptörü (vLinker/ELM327) bağlanınca\nhücre gerilimleri burada gerçek zamanlı gösterilir.",
                    color = Color(0xFFF59E0B),
                    fontSize = 12.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(10),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(cellVoltages) { cell ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF1E2638))
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${cell.voltageMv}",
                        fontSize = 9.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- Canlı car_service Tanısı (APK'dan doğrulanmış property ID'leri) ---
        Text(
            "Araç Veri Yolu (car_service): ${if (carReachable) "BAĞLI" else "BAĞLI DEĞİL"}",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (carReachable) Color(0xFF22C55E) else Color(0xFFEF4444)
        )
        Text(
            if (carReachable)
                "ID anlamları APK'dan doğrulandı; doğrulananlar etiketli, çözülemeyen 4 ID ham olarak gösterilir. Göstergeye yalnızca doğrulanmış değerler yansır."
            else
                "ADB bağlı değil veya car_service yanıt vermiyor. Vites/hız/SoC gibi kritik veriler tahmin edilmez.",
            fontSize = 11.sp,
            color = Color(0xFF8F9CAE)
        )
        if (liveCarProps.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF11151E))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                liveCarProps.values.sortedBy { it.idHex }.forEach { prop ->
                    val label = com.example.data.CarPropertyReader.labelFor(prop.idHex)
                    Text(
                        if (label != null)
                            "$label [${prop.idHex}] → float=${prop.floatValues} int=${prop.intValues}"
                        else
                            "ANLAMI BİLİNMİYOR (ham) [${prop.idHex}] → float=${prop.floatValues} int=${prop.intValues}",
                        fontSize = 10.sp,
                        color = if (label != null) Color(0xFF38BDF8) else Color(0xFFF59E0B)
                    )
                }
            }
        }
    }
}

@Composable
fun SoftwareUpdateContent(repository: VehicleRepository) {
    var launcherError by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SkyOS Sürümü: 2026.44.2", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        // Sahte "guncelleme kontrolu" butonu YOK — gercek OTA sunucusu olmadan
        // buton koymak ve basinca bir sey oluyormus gibi yapmak kullaniciyi yaniltir.
        Text(
            "OTA güncelleme sunucusu bu sürümde bulunmuyor. Yeni APK yayınlandığında GitHub üzerinden manuel güncelleme yapılır.",
            fontSize = 13.sp,
            color = Color(0xFF8F9CAE)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // --- Orijinal launcher'a donus ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF161C26))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Ana Ekran (Launcher)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "SkyOS'u ana ekran yapmak için sistem ayarlarından varsayılan başlatıcıyı seçin. Aracın orijinal ekranına dönmek için aşağıdaki düğmeyi kullanın.",
                color = Color(0xFF8F9CAE),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
            Button(
                onClick = { launcherError = repository.openOriginalLauncher() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Orijinal Launcher'a Dön", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            launcherError?.let {
                Text(it, color = Color(0xFFF59E0B), fontSize = 12.sp)
            }
        }
    }
}

// Helpers
@Composable
fun SettingsToggleRow(title: String, desc: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF161C26))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(desc, color = Color(0xFF8F9CAE), fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF00D2FF)
            )
        )
    }
}

@Composable
fun SettingsRowWithSegmented(
    title: String,
    desc: String,
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF161C26))
            .padding(14.dp)
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(desc, color = Color(0xFF8F9CAE), fontSize = 11.sp)
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0E121A))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            options.forEachIndexed { i, opt ->
                val isSelected = i == selectedIndex
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF00D2FF) else Color.Transparent)
                        .clickable { onSelect(i) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = opt,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else Color(0xFFD1D5DB)
                    )
                }
            }
        }
    }
}
