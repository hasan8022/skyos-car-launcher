package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.model.RadioStation

@Composable
fun MusicScreen(
    repository: VehicleRepository,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPlaying by repository.radioManager.isPlaying.collectAsState()
    val currentStation by repository.radioManager.currentStation.collectAsState()

    var selectedSource by remember { mutableStateOf("internet_radyo") }
    var selectedGenreTab by remember { mutableStateOf("Türkiye") }

    // Tür sekmeleri gerçek istasyon verisinden türetilir — içi boş sahte sekme gösterilmez
    val allStations = repository.radioManager.popularStations
    val genreTabs = buildList {
        add("Favoriler")
        add("Türkiye")
        add("Dünya")
        listOf("Pop", "Rock", "Türkü", "Arabesk", "Jazz").forEach { genre ->
            if (allStations.any { it.genre.contains(genre, ignoreCase = true) }) add(genre)
        }
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1217))
    ) {
        // Left Side Music Sources Sidebar (~200dp)
        Column(
            modifier = Modifier
                .width(200.dp)
                .fillMaxHeight()
                .background(Color(0xFF141820))
                .padding(14.dp)
        ) {
            Text("SPOTIFY", color = Color(0xFF6B7280), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            MusicSourceItem("Ana sayfa", Icons.Default.Home, selectedSource == "spotify_home") { selectedSource = "spotify_home" }
            MusicSourceItem("Ara", Icons.Default.Search, selectedSource == "spotify_search") { selectedSource = "spotify_search" }
            MusicSourceItem("Beğenilenler", Icons.Default.FavoriteBorder, selectedSource == "spotify_fav") { selectedSource = "spotify_fav" }
            MusicSourceItem("Listelerim", Icons.Default.QueueMusic, selectedSource == "spotify_playlists") { selectedSource = "spotify_playlists" }

            Spacer(modifier = Modifier.height(18.dp))

            Text("RADYO", color = Color(0xFF6B7280), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            MusicSourceItem("İnternet radyosu", Icons.Default.Radio, selectedSource == "internet_radyo") { selectedSource = "internet_radyo" }
            MusicSourceItem("FM radyo", Icons.Default.Sensors, selectedSource == "fm_radyo") { selectedSource = "fm_radyo" }
            MusicSourceItem("USB Müzik", Icons.Default.Usb, selectedSource == "usb_muzik") { selectedSource = "usb_muzik" }
        }

        // Right Content Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (selectedSource) {
                        "fm_radyo" -> "FM Radyo"
                        "usb_muzik" -> "USB Müzik"
                        else -> "İnternet radyosu"
                    },
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E2638))
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedSource.startsWith("spotify")) {
                // Real Spotify Web Player Screen Integration
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF141822))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1DB954)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null, tint = Color.Black, modifier = Modifier.size(44.dp))
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Spotify Araç İçi Web Player", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Çalma listeleriniz, favori şarkılarınız ve podcastleriniz", color = Color(0xFF8F9CAE), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { repository.openWebBrowser("Spotify", "https://open.spotify.com") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DB954)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Spotify Web Oynatıcısını Aç", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            } else if (selectedSource == "fm_radyo") {
                // FM radyo donanımına bu uygulamadan erişilemez — sahte frekans gösterilmez
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF141822))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SensorsOff,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("FM Radyo Kullanılamıyor", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Aracın FM tuner donanımına uygulama üzerinden erişilemiyor. FM dinlemek için aracın kendi radyo uygulamasını kullanın; internet üzerinden yayın yapan gerçek istasyonlar için \"İnternet radyosu\" sekmesini açın.",
                        color = Color(0xFF8F9CAE),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { selectedSource = "internet_radyo" },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text("İnternet Radyosunu Aç", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            } else if (selectedSource == "usb_muzik") {
                // USB müzik bu sürümde desteklenmiyor — boş/uydu liste gösterilmez
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF141822))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.UsbOff,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("USB Müzik Desteklenmiyor", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "USB depolamadaki müzik dosyalarını tarama özelliği bu sürümde bulunmuyor. Spotify Web veya internet radyosu gerçek yayın kaynakları olarak kullanılabilir.",
                        color = Color(0xFF8F9CAE),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            } else {
                // Internet Radio Genre Tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    genreTabs.forEach { tab ->
                        val isSelected = selectedGenreTab == tab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) Color.White else Color(0xFF1B2230))
                                .clickable { selectedGenreTab = tab }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = tab,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.Black else Color(0xFF9CA3AF)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Station List
                // Gerçek tür filtreleme — eşleşmeyen sekmede tüm liste gösterilmez
                val stations = allStations.filter {
                    when (selectedGenreTab) {
                        "Favoriler" -> it.isFavorite
                        "Dünya" -> !it.isDomestic
                        "Türkiye" -> it.isDomestic
                        else -> it.genre.contains(selectedGenreTab, ignoreCase = true)
                    }
                }

                if (stations.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Bu türde kayıtlı istasyon yok.",
                            color = Color(0xFF8F9CAE),
                            fontSize = 13.sp
                        )
                    }
                } else LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(stations) { station ->
                        val isCurrent = currentStation?.id == station.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isCurrent) Color(0xFF0284C7).copy(alpha = 0.25f) else Color(0xFF161C26))
                                .clickable { repository.radioManager.playStation(station) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF8B5CF6)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.Radio, contentDescription = null, tint = Color.White)
                                }

                                Column {
                                    Text(text = station.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text(text = "${station.genre} · ${station.bitrate}", fontSize = 12.sp, color = Color(0xFF8F9CAE))
                                }
                            }

                            Icon(
                                imageVector = if (station.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "Favori",
                                tint = if (station.isFavorite) Color(0xFFFBBF24) else Color(0xFF6B7280)
                            )
                        }
                    }
                }
            }

            // Player Bar at Bottom of Music Screen (matching screenshot 50)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF141822))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222938)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFF00D2FF))
                    }

                    Text(
                        text = currentStation?.name ?: "Çalmıyor",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = { repository.radioManager.previousStation() }) {
                        Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "Geri", tint = Color.White)
                    }

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .clickable { repository.radioManager.togglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat/Durdur",
                            tint = Color.Black
                        )
                    }

                    IconButton(onClick = { repository.radioManager.nextStation() }) {
                        Icon(imageVector = Icons.Default.SkipNext, contentDescription = "İleri", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun MusicSourceItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFF222938) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = if (isSelected) Color(0xFF00D2FF) else Color(0xFF8F9CAE), modifier = Modifier.size(18.dp))
        Text(text = title, fontSize = 13.sp, color = if (isSelected) Color.White else Color(0xFFD1D5DB), fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
    }
}
