package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository

/**
 * SkyOS İlk Açılış Kurulum Sihirbazı.
 *
 * Gerçek durum gösterir, sahte "hazır" mesajı vermez:
 * - Mikrofon/konum izni durumu cihazdan canlı okunur
 * - GPS fix durumu telemetriden canlı okunur
 * - Sesli asistan desteği cihazdan canlı okunur
 * - Ev/İş adresleri kullanıcının girdiği GERÇEK değerlerdir
 */
@Composable
fun SetupWizardScreen(
    repository: VehicleRepository,
    speechAvailable: Boolean,
    onDeviceRecognition: Boolean,
    onRequestPermissions: () -> Unit,
    onFinish: () -> Unit
) {
    var step by remember { mutableStateOf(0) }
    var homeAddress by remember { mutableStateOf(repository.getSavedLocationName("home_address") ?: "") }
    var workAddress by remember { mutableStateOf(repository.getSavedLocationName("work_address") ?: "") }

    val telemetry by repository.telemetryHelper.telemetry.collectAsState()

    // Canlı izin durumu (her recomposition'da cihazdan okunur)
    val context = repository.getContext()
    fun granted(p: String) = androidx.core.content.ContextCompat.checkSelfPermission(
        context, p
    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    val micGranted = granted(android.Manifest.permission.RECORD_AUDIO)
    val locGranted = granted(android.Manifest.permission.ACCESS_FINE_LOCATION)
    val btGranted = if (android.os.Build.VERSION.SDK_INT >= 31)
        granted(android.Manifest.permission.BLUETOOTH_CONNECT) && granted(android.Manifest.permission.BLUETOOTH_SCAN)
    else true
    val notifGranted = if (android.os.Build.VERSION.SDK_INT >= 33)
        granted(android.Manifest.permission.POST_NOTIFICATIONS)
    else true
    val phoneGranted = granted(android.Manifest.permission.READ_PHONE_STATE) &&
        granted(android.Manifest.permission.CALL_PHONE) &&
        granted(android.Manifest.permission.READ_CONTACTS) &&
        granted(android.Manifest.permission.READ_CALL_LOG)
    val storageGranted = granted(android.Manifest.permission.READ_EXTERNAL_STORAGE)
    val cameraGranted = granted(android.Manifest.permission.CAMERA)

    val bgColor = Color(0xFF0F141C)
    val cardColor = Color(0xFF1A2433)
    val accent = Color(0xFF00E5FF)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.72f)
                .background(cardColor, RoundedCornerShape(24.dp))
                .padding(36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "SkyOS",
                color = accent,
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "İlk Kurulum — Adım ${step + 1}/3",
                color = Color(0xFF8E9DAF),
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            when (step) {
                0 -> {
                    Text(
                        text = "SkyOS'a hoş geldiniz",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Başlamadan önce birkaç ayar yapalım:\n\n" +
                                "1. Mikrofon ve konum izinleri (sesli asistan ve navigasyon için)\n" +
                                "2. Ev ve iş adresleriniz (hızlı rota için)\n\n" +
                                "Bu bilgiler yalnızca cihazınızda saklanır.",
                        color = Color(0xFFB8C4D4),
                        fontSize = 17.sp,
                        lineHeight = 26.sp
                    )
                    Spacer(modifier = Modifier.height(28.dp))
                    Button(
                        onClick = { step = 1 },
                        colors = ButtonDefaults.buttonColors(containerColor = accent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("Kuruluma Başla", color = Color(0xFF0F141C), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }

                1 -> {
                    Text(
                        text = "İzinler",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    SetupStatusRow("Mikrofon (sesli asistan)", micGranted)
                    SetupStatusRow("Konum (GPS navigasyon)", locGranted)
                    SetupStatusRow("Bluetooth (telefon ve medya)", btGranted)
                    SetupStatusRow("Bildirimler (uyarılar)", notifGranted)
                    SetupStatusRow("Telefon, rehber ve arama kaydı", phoneGranted)
                    SetupStatusRow("Depolama (medya dosyaları)", storageGranted)
                    SetupStatusRow("Kamera (geri görüş)", cameraGranted)
                    SetupStatusRow("Sesli tanıma servisi", speechAvailable,
                        falseText = "Bu cihazda desteklenmiyor")
                    if (speechAvailable) {
                        SetupStatusRow(
                            "Cihaz üzerinde tanıma (internetsiz)",
                            onDeviceRecognition,
                            trueText = "Destekleniyor",
                            falseText = "Yok — internet gerekli"
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    val allGranted = micGranted && locGranted && btGranted && notifGranted && phoneGranted
                    if (!allGranted) {
                        Button(
                            onClick = { onRequestPermissions() },
                            colors = ButtonDefaults.buttonColors(containerColor = accent),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(56.dp)
                        ) {
                            Text("İzinleri Ver", color = Color(0xFF0F141C), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "İzinleri verdikten sonra durum otomatik güncellenir.",
                            color = Color(0xFF8E9DAF),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Text(
                            text = "Tüm izinler hazır ✓",
                            color = Color(0xFF00E676),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "İstemediğiniz izni sistem penceresinde reddedebilirsiniz; ilgili özellik çalışmaz, uygulama yine açılır.",
                            color = Color(0xFF8E9DAF),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { step = 0 }) {
                            Text("Geri", color = Color(0xFF8E9DAF), fontSize = 16.sp)
                        }
                        Button(
                            onClick = { step = 2 },
                            colors = ButtonDefaults.buttonColors(containerColor = accent),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Devam", color = Color(0xFF0F141C), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                2 -> {
                    Text(
                        text = "Ev ve İş Adresleri",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\"Eve git\" ve \"işe git\" komutları bu adresleri kullanır. Boş bırakırsanız bu komutlar çalışmaz — sahte adres kullanılmaz.",
                        color = Color(0xFF8E9DAF),
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedTextField(
                        value = homeAddress,
                        onValueChange = { homeAddress = it },
                        label = { Text("Ev adresi (ör. Mahalle, Cadde, İlçe)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accent,
                            focusedLabelColor = accent,
                            unfocusedTextColor = Color.White,
                            focusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = workAddress,
                        onValueChange = { workAddress = it },
                        label = { Text("İş adresi (opsiyonel)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accent,
                            focusedLabelColor = accent,
                            unfocusedTextColor = Color.White,
                            focusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Canlı GPS durumu
                    SetupStatusRow(
                        label = "GPS konumu",
                        ok = telemetry.hasGpsFix,
                        trueText = if (telemetry.hasGpsFix) "Aktif" else "Alınıyor…",
                        falseText = "Henüz yok (araç açık alanda birkaç saniyede bulur)"
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { step = 1 }) {
                            Text("Geri", color = Color(0xFF8E9DAF), fontSize = 16.sp)
                        }
                        Button(
                            onClick = {
                                if (homeAddress.isNotBlank()) {
                                    repository.setSavedLocationName("home_address", homeAddress.trim())
                                }
                                if (workAddress.isNotBlank()) {
                                    repository.setSavedLocationName("work_address", workAddress.trim())
                                }
                                repository.markSetupCompleted()
                                onFinish()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accent),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Kurulumu Bitir", color = Color(0xFF0F141C), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupStatusRow(
    label: String,
    ok: Boolean,
    trueText: String = "Verildi",
    falseText: String = "Verilmedi"
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color(0xFFB8C4D4), fontSize = 16.sp)
        Text(
            text = if (ok) "✓ $trueText" else "✗ $falseText",
            color = if (ok) Color(0xFF00E676) else Color(0xFFEF4444),
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
