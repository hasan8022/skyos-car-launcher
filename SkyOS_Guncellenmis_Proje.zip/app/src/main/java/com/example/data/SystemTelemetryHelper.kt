package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

data class RealSystemTelemetry(
    // -1 = henüz gerçek ölçüm alınamadı (UI "Veri Yok" gösterir) — sahte başlangıç değeri YOK
    val batteryPercent: Int = -1,
    val isCharging: Boolean = false,
    val batteryVoltageMv: Int = -1,
    val batteryTempC: Float = -1f,
    val wifiConnected: Boolean = false,
    val wifiSsid: String = "Bağlı Değil",
    val bluetoothEnabled: Boolean = false,
    val bluetoothDeviceName: String = "Bağlı Değil",
    val pairedDevices: List<String> = emptyList(),
    val isUsbDebuggingEnabled: Boolean = false,
    val isAdbPort5555Listening: Boolean = false,
    val musicVolume: Int = 5,
    val maxMusicVolume: Int = 15,
    // Konum yalnızca gerçek GPS fix'i ile dolar (hasGpsFix=false iken 0,0 = bilinmiyor)
    val currentLatitude: Double = 0.0,
    val currentLongitude: Double = 0.0,
    val gpsSpeedKmh: Int = 0,
    val hasGpsFix: Boolean = false
)

/**
 * Reads 100% genuine Android hardware and OS telemetry:
 * Real BatteryManager, ConnectivityManager, WifiManager, BluetoothAdapter,
 * AudioManager, LocationManager (GPS), and Settings.Global USB Debugging status.
 */
class SystemTelemetryHelper(private val context: Context) {

    private val _telemetry = MutableStateFlow(RealSystemTelemetry())
    val telemetry: StateFlow<RealSystemTelemetry> = _telemetry.asStateFlow()

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private var batteryReceiver: BroadcastReceiver? = null

    init {
        registerBatteryReceiver()
        updateAudioVolume()
        updateNetworkStatus()
        updateBluetoothStatus()
        updateAdbSettings()
        startLocationUpdates()
    }

    private fun registerBatteryReceiver() {
        val appContext = context.applicationContext
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                if (intent == null) return
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                // Sahte varsayilan YOK: deger okunamazsa onceki gercek deger korunur
                val prev = _telemetry.value
                val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else prev.batteryPercent
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                               status == BatteryManager.BATTERY_STATUS_FULL
                val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                val voltRaw = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, Int.MIN_VALUE)
                val temp = if (tempRaw != Int.MIN_VALUE) tempRaw / 10f else prev.batteryTempC
                val volt = if (voltRaw != Int.MIN_VALUE) voltRaw else prev.batteryVoltageMv

                _telemetry.value = _telemetry.value.copy(
                    batteryPercent = pct,
                    isCharging = charging,
                    batteryTempC = temp,
                    batteryVoltageMv = volt
                )
            }
        }
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        try {
            appContext.registerReceiver(batteryReceiver, filter)
        } catch (_: Exception) {}
    }

    fun updateNetworkStatus() {
        try {
            val connMgr = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = connMgr?.activeNetwork
            val caps = connMgr?.getNetworkCapabilities(network)
            val hasWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val hasCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

            val wifiMgr = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ssidRaw = wifiMgr?.connectionInfo?.ssid?.replace("\"", "") ?: ""
            val ssid = if (hasWifi && ssidRaw.isNotBlank() && ssidRaw != "<unknown ssid>") ssidRaw
                       else if (hasWifi) "Wi-Fi Aktif"
                       else if (hasCellular) "Hücresel Ağ (4.5G)"
                       else "Bağlı Değil"

            _telemetry.value = _telemetry.value.copy(
                wifiConnected = hasWifi || hasCellular,
                wifiSsid = ssid
            )
        } catch (e: Exception) {
            Log.e("SystemTelemetry", "Network read error: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun updateBluetoothStatus() {
        try {
            val btAdapter = BluetoothAdapter.getDefaultAdapter()
            val isEnabled = btAdapter?.isEnabled == true
            val bondedNames = if (isEnabled) {
                btAdapter?.bondedDevices?.mapNotNull { it.name } ?: emptyList()
            } else {
                emptyList()
            }
            val devName = if (bondedNames.isNotEmpty()) bondedNames.first()
                          else if (isEnabled) "Eşleşmiş cihaz yok"
                          else "Bağlı Değil"

            _telemetry.value = _telemetry.value.copy(
                bluetoothEnabled = isEnabled,
                bluetoothDeviceName = devName,
                pairedDevices = bondedNames
            )
        } catch (e: Exception) {
            Log.e("SystemTelemetry", "Bluetooth read error: ${e.message}")
        }
    }

    fun updateAdbSettings() {
        val usbDebugOn = try {
            Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.ADB_ENABLED,
                0
            ) == 1
        } catch (e: Exception) {
            false
        }
        _telemetry.value = _telemetry.value.copy(isUsbDebuggingEnabled = usbDebugOn)
    }

    suspend fun probeAdbPort5555(): Boolean = withContext(Dispatchers.IO) {
        val isListening = try {
            Socket().use { s ->
                s.connect(InetSocketAddress("127.0.0.1", 5555), 600)
                s.isConnected
            }
        } catch (e: Exception) {
            false
        }
        _telemetry.value = _telemetry.value.copy(isAdbPort5555Listening = isListening)
        isListening
    }

    fun updateAudioVolume() {
        val cur = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 5
        val max = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
        _telemetry.value = _telemetry.value.copy(musicVolume = cur, maxMusicVolume = max)
    }

    fun setSystemVolume(level: Int) {
        val max = _telemetry.value.maxMusicVolume
        val target = level.coerceIn(0, max)
        try {
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            _telemetry.value = _telemetry.value.copy(musicVolume = target)
        } catch (e: Exception) {
            Log.e("SystemTelemetry", "Volume set error: ${e.message}")
        }
    }

    /**
     * GPS güncellemelerini başlatır. Konum izni yoksa hiçbir şey yapmaz (sessiz),
     * izin verildikten sonra tekrar çağrılmalıdır (MainActivity bunu yapar).
     * İlk açılışta son bilinen GERÇEK konumla (cihazın kendi kaydı) başlar —
     * uydurma konum üretilmez.
     */
    fun startLocationUpdates() {
        val fineGranted = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val coarseGranted = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) return

        try {
            // Son bilinen gerçek konumla anında başla (varsa) — harita bekletilmez
            val lastKnown = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (lastKnown != null && !_telemetry.value.hasGpsFix) {
                _telemetry.value = _telemetry.value.copy(
                    currentLatitude = lastKnown.latitude,
                    currentLongitude = lastKnown.longitude,
                    hasGpsFix = true
                )
            }

            val listener = object : LocationListener {
                override fun onLocationChanged(loc: Location) {
                    val speed = if (loc.hasSpeed()) (loc.speed * 3.6f).toInt() else _telemetry.value.gpsSpeedKmh
                    _telemetry.value = _telemetry.value.copy(
                        currentLatitude = loc.latitude,
                        currentLongitude = loc.longitude,
                        gpsSpeedKmh = speed,
                        hasGpsFix = true
                    )
                }
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }

            if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1.0f, listener)
            } else if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 5.0f, listener)
            }
        } catch (e: Exception) {
            Log.d("SystemTelemetry", "GPS updates permission or disabled: ${e.message}")
        }
    }

    fun release() {
        val appContext = context.applicationContext
        batteryReceiver?.let {
            try {
                appContext.unregisterReceiver(it)
            } catch (_: Exception) {}
            batteryReceiver = null
        }
    }
}
