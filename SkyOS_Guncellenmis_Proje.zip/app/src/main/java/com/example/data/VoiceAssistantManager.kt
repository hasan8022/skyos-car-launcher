package com.example.data

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.model.AppLanguage
import com.example.model.Gear
import com.example.model.SmartScreenMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class VoiceAssistantManager(
    private val context: Context,
    private val repository: VehicleRepository
) : TextToSpeech.OnInitListener {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognitionAvailable = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _assistantResponse = MutableStateFlow("")
    val assistantResponse: StateFlow<String> = _assistantResponse.asStateFlow()

    // OsmAnd Core EV Voice Assistant with Turkish TTS and POI Search
    val evVoiceAssistant = com.example.osmand.voice.EVVoiceAssistantManager(
        context = context,
        routingManager = repository.evRoutingManager,
        searchEngine = repository.osmSearchEngine,
        getVehicleProfile = { repository.getVehicleEVProfile() },
        // Gerçek GPS konumu; fix yoksa (0,0) döner ve sesli rota komutu reddedilir
        getCurrentLocation = {
            val t = repository.telemetryHelper.telemetry.value
            if (t.hasGpsFix) com.example.osmand.ev.GeoPoint(t.currentLatitude, t.currentLongitude)
            else com.example.osmand.ev.GeoPoint(0.0, 0.0)
        }
    )

    init {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "TTS init error: ${e.message}")
        }

        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        try {
            isRecognitionAvailable = SpeechRecognizer.isRecognitionAvailable(context)
            if (isRecognitionAvailable) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _assistantResponse.value = "Dinliyorum, konuşun..."
                        }

                        override fun onBeginningOfSpeech() {
                            _assistantResponse.value = "Ses algılandı..."
                        }

                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {
                            _assistantResponse.value = "Komut işleniyor..."
                        }

                        override fun onError(error: Int) {
                            _isListening.value = false
                            val msg = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH -> "Ses eşleşmedi, tekrar deneyin."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Zaman aşımı, lütfen konuşun."
                                SpeechRecognizer.ERROR_AUDIO -> "Mikrofon hatası."
                                else -> "Ses algılanamadı ($error)."
                            }
                            _assistantResponse.value = msg
                        }

                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val recognizedText = matches?.firstOrNull() ?: ""
                            if (recognizedText.isNotBlank()) {
                                processVoiceCommand(recognizedText)
                            } else {
                                _isListening.value = false
                                _assistantResponse.value = "Komut algılanamadı."
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                            if (!partial.isNullOrBlank()) {
                                _lastSpokenText.value = partial
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "SpeechRecognizer init error: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            updateTtsLanguage(repository.i18nManager.getLanguage())
        }
    }

    fun updateTtsLanguage(language: AppLanguage) {
        if (!isTtsReady) return
        val loc = when (language) {
            AppLanguage.TR -> Locale("tr", "TR")
            AppLanguage.EN -> Locale.ENGLISH
            AppLanguage.DE -> Locale.GERMAN
            AppLanguage.ES -> Locale("es", "ES")
            AppLanguage.RU -> Locale("ru", "RU")
        }
        tts?.language = loc
    }

    fun speak(text: String) {
        _assistantResponse.value = text
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SKYOS_TTS")
        }
    }

    /** Cihazda sesli tanıma servisi gerçekten mevcut mu (UI rozeti için). */
    fun isRecognitionSupported(): Boolean = isRecognitionAvailable

    /**
     * Android API 31+ SpeechRecognizer.onDevice bayrağı.
     * Cihaz tanımayı kendi üzerinde yapıyorsa internet gerektirmez; head unit'lerde
     * Google servisi olmadan da çalışır. UI'da dürüstçe gösterilir.
     */
    fun isOnDeviceRecognition(): Boolean = try {
        isRecognitionAvailable &&
            android.os.Build.VERSION.SDK_INT >= 31 &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    } catch (_: Exception) { false }

    fun startListening() {
        // Mikrofon izni gerçekten verilmiş mi? Verilmediyse sahte "dinliyorum" gösterme.
        val micGranted = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!micGranted) {
            _isListening.value = false
            speak("Mikrofon izni verilmemiş. Lütfen kurulum ekranından mikrofon iznini verin.")
            return
        }
        if (!isRecognitionAvailable || speechRecognizer == null) {
            _isListening.value = false
            speak("Bu cihazda sesli tanıma servisi bulunamadı. Sesli asistan desteklenmiyor.")
            return
        }

        _isListening.value = true
        _lastSpokenText.value = ""
        _assistantResponse.value = "Dinliyorum..."

        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            _assistantResponse.value = "Dinleme başlatılamadı."
            Log.e("VoiceAssistant", "startListening error: ${e.message}")
        }
    }

    fun stopListening() {
        _isListening.value = false
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
    }

    /**
     * Executes single or compound commands, e.g.:
     * "Klimayı 22 yap, perdeyi aç, eve git"
     */
    fun processVoiceCommand(commandText: String) {
        _isListening.value = false
        _lastSpokenText.value = commandText
        val subCommands = commandText.split(",", " ve ", " and ", " und ", " y ", " и ").map { it.trim() }
        val responses = mutableListOf<String>()

        scope.launch {
            for (sub in subCommands) {
                if (sub.isNotEmpty()) {
                    val resp = executeSingleCommand(sub.lowercase(Locale.ROOT))
                    responses.add(resp)
                    delay(350)
                }
            }
            val finalResponse = responses.filter { it.isNotBlank() }.joinToString(". ")
            speak(if (finalResponse.isNotBlank()) finalResponse else "Komut anlaşıldı.")
        }
    }

    /**
     * SkyOS APK sesli asistan komut isleyicisi (tr.halil.et5 F8) ile birebir ayni
     * komut seti ve ayni yanit cumleleri. Normalize APK'daki gibi yapilir:
     * lowercase(tr-TR) -> noktalama/sembol temizligi (yalniz a-zçğıöşü0-9 ve bosluk).
     */
    private fun executeSingleCommand(rawCmd: String): String {
        val cmd = rawCmd.lowercase(Locale("tr", "TR"))
            .replace(Regex("[^a-zçğıöşü0-9 ]"), "")
            .trim()
            .replace(Regex("\\s+"), " ")
        val state = repository.vehicleState.value
        val radio = repository.radioManager

        // --- Ses / Medya (APK birebir komutlar) ---
        if (cmd in setOf("duraklat", "durdur", "müziği durdur", "müziği kapat", "müzik durdur", "müzik kapat")) {
            if (radio.isPlaying.value) radio.togglePlayPause()
            return "Tamam."
        }
        if (cmd in setOf("müzik çal", "müziği aç", "müziği başlat", "devam et", "radyoyu aç")) {
            if (!radio.isPlaying.value) radio.togglePlayPause()
            return "Tamam."
        }
        if (cmd in setOf("sonraki", "sonraki şarkı", "sonraki parça", "sıradaki şarkı", "şarkıyı geç", "geç")) {
            radio.nextStation()
            return "Tamam."
        }
        if (cmd in setOf("önceki", "önceki şarkı", "önceki parça")) {
            radio.previousStation()
            return "Tamam."
        }
        if (cmd in setOf("sesi kapat", "sessize al")) {
            repository.telemetryHelper.setSystemVolume(0)
            return "Tamam."
        }
        if (cmd in setOf("sesi düşür", "sesi azalt", "sesi kıs")) {
            val cur = repository.telemetryHelper.telemetry.value.musicVolume
            repository.telemetryHelper.setSystemVolume(cur - 4)
            return "Tamam."
        }
        if (cmd in setOf("sesi artır", "sesi yükselt", "sesi aç")) {
            val cur = repository.telemetryHelper.telemetry.value.musicVolume
            repository.telemetryHelper.setSystemVolume(cur + 4)
            return "Tamam."
        }

        // --- Navigasyon (APK birebir komutlar) ---
        if (cmd in setOf("eve git", "eve gidelim", "eve dön", "eve götür", "beni eve götür", "evime git", "evime götür", "evi göster")) {
            val q = repository.getVoiceTargetQuery("home")
            repository.setSearchQuery(q)
            repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
            evVoiceAssistant.handleVoiceCommand("Beni $q'ye götür")
            return "Eve gidiyoruz."
        }
        if (cmd in setOf("işe git", "işe gidelim", "işe götür", "beni işe götür", "ofise git")) {
            val q = repository.getVoiceTargetQuery("work")
            repository.setSearchQuery(q)
            repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
            evVoiceAssistant.handleVoiceCommand("Beni $q'ye götür")
            return "İşe gidiyoruz."
        }
        if (cmd in setOf("navigasyonu kapat", "navigasyonu bitir", "navigasyonu iptal et", "rotayı iptal et", "yol tarifini iptal et")) {
            repository.evRoutingManager.clearRoute()
            return "Navigasyonu kapatıyorum."
        }
        if (cmd.contains("şarj istasyonu") || cmd == "en yakın şarj istasyonu" || cmd.contains("şarj bul")) {
            val q = repository.getVoiceTargetQuery("charger")
            repository.setSearchQuery(q)
            repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
            evVoiceAssistant.handleVoiceCommand("Beni en yakın şarj istasyonuna götür")
            return "En yakın şarj istasyonunu buluyorum."
        }
        if (cmd.startsWith("beni ") && (cmd.contains("götür") || cmd.contains("git"))) {
            repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
            evVoiceAssistant.handleVoiceCommand(cmd)
            return "Rota hesaplanıyor."
        }

        // --- Klima (APK birebir: regex ile derece yakalama, 16-32 arasi) ---
        val tempMatch = Regex("(\\d{2}(?:[.,]5)?)\\s*derece|sıcaklı\\D{0,15}(\\d{2}(?:[.,]5)?)").find(cmd)
        if (tempMatch != null) {
            val numStr = (tempMatch.groupValues[1].ifEmpty { tempMatch.groupValues[2] }).replace(',', '.')
            val target = numStr.toFloatOrNull()
            if (target != null && target in 16.0f..32.0f) {
                repository.adjustDriverTemp(target - state.driverTemp)
                if (!state.climatePower) repository.toggleClimatePower()
                return "Sıcaklığı ${numStr.replace('.', ',')} derece yapıyorum."
            }
        }
        if (cmd.contains("üşüdüm") || cmd.contains("üşüyorum") || cmd.contains("çok soğuk") || cmd.contains("sıcak yap") || cmd.contains("ısıt")) {
            repository.adjustDriverTemp(+2f)
            if (!state.climatePower) repository.toggleClimatePower()
            return "Sıcaklığı biraz artırıyorum."
        }
        if (cmd.contains("çok sıcak") || cmd.contains("terledim") || cmd.contains("serinlet") || cmd.contains("soğut")) {
            repository.adjustDriverTemp(-2f)
            if (!state.climatePower) repository.toggleClimatePower()
            return "Sıcaklığı biraz düşürüyorum."
        }
        val fanMatch = Regex("fan\\D{0,12}(\\d)").find(cmd)
        if (fanMatch != null) {
            val fan = fanMatch.groupValues[1].toIntOrNull()
            if (fan != null && fan in 0..7) {
                repository.setFanSpeed(fan)
                return "Fanı $fan yapıyorum."
            }
        }
        if (cmd.contains("klima")) {
            val wantsOff = cmd.contains("kapat") || cmd.contains("kapa")
            val wantsOn = cmd.contains("aç") || cmd.contains("çalıştır")
            if (wantsOff) {
                if (state.climatePower) repository.toggleClimatePower()
                return "Klimayı kapatıyorum."
            }
            if (wantsOn) {
                if (!state.climatePower) repository.toggleClimatePower()
                return "Klimayı açıyorum."
            }
        }
        if (cmd.contains("buğu") || cmd.contains("buğu çöz")) {
            if (cmd.contains("arka")) {
                if (!state.ventDefrostRear) repository.toggleDefrostRear()
                return "Arka cam buğu çözmeyi açıyorum."
            }
            if (!state.ventDefrostFront) repository.toggleDefrostFront()
            return "Ön cam buğu çözmeyi açıyorum."
        }
        if (cmd.contains("koltuk ısıt")) {
            val off = cmd.contains("kapat")
            if (cmd.contains("yolcu")) {
                if (off) { while (repository.vehicleState.value.passengerSeatHeat != 0) repository.cyclePassengerSeatHeat() }
                else { while (repository.vehicleState.value.passengerSeatHeat != 2) repository.cyclePassengerSeatHeat() }
            } else {
                if (off) { while (repository.vehicleState.value.driverSeatHeat != 0) repository.cycleDriverSeatHeat() }
                else { while (repository.vehicleState.value.driverSeatHeat != 2) repository.cycleDriverSeatHeat() }
            }
            return if (off) "Koltuk ısıtmayı kapatıyorum." else "Koltuk ısıtmayı açıyorum."
        }

        // --- Arac govde komutlari (APK birebir yanitlar) ---
        if (cmd.contains("tavan perdesi") || cmd.contains("perde")) {
            val off = cmd.contains("kapat")
            if (off) {
                if (state.sunshadeOpen) repository.toggleSunshade()
                return "Tavan perdesini kapatıyorum."
            }
            if (cmd.contains("aç")) {
                if (!state.sunshadeOpen) repository.toggleSunshade()
                return "Tavan perdesini açıyorum."
            }
        }
        if (cmd.contains("cam tavan") || cmd.contains("tavan")) {
            if (cmd.contains("arala") || cmd.contains("havalandır")) {
                if (!state.sunroofOpen) repository.toggleSunroof()
                return "Cam tavanı aralıyorum."
            }
            if (cmd.contains("kapat")) {
                if (state.sunroofOpen) repository.toggleSunroof()
                return "Cam tavanı kapatıyorum."
            }
            if (cmd.contains("aç")) {
                if (!state.sunroofOpen) repository.toggleSunroof()
                return "Cam tavanı açıyorum."
            }
        }
        if (cmd.contains("camı") || cmd.contains("camları") || cmd.contains("cam ")) {
            // APK gercegi: camlar ekrandan kontrol edilemiyor (arac desteklemiyor)
            return "Bu araçta camlar ekrandan kontrol edilemiyor; kapıdaki düğmeleri kullanın."
        }
        if (cmd.contains("ayna")) {
            val fold = cmd.contains("katla") || cmd.contains("kapat")
            if (fold) {
                if (!state.mirrorsFolded) repository.toggleMirrors()
                return "Aynaları katlıyorum."
            }
            if (state.mirrorsFolded) repository.toggleMirrors()
            return "Aynaları açıyorum."
        }
        if (cmd.contains("bagaj")) {
            return if (state.gear == Gear.P) {
                repository.toggleTrunk()
                "Bagajı açıyorum."
            } else {
                "Bagaj yalnızca park vitesinde açılabilir."
            }
        }
        if (cmd.contains("şarjı bitir") || cmd.contains("şarjı durdur")) {
            repository.stopCharging()
            return "Şarjı bitiriyorum."
        }
        if (cmd.contains("220") || cmd.contains("priz")) {
            repository.toggle220V()
            return "Tamam."
        }

        // --- Akilli modlar (APK birebir yanitlar) ---
        if (cmd.contains("kamp")) {
            val off = cmd.contains("kapat")
            repository.setSmartMode(if (off) SmartScreenMode.NONE else SmartScreenMode.CAMP_MODE)
            return if (off) "Kamp modunu kapatıyorum." else "Kamp modunu açıyorum."
        }
        if (cmd.contains("evcil hayvan") || cmd.contains("köpek modu")) {
            val off = cmd.contains("kapat")
            repository.setSmartMode(if (off) SmartScreenMode.NONE else SmartScreenMode.PET_MODE)
            return if (off) "Evcil hayvan modunu kapatıyorum." else "Evcil hayvan modunu açıyorum."
        }
        if (cmd.contains("oto yıkama") || cmd.contains("yıkama modu")) {
            val off = cmd.contains("kapat")
            repository.setSmartMode(if (off) SmartScreenMode.NONE else SmartScreenMode.CAR_WASH)
            return if (off) "Oto yıkama modunu kapatıyorum." else "Oto yıkama modunu açıyorum."
        }
        if (cmd.contains("ekran temizleme")) {
            repository.setSmartMode(SmartScreenMode.SCREEN_CLEAN)
            return "Ekran temizleme modunu açıyorum."
        }

        // --- Ekran acma komutlari (APK birebir yanitlar) ---
        if (cmd.contains("haritayı aç") || cmd.contains("harita aç")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
            return "Haritayı açıyorum."
        }
        if (cmd.contains("kamerayı aç") || cmd.contains("kamera aç")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.CAMERA)
            return "Kamerayı açıyorum."
        }
        if (cmd.contains("enerji")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.ENERGY)
            return "Enerji ekranını açıyorum."
        }
        if (cmd.contains("telefonu aç") || cmd.contains("telefon aç")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.PHONE)
            return "Telefonu açıyorum."
        }
        if (cmd.contains("müziği aç") || cmd.contains("müzik ekranı")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.MUSIC)
            return "Müziği açıyorum."
        }
        if (cmd.contains("uygulamaları aç") || cmd.contains("uygulamalar")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.APPS)
            return "Uygulamaları açıyorum."
        }
        if (cmd.contains("ayarları aç") || cmd.contains("ayarlar")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.SETTINGS)
            return "Ayarları açıyorum."
        }
        if (cmd.contains("klima ekranı") || cmd.contains("hızlı kontrol")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.CLIMATE)
            return "Hızlı kontrolleri açıyorum."
        }

        // --- Medya uygulamalari ---
        if (cmd.contains("youtube")) {
            repository.openWebBrowser("YouTube", "https://m.youtube.com")
            return "YouTube açılıyor."
        }
        if (cmd.contains("spotify")) {
            repository.openWebBrowser("Spotify", "https://open.spotify.com")
            return "Spotify açılıyor."
        }
        if (cmd.contains("kral")) {
            val st = radio.popularStations.find { it.name.contains("Kral", true) }
            if (st != null) radio.playStation(st)
            return "Radyoyu açıyorum."
        }
        if (cmd.contains("power")) {
            val st = radio.popularStations.find { it.name.contains("Power", true) }
            if (st != null) radio.playStation(st)
            return "Radyoyu açıyorum."
        }
        if (cmd.contains("trt")) {
            val st = radio.popularStations.find { it.name.contains("TRT", true) }
            if (st != null) radio.playStation(st)
            return "Radyoyu açıyorum."
        }
        if (cmd.contains("radyo")) {
            return "Ne dinlemek istersin?"
        }

        // --- Bilgi sorgulari (gercek telemetri) ---
        if (cmd.contains("menzil") || cmd.contains("batarya") || cmd.contains("şarj durumu") || cmd.contains("pil")) {
            if (state.batteryPercent < 0) return "Batarya verisi şu an okunamıyor."
            val chg = if (state.isCharging) ", şarj oluyor" else ""
            return "Batarya yüzde ${state.batteryPercent}$chg, kalan menzil ${state.rangeKm} kilometre."
        }
        if (cmd.contains("hızım") || cmd.contains("kaçla gidiyorum")) {
            return "Şu anki hızınız ${state.speedKmh} kilometre."
        }
        if (cmd.contains("telefon")) {
            repository.setActiveScreen(com.example.model.ActiveScreen.PHONE)
            return "Telefonu açıyorum."
        }

        // APK davranisi: anlasilmayan komutta durustce soyle, sahte "uygulandim" deme
        return "Anlaşılamadı."
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
