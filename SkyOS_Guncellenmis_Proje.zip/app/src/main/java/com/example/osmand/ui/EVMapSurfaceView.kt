package com.example.osmand.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.example.osmand.ev.EVRouteResult
import com.example.osmand.ev.GeoPoint
import com.example.osmand.ev.SlopeCategory
import com.example.osmand.safety.ActiveSafetyAlert
import com.example.osmand.tiles.OsmTileEngine
import com.example.osmand.tiles.TileCoord
import kotlin.math.*

/**
 * Automotive MapSurfaceView powered by real OpenStreetMap tile rendering
 * and OsmAnd Core EV navigation principles.
 * Features:
 * 1. Real Live OpenStreetMap / CartoDB tile downloading and multi-level caching.
 * 2. 150% scaled typography and European speed limit shields.
 * 3. Asymmetric Map Padding centering the EV vehicle arrow in the right 40% screen area.
 * 4. Dynamic Day/Night rendering engine.
 * 5. Real-time slope/regen energy colored polyline.
 * 6. Interactive Touch Gestures (Pinch-to-zoom, Pan, and Recenter).
 * 7. 3D perspective tilt and dynamic layer toggles (Traffic, Radars, Charging, Parking).
 */
class EVMapSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback, Runnable {

    // Real OpenStreetMap Tile Engine
    private val tileEngine = OsmTileEngine(context)

    // Automotive 150% scaling factor for 10-15 inch center console displays
    var textScale: Float = 1.5f
    var symbolScale: Float = 1.5f
    var isNightMode: Boolean = true

    // Map Padding & Center Offset: Shifting vehicle arrow to right 40% zone
    var leftPaddingFraction: Float = 0.60f
    var mapPaddingLeft: Int = 0
    var mapPaddingTop: Int = 0
    var mapPaddingRight: Int = 0
    var mapPaddingBottom: Int = 0

    // Vehicle position and heading — sahte varsayılan konum YOK.
    // hasVehicleFix=false iken araç imleci çizilmez (konum uydurulmaz).
    var vehicleLatitude: Double = 0.0
    var vehicleLongitude: Double = 0.0
    var vehicleHeadingDegrees: Float = 0.0f
    var vehicleSpeedKmh: Int = 0
    var speedLimitKmh: Int = -1 // -1 = bilinmiyor
    var hasVehicleFix: Boolean = false

    // Layer toggles
    var showTraffic: Boolean = true
    var showSpeedCameras: Boolean = true
    var showChargingStations: Boolean = true
    var showParking: Boolean = true
    var tilt3D: Boolean = true
    var isHeadingUp: Boolean = true

    // Active Route and Alerts
    var activeRoute: EVRouteResult? = null
    var activeAlert: ActiveSafetyAlert? = null

    // Touch & Interactive State
    private var zoomFactor: Float = 1.0f
    private var panOffsetX: Float = 0f
    private var panOffsetY: Float = 0f
    private var lastTouchX: Float = 0f
    private var lastTouchY: Float = 0f
    private var isDragging: Boolean = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomFactor = (zoomFactor * detector.scaleFactor).coerceIn(0.5f, 3.5f)
            return true
        }
    })

    private var renderThread: Thread? = null
    @Volatile
    private var isRunning: Boolean = false

    private val surfaceHolder: SurfaceHolder = holder.apply {
        addCallback(this@EVMapSurfaceView)
    }

    // Cached Paints for 30 FPS smooth rendering
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tilePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val roadOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val trafficFlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val polylinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val speedShieldBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.RED
    }
    private val speedShieldBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val vehicleArrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#00E5FF")
    }
    private val vehicleHaloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#4000E5FF")
        strokeWidth = 6f
    }
    private val building3dPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val building3dRoofPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private var animPulse = 0f
    private var animDirection = 1

    override fun surfaceCreated(holder: SurfaceHolder) {
        isRunning = false
        renderThread?.interrupt()
        try { renderThread?.join(200) } catch (_: Exception) {}

        isRunning = true
        renderThread = Thread(this, "EVMapRenderThread").apply { start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        mapPaddingLeft = (width * leftPaddingFraction).toInt()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        isRunning = false
        renderThread?.interrupt()
        try {
            renderThread?.join(300)
        } catch (_: InterruptedException) {}
        renderThread = null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                isDragging = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && isDragging) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    panOffsetX += dx
                    panOffsetY += dy
                    lastTouchX = event.x
                    lastTouchY = event.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDragging = false
            }
        }
        return true
    }

    fun recenter() {
        panOffsetX = 0f
        panOffsetY = 0f
        zoomFactor = 1.0f
    }

    override fun run() {
        var lastTime = System.currentTimeMillis()
        while (isRunning) {
            val now = System.currentTimeMillis()
            val elapsed = now - lastTime
            if (elapsed < 33) {
                try {
                    Thread.sleep(33 - elapsed)
                } catch (_: InterruptedException) {
                    break
                }
            }
            lastTime = System.currentTimeMillis()

            if (!isRunning) break

            val surface = surfaceHolder.surface
            if (surface == null || !surface.isValid) {
                continue
            }

            animPulse += 0.05f * animDirection
            if (animPulse >= 1f) animDirection = -1
            if (animPulse <= 0f) animDirection = 1

            var canvas: Canvas? = null
            try {
                if (!isRunning || !surfaceHolder.surface.isValid) continue
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null && isRunning && surfaceHolder.surface.isValid) {
                    drawMapFrame(canvas)
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) {
                    try {
                        if (surfaceHolder.surface.isValid) {
                            surfaceHolder.unlockCanvasAndPost(canvas)
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private fun drawMapFrame(canvas: Canvas) {
        val width = width.toFloat()
        val height = height.toFloat()
        if (width <= 0 || height <= 0) return

        // 1. Calculate vehicle center in the right 40% area
        val vehicleCenterX = width * (1.0f - (1.0f - leftPaddingFraction) / 2.0f)
        val vehicleCenterY = height * 0.58f

        // Apply interactive pan
        val effectiveCenterX = vehicleCenterX + panOffsetX
        val effectiveCenterY = vehicleCenterY + panOffsetY

        // 2. Base Background Color
        backgroundPaint.color = if (isNightMode) Color.parseColor("#0F141C") else Color.parseColor("#EAEFF5")
        canvas.drawRect(0f, 0f, width, height, backgroundPaint)

        canvas.save()
        canvas.translate(effectiveCenterX, effectiveCenterY)
        canvas.scale(zoomFactor, zoomFactor)

        if (tilt3D) {
            canvas.skew(0.0f, -0.06f)
        }

        if (isHeadingUp) {
            canvas.rotate(-vehicleHeadingDegrees)
        }
        canvas.translate(-vehicleCenterX, -vehicleCenterY)

        // 3. Draw Real OpenStreetMap Tiles
        val drewRealTiles = drawRealOsmTiles(canvas, vehicleCenterX, vehicleCenterY)

        // 4. Sahte vektör yol/bina/trafik çizimi YOK — tile'lar yüklenene kadar
        // arka plan sade kalır, durum metni kullanıcıya aşağıda bildirilir.

        // 5. Gerçek rota geometrisi (rota yoksa hiçbir şey çizilmez)
        drawEVRoutePolyline(canvas, vehicleCenterX, vehicleCenterY)

        // 6. Gerçek veriye dayalı işaretçiler (rota hedefi, canlı şarj, canlı uyarı)
        drawMapPoiMarkers(canvas, vehicleCenterX, vehicleCenterY)

        // 7. Draw Vehicle Cursor — yalnızca GERÇEK GPS fix varken (konum uydurulmaz)
        if (hasVehicleFix) {
            drawVehicleArrow(canvas, vehicleCenterX, vehicleCenterY)
        }

        canvas.restore()

        // 8. Tile'lar henüz inmediyse dürüst durum bildirimi (sahte harita yerine)
        if (hasVehicleFix && !drewRealTiles) {
            val waitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#8E9DAF")
                textSize = 22f * textScale
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(
                "Harita yükleniyor… (internet bağlantısı gerekli)",
                width / 2f, height / 2f, waitPaint
            )
        }

        // 10. Draw 150% Scaled Speed Limit Shield (yalnızca gerçek hız limiti verisi varken)
        if (speedLimitKmh > 0) {
            drawSpeedLimitShield(canvas, effectiveCenterX, effectiveCenterY)
        }

        // 11. GPS fix yoksa kullanıcıya açık durum bildirimi
        if (!hasVehicleFix) {
            val infoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#F59E0B")
                textSize = 34f * textScale
                textAlign = Paint.Align.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            canvas.drawText(
                "GPS konumu bekleniyor…",
                width / 2f, 60f * textScale, infoPaint
            )
        }
    }

    /**
     * Downloads and draws genuine OpenStreetMap raster tiles around current vehicle GPS location.
     */
    private fun drawRealOsmTiles(canvas: Canvas, centerX: Float, centerY: Float): Boolean {
        // GPS fix yoksa (0,0) koordinatına tile indirmeyiz — sahte konum gösterilmez.
        if (!hasVehicleFix) return false

        val zoom = currentZoom()

        val n = 2.0.pow(zoom)
        val latRad = Math.toRadians(vehicleLatitude)
        val xDouble = (vehicleLongitude + 180.0) / 360.0 * n
        val yDouble = (1.0 - asinh(tan(latRad)) / Math.PI) / 2.0 * n

        val centerTileX = xDouble.toInt()
        val centerTileY = yDouble.toInt()
        val fracX = ((xDouble - centerTileX) * 256.0).toFloat()
        val fracY = ((yDouble - centerTileY) * 256.0).toFloat()

        var drawnTileCount = 0

        // Draw 5x4 tile grid covering wide screen
        for (dx in -3..3) {
            for (dy in -2..2) {
                val tileX = centerTileX + dx
                val tileY = centerTileY + dy
                val coord = TileCoord(tileX, tileY, zoom)

                val posX = centerX + (dx * 256f - fracX)
                val posY = centerY + (dy * 256f - fracY)

                val bmp = tileEngine.getCachedTile(coord, isNightMode)
                if (bmp != null && !bmp.isRecycled) {
                    val destRect = RectF(posX, posY, posX + 256f, posY + 256f)
                    canvas.drawBitmap(bmp, null, destRect, tilePaint)
                    drawnTileCount++
                } else {
                    tileEngine.loadTileAsync(coord, isNightMode) {
                        // Will be rendered in next frame of 30 FPS render loop
                    }
                }
            }
        }

        return drawnTileCount > 0
    }

    /**
     * Mevcut zoom faktorune karsilik gelen OSM tile zoom seviyesi.
     * drawRealOsmTiles ile rota/projeksiyon ayni zoom'u kullanmali.
     */
    private fun currentZoom(): Int = when {
        zoomFactor >= 1.7f -> 16
        zoomFactor <= 0.7f -> 14
        else -> 15
    }

    /**
     * Gercek enlem/boylami, arac konumuna gore ekran pikseline donusturur.
     * drawRealOsmTiles ile birebir ayni Web-Mercator matematigi kullanilir,
     * boylece rota/isaretler tile'larla hizali cizer.
     */
    private fun projectToScreen(lat: Double, lon: Double, centerX: Float, centerY: Float): Pair<Float, Float>? {
        if (!hasVehicleFix) return null
        val zoom = currentZoom()
        val n = 2.0.pow(zoom)
        val vehLatRad = Math.toRadians(vehicleLatitude)
        val vehX = (vehicleLongitude + 180.0) / 360.0 * n
        val vehY = (1.0 - asinh(tan(vehLatRad)) / Math.PI) / 2.0 * n
        val latRad = Math.toRadians(lat)
        val x = (lon + 180.0) / 360.0 * n
        val y = (1.0 - asinh(tan(latRad)) / Math.PI) / 2.0 * n
        return Pair(
            centerX + ((x - vehX) * 256.0).toFloat(),
            centerY + ((y - vehY) * 256.0).toFloat()
        )
    }

    /**
     * Aktif rotanin GERCEK geometrisini (OSRM yol koordinatlari) cizer.
     * Rota yoksa veya GPS fix yoksa hicbir sey cizilmez — uydurma cizgi yok.
     */
    private fun drawEVRoutePolyline(canvas: Canvas, centerX: Float, centerY: Float) {
        val route = activeRoute ?: return
        if (!hasVehicleFix) return
        val pts = route.pathCoordinates
        if (pts.size < 2) return

        polylinePaint.strokeWidth = 12f * symbolScale
        polylinePaint.color = Color.parseColor("#00E5FF")

        var prevX = 0f
        var prevY = 0f
        var first = true
        for (gp in pts) {
            val p = projectToScreen(gp.latitude, gp.longitude, centerX, centerY) ?: continue
            if (!first) {
                canvas.drawLine(prevX, prevY, p.first, p.second, polylinePaint)
            }
            prevX = p.first
            prevY = p.second
            first = false
        }
    }

    /**
     * Yalnizca GERCEK veriye dayali isaretciler cizer:
     * - Aktif rotanin varis noktasi (gercek canli geocode sonucu)
     * - Rota uzerindeki sarj istasyonlari (canli Overpass API verisi)
     * - Aktif guvenlik uyarisi (canli Overpass tehlike noktasi)
     * Bunlardan hicbiri yoksa haritaya uydurma isaret CIZILMEZ.
     */
    private fun drawMapPoiMarkers(canvas: Canvas, centerX: Float, centerY: Float) {
        if (!hasVehicleFix) return
        val scale = symbolScale
        val route = activeRoute

        if (route != null) {
            if (showChargingStations) {
                val chgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#00C853")
                    style = Paint.Style.FILL
                }
                textPaint.textSize = 11f * scale
                textPaint.color = Color.WHITE
                for (stop in route.requiredChargeStops) {
                    val p = projectToScreen(stop.location.latitude, stop.location.longitude, centerX, centerY) ?: continue
                    canvas.drawCircle(p.first, p.second, 16f * scale, chgPaint)
                    val label = "${stop.powerKw} kW"
                    canvas.drawText(label, p.first - textPaint.measureText(label) / 2f, p.second + 30f * scale, textPaint)
                }
            }

            // Varis noktasi (gercek hedef koordinat)
            val dest = projectToScreen(route.destinationPoint.latitude, route.destinationPoint.longitude, centerX, centerY)
            if (dest != null) {
                val destPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#D50000")
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(dest.first, dest.second, 16f * scale, destPaint)
                val dLabel = route.destinationName.take(24)
                textPaint.textSize = 12f * scale
                textPaint.color = Color.WHITE
                canvas.drawText(dLabel, dest.first - textPaint.measureText(dLabel) / 2f, dest.second - 24f * scale, textPaint)
            }
        }

        // Aktif guvenlik uyarisi (canli Overpass hazard verisi)
        val alert = activeAlert
        if (alert != null && showSpeedCameras) {
            val p = projectToScreen(alert.hazard.location.latitude, alert.hazard.location.longitude, centerX, centerY)
            if (p != null) {
                val camPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#D50000")
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(p.first, p.second, 16f * scale, camPaint)
                val cLabel = alert.hazard.type.title
                textPaint.textSize = 10f * scale
                textPaint.color = Color.WHITE
                canvas.drawText(cLabel, p.first - textPaint.measureText(cLabel) / 2f, p.second - 22f * scale, textPaint)
            }
        }
    }



    private fun drawVehicleArrow(canvas: Canvas, centerX: Float, centerY: Float) {
        val scale = symbolScale

        val haloRadius = (32f + animPulse * 14f) * scale
        vehicleHaloPaint.strokeWidth = (4f * (1f - animPulse)) * scale
        canvas.drawCircle(centerX, centerY, haloRadius, vehicleHaloPaint)

        canvas.save()
        if (!isHeadingUp) {
            canvas.rotate(vehicleHeadingDegrees, centerX, centerY)
        }

        val arrowPath = Path().apply {
            moveTo(centerX, centerY - 24f * scale)
            lineTo(centerX - 14f * scale, centerY + 18f * scale)
            lineTo(centerX, centerY + 10f * scale)
            lineTo(centerX + 14f * scale, centerY + 18f * scale)
            close()
        }
        canvas.drawPath(arrowPath, vehicleArrowPaint)

        val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawCircle(centerX, centerY, 4f * scale, innerPaint)

        canvas.restore()
    }

    /**
     * 150% scaled European automotive Speed Limit Shield badge.
     */
    private fun drawSpeedLimitShield(canvas: Canvas, centerX: Float, centerY: Float) {
        val scale = textScale
        val shieldRadius = 26f * scale
        val shieldX = centerX - 180f
        val shieldY = centerY - 180f

        speedShieldBorderPaint.strokeWidth = 6f * scale
        canvas.drawCircle(shieldX, shieldY, shieldRadius, speedShieldBgPaint)
        canvas.drawCircle(shieldX, shieldY, shieldRadius, speedShieldBorderPaint)

        textPaint.color = Color.BLACK
        textPaint.textSize = 20f * scale
        val text = speedLimitKmh.toString()
        val textWidth = textPaint.measureText(text)
        canvas.drawText(text, shieldX - textWidth / 2f, shieldY + 7f * scale, textPaint)
    }
}
