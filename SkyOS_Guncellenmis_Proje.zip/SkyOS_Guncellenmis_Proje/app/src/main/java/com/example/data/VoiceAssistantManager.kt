package com.example.data

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.model.AppLanguage
import com.example.model.Gear
import com.example.model.SmartScreenMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class VoiceAssistantManager(
    private val context: Context,
    private val repository: VehicleRepository
) : TextToSpeech.OnInitListener {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognitionAvailable = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _assistantResponse = MutableStateFlow("")
    val assistantResponse: StateFlow<String> = _assistantResponse.asStateFlow()

    // OsmAnd Core EV Voice Assistant with Turkish TTS and POI Search
    val evVoiceAssistant = com.example.osmand.voice.EVVoiceAssistantManager(
        context = context,
        routingManager = repository.evRoutingManager,
        searchEngine = repository.osmSearchEngine,
        getVehicleProfile = { repository.getVehicleEVProfile() },
        // Gerçek GPS konumu; fix yoksa (0,0) döner ve sesli rota komutu reddedilir
        getCurrentLocation = {
            val t = repository.telemetryHelper.telemetry.value
            if (t.hasGpsFix) com.example.osmand.ev.GeoPoint(t.currentLatitude, t.currentLongitude)
            else com.example.osmand.ev.GeoPoint(0.0, 0.0)
        }
    )

    init {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "TTS init error: ${e.message}")
        }

        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        try {
            isRecognitionAvailable = SpeechRecognizer.isRecognitionAvailable(context)
            if (isRecognitionAvailable) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _assistantResponse.value = "Dinliyorum, konuşun..."
                        }

                        override fun onBeginningOfSpeech() {
                            _assistantResponse.value = "Ses algılandı..."
                        }

                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {
                            _assistantResponse.value = "Komut işleniyor..."
                        }

                        override fun onError(error: Int) {
                            _isListening.value = false
                            val msg = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH -> "Ses eşleşmedi, tekrar deneyin."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Zaman aşımı, lütfen konuşun."
                                SpeechRecognizer.ERROR_AUDIO -> "Mikrofon hatası."
                                else -> "Ses algılanamadı ($error)."
                            }
                            _assistantResponse.value = msg
                        }

                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val recognizedText = matches?.firstOrNull() ?: ""
                            if (recognizedText.isNotBlank()) {
                                processVoiceCommand(recognizedText)
                            } else {
                                _isListening.value = false
                                _assistantResponse.value = "Komut algılanamadı."
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                            if (!partial.isNullOrBlank()) {
                                _lastSpokenText.value = partial
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "SpeechRecognizer init error: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            updateTtsLanguage(repository.i18nManager.getLanguage())
        }
    }

    fun updateTtsLanguage(language: AppLanguage) {
        if (!isTtsReady) return
        val loc = when (language) {
            AppLanguage.TR -> Locale("tr", "TR")
            AppLanguage.EN -> Locale.ENGLISH
            AppLanguage.DE -> Locale.GERMAN
            AppLanguage.ES -> Locale("es", "ES")
            AppLanguage.RU -> Locale("ru", "RU")
        }
        tts?.language = loc
    }

    fun speak(text: String) {
        _assistantResponse.value = text
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SKYOS_TTS")
        }
    }

    fun startListening() {
        _isListening.value = true
        _lastSpokenText.value = ""
        _assistantResponse.value = "Dinliyorum..."

        if (speechRecognizer != null && isRecognitionAvailable) {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("VoiceAssistant", "startListening error: ${e.message}")
            }
        }
    }

    fun stopListening() {
        _isListening.value = false
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
    }

    /**
     * Executes single or compound commands, e.g.:
     * "Klimayı 22 yap, perdeyi aç, eve git"
     */
    fun processVoiceCommand(commandText: String) {
        _isListening.value = false
        _lastSpokenText.value = commandText
        val subCommands = commandText.split(",", " ve ", " and ", " und ", " y ", " и ").map { it.trim() }
        val responses = mutableListOf<String>()

        scope.launch {
            for (sub in subCommands) {
                if (sub.isNotEmpty()) {
                    val resp = executeSingleCommand(sub.lowercase(Locale.ROOT))
                    responses.add(resp)
                    delay(350)
                }
            }
            val finalResponse = responses.filter { it.isNotBlank() }.joinToString(". ")
            speak(if (finalResponse.isNotBlank()) finalResponse else "Komut anlaşıldı.")
        }
    }

    private fun executeSingleCommand(cmd: String): String {
        val state = repository.vehicleState.value
        return when {
            // Climate & Comfort
            cmd.contains("üşüdüm") || cmd.contains("ısıt") || cmd.contains("sıcak yap") -> {
                repository.adjustDriverTemp(+2f)
                repository.cycleDriverSeatHeat()
                "Sıcaklık artırıldı ve koltuk ısıtma açıldı"
            }
            cmd.contains("sıcaklığı 22") || cmd.contains("derece 22") || cmd.contains("set temp 22") -> {
                repository.adjustDriverTemp(22.0f - state.driverTemp)
                "Klima sıcaklığı 22 dereceye ayarlandı"
            }
            cmd.contains("koltuğumu ısıt") || cmd.contains("koltuk ısıtma") || cmd.contains("seat heat") -> {
                repository.cycleDriverSeatHeat()
                "Sürücü koltuk ısıtması açıldı"
            }
            cmd.contains("klimayı kapat") || cmd.contains("klima kapat") || cmd.contains("turn off ac") -> {
                repository.toggleClimatePower()
                "Klima kapatıldı"
            }
            cmd.contains("klimayı aç") || cmd.contains("klima aç") || cmd.contains("turn on ac") -> {
                if (!state.climatePower) repository.toggleClimatePower()
                "Klima açıldı"
            }
            cmd.contains("ön buğu") || cmd.contains("buğu çöz") -> {
                repository.toggleDefrostFront()
                "Ön cam buğu çözücü aktif edildi"
            }
            cmd.contains("arka buğu") -> {
                repository.toggleDefrostRear()
                "Arka cam rezistansı aktif edildi"
            }

            // Real Music & Web Media
            cmd.contains("youtube") || cmd.contains("video aç") -> {
                repository.openWebBrowser("YouTube", "https://m.youtube.com")
                "YouTube araç içi oynatıcı açılıyor"
            }
            cmd.contains("spotify") -> {
                repository.openWebBrowser("Spotify", "https://open.spotify.com")
                "Spotify müzik açılıyor"
            }
            cmd.contains("kral fm") || cmd.contains("kral") -> {
                val kral = repository.radioManager.popularStations.find { it.name.contains("Kral", true) }
                if (kral != null) repository.radioManager.playStation(kral)
                "Kral FM açılıyor"
            }
            cmd.contains("power pop") || cmd.contains("power fm") || cmd.contains("power") -> {
                val p = repository.radioManager.popularStations.find { it.name.contains("Power", true) }
                if (p != null) repository.radioManager.playStation(p)
                "Power POP çalınıyor"
            }
            cmd.contains("trt fm") || cmd.contains("trt") -> {
                val trt = repository.radioManager.popularStations.find { it.name.contains("TRT", true) }
                if (trt != null) repository.radioManager.playStation(trt)
                "TRT FM çalınıyor"
            }
            cmd.contains("müziği durdur") || cmd.contains("müzik kapat") || cmd.contains("stop music") -> {
                if (repository.radioManager.isPlaying.value) repository.radioManager.togglePlayPause()
                "Müzik durduruldu"
            }
            cmd.contains("sonraki şarkı") || cmd.contains("next track") || cmd.contains("sonraki") -> {
                repository.radioManager.nextStation()
                "Sonraki radyo istasyonuna geçildi"
            }

            // OsmAnd Core EV Real Navigation with Voice Guidance
            cmd.contains("beni ") && (cmd.contains("götür") || cmd.contains("git")) -> {
                repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
                evVoiceAssistant.handleVoiceCommand(cmd)
                "Hedefe EV rotası hazırlanıyor..."
            }
            cmd.contains("eve git") || cmd.contains("go home") || cmd.contains("ev") -> {
                repository.setSearchQuery("Ev (Kadıköy, İstanbul)")
                repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
                evVoiceAssistant.handleVoiceCommand("Beni Ev (Kadıköy, İstanbul)'a götür")
                "Eve OsmAnd EV rotası oluşturuluyor"
            }
            cmd.contains("şarj") || cmd.contains("şarj istasyonu") || cmd.contains("charger") -> {
                repository.setSearchQuery("ZES Hızlı Şarj (Sultanahmet)")
                repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
                evVoiceAssistant.handleVoiceCommand("Beni en yakın şarj istasyonuna götür")
                "En yakın şarj istasyonuna yönlendiriliyorsunuz"
            }
            cmd.contains("işe git") || cmd.contains("go to work") -> {
                repository.setSearchQuery("İş (Levent, İstanbul)")
                repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
                evVoiceAssistant.handleVoiceCommand("Beni İş (Levent, İstanbul)'e götür")
                "İş yerine rota hesaplanıyor"
            }

            // Phone
            cmd.contains("ara") || cmd.contains("call") -> {
                repository.setActiveScreen(com.example.model.ActiveScreen.PHONE)
                "Telefon araması açılıyor"
            }

            // Real Vehicle Telemetry & Hardware status
            cmd.contains("adb") || cmd.contains("hata ayıklama") -> {
                val adbOn = repository.adbBridge.isUsbDebuggingEnabled.value
                val status = if (adbOn) "açık ve 127.0.0.1:5555 soketi dinleniyor" else "kapalı, geliştirici ayarlarından açabilirsiniz"
                "USB hata ayıklama $status"
            }
            cmd.contains("menzil") || cmd.contains("range") -> {
                "Kalan menziliniz ${state.rangeKm} kilometre, gerçek batarya yüzde ${state.batteryPercent}"
            }
            cmd.contains("batarya") || cmd.contains("pil") || cmd.contains("battery") -> {
                val chg = if (state.isCharging) "ve şarj ediliyor" else ""
                "Cihaz batarya doluluk oranı yüzde ${state.batteryPercent} $chg"
            }
            cmd.contains("wifi") || cmd.contains("bağlantı") -> {
                val wifi = if (state.wifiConnected) "bağlı: ${state.wifiSsid}" else "bağlı değil"
                "Ağ durumu: Wi-Fi $wifi"
            }

            // Physical controls
            cmd.contains("perdeyi aç") || cmd.contains("perde aç") -> {
                if (!state.sunshadeOpen) repository.toggleSunshade()
                "Güneşlik perdesi açıldı"
            }
            cmd.contains("perdeyi kapat") || cmd.contains("perde kapat") -> {
                if (state.sunshadeOpen) repository.toggleSunshade()
                "Güneşlik perdesi kapatıldı"
            }
            cmd.contains("cam tavanı arala") || cmd.contains("tavanı aç") -> {
                if (!state.sunroofOpen) repository.toggleSunroof()
                "Cam tavan havalandırma konumuna getirildi"
            }
            cmd.contains("aynaları katla") || cmd.contains("ayna katla") -> {
                if (!state.mirrorsFolded) repository.toggleMirrors()
                "Aynalar katlandı"
            }
            cmd.contains("aynaları aç") || cmd.contains("ayna aç") -> {
                if (state.mirrorsFolded) repository.toggleMirrors()
                "Aynalar açıldı"
            }
            cmd.contains("220") || cmd.contains("priz") -> {
                repository.toggle220V()
                val st = if (!state.outlet220V) "açıldı" else "kapatıldı"
                "220 Volt araç içi priz $st"
            }
            cmd.contains("bagajı aç") || cmd.contains("bagaj") -> {
                if (state.gear == Gear.P) {
                    repository.toggleTrunk()
                    "Bagaj açıldı"
                } else {
                    "Güvenlik nedeniyle bagaj yalnızca Park vitesinde açılabilir"
                }
            }
            cmd.contains("kaput") -> {
                repository.toggleHood()
                "Ön kaput mandalı açıldı"
            }

            // Smart Modes
            cmd.contains("oto yıkama") || cmd.contains("yıkama modu") -> {
                repository.setSmartMode(SmartScreenMode.CAR_WASH)
                "Oto yıkama modu aktif edildi. Aynalar katlandı ve radar susturuldu"
            }
            cmd.contains("evcil hayvan") || cmd.contains("köpek modu") -> {
                repository.setSmartMode(SmartScreenMode.PET_MODE)
                "Evcil hayvan modu devrede. Klima açık tutuluyor"
            }
            cmd.contains("kamp") || cmd.contains("kamp modu") -> {
                repository.setSmartMode(SmartScreenMode.CAMP_MODE)
                "Kamp modu devrede. Kabin iklimlendirmesi korunuyor"
            }
            cmd.contains("ekran temizleme") -> {
                repository.setSmartMode(SmartScreenMode.SCREEN_CLEAN)
                "Ekran temizleme modu açıldı"
            }

            else -> "Komut uygulandı: $cmd"
        }
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
