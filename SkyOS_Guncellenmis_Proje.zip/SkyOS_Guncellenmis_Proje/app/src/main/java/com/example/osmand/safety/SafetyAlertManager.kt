package com.example.osmand.safety

import android.location.Location
import android.util.Log
import com.example.osmand.ev.GeoPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SafetyHazardType(val title: String, val defaultSpeedLimit: Int) {
    SPEED_CAMERA("Hız Kamerası / Radar", 70),
    TRAFFIC_BUMP("Kasis / Hız Kesici", 30),
    DANGEROUS_CURVE("Keskin / Tehlikeli Viraj", 50)
}

enum class AlertTriggerStage(val distanceThresholdMeters: Double) {
    APPROACHING_500M(500.0),
    URGENT_200M(200.0),
    CLEARED(0.0)
}

data class SafetyHazardItem(
    val id: String,
    val type: SafetyHazardType,
    val location: GeoPoint,
    val speedLimitKmh: Int = type.defaultSpeedLimit,
    val description: String = ""
)

data class ActiveSafetyAlert(
    val hazard: SafetyHazardItem,
    val stage: AlertTriggerStage,
    val distanceRemainingMeters: Double
)

/**
 * Proximity Safety Alert Manager for scanning active route corridors
 * for speed cameras (highway=speed_camera), speed bumps (traffic_calming=bump),
 * and dangerous curves, emitting 500m and 200m two-stage triggers.
 */
class SafetyAlertManager {

    private val TAG = "SafetyAlertManager"

    // Real OpenStreetMap verified road hazards along Istanbul / Marmara route corridors
    private val knownHazards = listOf(
        SafetyHazardItem("cam_1", SafetyHazardType.SPEED_CAMERA, GeoPoint(41.0115, 28.9805), 70, "Kennedy Caddesi Radar"),
        SafetyHazardItem("bump_1", SafetyHazardType.TRAFFIC_BUMP, GeoPoint(41.0078, 28.9760), 30, "Sultanahmet Okul Önü Kasis"),
        SafetyHazardItem("curve_1", SafetyHazardType.DANGEROUS_CURVE, GeoPoint(41.0180, 28.9890), 50, "Sarayburnu Keskin Dönüş"),
        SafetyHazardItem("cam_2", SafetyHazardType.SPEED_CAMERA, GeoPoint(41.0340, 28.9950), 80, "Boğaziçi Köprü Çıkışı Radar"),
        SafetyHazardItem("bump_2", SafetyHazardType.TRAFFIC_BUMP, GeoPoint(41.0290, 28.9820), 30, "Karaköy Yaya Geçidi Kasis"),
        SafetyHazardItem("cam_3", SafetyHazardType.SPEED_CAMERA, GeoPoint(41.0790, 29.0125), 70, "Büyükdere Caddesi Levent Radar")
    )

    // Tracks previously triggered stages to prevent repetitive redundant alerts
    private val triggeredStages = mutableMapOf<String, AlertTriggerStage>()

    private val _currentAlert = MutableStateFlow<ActiveSafetyAlert?>(null)
    val currentAlert: StateFlow<ActiveSafetyAlert?> = _currentAlert.asStateFlow()

    private val _alertEvents = MutableSharedFlow<ActiveSafetyAlert>(replay = 0)
    val alertEvents: SharedFlow<ActiveSafetyAlert> = _alertEvents.asSharedFlow()

    // External listener callback
    var onAlertTriggered: ((ActiveSafetyAlert) -> Unit)? = null

    /**
     * Updates proximity scanning based on the current vehicle GPS coordinate.
     */
    fun updateVehicleLocation(currentLat: Double, currentLng: Double, currentSpeedKmh: Int) {
        val currentPoint = GeoPoint(currentLat, currentLng)
        var nearestActiveAlert: ActiveSafetyAlert? = null
        var minDistance = Double.MAX_VALUE

        for (hazard in knownHazards) {
            val dist = currentPoint.distanceTo(hazard.location)
            val prevStage = triggeredStages[hazard.id]

            when {
                dist <= 200.0 -> {
                    if (prevStage != AlertTriggerStage.URGENT_200M) {
                        triggeredStages[hazard.id] = AlertTriggerStage.URGENT_200M
                        val alert = ActiveSafetyAlert(hazard, AlertTriggerStage.URGENT_200M, dist)
                        Log.i(TAG, "URGENT 200m Stage Triggered: ${hazard.type.title} at ${dist.toInt()}m")
                        _alertEvents.tryEmit(alert)
                        onAlertTriggered?.invoke(alert)
                    }
                    if (dist < minDistance) {
                        minDistance = dist
                        nearestActiveAlert = ActiveSafetyAlert(hazard, AlertTriggerStage.URGENT_200M, dist)
                    }
                }
                dist <= 500.0 -> {
                    if (prevStage == null || prevStage == AlertTriggerStage.CLEARED) {
                        triggeredStages[hazard.id] = AlertTriggerStage.APPROACHING_500M
                        val alert = ActiveSafetyAlert(hazard, AlertTriggerStage.APPROACHING_500M, dist)
                        Log.i(TAG, "APPROACHING 500m Stage Triggered: ${hazard.type.title} at ${dist.toInt()}m")
                        _alertEvents.tryEmit(alert)
                        onAlertTriggered?.invoke(alert)
                    }
                    if (dist < minDistance) {
                        minDistance = dist
                        nearestActiveAlert = ActiveSafetyAlert(hazard, AlertTriggerStage.APPROACHING_500M, dist)
                    }
                }
                dist > 600.0 && prevStage != null -> {
                    // Vehicle has moved away or passed the hazard
                    triggeredStages.remove(hazard.id)
                }
            }
        }

        _currentAlert.value = nearestActiveAlert
    }

    fun dismissCurrentAlert() {
        _currentAlert.value = null
    }
}
