package com.example

import com.example.model.Gear
import com.example.model.VehicleState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun `test initial vehicle state`() {
        val state = VehicleState()
        assertEquals(Gear.P, state.gear)
        assertEquals(78, state.batteryPercent)
        assertEquals(312, state.rangeKm)
        assertFalse(state.trunk)
        assertFalse(state.hood)
    }

    @Test
    fun `test vehicle gear and safety logic`() {
        var state = VehicleState()
        assertEquals(Gear.P, state.gear)

        // Trunk opens in P
        state = state.copy(trunk = true)
        assertTrue(state.trunk)

        // Switch to D
        state = state.copy(gear = Gear.D, trunk = false)
        assertEquals(Gear.D, state.gear)
        assertFalse(state.trunk)
    }
}
