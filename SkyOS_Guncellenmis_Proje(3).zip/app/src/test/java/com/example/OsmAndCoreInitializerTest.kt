package com.example

import com.example.osmand.init.OsmAndCoreInitializer
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class OsmAndCoreInitializerTest {

    @Test
    fun testInitialStatus() {
        // OsmAndCoreInitializer should report status accurately
        assertNotNull(OsmAndCoreInitializer.status.value)
    }

    @Test
    fun testInitializationResultDataStructure() {
        val dummyDir = File("/tmp/osmand_test")
        val dummyResult = OsmAndCoreInitializer.InitializationResult(
            isSuccess = true,
            isNativeLibraryLoaded = false,
            loadedObfFiles = listOf(File(dummyDir, "test.obf")),
            mapsDirectory = dummyDir,
            status = OsmAndCoreInitializer.InitStatus.READY
        )

        assertTrue(dummyResult.isSuccess)
        assertFalse(dummyResult.isNativeLibraryLoaded)
        assertEquals(1, dummyResult.loadedObfFiles.size)
        assertEquals("test.obf", dummyResult.loadedObfFiles.first().name)
        assertEquals(OsmAndCoreInitializer.InitStatus.READY, dummyResult.status)
    }
}
