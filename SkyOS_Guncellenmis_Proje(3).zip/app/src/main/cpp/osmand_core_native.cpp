#include <jni.h>
#include <string>
#include <vector>
#include <cmath>
#include <android/log.h>

#define TAG "OsmAndCoreNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static bool s_isCoreInitialized = false;
static std::string s_mapsDirectory = "";

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_osmand_nativecore_OsmAndNativeCore_nativeInitCore(
    JNIEnv* env,
    jobject /* this */,
    jstring mapsPath
) {
    if (mapsPath != nullptr) {
        const char* pathChars = env->GetStringUTFChars(mapsPath, nullptr);
        s_mapsDirectory = std::string(pathChars);
        env->ReleaseStringUTFChars(mapsPath, pathChars);
    }
    s_isCoreInitialized = true;
    LOGI("OsmAnd Core Native initialized. Maps directory: %s", s_mapsDirectory.c_str());
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_osmand_nativecore_OsmAndNativeCore_nativeLoadMapObf(
    JNIEnv* env,
    jobject /* this */,
    jstring obfFilePath
) {
    if (!obfFilePath) return JNI_FALSE;
    const char* filePath = env->GetStringUTFChars(obfFilePath, nullptr);
    LOGI("OsmAnd Core: Registered offline OBF map file: %s", filePath);
    env->ReleaseStringUTFChars(obfFilePath, filePath);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_example_osmand_nativecore_OsmAndNativeCore_nativeCalculateSegmentSlopeEnergy(
    JNIEnv* env,
    jobject /* this */,
    jdouble distanceMeters,
    jdouble elevationStartMeters,
    jdouble elevationEndMeters,
    jdouble vehicleWeightKg,
    jdouble regenEfficiency
) {
    // Dynamic slope and gravitational potential energy calculation
    if (distanceMeters <= 0.001) return 0.0f;
    double deltaH = elevationEndMeters - elevationStartMeters;
    double slopePercent = (deltaH / distanceMeters) * 100.0;
    
    // Wh = m * g * deltaH / 3600
    const double g = 9.81;
    double potentialEnergyWh = (vehicleWeightKg * g * deltaH) / 3600.0;
    
    // Rolling resistance + aero approximation at 60 km/h: ~150 Wh/km base
    double baseWh = (distanceMeters / 1000.0) * 150.0;
    
    double netWh;
    if (potentialEnergyWh < 0.0) {
        // Downhill regenerative braking
        netWh = baseWh + (potentialEnergyWh * regenEfficiency);
    } else {
        // Uphill extra energy
        netWh = baseWh + (potentialEnergyWh / 0.90);
    }
    return static_cast<jfloat>(netWh);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_osmand_nativecore_OsmAndNativeCore_nativeIsCoreReady(
    JNIEnv* env,
    jobject /* this */
) {
    return s_isCoreInitialized ? JNI_TRUE : JNI_FALSE;
}
