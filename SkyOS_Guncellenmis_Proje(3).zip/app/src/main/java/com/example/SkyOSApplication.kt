package com.example

import android.app.Application
import android.util.Log
import com.example.osmand.init.OsmAndCoreInitializer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SkyOSApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Initializing SkyOS Automotive Application...")

        // Stable asynchronous startup sequence via OsmAndCoreInitializer singleton
        applicationScope.launch {
            val result = OsmAndCoreInitializer.initialize(this@SkyOSApplication)
            Log.i(TAG, "OsmAndCoreInitializer completed: success=${result.isSuccess}, native=${result.isNativeLibraryLoaded}, maps=${result.loadedObfFiles.size}")
        }
    }

    companion object {
        private const val TAG = "SkyOSApplication"
    }
}
