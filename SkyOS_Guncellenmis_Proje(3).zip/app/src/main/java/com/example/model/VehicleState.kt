package com.example.model

/**
 * Core models representing the Skywell ET5 / EV vehicle state and infotainment configurations.
 */
enum class Gear { P, R, N, D, S }

enum class DriveMode { NORMAL, ECO, SPORT, WINTER }

enum class SteeringMode { COMFORT, STANDARD, SPORT }

enum class BrakeMode { COMFORT, SPORT }

enum class AppLanguage(val code: String, val displayName: String) {
    TR("tr", "Türkçe"),
    EN("en", "English"),
    DE("de", "Deutsch"),
    ES("es", "Español"),
    RU("ru", "Русский")
}

enum class ThemeMode {
    DARK,
    LIGHT,
    AUTO
}

enum class SmartScreenMode {
    NONE,
    PET_MODE,
    TEMP_NOTE,
    CAR_WASH,
    CAMP_MODE,
    WATCH_MODE,
    SLEEP_MODE,
    PARTY_MODE,
    SCREEN_CLEAN
}

enum class ActiveScreen {
    MAP,
    SETTINGS,
    CLIMATE,
    PHONE,
    MUSIC,
    APPS,
    ENERGY,
    OBD,
    VISUAL_DRIVE,
    AUTO_PARK,
    CAMERA
}

data class VehicleState(
    // Transmission & Motion
    val gear: Gear = Gear.P,
    val speedKmh: Int = 0,
    val powerKw: Float = 0f, // positive: acceleration, negative: regen
    val regenPercent: Int = 20,
    val isRegenActive: Boolean = false,
    val driveMode: DriveMode = DriveMode.NORMAL,
    val steeringMode: SteeringMode = SteeringMode.STANDARD,
    val brakeMode: BrakeMode = BrakeMode.COMFORT,
    val creepEnabled: Boolean = true,
    val hillDescentEnabled: Boolean = false,

    // Battery & Energy — -1 = VERİ YOK (gerçek kaynak doğrulanana kadar gösterilmez)
    val batteryPercent: Int = -1,
    val rangeKm: Int = -1,
    val chargeLimitPercent: Int = 80,
    val isCharging: Boolean = false,
    val chargePowerKw: Float = 0f,
    val batterySoH: Float = -1f,
    val realCapacityKwh: Float = -1f,
    val avgConsumptionKwhPer100Km: Float = -1f,

    // Doors & Hatches (true = open)
    val doorFL: Boolean = false,
    val doorFR: Boolean = false,
    val doorRL: Boolean = false,
    val doorRR: Boolean = false,
    val hood: Boolean = false,
    val trunk: Boolean = false,
    val chargePort: Boolean = false,
    val sunroofOpen: Boolean = false,
    val sunshadeOpen: Boolean = false,
    val mirrorsFolded: Boolean = false,
    val outlet220V: Boolean = false,

    // Climate & Comfort
    val driverTemp: Float = 22.0f,
    val passengerTemp: Float = 22.0f,
    val fanSpeed: Int = 2, // 0..7
    val acEnabled: Boolean = true,
    val autoClimate: Boolean = true,
    val recircEnabled: Boolean = false,
    val ventFace: Boolean = true,
    val ventFoot: Boolean = false,
    val ventDefrostFront: Boolean = false,
    val ventDefrostRear: Boolean = false,
    val climatePower: Boolean = true,
    val driverSeatHeat: Int = 0, // 0..3
    val driverSeatVent: Int = 0, // 0..3
    val passengerSeatHeat: Int = 0, // 0..3
    val passengerSeatVent: Int = 0, // 0..3

    // Lights & Signals
    val leftSignal: Boolean = false,
    val rightSignal: Boolean = false,
    val hazardLights: Boolean = false,
    val brakeLights: Boolean = false,
    val headlights: Boolean = true,
    val highBeam: Boolean = false,
    val ambientColorHex: String = "#00D2FF",
    val headlightHeight: Int = 2, // 0..3

    // Temperatures — null = sensörden okunamadı
    val outsideTempC: Int? = null,
    val insideTempC: Int? = null,

    // Connectivity (gerçek cihaz durumu SystemTelemetryHelper'dan gelir)
    val wifiConnected: Boolean = false,
    val wifiSsid: String = "",
    val bluetoothConnected: Boolean = false,
    val bluetoothDeviceName: String = "",

    // Safety & ADAS
    val blindSpotWarningLeft: Boolean = false,
    val blindSpotWarningRight: Boolean = false,
    val laneDepartureWarning: Boolean = false,
    val forwardCollisionWarning: Boolean = false,
    val speedLimitKmh: Int = -1, // -1 = bilinmiyor
    val isSignalReminderActive: Boolean = false,
    val isIceWarningActive: Boolean = false,

    // Park Radar (cm) — boş liste = sensör verisi yok
    val frontRadarDistances: List<Float> = emptyList(),
    val rearRadarDistances: List<Float> = emptyList(),
    val sideRadarDistances: List<Float> = emptyList(),
    val isAutoParkSearching: Boolean = false,
    val isAutoParkReady: Boolean = false,

    // Navigation & Map Options
    val navTrafficEnabled: Boolean = true,
    val navSpeedCamerasEnabled: Boolean = true,
    val navAvoidTolls: Boolean = false,
    val navAvoidFerries: Boolean = true,
    val navAvoidHighways: Boolean = false,
    val navVoiceGuidance: Boolean = true,
    val navShowChargingStations: Boolean = true,
    val navShowParking: Boolean = true,
    val navLaneGuidance: Boolean = true,
    val nav3DTilt: Boolean = true,
    val navAutoZoom: Boolean = true,
    val navSpeedLimitWarning: Boolean = true,
    val navTrafficLights: Boolean = true,
    val navOfflineCache: Boolean = true,

    // Customization & Appearance
    val carColorHex: String = "#7BA4C7", // Sky Blue default from ET5
    val is3DView: Boolean = true,
    val volumeLevel: Int = 5,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val activeDriverProfileId: Int = 1,

    // --- Real-data availability flags (sahte veri göstermemek için) ---
    /** car_service'e ADB üzerinden en az bir gerçek okuma yapılabildi */
    val vehicleBusConnected: Boolean = false,
    /** Property ID → anlam eşlemesi araçta canlı kalibre edildi */
    val carMappingVerified: Boolean = false,
    /** Cihaz GPS'inden gerçek konum alınıyor */
    val hasGpsFix: Boolean = false,
    /** Hız GPS'ten geliyorsa true (araç veri yolu doğrulanmadıysa) */
    val speedFromGps: Boolean = false
)

data class DriverProfile(
    val id: Int,
    val name: String,
    val initial: String,
    val avatarColorHex: String,
    val preferredTemp: Float = 22.0f,
    val seatMemoryPos: Int = 1,
    val mirrorAngle: Int = 50,
    val preferredDriveMode: DriveMode = DriveMode.NORMAL,
    val screenBrightness: Float = 0.85f,
    val connectedPhoneName: String = "Telefon"
)

data class RadioStation(
    val id: String,
    val name: String,
    val genre: String,
    val bitrate: String,
    val streamUrl: String,
    val isFavorite: Boolean = false,
    val isDomestic: Boolean = true
)

data class ObdCellData(
    val cellNumber: Int,
    val voltageMv: Int,
    val temperatureC: Int
)

data class ObdTelemetry(
    // isConnected=false iken hiçbir sensör değeri gösterilmez (UI "Bağlantı Yok" der)
    val isConnected: Boolean = false,
    val deviceName: String = "",
    val isAdbConnected: Boolean = false,
    val battery12vVoltage: Float = -1f,   // -1 = okunamadı
    val motorRpm: Int = -1,
    val motorTorqueNm: Float = -1f,
    val inverterTempC: Float = -1f,
    val dcDcStatus: String = "",
    val dtcCodes: List<String> = emptyList(),
    val minCellMv: Int = -1,
    val maxCellMv: Int = -1,
    val deltaCellMv: Int = -1,
    val minTempC: Int? = null,
    val maxTempC: Int? = null,
    val tirePressureBar: List<Float> = emptyList(),
    val tireTempC: List<Int> = emptyList()
)
