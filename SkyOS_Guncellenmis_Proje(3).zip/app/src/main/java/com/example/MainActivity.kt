package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.example.data.VehicleRepository
import com.example.data.VoiceAssistantManager
import com.example.ui.components.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var repository: VehicleRepository
    private lateinit var assistantManager: VoiceAssistantManager
    private var speechRecognizer: SpeechRecognizer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Handle audio / location permissions
        if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
            setupSpeechRecognizer()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on in automotive dashboard
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()

        repository = VehicleRepository(this)
        assistantManager = VoiceAssistantManager(this, repository)

        // Check incoming intent (e.g. shared location from Google Maps: "Paylaş > SkyOS")
        handleIncomingIntent(intent)

        // Request runtime permissions gracefully
        requestRequiredPermissions()

        setContent {
            val vehicleState by repository.vehicleState.collectAsState()
            val isDark = repository.isDarkModeEffective(vehicleState)

            MyApplicationTheme(darkTheme = isDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HomeScreen(
                        repository = repository,
                        assistantManager = assistantManager
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                repository.setSearchQuery(sharedText)
                repository.setActiveScreen(com.example.model.ActiveScreen.MAP)
                assistantManager.speak("Paylaşılan konum araca aktarıldı: $sharedText")
            }
        }
    }

    private fun requestRequiredPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            setupSpeechRecognizer()
        }
    }

    private fun setupSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        assistantManager.stopListening()
                    }
                    override fun onError(error: Int) {
                        assistantManager.stopListening()
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()
                        if (!text.isNullOrBlank()) {
                            assistantManager.processVoiceCommand(text)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    /**
     * Direksiyon tuşları ve donanım tuşları (ET5 head unit).
     *
     * Bu ünitede direksiyon tuşları standart Android KeyEvent olarak gelir:
     *  - İleri/geri tuşu  → KEYCODE_MEDIA_NEXT / MEDIA_PREVIOUS
     *  - Orta/OK tuşu     → KEYCODE_MEDIA_PLAY_PAUSE veya DPAD_CENTER
     *  - Ses +/-          → KEYCODE_VOLUME_UP / DOWN
     *  - Arama cevapla    → KEYCODE_MEDIA_PLAY (uzun basışta kapatma HEADSETHOOK)
     *  - Sesli asistan    → KEYCODE_VOICE_ASSIST
     *
     * Compose tarafında özel bir tuş yakalayıcı olmadığı için Activity seviyesinde
     * merkezi olarak işliyoruz; ekran geçişleri repository üzerinden yapılır.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            when (event.keyCode) {
                // Direksiyon ileri/geri → sonraki/önceki radyo istasyonu
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    repository.radioManager.nextStation()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    repository.radioManager.previousStation()
                    return true
                }
                // Direksiyon OK → çal/duraklat
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    repository.radioManager.togglePlayPause()
                    return true
                }
                // Direksiyon sesli asistan tuşu → dinlemeyi başlat
                KeyEvent.KEYCODE_VOICE_ASSIST -> {
                    startListeningVoice()
                    return true
                }
                // DPAD merkez/enter → mevcut odaktaki eylem (Compose focus'a bırak)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    return super.dispatchKeyEvent(event) // Compose focus halletsin
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    fun startListeningVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("tr", "TR"))
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        assistantManager.release()
        repository.release()
    }
}
