package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Gear
import com.example.model.ThemeMode
import com.example.model.VehicleState

@Composable
fun TopStatusBar(
    vehicleState: VehicleState,
    onGearSelected: (Gear) -> Unit,
    onSosClicked: () -> Unit,
    onBatteryToggleRemaining: () -> Unit,
    showRemainingKm: Boolean,
    isDark: Boolean = true,
    onCycleTheme: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // Glowing pulse for S gear
    val infiniteTransition = rememberInfiniteTransition(label = "sportPulse")
    val sportGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sportAlpha"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .background(if (isDark) Color(0xFF0C0E12) else Color(0xFFE2E8F0))
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Gears: P R N D S
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val gears = listOf(Gear.P, Gear.R, Gear.N, Gear.D, Gear.S)
            gears.forEach { gear ->
                val isSelected = vehicleState.gear == gear
                val isSport = gear == Gear.S

                val gearColor = when {
                    isSelected && isSport -> Color(0xFFFF2A2A)
                    isSelected -> if (isDark) Color.White else Color(0xFF0F172A)
                    else -> if (isDark) Color(0xFF6B7280) else Color(0xFF94A3B8)
                }

                Box(
                    modifier = Modifier
                        .testTag("gear_button_${gear.name}")
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onGearSelected(gear) }
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = gear.name,
                        fontSize = 18.sp,
                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                        color = gearColor.copy(alpha = if (isSelected && isSport) sportGlowAlpha else 1f)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Temperatures — sensörden okunamadıysa "—" göster (sahte değer yok)
            Text(
                text = "Dış ${vehicleState.outsideTempC?.let { "$it°" } ?: "—"}   İç ${vehicleState.insideTempC?.let { "$it°" } ?: "—"}",
                fontSize = 13.sp,
                color = if (isDark) Color(0xFF9CA3AF) else Color(0xFF475569),
                fontWeight = FontWeight.Medium
            )
        }

        // Right side indicators: Wi-Fi, Bluetooth, Battery, Theme Switcher, SOS
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Wi-Fi Icon
            Icon(
                imageVector = if (vehicleState.wifiConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                contentDescription = "Wi-Fi",
                tint = if (vehicleState.wifiConnected) Color(0xFF0284C7) else Color(0xFF94A3B8),
                modifier = Modifier.size(17.dp)
            )

            // Bluetooth Icon
            Icon(
                imageVector = if (vehicleState.bluetoothConnected) Icons.Default.Bluetooth else Icons.Default.BluetoothDisabled,
                contentDescription = "Bluetooth",
                tint = if (vehicleState.bluetoothConnected) Color(0xFF0284C7) else Color(0xFF94A3B8),
                modifier = Modifier.size(17.dp)
            )

            // Battery % & Range toggle
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onBatteryToggleRemaining() }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = when {
                        vehicleState.batteryPercent < 0 -> Icons.Default.BatteryUnknown
                        vehicleState.isCharging -> Icons.Default.BatteryChargingFull
                        vehicleState.batteryPercent > 80 -> Icons.Default.BatteryFull
                        vehicleState.batteryPercent > 50 -> Icons.Default.Battery5Bar
                        else -> Icons.Default.Battery3Bar
                    },
                    contentDescription = "Batarya",
                    tint = if (vehicleState.batteryPercent < 0 || vehicleState.batteryPercent > 20) (if (isDark) Color.White else Color(0xFF0F172A)) else Color(0xFFEF4444),
                    modifier = Modifier.size(18.dp)
                )

                Text(
                    // Araç SoC/menzili car_service'ten doğrulanmadıysa uydurma değer gösterilmez
                    text = when {
                        vehicleState.batteryPercent < 0 -> "Veri Yok"
                        showRemainingKm && vehicleState.rangeKm >= 0 -> "${vehicleState.rangeKm} km"
                        vehicleState.rangeKm >= 0 -> "%${vehicleState.batteryPercent} - ${vehicleState.rangeKm} km"
                        else -> "%${vehicleState.batteryPercent}"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (vehicleState.batteryPercent < 0) Color(0xFFF59E0B) else if (isDark) Color.White else Color(0xFF0F172A)
                )
            }

            // Theme Switcher Button (Siyah / Beyaz / Otomatik)
            Row(
                modifier = Modifier
                    .testTag("theme_switcher_button")
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isDark) Color(0xFF1E2638) else Color(0xFFCBD5E1))
                    .clickable { onCycleTheme() }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = when (vehicleState.themeMode) {
                        ThemeMode.DARK -> Icons.Default.DarkMode
                        ThemeMode.LIGHT -> Icons.Default.LightMode
                        ThemeMode.AUTO -> Icons.Default.BrightnessAuto
                    },
                    contentDescription = "Tema Değiştir",
                    tint = when (vehicleState.themeMode) {
                        ThemeMode.DARK -> Color(0xFF38BDF8)
                        ThemeMode.LIGHT -> Color(0xFFF59E0B)
                        ThemeMode.AUTO -> Color(0xFF10B981)
                    },
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = when (vehicleState.themeMode) {
                        ThemeMode.DARK -> "Siyah"
                        ThemeMode.LIGHT -> "Beyaz"
                        ThemeMode.AUTO -> "Oto"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF0F172A)
                )
            }

            // SOS Button (Red Pill matching screenshot)
            Box(
                modifier = Modifier
                    .testTag("sos_button")
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFDC2626))
                    .clickable { onSosClicked() }
                    .padding(horizontal = 10.dp, vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SOS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
