package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary SkyOS Accents
val SkyCyan = Color(0xFF00D2FF)
val SkyBlueLight = Color(0xFF0284C7)
val SkyCyanDark = Color(0xFF0369A1)
val SkySportRed = Color(0xFFFF2A2A)
val SkyRegenGreen = Color(0xFF10B981)

// Dark Automotive Colors
val DarkBackground = Color(0xFF0A0C10)
val DarkSurface = Color(0xFF131722)
val DarkSurfaceElevated = Color(0xFF1B2232)
val DarkSurfaceHighlight = Color(0xFF263044)
val DarkBorder = Color(0xFF232D3F)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFF9CA3AF)
val DarkTextMuted = Color(0xFF6B7280)

// Light Automotive Colors (Crisp Tesla/Skywell Day Mode)
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF8FAFC)
val LightSurfaceHighlight = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF64748B)

// Status Colors
val StatusAlertRed = Color(0xFFEF4444)
val StatusWarningAmber = Color(0xFFF59E0B)
val StatusSuccessGreen = Color(0xFF10B981)
