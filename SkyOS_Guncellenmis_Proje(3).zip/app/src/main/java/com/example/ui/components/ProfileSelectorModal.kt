package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DriverProfile

@Composable
fun ProfileSelectorModal(
    profiles: List<DriverProfile>,
    activeProfileId: Int,
    onProfileSelected: (Int) -> Unit,
    onOpenProfileSettings: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomStart
    ) {
        Column(
            modifier = Modifier
                .padding(start = 16.dp, bottom = 68.dp)
                .width(320.dp)
                .clickable(enabled = false) {}
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF141820).copy(alpha = 0.98f))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "SÜRÜCÜ PROFİLİ",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF6B7280)
            )

            profiles.forEach { profile ->
                val isSelected = profile.id == activeProfileId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) Color(0xFF222B3D) else Color.Transparent)
                        .clickable {
                            onProfileSelected(profile.id)
                            onDismiss()
                        }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(profile.avatarColorHex))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = profile.initial, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Column {
                            Text(text = profile.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "${profile.preferredTemp}°C · ${profile.connectedPhoneName}", color = Color(0xFF8F9CAE), fontSize = 11.sp)
                        }
                    }

                    if (isSelected) {
                        Icon(imageVector = Icons.Default.Sync, contentDescription = "Aktif", tint = Color(0xFF00D2FF), modifier = Modifier.size(18.dp))
                    }
                }
            }

            Divider(color = Color(0xFF262E3E), thickness = 1.dp)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        onOpenProfileSettings()
                        onDismiss()
                    }
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Person, contentDescription = "Profil ayarları", tint = Color(0xFF9CA3AF), modifier = Modifier.size(18.dp))
                Text(text = "Profil ayarları", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
