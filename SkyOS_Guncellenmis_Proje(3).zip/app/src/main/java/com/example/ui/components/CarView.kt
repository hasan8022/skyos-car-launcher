package com.example.ui.components

import android.annotation.SuppressLint
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.model.VehicleState

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CarView(
    vehicleState: VehicleState,
    onToggleDoor: (String) -> Unit,
    onToggleTrunk: () -> Unit,
    onToggleHood: () -> Unit,
    onToggleChargePort: () -> Unit,
    onToggle2D3D: () -> Unit,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var is3dReady by remember { mutableStateOf(false) }

    // When vehicle state changes, sync to Three.js CAR object via Javascript
    LaunchedEffect(
        vehicleState.doorFL, vehicleState.doorFR, vehicleState.doorRL, vehicleState.doorRR,
        vehicleState.hood, vehicleState.trunk, vehicleState.chargePort,
        vehicleState.leftSignal, vehicleState.rightSignal, vehicleState.hazardLights,
        vehicleState.brakeLights, vehicleState.carColorHex, is3dReady
    ) {
        if (is3dReady && webViewRef != null) {
            val js = """
                try {
                    if (window.CAR) {
                        CAR.setColor('${vehicleState.carColorHex}');
                        CAR.state({
                            doors: [${vehicleState.doorFL}, ${vehicleState.doorFR}, ${vehicleState.doorRL}, ${vehicleState.doorRR}],
                            hood: ${vehicleState.hood},
                            trunk: ${vehicleState.trunk},
                            charge: ${vehicleState.chargePort},
                            left: ${vehicleState.leftSignal},
                            right: ${vehicleState.rightSignal},
                            hazard: ${vehicleState.hazardLights},
                            brake: ${vehicleState.brakeLights}
                        });
                    }
                } catch(e) { console.error(e); }
            """.trimIndent()
            webViewRef?.evaluateJavascript(js, null)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isDark) Color(0xFF0F1217) else Color(0xFFFFFFFF)),
        contentAlignment = Alignment.Center
    ) {
        Crossfade(targetState = vehicleState.is3DView, label = "carViewCrossfade") { is3D ->
            if (is3D) {
                // 3D Three.js Interactive WebGL Model using bundled car3d.eski.js
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(0) // transparent background
                            setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                allowFileAccess = true
                                allowContentAccess = true
                                @Suppress("DEPRECATION")
                                allowFileAccessFromFileURLs = true
                                @Suppress("DEPRECATION")
                                allowUniversalAccessFromFileURLs = true
                                databaseEnabled = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onConsoleMessage(msg: ConsoleMessage?): Boolean {
                                    Log.d("Car3D_JS", "${msg?.message()} [${msg?.sourceId()}:${msg?.lineNumber()}]")
                                    return true
                                }
                            }

                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun onPart(part: String) {
                                    when (part) {
                                        "dFL", "dFR", "dRL", "dRR" -> onToggleDoor(part)
                                        "hood" -> onToggleHood()
                                        "trunk" -> onToggleTrunk()
                                        "charge" -> onToggleChargePort()
                                    }
                                }

                                @JavascriptInterface
                                fun onLabel(type: String, x: Double, y: Double, dist: Double) {
                                    // Park sensor label callback
                                }

                                @JavascriptInterface
                                fun ready() {
                                    is3dReady = true
                                    post {
                                        evaluateJavascript("if(window.CAR) CAR.setColor('${vehicleState.carColorHex}');", null)
                                    }
                                }
                            }, "Et5")

                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    is3dReady = true
                                }
                            }

                            loadUrl("file:///android_asset/car/index.html")
                            webViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // 2D Clean Top-Down Vehicle View (Fast, light for older screens or 2D mode)
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    val resId = when {
                        vehicleState.hazardLights -> R.drawable.arac_ust_dortlu
                        vehicleState.leftSignal -> R.drawable.arac_ust_sol
                        vehicleState.rightSignal -> R.drawable.arac_ust_sag
                        vehicleState.brakeLights -> R.drawable.arac_ust_stop
                        else -> R.drawable.arac_ust
                    }

                    Image(
                        painter = painterResource(id = resId),
                        contentDescription = "Araç Üstten Görünüm",
                        modifier = Modifier
                            .fillMaxHeight(0.85f)
                            .wrapContentWidth()
                    )

                    // Door status badges overlay in 2D mode
                    if (vehicleState.trunk) {
                        StatusPill(text = "Bagaj Açık", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp))
                    }
                    if (vehicleState.hood) {
                        StatusPill(text = "Kaput Açık", modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp))
                    }
                    if (vehicleState.doorFL) {
                        StatusPill(text = "Ön Sol Kapı Açık", modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp))
                    }
                    if (vehicleState.doorFR) {
                        StatusPill(text = "Ön Sağ Kapı Açık", modifier = Modifier.align(Alignment.CenterEnd).padding(end = 12.dp))
                    }
                }
            }
        }

        // 2D / 3D Mode Toggle Switch at top right of vehicle card
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E2638).copy(alpha = 0.9f))
                .clickable { onToggle2D3D() }
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Text(
                text = if (vehicleState.is3DView) "3D Araç" else "2D Üstten",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00D2FF)
            )
        }
    }
}

@Composable
fun StatusPill(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFEF4444).copy(alpha = 0.9f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

