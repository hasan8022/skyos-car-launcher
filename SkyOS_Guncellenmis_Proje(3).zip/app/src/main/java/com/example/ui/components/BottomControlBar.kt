package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveScreen
import com.example.model.VehicleState

@Composable
fun BottomControlBar(
    vehicleState: VehicleState,
    activeScreen: ActiveScreen,
    onScreenSelected: (ActiveScreen) -> Unit,
    onAdjustDriverTemp: (Float) -> Unit,
    onCycleDriverSeatHeat: () -> Unit,
    onCyclePassengerSeatHeat: () -> Unit,
    onToggleDefrostFront: () -> Unit,
    onToggleDefrostRear: () -> Unit,
    onToggleRecirc: () -> Unit,
    onAdjustVolume: (Int) -> Unit,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(58.dp),
        color = if (isDark) Color(0xFF0E1116) else Color(0xFFFFFFFF)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Car Settings Icon
            BottomBarIconButton(
                icon = Icons.Default.DirectionsCar,
                contentDescription = "Araç Kontrolleri",
                isSelected = activeScreen == ActiveScreen.SETTINGS,
                testTag = "bottom_car_btn",
                isDark = isDark,
                onClick = { onScreenSelected(ActiveScreen.SETTINGS) }
            )

            // 2. Driver Temp (< 22,0° >)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeScreen == ActiveScreen.CLIMATE) Color(0xFF1E2638) else Color.Transparent)
                    .clickable { onScreenSelected(ActiveScreen.CLIMATE) }
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                IconButton(
                    onClick = { onAdjustDriverTemp(-0.5f) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "Sıcaklık Azalt",
                        tint = Color(0xFF9CA3AF),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = String.format(java.util.Locale.US, "%.1f°", vehicleState.driverTemp).replace(".", ","),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                IconButton(
                    onClick = { onAdjustDriverTemp(+0.5f) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Sıcaklık Artır",
                        tint = Color(0xFF9CA3AF),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // 3. Fan Speed
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onScreenSelected(ActiveScreen.CLIMATE) }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Air,
                    contentDescription = "Fan",
                    tint = if (vehicleState.climatePower) Color(0xFF38BDF8) else Color(0xFF6B7280),
                    modifier = Modifier.size(17.dp)
                )
                Text(
                    text = "${vehicleState.fanSpeed}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            // 4. Driver Seat Heating
            SeatHeatButton(
                level = vehicleState.driverSeatHeat,
                testTag = "seat_heat_driver",
                onClick = onCycleDriverSeatHeat
            )

            // 5. Apps Menu (9-dot grid)
            BottomBarIconButton(
                icon = Icons.Default.Apps,
                contentDescription = "Uygulamalar",
                isSelected = activeScreen == ActiveScreen.APPS,
                testTag = "bottom_apps_btn",
                onClick = { onScreenSelected(ActiveScreen.APPS) }
            )

            // 6. Front Defrost
            BottomBarIconButton(
                icon = Icons.Default.VerticalAlignTop,
                contentDescription = "Ön Cam Buğu",
                isSelected = vehicleState.ventDefrostFront,
                activeColor = Color(0xFF38BDF8),
                testTag = "bottom_defrost_front",
                onClick = onToggleDefrostFront
            )

            // 7. Rear Defrost
            BottomBarIconButton(
                icon = Icons.Default.VerticalAlignBottom,
                contentDescription = "Arka Cam Buğu",
                isSelected = vehicleState.ventDefrostRear,
                activeColor = Color(0xFFF59E0B),
                testTag = "bottom_defrost_rear",
                onClick = onToggleDefrostRear
            )

            // 8. Phone
            BottomBarIconButton(
                icon = Icons.Default.Phone,
                contentDescription = "Telefon",
                isSelected = activeScreen == ActiveScreen.PHONE,
                testTag = "bottom_phone_btn",
                onClick = { onScreenSelected(ActiveScreen.PHONE) }
            )

            // 9. Music
            BottomBarIconButton(
                icon = Icons.Default.MusicNote,
                contentDescription = "Müzik",
                isSelected = activeScreen == ActiveScreen.MUSIC,
                testTag = "bottom_music_btn",
                onClick = { onScreenSelected(ActiveScreen.MUSIC) }
            )

            // 10. Camera
            BottomBarIconButton(
                icon = Icons.Default.Videocam,
                contentDescription = "Kamera",
                isSelected = activeScreen == ActiveScreen.CAMERA,
                testTag = "bottom_camera_btn",
                onClick = { onScreenSelected(ActiveScreen.CAMERA) }
            )

            // 11. Visual Drive / Speed
            BottomBarIconButton(
                icon = Icons.Default.Speed,
                contentDescription = "Sürüş Görünümü",
                isSelected = activeScreen == ActiveScreen.VISUAL_DRIVE,
                testTag = "bottom_drive_visual_btn",
                onClick = { onScreenSelected(ActiveScreen.VISUAL_DRIVE) }
            )

            // 12. Recirculation / Rejen
            BottomBarIconButton(
                icon = Icons.Default.Sync,
                contentDescription = "İç Hava",
                isSelected = vehicleState.recircEnabled,
                testTag = "bottom_recirc_btn",
                onClick = onToggleRecirc
            )

            // 13. ESC Button
            Text(
                text = "ESC",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9CA3AF),
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { onScreenSelected(ActiveScreen.SETTINGS) }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            )

            // 14. Passenger Seat Heating
            SeatHeatButton(
                level = vehicleState.passengerSeatHeat,
                testTag = "seat_heat_passenger",
                onClick = onCyclePassengerSeatHeat
            )

            // 15. Volume (< 5 >)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 2.dp)
            ) {
                IconButton(
                    onClick = { onAdjustVolume(vehicleState.volumeLevel - 1) },
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "Ses Azalt",
                        tint = Color(0xFF9CA3AF),
                        modifier = Modifier.size(16.dp)
                    )
                }

                Icon(
                    imageVector = if (vehicleState.volumeLevel == 0) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                    contentDescription = "Ses Seviyesi",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "${vehicleState.volumeLevel}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                IconButton(
                    onClick = { onAdjustVolume(vehicleState.volumeLevel + 1) },
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Ses Artır",
                        tint = Color(0xFF9CA3AF),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BottomBarIconButton(
    icon: ImageVector,
    contentDescription: String,
    isSelected: Boolean,
    testTag: String,
    activeColor: Color = Color(0xFF0284C7),
    isDark: Boolean = true,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .testTag(testTag)
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) activeColor.copy(alpha = 0.2f) else Color.Transparent)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (isSelected) activeColor else (if (isDark) Color(0xFF9CA3AF) else Color(0xFF475569)),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun SeatHeatButton(
    level: Int, // 0..3
    testTag: String,
    isDark: Boolean = true,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.AirlineSeatReclineNormal,
            contentDescription = "Koltuk Isıtma",
            tint = if (level > 0) Color(0xFFF97316) else (if (isDark) Color(0xFF9CA3AF) else Color(0xFF475569)),
            modifier = Modifier.size(18.dp)
        )
        // 3 indicator dots
        Row(
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.padding(top = 1.dp)
        ) {
            repeat(3) { index ->
                Box(
                    modifier = Modifier
                        .size(3.dp)
                        .clip(CircleShape)
                        .background(if (index < level) Color(0xFFF97316) else (if (isDark) Color(0xFF4B5563) else Color(0xFFCBD5E1)))
                )
            }
        }
    }
}
