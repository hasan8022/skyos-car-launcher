package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VoiceAssistantManager
import kotlin.math.sin

@Composable
fun VoiceAssistantOrb(
    assistantManager: VoiceAssistantManager,
    isDark: Boolean = true,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isListening by assistantManager.isListening.collectAsState()
    val spokenText by assistantManager.lastSpokenText.collectAsState()
    val assistantResponse by assistantManager.assistantResponse.collectAsState()

    var typedCommand by remember { mutableStateOf("") }

    // Pulsing orb animation
    val infiniteTransition = rememberInfiniteTransition(label = "orbPulse")
    val scaleAnim by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orbScale"
    )

    val rippleScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rippleScale"
    )

    val rippleAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rippleAlpha"
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.65f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.62f)
                .padding(bottom = 65.dp)
                .clickable(enabled = false) {} // prevent dismissing when tapping inside
                .clip(RoundedCornerShape(26.dp))
                .background(if (isDark) Color(0xFF131722).copy(alpha = 0.96f) else Color(0xFFFFFFFF).copy(alpha = 0.98f))
                .border(
                    width = 1.dp,
                    color = if (isDark) Color(0xFF263248) else Color(0xFFE2E8F0),
                    shape = RoundedCornerShape(26.dp)
                )
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Asistan",
                        tint = Color(0xFF00D2FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "SkyOS Akıllı Sesli Asistan",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color(0xFF00D2FF) else Color(0xFF0284C7)
                    )
                }

                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Kapat",
                        tint = if (isDark) Color(0xFF9CA3AF) else Color(0xFF64748B)
                    )
                }
            }

            // Glowing Animated Assistant Orb with Ripple Waves
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clickable { assistantManager.startListening() },
                contentAlignment = Alignment.Center
            ) {
                // Outward Radiating Concentric Ripple
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .scale(rippleScale)
                        .clip(CircleShape)
                        .border(
                            width = 2.dp,
                            brush = Brush.radialGradient(
                                listOf(
                                    Color(0xFF00D2FF).copy(alpha = rippleAlpha),
                                    Color(0xFFA855F7).copy(alpha = rippleAlpha * 0.5f),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // Glowing Outer Aura
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .scale(scaleAnim)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFF38BDF8).copy(alpha = 0.75f),
                                    Color(0xFFA855F7).copy(alpha = 0.55f),
                                    Color(0xFFEC4899).copy(alpha = 0.35f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Core Holographic Sphere
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color.White, Color(0xFF00D2FF), Color(0xFF9333EA))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Mikrofon",
                        tint = Color.Black,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Real-time Soundwave Frequency Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .padding(horizontal = 24.dp)
            ) {
                val width = size.width
                val height = size.height
                val midY = height / 2

                // Wave 1: Primary Cyan Sine Wave
                val path1 = Path()
                path1.moveTo(0f, midY)
                val points = 60
                for (i in 0..points) {
                    val x = (width / points) * i
                    val normalizedX = (i.toFloat() / points)
                    // Bell envelope so edges taper to zero
                    val envelope = sin(normalizedX * Math.PI).toFloat()
                    val y = midY + sin(normalizedX * 4 * Math.PI + wavePhase).toFloat() * 14f * envelope
                    path1.lineTo(x, y)
                }
                drawPath(
                    path = path1,
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF00D2FF), Color(0xFF38BDF8), Color(0xFFA855F7))
                    ),
                    style = Stroke(width = 3.dp.toPx())
                )

                // Wave 2: Secondary Magenta Harmonics
                val path2 = Path()
                path2.moveTo(0f, midY)
                for (i in 0..points) {
                    val x = (width / points) * i
                    val normalizedX = (i.toFloat() / points)
                    val envelope = sin(normalizedX * Math.PI).toFloat()
                    val y = midY + sin(normalizedX * 6 * Math.PI - wavePhase * 1.3f).toFloat() * 10f * envelope
                    path2.lineTo(x, y)
                }
                drawPath(
                    path = path2,
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFFEC4899).copy(alpha = 0.7f), Color(0xFF8B5CF6).copy(alpha = 0.7f))
                    ),
                    style = Stroke(width = 2.dp.toPx())
                )
            }

            // Prompt text: "Dinliyorum..." or Recognized text
            Text(
                text = if (assistantResponse.isNotEmpty()) assistantResponse else if (isListening) "Dinliyorum, buyrun..." else "Dokunup konuşun veya yazın",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF0F172A)
            )

            if (spokenText.isNotEmpty()) {
                Text(
                    text = "\"$spokenText\"",
                    fontSize = 13.sp,
                    color = Color(0xFF0284C7),
                    fontWeight = FontWeight.Medium
                )
            }

            // Text input fallback for quick typing or testing
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isDark) Color(0xFF1B2232) else Color(0xFFF1F5F9))
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    placeholder = {
                        Text(
                            "Komut yazın veya söyleyin...",
                            color = if (isDark) Color(0xFF6B7280) else Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = if (isDark) Color.White else Color(0xFF0F172A),
                        unfocusedTextColor = if (isDark) Color.White else Color(0xFF0F172A)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("voice_command_text_input"),
                    singleLine = true
                )

                IconButton(
                    onClick = {
                        if (typedCommand.isNotBlank()) {
                            assistantManager.processVoiceCommand(typedCommand)
                            typedCommand = ""
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Gönder",
                        tint = Color(0xFF0284C7)
                    )
                }
            }

            // Suggested Command Chips (including compound commands)
            Text(
                "Örnek Komutlar:",
                fontSize = 11.sp,
                color = if (isDark) Color(0xFF8F9CAE) else Color(0xFF64748B)
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                AssistantChip("Klimayı 22 yap", isDark) { assistantManager.processVoiceCommand("Klimayı 22 yap") }
                AssistantChip("Kral FM aç", isDark) { assistantManager.processVoiceCommand("Kral FM aç") }
                AssistantChip("Eve git", isDark) { assistantManager.processVoiceCommand("Eve git") }
                AssistantChip("Menzil kaç?", isDark) { assistantManager.processVoiceCommand("Menzilim ne kadar?") }
            }

            AssistantChip("⚡ Klimayı 22 yap, perdeyi aç, eve git", isDark) {
                assistantManager.processVoiceCommand("Klimayı 22 yap, perdeyi aç, eve git")
            }
        }
    }
}

@Composable
fun AssistantChip(text: String, isDark: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isDark) Color(0xFF222B3D) else Color(0xFFE2E8F0))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            color = if (isDark) Color(0xFFD1D5DB) else Color(0xFF1E293B),
            fontWeight = FontWeight.Medium
        )
    }
}
