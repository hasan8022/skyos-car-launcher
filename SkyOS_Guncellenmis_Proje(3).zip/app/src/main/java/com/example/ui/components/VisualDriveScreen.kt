package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.VehicleState

@Composable
fun VisualDriveScreen(
    vehicleState: VehicleState,
    modifier: Modifier = Modifier
) {
    // Road lane animation
    val infiniteTransition = rememberInfiniteTransition(label = "laneAnim")
    val laneOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "laneOffset"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF14171E))
    ) {
        // Road and Lane Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Center lane marks (moving)
            val leftLaneX = width * 0.32f
            val rightLaneX = width * 0.68f

            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(40f, 30f), laneOffset)

            // Left lane line
            drawLine(
                color = Color.White.copy(alpha = 0.85f),
                start = Offset(leftLaneX, 0f),
                end = Offset(leftLaneX, height),
                strokeWidth = 6f,
                pathEffect = dashEffect
            )

            // Right lane line
            drawLine(
                color = Color.White.copy(alpha = 0.85f),
                start = Offset(rightLaneX, 0f),
                end = Offset(rightLaneX, height),
                strokeWidth = 6f,
                pathEffect = dashEffect
            )

            // Outer continuous line
            drawLine(
                color = Color.White.copy(alpha = 0.4f),
                start = Offset(width * 0.12f, 0f),
                end = Offset(width * 0.12f, height),
                strokeWidth = 4f
            )
            drawLine(
                color = Color.White.copy(alpha = 0.4f),
                start = Offset(width * 0.88f, 0f),
                end = Offset(width * 0.88f, height),
                strokeWidth = 4f
            )
        }

        // Host Vehicle in center
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(width = 85.dp, height = 160.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.arac_ust),
                contentDescription = "Araç",
                modifier = Modifier.fillMaxSize()
            )
        }

        // Çevredeki araçlar yalnızca GERÇEK ADAS sensör verisiyle çizilir.
        // Projede doğrulanmış bir çevre-sensörü kaynağı yok → sahte araç çizilmez.
        if (!vehicleState.vehicleBusConnected) {
            Text(
                text = "Çevre sensörü verisi yok — yalnızca kendi aracınız gösteriliyor",
                fontSize = 11.sp,
                color = Color(0xFFF59E0B),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
            )
        }

        // Large Speed & Info overlay at top right of visual view (matches 81: "41 KM/SA")
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = "${vehicleState.speedKmh}",
                fontSize = 58.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Text(
                text = "KM/SA",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9CA3AF)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Speed Limit Badge — kaynak (OSM/maxspeed) yoksa gösterilmez
            if (vehicleState.speedLimitKmh > 0) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${vehicleState.speedLimitKmh}",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black
                    )
                }
            }
        }
    }
}
