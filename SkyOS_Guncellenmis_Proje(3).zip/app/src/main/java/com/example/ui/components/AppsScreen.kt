package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveScreen

data class SkyAppItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val targetScreen: ActiveScreen? = null,
    val webUrl: String? = null,
    val subtitle: String? = null
)

@Composable
fun AppsScreen(
    onNavigate: (ActiveScreen) -> Unit,
    onOpenWebBrowser: (title: String, url: String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val skyOsApps = listOf(
        SkyAppItem("Müzik", Icons.Default.MusicNote, Color(0xFF222938), targetScreen = ActiveScreen.MUSIC),
        SkyAppItem("Radyo", Icons.Default.Radio, Color(0xFF222938), targetScreen = ActiveScreen.MUSIC),
        SkyAppItem("Telefon", Icons.Default.Phone, Color(0xFF222938), targetScreen = ActiveScreen.PHONE),
        SkyAppItem("Harita", Icons.Default.Navigation, Color(0xFF222938), targetScreen = ActiveScreen.MAP),
        SkyAppItem("Kamera", Icons.Default.Videocam, Color(0xFF222938), targetScreen = ActiveScreen.CAMERA),
        SkyAppItem("Enerji", Icons.Default.Speed, Color(0xFF222938), targetScreen = ActiveScreen.ENERGY),
        SkyAppItem("Ayarlar", Icons.Default.Settings, Color(0xFF222938), targetScreen = ActiveScreen.SETTINGS),
        SkyAppItem("Sürüş Görünümü", Icons.Default.Explore, Color(0xFF222938), targetScreen = ActiveScreen.VISUAL_DRIVE)
    )

    val musicApps = listOf(
        SkyAppItem("Spotify", Icons.Default.PlayCircle, Color(0xFF1DB954), webUrl = "https://open.spotify.com", subtitle = "Web Player"),
        SkyAppItem("YouTube", Icons.Default.SmartDisplay, Color(0xFFFF0000), webUrl = "https://m.youtube.com", subtitle = "Video & Müzik"),
        SkyAppItem("Apple Music", Icons.Default.MusicNote, Color(0xFFFA243C), webUrl = "https://music.apple.com", subtitle = "Web Player"),
        SkyAppItem("Deezer", Icons.Default.Favorite, Color(0xFFA238FF), webUrl = "https://www.deezer.com", subtitle = "Web Player"),
        SkyAppItem("SoundCloud", Icons.Default.CloudQueue, Color(0xFFFF5500), webUrl = "https://m.soundcloud.com", subtitle = "Web Player")
    )

    val navApps = listOf(
        SkyAppItem("Yandex Harita", Icons.Default.Explore, Color(0xFFFF0000), webUrl = "https://yandex.com.tr/harita", subtitle = "Canlı Trafik"),
        SkyAppItem("Eşarj İstasyonları", Icons.Default.EvStation, Color(0xFF00D2FF), webUrl = "https://esarj.com", subtitle = "Hızlı Şarj"),
        SkyAppItem("ZES Şarj", Icons.Default.Bolt, Color(0xFFFF9800), webUrl = "https://zes.net", subtitle = "Şarj Haritası")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1217))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Uygulamalar",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E2638))
            ) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // SKYOS SYSTEM APPS
        Text("SKYOS SİSTEMİ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6B7280))
        Spacer(modifier = Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(170.dp)
        ) {
            items(skyOsApps) { app ->
                AppGridCard(app = app, onClick = {
                    app.targetScreen?.let { onNavigate(it) }
                })
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // MÜZİK VE VİDEO UYGULAMALARI (Real Web/Native Players)
        Text("MÜZİK VE VİDEO (GERÇEK OYNATICI)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6B7280))
        Spacer(modifier = Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(85.dp)
        ) {
            items(musicApps) { app ->
                AppGridCard(app = app, onClick = {
                    if (app.webUrl != null) {
                        onOpenWebBrowser(app.title, app.webUrl)
                    } else {
                        app.targetScreen?.let { onNavigate(it) }
                    }
                })
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // NAVİGASYON VE ŞARJ HARİTALARI
        Text("NAVİGASYON VE ŞARJ HARİTALARI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6B7280))
        Spacer(modifier = Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(85.dp)
        ) {
            items(navApps) { app ->
                AppGridCard(app = app, onClick = {
                    if (app.webUrl != null) {
                        onOpenWebBrowser(app.title, app.webUrl)
                    } else {
                        app.targetScreen?.let { onNavigate(it) }
                    }
                })
            }
        }
    }
}

@Composable
fun AppGridCard(app: SkyAppItem, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(78.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF161C26))
            .clickable(onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(app.color),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = app.icon, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(18.dp))
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = app.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1
            )
            if (app.subtitle != null) {
                Text(
                    text = app.subtitle,
                    fontSize = 9.sp,
                    color = Color(0xFF00D2FF),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
