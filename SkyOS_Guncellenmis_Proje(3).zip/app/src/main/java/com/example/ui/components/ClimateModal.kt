package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VehicleState

@Composable
fun ClimateModal(
    vehicleState: VehicleState,
    onAdjustDriverTemp: (Float) -> Unit,
    onSetFanSpeed: (Int) -> Unit,
    onToggleAC: () -> Unit,
    onToggleAuto: () -> Unit,
    onToggleRecirc: () -> Unit,
    onToggleVentFace: () -> Unit,
    onToggleVentFoot: () -> Unit,
    onToggleDefrostFront: () -> Unit,
    onTogglePower: () -> Unit,
    onCycleDriverSeatHeat: () -> Unit,
    onCycleDriverSeatVent: () -> Unit,
    onCyclePassengerSeatHeat: () -> Unit,
    onCyclePassengerSeatVent: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0E14).copy(alpha = 0.98f))
            .padding(16.dp)
    ) {
        // Close Button (Top right)
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E2533))
        ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // SÜRÜCÜ (Driver side controls)
            Column(
                modifier = Modifier
                    .weight(0.28f)
                    .padding(end = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "SÜRÜCÜ",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8F9CAE)
                )

                SeatControlRow(
                    label = "Koltuk Isıtma",
                    icon = Icons.Default.AirlineSeatReclineNormal,
                    activeColor = Color(0xFFF97316),
                    level = vehicleState.driverSeatHeat,
                    onLevelSelected = { onCycleDriverSeatHeat() }
                )

                SeatControlRow(
                    label = "Koltuk Havalandırma",
                    icon = Icons.Default.AcUnit,
                    activeColor = Color(0xFF38BDF8),
                    level = vehicleState.driverSeatVent,
                    onLevelSelected = { onCycleDriverSeatVent() }
                )
            }

            // CENTER: Temperature, Airflow, Fan Slider & Control Bar
            Column(
                modifier = Modifier
                    .weight(0.44f)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Large Temperature Selector: < 22,0° >
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(
                        onClick = { onAdjustDriverTemp(-0.5f) },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2638))
                    ) {
                        Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Azalt", tint = Color.White)
                    }

                    Text(
                        text = String.format(java.util.Locale.US, "%.1f°", vehicleState.driverTemp).replace(".", ","),
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )

                    IconButton(
                        onClick = { onAdjustDriverTemp(+0.5f) },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2638))
                    ) {
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Artır", tint = Color.White)
                    }
                }

                // Airflow visualization capsule
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(80.dp)
                        .clip(RoundedCornerShape(40.dp))
                        .background(Color(0xFF171C26)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Box(modifier = Modifier.width(6.dp).height(24.dp).background(Color(0xFF00D2FF)))
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(modifier = Modifier.width(6.dp).height(24.dp).background(Color(0xFF00D2FF)))
                        }

                        Text(
                            text = if (vehicleState.climatePower) "Klima Açık · Çift Bölge" else "Klima Kapalı",
                            color = if (vehicleState.climatePower) Color(0xFF00D2FF) else Color(0xFF6B7280),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Icon(
                            imageVector = Icons.Default.Air,
                            contentDescription = "Hava Akışı",
                            tint = Color(0xFF00D2FF).copy(alpha = 0.7f),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                // Fan Slider: - [fan] [========|========] 2 +
                Row(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { onSetFanSpeed(vehicleState.fanSpeed - 1) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Azalt", tint = Color.White)
                    }

                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = "Fan",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )

                    Slider(
                        value = vehicleState.fanSpeed.toFloat(),
                        onValueChange = { onSetFanSpeed(it.toInt()) },
                        valueRange = 0f..7f,
                        steps = 6,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("climate_fan_slider"),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color(0xFF00D2FF),
                            inactiveTrackColor = Color(0xFF2E384D)
                        )
                    )

                    Text(
                        text = "${vehicleState.fanSpeed}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    IconButton(
                        onClick = { onSetFanSpeed(vehicleState.fanSpeed + 1) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Artır", tint = Color.White)
                    }
                }

                // Control Buttons Grid
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    ClimateModeBtn(
                        title = "Otomatik",
                        icon = Icons.Default.AutoAwesome,
                        isActive = vehicleState.autoClimate,
                        onClick = onToggleAuto
                    )
                    ClimateModeBtn(
                        title = "A/C",
                        icon = Icons.Default.AcUnit,
                        isActive = vehicleState.acEnabled,
                        onClick = onToggleAC
                    )
                    ClimateModeBtn(
                        title = "İç hava",
                        icon = Icons.Default.Sync,
                        isActive = vehicleState.recircEnabled,
                        onClick = onToggleRecirc
                    )
                    ClimateModeBtn(
                        title = "Yüz",
                        icon = Icons.Default.ArrowForward,
                        isActive = vehicleState.ventFace,
                        onClick = onToggleVentFace
                    )
                    ClimateModeBtn(
                        title = "Ayak",
                        icon = Icons.Default.ArrowDownward,
                        isActive = vehicleState.ventFoot,
                        onClick = onToggleVentFoot
                    )
                    ClimateModeBtn(
                        title = "Ön cam",
                        icon = Icons.Default.VerticalAlignTop,
                        isActive = vehicleState.ventDefrostFront,
                        onClick = onToggleDefrostFront
                    )
                    ClimateModeBtn(
                        title = if (vehicleState.climatePower) "Kapat" else "Aç",
                        icon = Icons.Default.PowerSettingsNew,
                        isActive = !vehicleState.climatePower,
                        activeColor = Color(0xFFEF4444),
                        onClick = onTogglePower
                    )
                }
            }

            // YOLCU (Passenger side controls)
            Column(
                modifier = Modifier
                    .weight(0.28f)
                    .padding(start = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "YOLCU",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8F9CAE)
                )

                SeatControlRow(
                    label = "Koltuk Isıtma",
                    icon = Icons.Default.AirlineSeatReclineNormal,
                    activeColor = Color(0xFFF97316),
                    level = vehicleState.passengerSeatHeat,
                    onLevelSelected = { onCyclePassengerSeatHeat() }
                )

                SeatControlRow(
                    label = "Koltuk Havalandırma",
                    icon = Icons.Default.AcUnit,
                    activeColor = Color(0xFF38BDF8),
                    level = vehicleState.passengerSeatVent,
                    onLevelSelected = { onCyclePassengerSeatVent() }
                )
            }
        }
    }
}

@Composable
fun SeatControlRow(
    label: String,
    icon: ImageVector,
    activeColor: Color,
    level: Int,
    onLevelSelected: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(bottom = 6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = activeColor, modifier = Modifier.size(16.dp))
            Text(text = label, fontSize = 11.sp, color = Color(0xFFD1D5DB))
        }

        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1B2230))
                .padding(2.dp)
        ) {
            val levels = listOf(0 to "Kapalı", 1 to "1", 2 to "2", 3 to "3")
            levels.forEach { (lvl, title) ->
                val isSelected = level == lvl
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) activeColor else Color.Transparent)
                        .clickable(onClick = onLevelSelected)
                        .padding(horizontal = 9.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else Color(0xFF9CA3AF)
                    )
                }
            }
        }
    }
}

@Composable
fun ClimateModeBtn(
    title: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color = Color(0xFF00D2FF),
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isActive) activeColor else Color(0xFF1A212E))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isActive) Color.Black else Color(0xFFD1D5DB),
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isActive) Color.Black else Color(0xFF9CA3AF),
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}
