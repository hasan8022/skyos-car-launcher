package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.model.VehicleState
import com.example.osmand.ev.GeoPoint
import com.example.osmand.safety.AlertTriggerStage
import com.example.osmand.search.LiveGeocodeResult
import com.example.osmand.ui.EVLauncherMapView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MapNavigationScreen(
    vehicleState: VehicleState,
    repository: VehicleRepository,
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    onVoiceSearchClicked: () -> Unit,
    onToggleFullScreen: () -> Unit,
    isFullScreen: Boolean,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val activeRoute by repository.evRoutingManager.activeRoute.collectAsState()
    val activeAlert by repository.safetyAlertManager.currentAlert.collectAsState()
    val isCalculatingRoute by repository.evRoutingManager.isCalculating.collectAsState()
    val downloadProgress by repository.mapDownloadManager.downloadState.collectAsState()

    var showNavOptionsPanel by remember { mutableStateOf(false) }
    var isHeadingUp by remember { mutableStateOf(true) }
    var searchSuggestions by remember { mutableStateOf<List<LiveGeocodeResult>>(emptyList()) }
    var isSearchFocused by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    var mapSurfaceRef by remember { mutableStateOf<com.example.osmand.ui.EVMapSurfaceView?>(null) }

    // Live OpenStreetMap Nominatim geocoder query with 300ms debounce
    LaunchedEffect(searchQuery) {
        searchJob?.cancel()
        if (searchQuery.isNotBlank()) {
            searchJob = coroutineScope.launch {
                delay(300)
                val liveResults = repository.liveGeocoder.searchLive(searchQuery)
                searchSuggestions = liveResults
            }
        } else {
            searchSuggestions = emptyList()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("map_navigation_container")
    ) {
        // 1. Native Real OpenStreetMap Map View (CartoDB tiles, 150% scaled automotive font & right 40% offset)
        // Konum: yalnızca GERÇEK GPS fix'i; fix yoksa son bilinen yerine 0,0 GÖNDERİLMEZ —
        // EVLauncherMapView hasVehicleFix=false ile "Konum bekleniyor" durumunu çizer.
        val realTelemetry by repository.telemetryHelper.telemetry.collectAsState()
        EVLauncherMapView(
            vehicleLatitude = if (realTelemetry.hasGpsFix) realTelemetry.currentLatitude else 0.0,
            vehicleLongitude = if (realTelemetry.hasGpsFix) realTelemetry.currentLongitude else 0.0,
            hasVehicleFix = realTelemetry.hasGpsFix,
            vehicleHeadingDegrees = if (isHeadingUp) 48.0f else 0.0f,
            vehicleSpeedKmh = vehicleState.speedKmh,
            speedLimitKmh = vehicleState.speedLimitKmh,
            isNightMode = isDark,
            isFullScreen = isFullScreen,
            showTraffic = vehicleState.navTrafficEnabled,
            showSpeedCameras = vehicleState.navSpeedCamerasEnabled,
            showChargingStations = vehicleState.navShowChargingStations,
            showParking = vehicleState.navShowParking,
            tilt3D = vehicleState.nav3DTilt,
            isHeadingUp = isHeadingUp,
            activeRoute = activeRoute,
            activeAlert = activeAlert,
            onViewReady = { mapSurfaceRef = it },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Cockpit Maneuver HUD Card (Real turn-by-turn instruction when navigating)
        activeRoute?.let { route ->
            val nextStep = route.maneuverSteps.firstOrNull { it.maneuverType != "depart" }
            if (nextStep != null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, top = 20.dp)
                        .widthIn(max = 380.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .testTag("cockpit_maneuver_hud"),
                    color = if (isDark) Color(0xF2101622) else Color(0xF5FFFFFF),
                    shadowElevation = 10.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0xFF00D2FF).copy(alpha = 0.35f) else Color(0x33000000))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val turnIcon = when {
                            nextStep.modifier.contains("left") -> Icons.Default.TurnLeft
                            nextStep.modifier.contains("right") -> Icons.Default.TurnRight
                            nextStep.maneuverType.contains("roundabout") -> Icons.Default.Cached
                            else -> Icons.Default.Straight
                        }
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00D2FF).copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = turnIcon,
                                contentDescription = null,
                                tint = Color(0xFF00D2FF),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = nextStep.instruction,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isDark) Color.White else Color.Black
                            )
                            Text(
                                text = "Mesafe: ${(nextStep.distanceMeters).toInt()} m",
                                fontSize = 12.sp,
                                color = if (isDark) Color(0xFF00D2FF) else Color(0xFF1976D2),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // 3. Top Search Bar & Live Suggestions
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth(if (activeRoute != null) 0.65f else 1.0f)
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(RoundedCornerShape(27.dp))
                    .background(if (isDark) Color(0xCC1A212E) else Color(0xEEFFFFFF))
                    .border(1.dp, if (isDark) Color(0x334B5E78) else Color(0x22000000), RoundedCornerShape(27.dp))
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Ara",
                    tint = if (isDark) Color(0xFF00D2FF) else Color(0xFF1976D2),
                    modifier = Modifier.size(24.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                TextField(
                    value = searchQuery,
                    onValueChange = {
                        onSearchQueryChanged(it)
                        isSearchFocused = true
                    },
                    placeholder = {
                        Text(
                            text = "Canlı OSM Arama (Kadıköy, Trugo Şarj, Taksim...)",
                            color = if (isDark) Color(0xFF8E9DAF) else Color(0xFF6B7280),
                            fontSize = 14.sp
                        )
                    },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = if (isDark) Color.White else Color.Black,
                        unfocusedTextColor = if (isDark) Color.White else Color.Black
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("map_search_input")
                )

                if (searchQuery.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            onSearchQueryChanged("")
                            searchSuggestions = emptyList()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Temizle",
                            tint = if (isDark) Color(0xFF8E9DAF) else Color(0xFF6B7280)
                        )
                    }
                }

                // Voice Assistant Microphone Trigger
                IconButton(
                    onClick = onVoiceSearchClicked,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00D2FF).copy(alpha = 0.15f))
                        .testTag("voice_assistant_mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Sesli Arama",
                        tint = Color(0xFF00D2FF),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Full Screen Toggle
                IconButton(
                    onClick = onToggleFullScreen,
                    modifier = Modifier.size(40.dp).testTag("fullscreen_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isFullScreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = "Tam Ekran",
                        tint = if (isDark) Color(0xFFE0E0E0) else Color(0xFF333333)
                    )
                }
            }

            // Quick Category Shortcuts
            if (searchQuery.isEmpty() && !isSearchFocused && activeRoute == null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickFilterChip(
                        icon = Icons.Default.Home,
                        label = "Ev",
                        isDark = isDark,
                        onClick = {
                            val q = repository.getVoiceTargetQuery("home")
                            onSearchQueryChanged(q)
                            triggerRouteSearch(q, repository, coroutineScope)
                        }
                    )
                    QuickFilterChip(
                        icon = Icons.Default.Work,
                        label = "İş",
                        isDark = isDark,
                        onClick = {
                            val q = repository.getVoiceTargetQuery("work")
                            onSearchQueryChanged(q)
                            triggerRouteSearch(q, repository, coroutineScope)
                        }
                    )
                    QuickFilterChip(
                        icon = Icons.Default.EvStation,
                        label = "Şarj İstasyonu",
                        isDark = isDark,
                        badgeColor = Color(0xFF00E676),
                        onClick = {
                            onSearchQueryChanged("şarj istasyonu")
                            triggerRouteSearch("şarj istasyonu", repository, coroutineScope)
                        }
                    )
                    QuickFilterChip(
                        icon = Icons.Default.LocalParking,
                        label = "Otopark",
                        isDark = isDark,
                        onClick = {
                            onSearchQueryChanged("otopark")
                            triggerRouteSearch("otopark", repository, coroutineScope)
                        }
                    )
                    QuickFilterChip(
                        icon = if (downloadProgress.isCompleted) Icons.Default.CloudDone else Icons.Default.CloudDownload,
                        label = if (downloadProgress.isCompleted) "Çevrimdışı Paket Hazır" else "Harita Paketi İndir",
                        isDark = isDark,
                        badgeColor = if (downloadProgress.isCompleted) Color(0xFF00E676) else Color(0xFF00D2FF),
                        onClick = {
                            showNavOptionsPanel = true
                        }
                    )
                }
            }

            // Live Search Results Dropdown from OpenStreetMap Nominatim
            if (searchSuggestions.isNotEmpty() && searchQuery.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isDark) Color(0xFA141A24) else Color(0xFAFFFFFF),
                    shadowElevation = 10.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0x334B5E78) else Color(0x22000000)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LazyColumn(modifier = Modifier.heightIn(max = 260.dp)) {
                        items(searchSuggestions) { poi ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSearchQueryChanged(poi.name)
                                        isSearchFocused = false
                                        triggerRouteTo(poi.name, poi.point, repository, coroutineScope)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (poi.isChargingStation) Icons.Default.EvStation else Icons.Default.Place,
                                    contentDescription = null,
                                    tint = if (poi.isChargingStation) Color(0xFF00E676) else Color(0xFF00D2FF),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = poi.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (isDark) Color.White else Color.Black
                                    )
                                    Text(
                                        text = poi.formattedAddress,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        color = if (isDark) Color(0xFF8E9DAF) else Color(0xFF6B7280)
                                    )
                                }
                                if (poi.isChargingStation) {
                                    Surface(
                                        color = Color(0xFF00E676).copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "DC HIZLI",
                                            color = Color(0xFF00E676),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = if (isDark) Color(0x22FFFFFF) else Color(0x11000000))
                        }
                    }
                }
            }
        }

        // 4. Proximity Safety Alerts HUD Banner (500m & 200m stage triggers)
        activeAlert?.let { alert ->
            val isUrgent = alert.stage == AlertTriggerStage.URGENT_200M
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 80.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .testTag("safety_alert_banner"),
                color = if (isUrgent) Color(0xFFD50000) else Color(0xFFFF9100),
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isUrgent) Icons.Default.Warning else Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isUrgent) "⚠️ DİKKAT: ${alert.hazard.type.title.uppercase()}" else alert.hazard.type.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "${alert.distanceRemainingMeters.toInt()}m kaldı • Hız Sınırı: ${alert.hazard.speedLimitKmh} km/s (${alert.hazard.description})",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // 5. EV Active Route Summary Card
        activeRoute?.let { route ->
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 24.dp, bottom = 24.dp)
                    .widthIn(max = 440.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .testTag("active_ev_route_card"),
                color = if (isDark) Color(0xEE141A24) else Color(0xEEFFFFFF),
                shadowElevation = 8.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0x334B5E78) else Color(0x22000000))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = route.destinationName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = if (isDark) Color.White else Color.Black
                            )
                            Text(
                                text = "${(route.totalDistanceMeters / 1000.0).toInt()} km • ${(route.totalDurationSeconds / 60)} dakika sürüş",
                                fontSize = 13.sp,
                                color = if (isDark) Color(0xFF8E9DAF) else Color(0xFF6B7280)
                            )
                        }

                        // Arrival SoC % Badge
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (route.arrivalSoCPercent > 20f) Color(0xFF00E676).copy(alpha = 0.2f) else Color(0xFFFF9100).copy(alpha = 0.2f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BatteryChargingFull,
                                    contentDescription = null,
                                    tint = if (route.arrivalSoCPercent > 20f) Color(0xFF00E676) else Color(0xFFFF9100),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Varışta: %${route.arrivalSoCPercent.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (route.arrivalSoCPercent > 20f) Color(0xFF00E676) else Color(0xFFFF9100)
                                )
                            }
                        }
                    }

                    // Auto-added charging station warning if out of range
                    if (route.requiredChargeStops.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val stop = route.requiredChargeStops.first()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF00E676).copy(alpha = 0.12f))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.EvStation,
                                contentDescription = null,
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Menzil yetmezliği: ${stop.name} (${stop.powerKw} kW DC) otomatik ara durak eklendi.",
                                fontSize = 12.sp,
                                color = if (isDark) Color.White else Color.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { repository.evRoutingManager.clearRoute() }
                        ) {
                            Text("Rotayı Sonlandır", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 6. Right Action Buttons (Compass, Recenter, Layer Settings)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            FloatingActionButton(
                onClick = { isHeadingUp = !isHeadingUp },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xDD1C2633) else Color(0xEEFFFFFF),
                contentColor = if (isDark) Color.White else Color.Black,
                modifier = Modifier.size(52.dp).testTag("compass_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Explore,
                    contentDescription = "Pusula",
                    tint = if (isHeadingUp) Color(0xFF00D2FF) else Color.Gray,
                    modifier = Modifier.size(26.dp)
                )
            }

            FloatingActionButton(
                onClick = { mapSurfaceRef?.recenter() },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xDD1C2633) else Color(0xEEFFFFFF),
                contentColor = if (isDark) Color.White else Color.Black,
                modifier = Modifier.size(52.dp).testTag("recenter_button")
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "Merkezle",
                    tint = Color(0xFF00D2FF),
                    modifier = Modifier.size(26.dp)
                )
            }

            FloatingActionButton(
                onClick = { showNavOptionsPanel = !showNavOptionsPanel },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xDD1C2633) else Color(0xEEFFFFFF),
                contentColor = if (isDark) Color.White else Color.Black,
                modifier = Modifier.size(52.dp).testTag("nav_options_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Traffic,
                    contentDescription = "Navigasyon Seçenekleri",
                    tint = if (showNavOptionsPanel) Color(0xFF00E676) else Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        // 7. Navigation Options Drawer Panel
        AnimatedVisibility(
            visible = showNavOptionsPanel,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(320.dp)
                    .background(if (isDark) Color(0xF2101620) else Color(0xF8FFFFFF))
                    .border(1.dp, if (isDark) Color(0x334B5E78) else Color(0x22000000)),
                color = Color.Transparent
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Harita & Navigasyon",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (isDark) Color.White else Color.Black
                        )
                        IconButton(onClick = { showNavOptionsPanel = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Kapat", tint = Color.Gray)
                        }
                    }

                    HorizontalDivider(
                        color = if (isDark) Color(0x334B5E78) else Color(0x22000000),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("offline_map_pack_card"),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isDark) Color(0x2E00D2FF) else Color(0x1400D2FF)
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isDark) Color(0xFF00D2FF).copy(alpha = 0.5f) else Color(0xFF0288D1).copy(alpha = 0.4f)
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (downloadProgress.isCompleted) Icons.Default.CloudDone else Icons.Default.CloudDownload,
                                            contentDescription = null,
                                            tint = if (downloadProgress.isCompleted) Color(0xFF00E676) else Color(0xFF00D2FF),
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Marmara Çevrimdışı Haritası",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (isDark) Color.White else Color.Black
                                            )
                                            Text(
                                                text = downloadProgress.statusText,
                                                fontSize = 11.sp,
                                                color = if (isDark) Color(0xFFB0BEC5) else Color(0xFF546E7A)
                                            )
                                        }
                                    }

                                    if (downloadProgress.isDownloading) {
                                        LinearProgressIndicator(
                                            progress = { downloadProgress.progressPercent / 100f },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(6.dp)
                                                .clip(RoundedCornerShape(3.dp)),
                                            color = Color(0xFF00D2FF),
                                            trackColor = if (isDark) Color(0x33FFFFFF) else Color(0x22000000)
                                        )
                                        Text(
                                            text = "${downloadProgress.downloadedTiles} / ${downloadProgress.totalTiles} karo indirildi (%${downloadProgress.progressPercent})",
                                            fontSize = 10.sp,
                                            color = Color(0xFF00D2FF),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    } else {
                                        Button(
                                            onClick = { repository.mapDownloadManager.startRegionalMapDownload() },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(36.dp)
                                                .testTag("download_regional_map_button"),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (downloadProgress.isCompleted) Color(0xFF2E7D32) else Color(0xFF0091EA)
                                            ),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (downloadProgress.isCompleted) Icons.Default.Refresh else Icons.Default.Download,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = Color.White
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (downloadProgress.isCompleted) "Paketi Yeniden Güncelle" else "Bölgesel Haritayı İndir",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }

                                    Text(
                                        text = "✓ İndirilen harita sıfır gecikmeyle yerel depodan anında açılır.\n✓ İnternet bağlı olduğunda canlı trafik, OSRM rota ve online POI araması eşzamanlı aktif kalır.",
                                        fontSize = 10.sp,
                                        lineHeight = 13.sp,
                                        color = if (isDark) Color(0xFF90A4AE) else Color(0xFF607D8B)
                                    )
                                }
                            }
                        }
                        item {
                            NavToggleItem(
                                title = "Canlı Trafik Yoğunluğu",
                                subtitle = "OSM akış verisi ile güzergah renklendirme",
                                checked = vehicleState.navTrafficEnabled,
                                onCheckedChange = { repository.toggleNavTraffic() },
                                isDark = isDark
                            )
                        }
                        item {
                            NavToggleItem(
                                title = "Radar & Hız Kameraları",
                                subtitle = "500m ve 200m iki aşamalı uyarılar",
                                checked = vehicleState.navSpeedCamerasEnabled,
                                onCheckedChange = { repository.toggleNavSpeedCameras() },
                                isDark = isDark
                            )
                        }
                        item {
                            NavToggleItem(
                                title = "Hızlı Şarj İstasyonları",
                                subtitle = "Haritada 180+ kW istasyonları göster",
                                checked = vehicleState.navShowChargingStations,
                                onCheckedChange = { repository.toggleNavChargingStations() },
                                isDark = isDark
                            )
                        }
                        item {
                            NavToggleItem(
                                title = "Otopark Noktaları",
                                subtitle = "İspark ve AVM otopark dolulukları",
                                checked = vehicleState.navShowParking,
                                onCheckedChange = { repository.toggleNavParking() },
                                isDark = isDark
                            )
                        }
                        item {
                            NavToggleItem(
                                title = "3D Harita & Bina Eğimi",
                                subtitle = "Perspektif görünümü aktif et",
                                checked = vehicleState.nav3DTilt,
                                onCheckedChange = { repository.toggleNav3DTilt() },
                                isDark = isDark
                            )
                        }
                        item {
                            NavToggleItem(
                                title = "Türkçe Sesli Yönlendirme",
                                subtitle = "TTS manevra emirleri ve batarya bilgisi",
                                checked = vehicleState.navVoiceGuidance,
                                onCheckedChange = { repository.toggleNavVoiceGuidance() },
                                isDark = isDark
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun triggerRouteTo(
    title: String,
    point: GeoPoint,
    repository: VehicleRepository,
    scope: kotlinx.coroutines.CoroutineScope
) {
    scope.launch {
        val profile = repository.getVehicleEVProfile()
        // Rota başlangıcı yalnızca GERÇEK GPS konumudur; fix yoksa rota hesaplanmaz
        val gps = repository.telemetryHelper.telemetry.value
        if (!gps.hasGpsFix) {
            android.util.Log.w("MapNavigation", "Rota hesaplanmadı: GPS konumu yok")
            return@launch
        }
        repository.evRoutingManager.calculateRoute(
            start = GeoPoint(gps.currentLatitude, gps.currentLongitude),
            destination = point,
            destinationName = title,
            vehicleProfile = profile
        )
    }
}

/**
 * Hızlı filtre çipi için metin sorgusundan rota: canlı OSM geocoding ile
 * hedef bulunur, GPS fix varsa rota hesaplanır. Sabit koordinat YOK.
 */
private fun triggerRouteSearch(
    query: String,
    repository: VehicleRepository,
    scope: kotlinx.coroutines.CoroutineScope
) {
    scope.launch {
        val gps = repository.telemetryHelper.telemetry.value
        if (!gps.hasGpsFix) {
            android.util.Log.w("MapNavigation", "Rota araması yapılmadı: GPS konumu yok")
            return@launch
        }
        val geocoder = com.example.osmand.search.OsmLiveGeocoder(repository.getContext())
        val results = geocoder.searchLive(query)
        val target = results.firstOrNull() ?: run {
            android.util.Log.w("MapNavigation", "Sonuç bulunamadı: $query")
            return@launch
        }
        triggerRouteTo(target.name, target.point, repository, scope)
    }
}

@Composable
private fun QuickFilterChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isDark: Boolean,
    badgeColor: Color = Color.Transparent,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isDark) Color(0xCC1A212E) else Color(0xEEFFFFFF),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0x334B5E78) else Color(0x22000000)),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (badgeColor != Color.Transparent) badgeColor else (if (isDark) Color(0xFF00D2FF) else Color(0xFF1976D2)),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isDark) Color.White else Color.Black
            )
        }
    }
}

@Composable
private fun NavToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    isDark: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isDark) Color(0x22FFFFFF) else Color(0x0A000000))
            .clickable { onCheckedChange(!checked) }
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = if (isDark) Color.White else Color.Black
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = if (isDark) Color(0xFF8E9DAF) else Color(0xFF6B7280)
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF00D2FF)
            )
        )
    }
}
