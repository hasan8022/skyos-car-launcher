package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveScreen
import com.example.model.DriverProfile
import com.example.model.Gear
import com.example.model.VehicleState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LeftCarCard(
    vehicleState: VehicleState,
    currentProfile: DriverProfile,
    currentStationName: String?,
    isPlayingMusic: Boolean,
    onToggleDoor: (String) -> Unit,
    onToggleTrunk: () -> Unit,
    onToggleHood: () -> Unit,
    onToggleChargePort: () -> Unit,
    onToggle2D3D: () -> Unit,
    onOpenVoiceAssistant: () -> Unit,
    onOpenProfileSelector: () -> Unit,
    onPlayPauseMusic: () -> Unit,
    onNextMusic: () -> Unit,
    onPrevMusic: () -> Unit,
    onOpenMusicScreen: () -> Unit,
    onToggle220V: () -> Unit,
    onToggleDefrostFront: () -> Unit,
    onToggleDefrostRear: () -> Unit,
    onToggleMirrors: () -> Unit,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    var activeMiniCardIndex by remember { mutableIntStateOf(0) }
    val currentTime = remember {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        sdf.format(Date())
    }

    val orbTransition = rememberInfiniteTransition(label = "leftCardOrb")
    val orbGlowScale by orbTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orbGlowScale"
    )

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(if (isDark) Color(0xFF0F1217) else Color(0xFFFFFFFF))
            .padding(top = 4.dp, start = 8.dp, end = 6.dp, bottom = 4.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Car 3D / 2D View
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            CarView(
                vehicleState = vehicleState,
                onToggleDoor = onToggleDoor,
                onToggleTrunk = onToggleTrunk,
                onToggleHood = onToggleHood,
                onToggleChargePort = onToggleChargePort,
                onToggle2D3D = onToggle2D3D,
                isDark = isDark,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Quick action pills row: [Bagaj] [Voice Assistant Orb] [Profile] [10:30] [Steering]
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Bagaj (Trunk button - only enabled in P)
            Row(
                modifier = Modifier
                    .testTag("trunk_pill_button")
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (vehicleState.trunk) Color(0xFFEF4444).copy(alpha = 0.25f)
                        else if (isDark) Color(0xFF1E2638) else Color(0xFFE2E8F0)
                    )
                    .clickable { onToggleTrunk() }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsCar,
                    contentDescription = "Bagaj",
                    tint = if (vehicleState.trunk) Color(0xFFEF4444) else (if (isDark) Color.White else Color(0xFF0F172A)),
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = if (vehicleState.trunk) "Bagaj Açık" else "Bagaj",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (vehicleState.trunk) Color(0xFFEF4444) else (if (isDark) Color.White else Color(0xFF0F172A))
                )
            }

            // Voice Assistant sphere with animated glowing ripple halo
            Box(
                modifier = Modifier
                    .size(42.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer pulsating glow ring
                Box(
                    modifier = Modifier
                        .size((36 * orbGlowScale).dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFF00D2FF).copy(alpha = 0.45f),
                                    Color(0xFFA855F7).copy(alpha = 0.25f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Inner assistant sphere
                Box(
                    modifier = Modifier
                        .testTag("voice_assistant_sphere_btn")
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFF38BDF8),
                                    Color(0xFFA855F7),
                                    Color(0xFFEC4899)
                                )
                            )
                        )
                        .clickable { onOpenVoiceAssistant() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Sesli Asistan",
                        tint = Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }

            // Profile Button [S Sürücü]
            Row(
                modifier = Modifier
                    .testTag("profile_pill_button")
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isDark) Color(0xFF1E2638) else Color(0xFFE2E8F0))
                    .clickable { onOpenProfileSelector() }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0284C7)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentProfile.initial,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Text(
                    text = currentProfile.name,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDark) Color.White else Color(0xFF0F172A)
                )
            }

            // Clock
            Text(
                text = currentTime,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF0F172A)
            )

            // Steering Wheel Icon
            Icon(
                imageVector = Icons.Default.BrightnessAuto,
                contentDescription = "Sürüş Asistanı",
                tint = Color(0xFF0284C7),
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Swipeable / Switchable Mini Cards (Music, Driving Info, Shortcuts, OBD)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (isDark) Color(0xFF141820) else Color(0xFFF8FAFC))
                .padding(10.dp)
        ) {
            when (activeMiniCardIndex) {
                0 -> {
                    // Card 1: Music Mini Player
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenMusicScreen() },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF20283A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = "Müzik",
                                    tint = Color(0xFF00D2FF),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = currentStationName ?: "Müzik",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (isPlayingMusic) "Çalıyor · İnternet Radyosu" else "Kaynak seçmek için dokunun",
                                    fontSize = 11.sp,
                                    color = Color(0xFF9CA3AF),
                                    maxLines = 1
                                )
                            }
                        }

                        // Playback controls
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onPrevMusic, modifier = Modifier.size(28.dp)) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Önceki",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(onClick = onPlayPauseMusic, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (isPlayingMusic) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Oynat/Durdur",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            IconButton(onClick = onNextMusic, modifier = Modifier.size(28.dp)) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Sonraki",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                1 -> {
                    // Card 2: Driving Info & Dynamic Power Bar (Gray = Accel, Green = Regen)
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Sürüş Bilgisi",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF9CA3AF)
                            )
                            Text(
                                text = if (vehicleState.powerKw >= 0) "+${vehicleState.powerKw.toInt()} kW" else "${vehicleState.powerKw.toInt()} kW (Rejen)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (vehicleState.powerKw < 0) Color(0xFF22C55E) else Color(0xFFE5E7EB)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Dynamic Power Line
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(0xFF222938))
                        ) {
                            val fraction = (Math.abs(vehicleState.powerKw) / 150f).coerceIn(0.05f, 1f)
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(fraction)
                                    .background(if (vehicleState.powerKw < 0) Color(0xFF22C55E) else Color(0xFF9CA3AF))
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (vehicleState.avgConsumptionKwhPer100Km >= 0f)
                                    "Tüketim: ${vehicleState.avgConsumptionKwhPer100Km} kWh"
                                else "Tüketim: Veri Yok",
                                fontSize = 11.sp,
                                color = if (vehicleState.avgConsumptionKwhPer100Km >= 0f) Color.White else Color(0xFFF59E0B)
                            )
                            Text(
                                text = "Trip A: —", // Gerçek trip sayacı car_service kalibrasyonu bekliyor
                                fontSize = 11.sp,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    }
                }

                2 -> {
                    // Card 3: Shortcuts (220V, Defog, Mirrors)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ShortcutMiniBtn(
                            title = "220V Priz",
                            isActive = vehicleState.outlet220V,
                            icon = Icons.Default.Power,
                            onClick = onToggle220V
                        )
                        ShortcutMiniBtn(
                            title = "Ön Buğu",
                            isActive = vehicleState.ventDefrostFront,
                            icon = Icons.Default.VerticalAlignTop,
                            onClick = onToggleDefrostFront
                        )
                        ShortcutMiniBtn(
                            title = "Arka Buğu",
                            isActive = vehicleState.ventDefrostRear,
                            icon = Icons.Default.VerticalAlignBottom,
                            onClick = onToggleDefrostRear
                        )
                        ShortcutMiniBtn(
                            title = "Aynalar",
                            isActive = vehicleState.mirrorsFolded,
                            icon = Icons.Default.CompareArrows,
                            onClick = onToggleMirrors
                        )
                    }
                }

                3 -> {
                    // Card 4: OBD Live Telemetry (4 user values)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Gerçek OBD/araç sensörü bağlanana kadar uydurma değer gösterilmez
                        ObdMiniStat("Batarya", "—")
                        ObdMiniStat("12V Akü", "—")
                        ObdMiniStat("Motor", "—")
                        ObdMiniStat("Lastik", "—")
                    }
                }
            }
        }

        // 4 dots indicator for the switchable cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(4) { i ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (activeMiniCardIndex == i) 6.dp else 4.dp)
                        .clip(CircleShape)
                        .background(if (activeMiniCardIndex == i) Color(0xFF00D2FF) else Color(0xFF4B5563))
                        .clickable { activeMiniCardIndex = i }
                )
            }
        }
    }
}

@Composable
fun ShortcutMiniBtn(
    title: String,
    isActive: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isActive) Color(0xFF00D2FF) else Color(0xFF9CA3AF),
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = title,
            fontSize = 10.sp,
            color = if (isActive) Color(0xFF00D2FF) else Color(0xFF9CA3AF),
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun ObdMiniStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 10.sp, color = Color(0xFF8F9CAE))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
