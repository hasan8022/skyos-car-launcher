package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository

data class Contact(val name: String, val phone: String, val isFavorite: Boolean = false)

@Composable
fun PhoneScreen(
    repository: VehicleRepository,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vehicleState by repository.vehicleState.collectAsState()
    var selectedTab by remember { mutableStateOf("Tuşlar") }
    var dialedNumber by remember { mutableStateOf("") }
    var activeCallName by remember { mutableStateOf<String?>(null) }

    val contacts = listOf(
        Contact("Ahmet Yılmaz", "+90 532 111 22 33", isFavorite = true),
        Contact("Mehmet Kaya", "+90 533 444 55 66", isFavorite = true),
        Contact("Ayşe Demir", "+90 542 777 88 99", isFavorite = true),
        Contact("Canan Özkan", "+90 555 123 45 67"),
        Contact("Skywell Servis", "0850 000 00 00", isFavorite = true),
        Contact("Acil Yol Yardım", "112")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1217))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Telefon",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = if (vehicleState.bluetoothConnected) "Bluetooth: ${vehicleState.bluetoothDeviceName} bağlı" else "Bluetooth telefonu bağlı değil",
                    fontSize = 12.sp,
                    color = if (vehicleState.bluetoothConnected) Color(0xFF22C55E) else Color(0xFF8F9CAE)
                )
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E2638))
            ) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs: [Favoriler] [Son aramalar] [Rehber] [Tuşlar]
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF161C26))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("Favoriler", "Son aramalar", "Rehber", "Tuşlar").forEach { tab ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF252E3E) else Color.Transparent)
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = tab,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else Color(0xFF8F9CAE)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Call Banner if call is placed
        if (activeCallName != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF047857))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(imageVector = Icons.Default.PhoneInTalk, contentDescription = null, tint = Color.White)
                    Column {
                        Text(text = "Görüşme Sürüyor: $activeCallName", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(text = "00:42 · Ses araç hoparlöründe", color = Color(0xFFA7F3D0), fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = { activeCallName = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Kapat", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Tab Contents
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                "Tuşlar" -> {
                    // Full Dialpad UI
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Dialed Number Display
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .height(46.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF171D27))
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (dialedNumber.isEmpty()) "Numara girin..." else dialedNumber,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (dialedNumber.isEmpty()) Color(0xFF6B7280) else Color.White
                            )

                            if (dialedNumber.isNotEmpty()) {
                                IconButton(onClick = { dialedNumber = dialedNumber.dropLast(1) }) {
                                    Icon(imageVector = Icons.Default.Backspace, contentDescription = "Sil", tint = Color(0xFF9CA3AF))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Dialpad Buttons (3x4 grid)
                        val keypad = listOf(
                            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                            listOf("*" to "", "0" to "+", "#" to "")
                        )

                        keypad.forEach { row ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                row.forEach { (digit, letters) ->
                                    Box(
                                        modifier = Modifier
                                            .size(width = 72.dp, height = 48.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF1E2638))
                                            .clickable { dialedNumber += digit },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = digit, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            if (letters.isNotEmpty()) {
                                                Text(text = letters, fontSize = 9.sp, color = Color(0xFF8F9CAE))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Green Call Button
                        Box(
                            modifier = Modifier
                                .size(width = 160.dp, height = 46.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF10B981))
                                .clickable {
                                    if (dialedNumber.isNotEmpty()) activeCallName = dialedNumber
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(imageVector = Icons.Default.Phone, contentDescription = "Ara", tint = Color.White)
                                Text(text = "Ara", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                "Rehber", "Favoriler", "Son aramalar" -> {
                    val list = if (selectedTab == "Favoriler") contacts.filter { it.isFavorite } else contacts
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list) { c ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF161C26))
                                    .clickable { activeCallName = c.name }
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF0284C7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = c.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text(text = c.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                        Text(text = c.phone, color = Color(0xFF8F9CAE), fontSize = 12.sp)
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "Ara",
                                    tint = Color(0xFF10B981)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
