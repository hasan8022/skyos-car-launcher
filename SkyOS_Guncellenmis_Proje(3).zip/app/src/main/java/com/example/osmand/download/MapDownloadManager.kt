package com.example.osmand.download

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.example.osmand.tiles.OsmTileEngine
import com.example.osmand.tiles.TileCoord
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class DownloadProgress(
    val isDownloading: Boolean = false,
    val progressPercent: Int = 0,
    val downloadedTiles: Int = 0,
    val totalTiles: Int = 0,
    val statusText: String = "Çevrimdışı paket hazır değil",
    val isCompleted: Boolean = false
)

/**
 * Manages downloading regional offline map packs directly to device storage.
 * Uses official, un-watermarked OpenStreetMap sources and prepares both
 * crisp daytime and automotive night-filtered tiles for zero-latency offline driving.
 */
class MapDownloadManager(
    private val context: Context,
    private val tileEngine: OsmTileEngine
) {
    private val TAG = "MapDownloadManager"
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val _downloadState = MutableStateFlow(DownloadProgress())
    val downloadState: StateFlow<DownloadProgress> = _downloadState.asStateFlow()

    private val diskCacheDir = tileEngine.diskCacheDir

    // Official OpenStreetMap tile mirrors (No API key, No watermarks)
    private val tileMirrors = listOf(
        "https://tile.openstreetmap.org",
        "https://tile.openstreetmap.de",
        "https://a.tile.openstreetmap.fr/osmfr",
        "https://b.tile.openstreetmap.fr/osmfr"
    )

    init {
        // Check if map package was previously downloaded
        val existingTiles = diskCacheDir.listFiles { _, name -> name.endsWith(".png") }?.size ?: 0
        if (existingTiles > 30) {
            _downloadState.value = DownloadProgress(
                isDownloading = false,
                progressPercent = 100,
                downloadedTiles = existingTiles,
                totalTiles = existingTiles,
                statusText = "Marmara Çevrimdışı Haritası Yüklü ($existingTiles Karo)",
                isCompleted = true
            )
        }
    }

    /**
     * Downloads Istanbul & Marmara regional tile pack (Zoom 13, 14, 15)
     * covering key highways, bridges, and city centers directly to local storage.
     */
    fun startRegionalMapDownload() {
        if (_downloadState.value.isDownloading) return

        scope.launch {
            _downloadState.value = DownloadProgress(
                isDownloading = true,
                progressPercent = 5,
                statusText = "OpenStreetMap sunucularına bağlanılıyor..."
            )

            // Define Istanbul & Marmara bounding box coordinates
            val targetTiles = mutableListOf<TileCoord>()

            // Zoom 13 (Metro overview)
            for (x in 4750..4755) {
                for (y in 3056..3062) {
                    targetTiles.add(TileCoord(x, y, 13))
                }
            }

            // Zoom 14 (City arterial streets)
            for (x in 9502..9510) {
                for (y in 6114..6122) {
                    targetTiles.add(TileCoord(x, y, 14))
                }
            }

            // Zoom 15 (Key central hubs: Sultanahmet, Kadıköy, Levent, Maslak)
            for (x in 19006..19018) {
                for (y in 12230..12242) {
                    targetTiles.add(TileCoord(x, y, 15))
                }
            }

            val total = targetTiles.size
            var downloaded = 0

            Log.i(TAG, "Starting regional offline download of $total tiles...")

            for ((index, coord) in targetTiles.withIndex()) {
                val fileNameLight = "${coord.z}_${coord.x}_${coord.y}_light.png"
                val fileLight = File(diskCacheDir, fileNameLight)

                val fileNameDark = "${coord.z}_${coord.x}_${coord.y}_dark.png"
                val fileDark = File(diskCacheDir, fileNameDark)

                // Download raw clean OpenStreetMap tile if not already cached
                if (!fileLight.exists() || fileLight.length() == 0L) {
                    val mirror = tileMirrors[index % tileMirrors.size]
                    val url = "$mirror/${coord.z}/${coord.x}/${coord.y}.png"
                    downloadTileUrl(url, fileLight)
                }

                // If dark tile doesn't exist, generate it locally from the clean light tile
                if (fileLight.exists() && (!fileDark.exists() || fileDark.length() == 0L)) {
                    try {
                        val lightBmp = BitmapFactory.decodeFile(fileLight.absolutePath)
                        if (lightBmp != null) {
                            val darkBmp = tileEngine.applyAutomotiveDarkFilter(lightBmp)
                            FileOutputStream(fileDark).use { out ->
                                darkBmp.compress(Bitmap.CompressFormat.PNG, 90, out)
                            }
                        }
                    } catch (_: Exception) {}
                }

                downloaded++
                val pct = ((downloaded.toFloat() / total) * 100).toInt()

                if (downloaded % 5 == 0 || downloaded == total) {
                    _downloadState.value = DownloadProgress(
                        isDownloading = downloaded < total,
                        progressPercent = pct,
                        downloadedTiles = downloaded,
                        totalTiles = total,
                        statusText = "İndiriliyor: %$pct ($downloaded / $total karo)",
                        isCompleted = downloaded == total
                    )
                }
            }

            _downloadState.value = DownloadProgress(
                isDownloading = false,
                progressPercent = 100,
                downloadedTiles = downloaded,
                totalTiles = total,
                statusText = "Marmara Harita Paketi İndirildi (Tam Çevrimdışı Hazır)",
                isCompleted = true
            )

            Log.i(TAG, "Offline map download completed successfully!")
        }
    }

    private fun downloadTileUrl(url: String, destFile: File): Boolean {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "SkyOS-Automotive-Launcher/2.0 (Linux; Android Car OS)")
                .build()

            val resp = httpClient.newCall(req).execute()
            if (resp.isSuccessful) {
                val bytes = resp.body?.bytes()
                if (bytes != null && bytes.isNotEmpty()) {
                    FileOutputStream(destFile).use { it.write(bytes) }
                    return true
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }
}
