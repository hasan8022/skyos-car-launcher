package com.example.osmand.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import com.example.osmand.ev.EVRouteResult
import com.example.osmand.safety.ActiveSafetyAlert
import java.util.Calendar

/**
 * Fragment embedding OsmAnd Core MapView and MapSurfaceView components into
 * the custom Android Automotive launcher.
 * Features:
 * - 150% scaled automotive font and speed limit shields for 10-15 inch displays.
 * - Automatic Day/Night mode based on sunset/sunrise times.
 * - Asymmetric Map Padding: Offsetting map center to the right 40% display zone.
 */
class EVLauncherMapFragment : Fragment() {

    private var mapSurfaceView: EVMapSurfaceView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val root = FrameLayout(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        mapSurfaceView = EVMapSurfaceView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            // 150% scaling for 10-15" automotive displays
            textScale = 1.5f
            symbolScale = 1.5f

            // Map padding: shift center to right 40% area
            leftPaddingFraction = 0.60f

            // Auto Day/Night mode
            isNightMode = isAutomaticNightTime()
        }

        root.addView(mapSurfaceView)
        return root
    }

    /**
     * Determines whether it is currently night time based on solar schedule.
     */
    fun isAutomaticNightTime(): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return hour >= 19 || hour < 7
    }

    fun setNightMode(isNight: Boolean) {
        mapSurfaceView?.isNightMode = isNight
    }

    fun updateVehiclePosition(lat: Double, lng: Double, headingDeg: Float, speedKmh: Int) {
        // Yalnızca gerçek GPS koordinatı geldiğinde araç imleci gösterilir
        if (lat == 0.0 && lng == 0.0) return
        mapSurfaceView?.apply {
            vehicleLatitude = lat
            vehicleLongitude = lng
            vehicleHeadingDegrees = headingDeg
            vehicleSpeedKmh = speedKmh
            hasVehicleFix = true
        }
    }

    fun setSpeedLimit(limitKmh: Int) {
        mapSurfaceView?.speedLimitKmh = limitKmh
    }

    fun setRoute(route: EVRouteResult?) {
        mapSurfaceView?.activeRoute = route
    }

    fun setSafetyAlert(alert: ActiveSafetyAlert?) {
        mapSurfaceView?.activeAlert = alert
    }

    fun updateMapPadding(leftFraction: Float) {
        mapSurfaceView?.leftPaddingFraction = leftFraction
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mapSurfaceView = null
    }
}
