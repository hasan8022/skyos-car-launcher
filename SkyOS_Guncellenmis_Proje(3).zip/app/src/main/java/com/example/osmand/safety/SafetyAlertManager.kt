package com.example.osmand.safety

import android.content.Context
import android.location.Location
import android.util.Log
import com.example.osmand.ev.GeoPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

enum class SafetyHazardType(val title: String, val defaultSpeedLimit: Int) {
    SPEED_CAMERA("Hız Kamerası / Radar", 70),
    TRAFFIC_BUMP("Kasis / Hız Kesici", 30),
    DANGEROUS_CURVE("Keskin / Tehlikeli Viraj", 50)
}

enum class AlertTriggerStage(val distanceThresholdMeters: Double) {
    APPROACHING_500M(500.0),
    URGENT_200M(200.0),
    CLEARED(0.0)
}

data class SafetyHazardItem(
    val id: String,
    val type: SafetyHazardType,
    val location: GeoPoint,
    val speedLimitKmh: Int = type.defaultSpeedLimit,
    val description: String = ""
)

data class ActiveSafetyAlert(
    val hazard: SafetyHazardItem,
    val stage: AlertTriggerStage,
    val distanceRemainingMeters: Double
)

/**
 * Proximity Safety Alert Manager for scanning active route corridors
 * for speed cameras (highway=speed_camera), speed bumps (traffic_calming=bump),
 * and dangerous curves, emitting 500m and 200m two-stage triggers.
 */
class SafetyAlertManager(private val context: Context? = null) {

    private val TAG = "SafetyAlertManager"

    /**
     * Sabit/kodlanmış tehlike listesi YOK. Tehlikeler (radar, kasis, keskin viraj)
     * canlı OpenStreetMap Overpass API'sinden, aracın o anki konumuna göre çekilir.
     * İnternet yoksa liste boş kalır → uyarı üretilmez (sahte uyarı gösterilmez).
     */
    @Volatile
    private var knownHazards: List<SafetyHazardItem> = emptyList()
    private var lastHazardFetchPoint: GeoPoint? = null
    private var lastHazardFetchTime: Long = 0L

    private val httpClient = okhttp3.OkHttpClient.Builder()
        .connectTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val hazardScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.Dispatchers.IO + kotlinx.coroutines.Job()
    )

    /**
     * Konum belirli mesafe değiştirdiğinde veya 5 dk geçtiğinde canlı
     * tehlike verisini Overpass'ten yeniler. UI thread'i bloklamaz.
     */
    private fun maybeRefreshHazards(currentPoint: GeoPoint) {
        val now = System.currentTimeMillis()
        val last = lastHazardFetchPoint
        val movedEnough = last == null || last.distanceTo(currentPoint) > 1500.0
        val staleEnough = now - lastHazardFetchTime > 300_000L
        if (!movedEnough && !staleEnough) return

        lastHazardFetchPoint = currentPoint
        lastHazardFetchTime = now

        hazardScope.launch {
            try {
                val q = """
                    [out:json][timeout:12];
                    (
                      node["highway"="speed_camera"](around:5000,${currentPoint.latitude},${currentPoint.longitude});
                      node["traffic_calming"="bump"](around:5000,${currentPoint.latitude},${currentPoint.longitude});
                    );
                    out body 30;
                """.trimIndent()
                val body = q.toRequestBody("text/plain".toMediaType())
                val req = okhttp3.Request.Builder()
                    .url("https://overpass-api.de/api/interpreter")
                    .post(body)
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@launch
                    val json = org.json.JSONObject(resp.body?.string() ?: return@launch)
                    val els = json.optJSONArray("elements") ?: return@launch
                    val fresh = mutableListOf<SafetyHazardItem>()
                    for (i in 0 until els.length()) {
                        val el = els.getJSONObject(i)
                        val lat = el.optDouble("lat", Double.NaN)
                        val lon = el.optDouble("lon", Double.NaN)
                        if (lat.isNaN() || lon.isNaN()) continue
                        val tags = el.optJSONObject("tags")
                        val isCamera = tags?.optString("highway") == "speed_camera"
                        val type = if (isCamera) SafetyHazardType.SPEED_CAMERA else SafetyHazardType.TRAFFIC_BUMP
                        val maxspeed = tags?.optString("maxspeed", "")?.filter { it.isDigit() }?.toIntOrNull()
                            ?: if (isCamera) 70 else 30
                        val label = tags?.optString("name", "")
                            ?.ifEmpty { if (isCamera) "Hız Kamerası" else "Kasis" }
                            ?: if (isCamera) "Hız Kamerası" else "Kasis"
                        fresh.add(SafetyHazardItem("osm_${el.optLong("id", i.toLong())}", type, GeoPoint(lat, lon), maxspeed, label))
                    }
                    if (fresh.isNotEmpty()) {
                        knownHazards = fresh
                        android.util.Log.i(TAG, "Canlı OSM tehlike verisi güncellendi: ${fresh.size} nokta")
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "Tehlike verisi çekilemedi (çevrimdışı?): ${e.message}")
            }
        }
    }

    // Tracks previously triggered stages to prevent repetitive redundant alerts
    private val triggeredStages = mutableMapOf<String, AlertTriggerStage>()

    private val _currentAlert = MutableStateFlow<ActiveSafetyAlert?>(null)
    val currentAlert: StateFlow<ActiveSafetyAlert?> = _currentAlert.asStateFlow()

    private val _alertEvents = MutableSharedFlow<ActiveSafetyAlert>(replay = 0)
    val alertEvents: SharedFlow<ActiveSafetyAlert> = _alertEvents.asSharedFlow()

    // External listener callback
    var onAlertTriggered: ((ActiveSafetyAlert) -> Unit)? = null

    /**
     * Updates proximity scanning based on the current vehicle GPS coordinate.
     */
    fun updateVehicleLocation(currentLat: Double, currentLng: Double, currentSpeedKmh: Int) {
        val currentPoint = GeoPoint(currentLat, currentLng)
        maybeRefreshHazards(currentPoint)
        var nearestActiveAlert: ActiveSafetyAlert? = null
        var minDistance = Double.MAX_VALUE

        for (hazard in knownHazards) {
            val dist = currentPoint.distanceTo(hazard.location)
            val prevStage = triggeredStages[hazard.id]

            when {
                dist <= 200.0 -> {
                    if (prevStage != AlertTriggerStage.URGENT_200M) {
                        triggeredStages[hazard.id] = AlertTriggerStage.URGENT_200M
                        val alert = ActiveSafetyAlert(hazard, AlertTriggerStage.URGENT_200M, dist)
                        Log.i(TAG, "URGENT 200m Stage Triggered: ${hazard.type.title} at ${dist.toInt()}m")
                        _alertEvents.tryEmit(alert)
                        onAlertTriggered?.invoke(alert)
                    }
                    if (dist < minDistance) {
                        minDistance = dist
                        nearestActiveAlert = ActiveSafetyAlert(hazard, AlertTriggerStage.URGENT_200M, dist)
                    }
                }
                dist <= 500.0 -> {
                    if (prevStage == null || prevStage == AlertTriggerStage.CLEARED) {
                        triggeredStages[hazard.id] = AlertTriggerStage.APPROACHING_500M
                        val alert = ActiveSafetyAlert(hazard, AlertTriggerStage.APPROACHING_500M, dist)
                        Log.i(TAG, "APPROACHING 500m Stage Triggered: ${hazard.type.title} at ${dist.toInt()}m")
                        _alertEvents.tryEmit(alert)
                        onAlertTriggered?.invoke(alert)
                    }
                    if (dist < minDistance) {
                        minDistance = dist
                        nearestActiveAlert = ActiveSafetyAlert(hazard, AlertTriggerStage.APPROACHING_500M, dist)
                    }
                }
                dist > 600.0 && prevStage != null -> {
                    // Vehicle has moved away or passed the hazard
                    triggeredStages.remove(hazard.id)
                }
            }
        }

        _currentAlert.value = nearestActiveAlert
    }

    fun dismissCurrentAlert() {
        _currentAlert.value = null
    }
}
