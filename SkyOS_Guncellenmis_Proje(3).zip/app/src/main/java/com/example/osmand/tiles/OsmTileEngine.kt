package com.example.osmand.tiles

import android.content.Context
import android.graphics.*
import android.util.Log
import android.util.LruCache
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.*

data class TileCoord(val x: Int, val y: Int, val z: Int)

/**
 * High-Performance OpenStreetMap Tile Engine.
 * Features:
 * 1. 100% Free, Keyless, Unrestricted Official OpenStreetMap Tile Source (Zero "API KEY REQUIRED" watermarks).
 * 2. Real-time Automotive Dark Mode filter (Desaturates + inverts luminance to luxury cockpit navy/slate).
 * 3. Multi-level caching (16 MB in-memory LRU cache + persistent local disk cache in osm_tiles_v2).
 * 4. Automatic clean-up of legacy watermarked tile caches.
 */
class OsmTileEngine(private val context: Context) {

    private val TAG = "OsmTileEngine"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // 16 MB memory cache for instant tile delivery
    private val memoryCache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount
        }
    }

    val diskCacheDir = File(context.cacheDir, "osm_tiles_v2").apply { mkdirs() }
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Pure OpenStreetMap official and regional mirrors (No API key, No watermarks)
    private val tileMirrors = listOf(
        "https://tile.openstreetmap.org",
        "https://tile.openstreetmap.de",
        "https://a.tile.openstreetmap.fr/osmfr",
        "https://b.tile.openstreetmap.fr/osmfr",
        "https://c.tile.openstreetmap.fr/osmfr"
    )
    private var mirrorIndex = 0

    init {
        // Clean up legacy watermarked cache from earlier CartoDB attempts
        scope.launch {
            try {
                val legacyCache = File(context.cacheDir, "osm_tiles")
                if (legacyCache.exists()) {
                    legacyCache.deleteRecursively()
                    Log.i(TAG, "Legacy watermarked osm_tiles cache purged successfully.")
                }
            } catch (_: Exception) {}
        }
    }

    fun getTileCoord(lat: Double, lon: Double, zoom: Int): TileCoord {
        val latRad = Math.toRadians(lat)
        val n = 2.0.pow(zoom)
        val x = ((lon + 180.0) / 360.0 * n).toInt()
        val y = ((1.0 - asinh(tan(latRad)) / Math.PI) / 2.0 * n).toInt()
        return TileCoord(x, y, zoom)
    }

    fun tileToLon(x: Int, z: Int): Double = x.toDouble() / 2.0.pow(z) * 360.0 - 180.0

    fun tileToLat(y: Int, z: Int): Double {
        val n = Math.PI - 2.0 * Math.PI * y.toDouble() / 2.0.pow(z)
        return Math.toDegrees(atan(sinh(n)))
    }

    fun getCachedTile(coord: TileCoord, isDark: Boolean): Bitmap? {
        val key = "${coord.z}_${coord.x}_${coord.y}_${if (isDark) "dark" else "light"}"
        val inMem = memoryCache.get(key)
        if (inMem != null && !inMem.isRecycled) return inMem

        // Quick synchronous disk check
        val fileName = "${coord.z}_${coord.x}_${coord.y}_${if (isDark) "dark" else "light"}.png"
        val diskFile = File(diskCacheDir, fileName)
        if (diskFile.exists() && diskFile.length() > 0) {
            try {
                val bmp = BitmapFactory.decodeFile(diskFile.absolutePath)
                if (bmp != null) {
                    memoryCache.put(key, bmp)
                    return bmp
                }
            } catch (_: Exception) {}
        }
        return null
    }

    fun loadTileAsync(
        coord: TileCoord,
        isDark: Boolean,
        onLoaded: (Bitmap) -> Unit
    ) {
        val key = "${coord.z}_${coord.x}_${coord.y}_${if (isDark) "dark" else "light"}"

        val inMemory = memoryCache.get(key)
        if (inMemory != null && !inMemory.isRecycled) {
            onLoaded(inMemory)
            return
        }

        scope.launch {
            val bitmap = getOrDownloadTile(coord, isDark)
            if (bitmap != null) {
                memoryCache.put(key, bitmap)
                withContext(Dispatchers.Main) {
                    onLoaded(bitmap)
                }
            }
        }
    }

    private fun getOrDownloadTile(coord: TileCoord, isDark: Boolean): Bitmap? {
        val targetMode = if (isDark) "dark" else "light"
        val fileName = "${coord.z}_${coord.x}_${coord.y}_$targetMode.png"
        val diskFile = File(diskCacheDir, fileName)

        // 1. Check Local Pre-downloaded Disk Storage
        if (diskFile.exists() && diskFile.length() > 0) {
            try {
                val bmp = BitmapFactory.decodeFile(diskFile.absolutePath)
                if (bmp != null) return bmp
            } catch (_: Exception) {
                diskFile.delete()
            }
        }

        // 2. If requesting dark, but we already have light on disk, convert it locally with zero network!
        if (isDark) {
            val lightFile = File(diskCacheDir, "${coord.z}_${coord.x}_${coord.y}_light.png")
            if (lightFile.exists() && lightFile.length() > 0) {
                try {
                    val lightBmp = BitmapFactory.decodeFile(lightFile.absolutePath)
                    if (lightBmp != null) {
                        val darkBmp = applyAutomotiveDarkFilter(lightBmp)
                        saveBitmapToDisk(darkBmp, diskFile)
                        return darkBmp
                    }
                } catch (_: Exception) {}
            }
        }

        // 3. Fetch clean, un-watermarked OpenStreetMap tile from official mirrors
        val startIndex = synchronized(this) {
            val idx = mirrorIndex % tileMirrors.size
            mirrorIndex++
            idx
        }

        for (i in tileMirrors.indices) {
            val mirrorBase = tileMirrors[(startIndex + i) % tileMirrors.size]
            val url = "$mirrorBase/${coord.z}/${coord.x}/${coord.y}.png"

            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "SkyOS-Automotive-Launcher/2.0 (Linux; Android Car OS)")
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val bytes = response.body?.bytes()
                    if (bytes != null && bytes.isNotEmpty()) {
                        val rawBmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (rawBmp != null) {
                            // Always save the raw clean light tile
                            val lightFile = File(diskCacheDir, "${coord.z}_${coord.x}_${coord.y}_light.png")
                            if (!lightFile.exists()) {
                                saveBytesToDisk(bytes, lightFile)
                            }

                            if (isDark) {
                                val darkBmp = applyAutomotiveDarkFilter(rawBmp)
                                saveBitmapToDisk(darkBmp, diskFile)
                                return darkBmp
                            } else {
                                return rawBmp
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Try next OSM mirror
            }
        }

        // 4. Fallback: High-contrast native vector street grid so screen is never blank
        return generateVectorFallbackTile(coord, isDark)
    }

    private fun saveBytesToDisk(bytes: ByteArray, file: File) {
        try {
            FileOutputStream(file).use { it.write(bytes) }
        } catch (_: Exception) {}
    }

    private fun saveBitmapToDisk(bmp: Bitmap, file: File) {
        try {
            FileOutputStream(file).use { out ->
                bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            }
        } catch (_: Exception) {}
    }

    /**
     * Converts clean OpenStreetMap tiles into a luxury automotive cockpit night theme:
     * - Desaturates daytime beige/yellow tones to 18%
     * - Inverts luminance to deep charcoal/navy (#0E1524)
     * - Renders roads and avenues in crisp contrasting steel/blue
     * - Renders street names and numbers in legible silver/white
     * - 100% free of any watermark or third-party restriction!
     */
    fun applyAutomotiveDarkFilter(src: Bitmap): Bitmap {
        val dest = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        // Step 1: Desaturate to 18% to remove daytime yellow/beige terrain
        val satMatrix = ColorMatrix().apply { setSaturation(0.18f) }

        // Step 2: Invert luminance and tint to luxury automotive night cockpit (#0E1524)
        val darkTintMatrix = ColorMatrix(floatArrayOf(
            -0.82f,  0f,     0f,     0f, 210f,
             0f,    -0.82f,  0f,     0f, 218f,
             0f,     0f,    -0.82f,  0f, 240f,
             0f,     0f,     0f,     1f,   0f
        ))
        satMatrix.postConcat(darkTintMatrix)

        paint.colorFilter = ColorMatrixColorFilter(satMatrix)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    /**
     * Generates a crisp local vector raster tile with road lines and street grid
     * if network is completely unreachable and tile is not yet cached.
     */
    private fun generateVectorFallbackTile(coord: TileCoord, isDark: Boolean): Bitmap {
        val size = 256
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        val canvas = Canvas(bitmap)

        val bgColor = if (isDark) Color.parseColor("#10151E") else Color.parseColor("#EAEFF5")
        canvas.drawColor(bgColor)

        val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = if (isDark) Color.parseColor("#1E2A3A") else Color.parseColor("#FFFFFF")
            strokeWidth = 10f
        }

        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = if (isDark) Color.parseColor("#151D28") else Color.parseColor("#DDE3EA")
            strokeWidth = 2f
        }

        canvas.drawRect(0f, 0f, 256f, 256f, gridPaint)
        canvas.drawLine(0f, 128f, 256f, 128f, roadPaint)
        canvas.drawLine(128f, 0f, 128f, 256f, roadPaint)

        return bitmap
    }

    fun clearCache() {
        memoryCache.evictAll()
        scope.launch {
            diskCacheDir.deleteRecursively()
            diskCacheDir.mkdirs()
        }
    }
}
