package com.example.osmand.ev

import android.content.Context
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import com.example.osmand.nativecore.OsmAndNativeCore
import com.example.osmand.routing.ManeuverStep
import com.example.osmand.routing.OsrmLiveRoutingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlin.math.*

enum class SlopeCategory(val colorHex: Int, val label: String) {
    REGEN_DOWNHILL(0xFF00E676.toInt(), "Rejenerasyon (Yeşil)"),
    NOMINAL_FLAT(0xFF00D2FF.toInt(), "Nominal (Mavi)"),
    MODERATE_UPHILL(0xFFFF9100.toInt(), "Yokuş (Turuncu)"),
    STEEP_UPHILL(0xFFFF1744.toInt(), "Dik Tırmanış (Kırmızı)")
}

data class GeoPoint(val latitude: Double, val longitude: Double, val altitudeMeters: Double = 30.0) {
    fun distanceTo(other: GeoPoint): Double {
        val r = 6371000.0 // Earth radius in meters
        val lat1 = Math.toRadians(latitude)
        val lat2 = Math.toRadians(other.latitude)
        val dLat = Math.toRadians(other.latitude - latitude)
        val dLon = Math.toRadians(other.longitude - longitude)
        val a = sin(dLat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}

data class RouteSegment(
    val start: GeoPoint,
    val end: GeoPoint,
    val distanceMeters: Double,
    val slopePercent: Double,
    val energyWh: Float,
    val slopeCategory: SlopeCategory
)

data class ChargingWaypoint(
    val name: String,
    val location: GeoPoint,
    val operator: String,
    val powerKw: Int,
    val plugTypes: List<PlugType>,
    val addedAutomatically: Boolean = true,
    val estimatedChargeTimeMin: Int = 25
)

data class EVRouteResult(
    val destinationName: String,
    val destinationPoint: GeoPoint,
    val totalDistanceMeters: Double,
    val totalDurationSeconds: Long,
    val totalEnergyWh: Double,
    val arrivalSoCPercent: Float,
    val requiredChargeStops: List<ChargingWaypoint>,
    val segments: List<RouteSegment>,
    val pathCoordinates: List<GeoPoint>,
    val maneuverSteps: List<ManeuverStep> = emptyList()
)

/**
 * Manages EV route calculation with real live OSRM routing,
 * out-of-range charging station insertion, arrival battery prediction,
 * and dynamic slope/regen polyline coloring.
 */
class EVRoutingManager(private val context: Context) {

    private val TAG = "EVRoutingManager"

    private val osrmService = OsrmLiveRoutingService()

    private val _activeRoute = MutableStateFlow<EVRouteResult?>(null)
    val activeRoute: StateFlow<EVRouteResult?> = _activeRoute.asStateFlow()

    private val _isCalculating = MutableStateFlow(false)
    val isCalculating: StateFlow<Boolean> = _isCalculating.asStateFlow()

    /**
     * Yarı yoldaki şarj istasyonlarını CANLI OpenStreetMap Overpass API'sinden çeker.
     * Sabit/kodlanmış istasyon listesi YOK — internet yoksa boş liste döner,
     * menzil yetmezliği durumunda "şarj istasyonu bulunamadı" bilgisi verilir.
     */
    private suspend fun fetchLiveChargingStationsNear(
        center: GeoPoint,
        radiusMeters: Int = 40000
    ): List<ChargingWaypoint> = withContext(Dispatchers.IO) {
        try {
            val query = """
                [out:json][timeout:15];
                node["amenity"="charging_station"](around:$radiusMeters,${center.latitude},${center.longitude});
                out body 20;
            """.trimIndent()
            val body = query.toRequestBody("text/plain".toMediaType())
            val request = Request.Builder()
                .url("https://overpass-api.de/api/interpreter")
                .post(body)
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()
                val json = JSONObject(response.body?.string() ?: return@withContext emptyList())
                val elements = json.optJSONArray("elements") ?: return@withContext emptyList()
                val stations = mutableListOf<ChargingWaypoint>()
                for (i in 0 until elements.length()) {
                    val el = elements.getJSONObject(i)
                    val lat = el.optDouble("lat", Double.NaN)
                    val lon = el.optDouble("lon", Double.NaN)
                    if (lat.isNaN() || lon.isNaN()) continue
                    val tags = el.optJSONObject("tags") ?: continue
                    val name = tags.optString("name", "").ifEmpty {
                        tags.optString("operator", "Şarj İstasyonu")
                    }
                    val operator = tags.optString("operator", "Bilinmiyor")
                    val powerKw = tags.optString("socket:type2:output", "")
                        .filter { it.isDigit() }.take(3).toIntOrNull() ?: 50
                    stations.add(
                        ChargingWaypoint(
                            name = name,
                            location = GeoPoint(lat, lon, 0.0),
                            operator = operator,
                            powerKw = powerKw.coerceIn(3, 350),
                            plugTypes = listOf(PlugType.CCS, PlugType.TYPE_2)
                        )
                    )
                }
                stations
            }
        } catch (e: Exception) {
            Log.w(TAG, "Canlı şarj istasyonu çekilemedi: ${e.message}")
            emptyList()
        }
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /**
     * Calculates an EV optimized route from start to destination:
     * 1. Fetches real driving route from OpenStreetMap OSRM server.
     * 2. Computes dynamic elevation slopes and energy consumption.
     * 3. Analyzes battery SoC and auto-inserts charging stations if out-of-range.
     */
    suspend fun calculateRoute(
        start: GeoPoint,
        destination: GeoPoint,
        destinationName: String,
        vehicleProfile: EVVehicleProfile
    ): EVRouteResult = withContext(Dispatchers.Default) {
        _isCalculating.value = true
        try {
            // Attempt live OpenStreetMap OSRM route fetch
            val liveRoute = osrmService.fetchLiveDrivingRoute(start, destination)

            val pathCoords = if (liveRoute != null && liveRoute.pathCoordinates.size >= 2) {
                liveRoute.pathCoordinates
            } else {
                // Fallback geometry generator
                val directDistanceMeters = start.distanceTo(destination)
                val steps = 35
                val list = mutableListOf<GeoPoint>()
                for (i in 0..steps) {
                    val fraction = i.toDouble() / steps
                    val lat = start.latitude + (destination.latitude - start.latitude) * fraction
                    val lon = start.longitude + (destination.longitude - start.longitude) * fraction
                    val elev = 25.0 + sin(fraction * Math.PI * 3) * 65.0 + (fraction * 40.0)
                    list.add(GeoPoint(lat, lon, elev))
                }
                list
            }

            val routeDistanceMeters = liveRoute?.totalDistanceMeters ?: (start.distanceTo(destination) * 1.28)
            val durationSec = liveRoute?.totalDurationSeconds ?: (((routeDistanceMeters / 1000.0) / 55.0) * 3600.0).toLong()

            // Build segments with dynamic slope and energy calculations
            val segments = mutableListOf<RouteSegment>()
            var totalEnergyWh = 0.0

            for (i in 0 until pathCoords.size - 1) {
                val p1 = pathCoords[i]
                val p2 = pathCoords[i + 1]
                val segDist = p1.distanceTo(p2)
                val deltaH = p2.altitudeMeters - p1.altitudeMeters
                val slopePercent = if (segDist > 0.1) (deltaH / segDist) * 100.0 else 0.0

                val segEnergyWh = OsmAndNativeCore.calculateSegmentEnergy(
                    distanceMeters = segDist,
                    elevationStartMeters = p1.altitudeMeters,
                    elevationEndMeters = p2.altitudeMeters,
                    vehicleWeightKg = vehicleProfile.vehicleWeightKg,
                    regenEfficiency = vehicleProfile.regenEfficiency
                )
                totalEnergyWh += segEnergyWh

                val category = when {
                    slopePercent < -1.5 -> SlopeCategory.REGEN_DOWNHILL
                    slopePercent <= 1.5 -> SlopeCategory.NOMINAL_FLAT
                    slopePercent <= 4.0 -> SlopeCategory.MODERATE_UPHILL
                    else -> SlopeCategory.STEEP_UPHILL
                }

                segments.add(
                    RouteSegment(
                        start = p1,
                        end = p2,
                        distanceMeters = segDist,
                        slopePercent = slopePercent,
                        energyWh = segEnergyWh,
                        slopeCategory = category
                    )
                )
            }

            // Menzil Yetmezlik Analizi (Out-of-Range Analysis):
            val maxRangeKm = vehicleProfile.calculateNominalRangeKm()
            val totalDistanceKm = routeDistanceMeters / 1000.0
            val requiredStops = mutableListOf<ChargingWaypoint>()

            if (totalDistanceKm > (maxRangeKm * 0.85)) {
                val halfwayPoint = pathCoords[pathCoords.size / 2]
                // Canlı OSM Overpass'ten yarı yol çevresindeki GERÇEK şarj istasyonları
                val liveStations = fetchLiveChargingStationsNear(halfwayPoint)
                val matchingStations = liveStations.filter { station ->
                    station.plugTypes.any { plug -> vehicleProfile.supportedPlugTypes.contains(plug) }
                }
                val bestStation = matchingStations.minByOrNull { it.location.distanceTo(halfwayPoint) }
                if (bestStation != null) {
                    requiredStops.add(bestStation)
                    Log.i(TAG, "Out-of-range ($totalDistanceKm km). Canlı şarj durağı: ${bestStation.name}")
                } else {
                    Log.w(TAG, "Out-of-range ($totalDistanceKm km) ama canlı şarj istasyonu bulunamadı — durak eklenmedi")
                }
            }

            // Varış Şarj Tahmini (Arrival SoC Prediction):
            val remainingKwh = vehicleProfile.remainingEnergyKwh()
            val consumedKwh = totalEnergyWh / 1000.0
            val arrivalKwh = (remainingKwh - consumedKwh).coerceAtLeast(0.0)
            val arrivalSoC = ((arrivalKwh / vehicleProfile.batteryCapacityKwh) * 100.0).toFloat().coerceIn(0f, 100f)

            val result = EVRouteResult(
                destinationName = destinationName,
                destinationPoint = destination,
                totalDistanceMeters = routeDistanceMeters,
                totalDurationSeconds = durationSec,
                totalEnergyWh = totalEnergyWh,
                arrivalSoCPercent = arrivalSoC,
                requiredChargeStops = requiredStops,
                segments = segments,
                pathCoordinates = pathCoords,
                maneuverSteps = liveRoute?.steps ?: listOf(
                    ManeuverStep("Yola çıkın ve güzergah boyunca ilerleyin", "depart", "straight", routeDistanceMeters, durationSec.toDouble(), start)
                )
            )

            _activeRoute.value = result
            result
        } finally {
            _isCalculating.value = false
        }
    }

    fun clearRoute() {
        _activeRoute.value = null
    }
}
