package com.example.osmand.ev

enum class PlugType(val label: String, val maxKw: Int) {
    CCS("CCS Combo 2", 350),
    TYPE_2("Type 2 Mennekes", 22),
    CHADEMO("CHAdeMO", 50),
    GB_T("GB/T", 120),
    TESLA_NACS("NACS", 250);

    fun isCompatibleWith(stationPlug: String): Boolean {
        val s = stationPlug.lowercase()
        return when (this) {
            CCS -> s.contains("ccs") || s.contains("combo") || s.contains("dc")
            TYPE_2 -> s.contains("type2") || s.contains("type 2") || s.contains("mennekes") || s.contains("ac")
            CHADEMO -> s.contains("chademo")
            GB_T -> s.contains("gbt") || s.contains("gb/t")
            TESLA_NACS -> s.contains("nacs") || s.contains("tesla")
        }
    }
}

/**
 * Data class representing the EV Vehicle battery, powertrain, and charging characteristics.
 */
data class EVVehicleProfile(
    val batteryCapacityKwh: Double = 72.0,      // Total nominal usable capacity (e.g. 72.0 kWh)
    val currentSoCPercent: Float = 78.0f,       // Current State of Charge (0-100%)
    val averageConsumptionWhPerKm: Double = 168.0, // Baseline energy consumption Wh/km (~16.8 kWh/100km)
    val supportedPlugTypes: List<PlugType> = listOf(PlugType.CCS, PlugType.TYPE_2),
    val vehicleWeightKg: Double = 1950.0,       // Vehicle curb weight + driver
    val regenEfficiency: Double = 0.82,         // Kinematic recovery efficiency factor
    val minSafeSoCPercent: Float = 12.0f        // Minimum reserve buffer before requiring charge
) {
    /**
     * Total remaining energy available in the traction battery.
     */
    fun remainingEnergyKwh(): Double {
        return (currentSoCPercent / 100.0) * batteryCapacityKwh
    }

    /**
     * Usable energy before reaching critical reserve buffer (e.g. 12% SoC).
     */
    fun usableEnergyToReserveKwh(): Double {
        val usableSoC = (currentSoCPercent - minSafeSoCPercent).coerceAtLeast(0f)
        return (usableSoC / 100.0) * batteryCapacityKwh
    }

    /**
     * Estimated remaining distance (km) under standard conditions.
     */
    fun calculateNominalRangeKm(): Double {
        val kwh = remainingEnergyKwh()
        return if (averageConsumptionWhPerKm > 0) {
            (kwh * 1000.0) / averageConsumptionWhPerKm
        } else 0.0
    }

    /**
     * Dynamic range calculation factoring in ambient temperature (HVAC overhead) and vehicle speed.
     */
    fun calculateDynamicRangeKm(speedKmh: Int, ambientTempC: Int): Double {
        // Temperature penalty factor: optimal at ~22°C, decreases in sub-zero or extreme heat
        val tempDelta = kotlin.math.abs(ambientTempC - 22)
        val tempEfficiencyFactor = (1.0 - (tempDelta * 0.012)).coerceIn(0.70, 1.0)

        // Speed aerodynamic drag factor (exponential over 90 km/h)
        val speedFactor = when {
            speedKmh <= 60 -> 0.90  // Low speed urban
            speedKmh <= 90 -> 1.00  // Optimal rural
            speedKmh <= 120 -> 1.25 // Highway cruise
            else -> 1.50           // High-speed autobahn
        }

        val dynamicConsumptionWhPerKm = averageConsumptionWhPerKm * speedFactor / tempEfficiencyFactor
        val usableKwh = remainingEnergyKwh()
        return (usableKwh * 1000.0) / dynamicConsumptionWhPerKm
    }
}
