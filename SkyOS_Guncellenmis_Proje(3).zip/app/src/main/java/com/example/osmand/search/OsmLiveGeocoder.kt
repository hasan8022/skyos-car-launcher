package com.example.osmand.search

import android.content.Context
import android.util.Log
import com.example.osmand.ev.GeoPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class LiveGeocodeResult(
    val placeId: Long,
    val name: String,
    val formattedAddress: String,
    val point: GeoPoint,
    val category: String,
    val isChargingStation: Boolean = false
)

/**
 * Real Live OpenStreetMap Geocoding and POI search client using the official Nominatim API.
 * Fetches real places, street names, charging hubs, and businesses directly from OpenStreetMap servers.
 */
class OsmLiveGeocoder(private val context: Context) {

    private val TAG = "OsmLiveGeocoder"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val offlineFallback = OsmAndOfflineSearchEngine(context)

    suspend fun searchLive(query: String): List<LiveGeocodeResult> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()

        try {
            val encodedQuery = URLEncoder.encode(trimmed, "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search?format=json&q=$encodedQuery&addressdetails=1&limit=8&countrycodes=tr"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "SkyOS-Automotive-Launcher/1.0 (Android; info@skyos.ev)")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val jsonString = response.body?.string() ?: ""
                val jsonArray = JSONArray(jsonString)
                val results = mutableListOf<LiveGeocodeResult>()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val lat = obj.optDouble("lat", 0.0)
                    val lon = obj.optDouble("lon", 0.0)
                    val displayName = obj.optString("display_name", "")
                    val placeId = obj.optLong("place_id", i.toLong())
                    val categoryClass = obj.optString("class", "place")
                    val type = obj.optString("type", "")

                    // Extract clean title from first part of comma-separated name
                    val parts = displayName.split(",")
                    val shortTitle = parts.firstOrNull()?.trim() ?: displayName
                    val subtitle = parts.drop(1).take(2).joinToString(", ").trim()

                    val isCharging = categoryClass == "amenity" && (type == "charging_station" || type.contains("charging")) ||
                            displayName.contains("şarj", ignoreCase = true) ||
                            displayName.contains("charging", ignoreCase = true)

                    results.add(
                        LiveGeocodeResult(
                            placeId = placeId,
                            name = shortTitle,
                            formattedAddress = if (subtitle.isNotEmpty()) subtitle else displayName,
                            point = GeoPoint(lat, lon),
                            category = if (isCharging) "charging" else categoryClass,
                            isChargingStation = isCharging
                        )
                    )
                }

                if (results.isNotEmpty()) {
                    Log.i(TAG, "Live Nominatim search for '$query' returned ${results.size} real locations.")
                    return@withContext results
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Live Nominatim search failed (${e.message}), switching to offline engine.")
        }

        // Fallback to offline index
        val local = offlineFallback.search(query)
        local.map {
            LiveGeocodeResult(
                placeId = it.title.hashCode().toLong(),
                name = it.title,
                formattedAddress = it.subtitle,
                point = it.point,
                category = it.category,
                isChargingStation = it.isChargingStation
            )
        }
    }
}
