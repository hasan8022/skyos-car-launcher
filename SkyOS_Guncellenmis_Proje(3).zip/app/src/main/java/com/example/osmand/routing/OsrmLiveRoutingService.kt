package com.example.osmand.routing

import android.util.Log
import com.example.osmand.ev.GeoPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.*

data class ManeuverStep(
    val instruction: String,
    val maneuverType: String,
    val modifier: String,
    val distanceMeters: Double,
    val durationSeconds: Double,
    val location: GeoPoint
)

data class LiveRouteData(
    val totalDistanceMeters: Double,
    val totalDurationSeconds: Long,
    val pathCoordinates: List<GeoPoint>,
    val steps: List<ManeuverStep>
)

/**
 * Real Live Routing Service querying the global OpenStreetMap OSRM routing server.
 * Returns genuine road network geometry, driving distances, and turn-by-turn maneuvers.
 */
class OsrmLiveRoutingService {

    private val TAG = "OsrmLiveRouting"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetchLiveDrivingRoute(
        start: GeoPoint,
        destination: GeoPoint
    ): LiveRouteData? = withContext(Dispatchers.IO) {
        val url = "https://router.project-osrm.org/route/v1/driving/" +
                "${start.longitude},${start.latitude};" +
                "${destination.longitude},${destination.latitude}" +
                "?overview=full&geometries=geojson&steps=true"

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "SkyOS-Automotive-Launcher/1.0 (Android; info@skyos.ev)")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: return@withContext null
                val root = JSONObject(body)
                val code = root.optString("code")
                if (code == "Ok") {
                    val routesArray = root.getJSONArray("routes")
                    if (routesArray.length() > 0) {
                        val primaryRoute = routesArray.getJSONObject(0)
                        val totalDistance = primaryRoute.optDouble("distance", 0.0)
                        val totalDuration = primaryRoute.optDouble("duration", 0.0).toLong()

                        // 1. Decode real GeoJSON path coordinates
                        val geometryObj = primaryRoute.getJSONObject("geometry")
                        val coordsArray = geometryObj.getJSONArray("coordinates")
                        val pathCoords = mutableListOf<GeoPoint>()

                        for (i in 0 until coordsArray.length()) {
                            val coordPair = coordsArray.getJSONArray(i)
                            val lon = coordPair.getDouble(0)
                            val lat = coordPair.getDouble(1)
                            // Synthetic realistic altitude variation based on coordinate hash for terrain
                            val alt = 25.0 + sin(lat * 100.0) * 35.0
                            pathCoords.add(GeoPoint(lat, lon, alt))
                        }

                        // 2. Decode turn-by-turn steps
                        val stepsList = mutableListOf<ManeuverStep>()
                        val legsArray = primaryRoute.optJSONArray("legs")
                        if (legsArray != null && legsArray.length() > 0) {
                            val leg = legsArray.getJSONObject(0)
                            val rawSteps = leg.optJSONArray("steps")
                            if (rawSteps != null) {
                                for (j in 0 until rawSteps.length()) {
                                    val stepObj = rawSteps.getJSONObject(j)
                                    val dist = stepObj.optDouble("distance", 0.0)
                                    val dur = stepObj.optDouble("duration", 0.0)
                                    val name = stepObj.optString("name", "")

                                    val maneuverObj = stepObj.optJSONObject("maneuver")
                                    val type = maneuverObj?.optString("type", "turn") ?: "turn"
                                    val modifier = maneuverObj?.optString("modifier", "") ?: ""
                                    val stepLocArray = maneuverObj?.optJSONArray("location")
                                    val stepPoint = if (stepLocArray != null) {
                                        GeoPoint(stepLocArray.getDouble(1), stepLocArray.getDouble(0))
                                    } else start

                                    val trInstruction = formatTurkishManeuver(type, modifier, name, dist)
                                    stepsList.add(
                                        ManeuverStep(
                                            instruction = trInstruction,
                                            maneuverType = type,
                                            modifier = modifier,
                                            distanceMeters = dist,
                                            durationSeconds = dur,
                                            location = stepPoint
                                        )
                                    )
                                }
                            }
                        }

                        Log.i(TAG, "Fetched live OSRM route: ${totalDistance.toInt()} meters, ${pathCoords.size} path points, ${stepsList.size} turn steps.")
                        return@withContext LiveRouteData(
                            totalDistanceMeters = totalDistance,
                            totalDurationSeconds = totalDuration,
                            pathCoordinates = pathCoords,
                            steps = stepsList
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "OSRM Live Routing API failed (${e.message}), calculating high-precision road corridor.")
        }
        null
    }

    private fun formatTurkishManeuver(type: String, modifier: String, streetName: String, distanceM: Double): String {
        val distText = if (distanceM >= 1000) "${(distanceM / 1000).toInt()} km" else "${distanceM.toInt()} metre"
        val onStreet = if (streetName.isNotBlank()) " $streetName yönüne" else ""

        return when (type) {
            "depart" -> "Yola çıkın ve$onStreet ilerleyin"
            "arrive" -> "Hedefe ulaştınız"
            "roundabout", "rotary" -> "Dönel kavşaktan çıkın$onStreet"
            "fork" -> "Çatalda ${if (modifier.contains("left")) "soldan" else "sağdan"} devam edin$onStreet"
            else -> when {
                modifier.contains("left") -> "$distText sonra sola dönün$onStreet"
                modifier.contains("right") -> "$distText sonra sağa dönün$onStreet"
                modifier.contains("straight") -> "Düz devam edin$onStreet"
                else -> "$distText sonra ilerleyin$onStreet"
            }
        }
    }
}
