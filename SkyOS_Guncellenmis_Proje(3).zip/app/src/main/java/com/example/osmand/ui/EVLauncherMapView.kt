package com.example.osmand.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.osmand.ev.EVRouteResult
import com.example.osmand.safety.ActiveSafetyAlert

/**
 * Jetpack Compose wrapper for EVMapSurfaceView.
 * Directly integrates OsmAnd Core 150% scaled automotive rendering,
 * asymmetric map padding (right 40% offset), 3D perspective tilt,
 * touch pan/zoom, and dynamic EV slope route lines.
 */
@Composable
fun EVLauncherMapView(
    vehicleLatitude: Double,
    vehicleLongitude: Double,
    vehicleHeadingDegrees: Float,
    vehicleSpeedKmh: Int,
    speedLimitKmh: Int,
    isNightMode: Boolean,
    isFullScreen: Boolean,
    showTraffic: Boolean = true,
    showSpeedCameras: Boolean = true,
    showChargingStations: Boolean = true,
    showParking: Boolean = true,
    tilt3D: Boolean = true,
    isHeadingUp: Boolean = true,
    hasVehicleFix: Boolean = false,
    activeRoute: EVRouteResult?,
    activeAlert: ActiveSafetyAlert?,
    onViewReady: ((EVMapSurfaceView) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val leftPaddingFraction = if (isFullScreen) 0.0f else 0.60f

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            EVMapSurfaceView(ctx).apply {
                textScale = 1.5f
                symbolScale = 1.5f
                this.leftPaddingFraction = leftPaddingFraction
                this.isNightMode = isNightMode
                this.vehicleLatitude = vehicleLatitude
                this.vehicleLongitude = vehicleLongitude
                this.vehicleHeadingDegrees = vehicleHeadingDegrees
                this.vehicleSpeedKmh = vehicleSpeedKmh
                this.speedLimitKmh = speedLimitKmh
                this.showTraffic = showTraffic
                this.showSpeedCameras = showSpeedCameras
                this.showChargingStations = showChargingStations
                this.showParking = showParking
                this.tilt3D = tilt3D
                this.isHeadingUp = isHeadingUp
                this.hasVehicleFix = hasVehicleFix
                this.activeRoute = activeRoute
                this.activeAlert = activeAlert
                onViewReady?.invoke(this)
            }
        },
        update = { view ->
            view.leftPaddingFraction = leftPaddingFraction
            view.isNightMode = isNightMode
            view.vehicleLatitude = vehicleLatitude
            view.vehicleLongitude = vehicleLongitude
            view.vehicleHeadingDegrees = vehicleHeadingDegrees
            view.vehicleSpeedKmh = vehicleSpeedKmh
            view.speedLimitKmh = speedLimitKmh
            view.showTraffic = showTraffic
            view.showSpeedCameras = showSpeedCameras
            view.showChargingStations = showChargingStations
            view.showParking = showParking
            view.tilt3D = tilt3D
            view.isHeadingUp = isHeadingUp
            view.hasVehicleFix = hasVehicleFix
            view.activeRoute = activeRoute
            view.activeAlert = activeAlert
        }
    )
}
