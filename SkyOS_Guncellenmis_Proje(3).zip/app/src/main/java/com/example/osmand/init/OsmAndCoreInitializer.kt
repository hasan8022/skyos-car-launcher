package com.example.osmand.init

import android.content.Context
import android.util.Log
import com.example.osmand.nativecore.OsmAndNativeCore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Singleton responsible for:
 * 1. Safely loading OsmAnd Core native C++ shared libraries (libosmand_core.so).
 * 2. Accessing, verifying, and extracting .obf offline vector map files from Android assets.
 * 3. Providing a thread-safe, resilient startup sequence for the automotive navigation subsystem.
 */
object OsmAndCoreInitializer {

    private const val TAG = "OsmAndCoreInitializer"
    private const val MAPS_DIR_NAME = "osmand/maps"
    private const val STYLES_DIR_NAME = "osmand/rendering_styles"
    private const val ROUTING_DIR_NAME = "osmand/routing"

    enum class InitStatus {
        NOT_INITIALIZED,
        INITIALIZING,
        READY,
        FAILED
    }

    data class InitializationResult(
        val isSuccess: Boolean,
        val isNativeLibraryLoaded: Boolean,
        val loadedObfFiles: List<File>,
        val mapsDirectory: File,
        val status: InitStatus,
        val errorMessage: String? = null
    )

    private val mutex = Mutex()

    private val _status = MutableStateFlow(InitStatus.NOT_INITIALIZED)
    val status: StateFlow<InitStatus> = _status.asStateFlow()

    private val _initResult = MutableStateFlow<InitializationResult?>(null)
    val initResult: StateFlow<InitializationResult?> = _initResult.asStateFlow()

    @Volatile
    private var isNativeLoaded: Boolean = false

    @Volatile
    private var cachedMapsDir: File? = null

    private val registeredObfFiles = mutableListOf<File>()

    /**
     * Synchronous / Suspended entry point to initialize OsmAnd Core and .obf offline maps.
     * Guaranteed to execute only once; subsequent calls return the cached InitializationResult.
     */
    suspend fun initialize(context: Context): InitializationResult = mutex.withLock {
        val currentResult = _initResult.value
        if (_status.value == InitStatus.READY && currentResult != null) {
            return currentResult
        }

        _status.value = InitStatus.INITIALIZING
        Log.i(TAG, "Starting OsmAnd Core initialization sequence...")

        val appContext = context.applicationContext

        return withContext(Dispatchers.IO) {
            try {
                // Step 1: Load native C++ library with fallback
                loadNativeLibraries()

                // Step 2: Prepare storage directories
                val mapsDir = setupDirectories(appContext)
                cachedMapsDir = mapsDir

                // Step 3: Register and extract .obf vector map files from assets
                extractObfMapsFromAssets(appContext, mapsDir)

                // Step 4: Index all available .obf files
                val indexedFiles = scanAndRegisterObfFiles(mapsDir)

                // Step 5: Initialize native / managed core subsystem
                OsmAndNativeCore.initialize(appContext)

                val result = InitializationResult(
                    isSuccess = true,
                    isNativeLibraryLoaded = isNativeLoaded,
                    loadedObfFiles = indexedFiles,
                    mapsDirectory = mapsDir,
                    status = InitStatus.READY
                )

                _status.value = InitStatus.READY
                _initResult.value = result
                Log.i(TAG, "OsmAnd Core initialization complete. Native: $isNativeLoaded, Indexed maps: ${indexedFiles.size}")
                result
            } catch (e: Exception) {
                Log.e(TAG, "OsmAnd Core initialization failed: ${e.message}", e)
                val failedResult = InitializationResult(
                    isSuccess = false,
                    isNativeLibraryLoaded = isNativeLoaded,
                    loadedObfFiles = emptyList(),
                    mapsDirectory = cachedMapsDir ?: File(appContext.filesDir, MAPS_DIR_NAME),
                    status = InitStatus.FAILED,
                    errorMessage = e.message
                )
                _status.value = InitStatus.FAILED
                _initResult.value = failedResult
                failedResult
            }
        }
    }

    /**
     * Non-blocking asynchronous initialization launcher with optional completion callback.
     */
    fun initializeAsync(
        context: Context,
        scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob()),
        onComplete: ((InitializationResult) -> Unit)? = null
    ) {
        scope.launch {
            val result = initialize(context)
            withContext(Dispatchers.Main) {
                onComplete?.invoke(result)
            }
        }
    }

    /**
     * Attempt loading libosmand_core.so shared native library.
     */
    private fun loadNativeLibraries() {
        try {
            System.loadLibrary("osmand_core")
            isNativeLoaded = true
            Log.i(TAG, "Native library 'osmand_core' loaded successfully.")
        } catch (e: UnsatisfiedLinkError) {
            Log.w(TAG, "Native 'osmand_core' not found on current architecture. Operating in high-performance managed engine mode: ${e.message}")
            isNativeLoaded = false
        } catch (e: Throwable) {
            Log.w(TAG, "Native load warning: ${e.message}")
            isNativeLoaded = false
        }
    }

    /**
     * Sets up internal and external files directories for maps, styles, and routing graphs.
     */
    private fun setupDirectories(context: Context): File {
        val mapsDir = File(context.filesDir, MAPS_DIR_NAME).apply { mkdirs() }
        File(context.filesDir, STYLES_DIR_NAME).mkdirs()
        File(context.filesDir, ROUTING_DIR_NAME).mkdirs()

        // Also ensure external maps folder if storage mounted
        context.getExternalFilesDir("maps")?.mkdirs()

        Log.d(TAG, "Map directory resolved: ${mapsDir.absolutePath}")
        return mapsDir
    }

    /**
     * Scans assets for .obf files and copies them to the internal map storage if missing or updated.
     */
    private fun extractObfMapsFromAssets(context: Context, destinationDir: File) {
        val assetManager = context.assets

        // Inspect both root assets and 'maps/' subfolder
        val assetSearchFolders = listOf("", "maps")

        for (folder in assetSearchFolders) {
            try {
                val list = assetManager.list(folder) ?: continue
                for (fileName in list) {
                    if (fileName.endsWith(".obf", ignoreCase = true)) {
                        val assetPath = if (folder.isEmpty()) fileName else "$folder/$fileName"
                        val destFile = File(destinationDir, fileName)

                        if (shouldExtractAsset(context, assetPath, destFile)) {
                            Log.i(TAG, "Extracting bundled .obf map from assets: $assetPath -> ${destFile.name}")
                            copyAssetToFile(assetManager.open(assetPath), destFile)
                        } else {
                            Log.d(TAG, "OBF map asset already up-to-date: ${destFile.name}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Notice scanning assets folder '$folder': ${e.message}")
            }
        }
    }

    /**
     * Checks if asset needs extraction based on file existence and length.
     */
    private fun shouldExtractAsset(context: Context, assetPath: String, destFile: File): Boolean {
        if (!destFile.exists()) return true
        if (destFile.length() == 0L) return true

        return try {
            val fd = context.assets.openFd(assetPath)
            val assetLength = fd.length
            fd.close()
            destFile.length() != assetLength
        } catch (_: Exception) {
            // Compressed asset inside APK without direct file descriptor; keep existing if > 0 bytes
            false
        }
    }

    private fun copyAssetToFile(input: InputStream, destFile: File) {
        val tempFile = File(destFile.parentFile, "${destFile.name}.tmp")
        try {
            input.use { inStream ->
                FileOutputStream(tempFile).use { outStream ->
                    inStream.copyTo(outStream)
                }
            }
            if (destFile.exists()) destFile.delete()
            tempFile.renameTo(destFile)
            Log.i(TAG, "Successfully extracted ${destFile.name} (${destFile.length()} bytes)")
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            throw e
        }
    }

    /**
     * Discovers all .obf files in maps directory and registers them with OsmAndNativeCore.
     */
    private fun scanAndRegisterObfFiles(mapsDir: File): List<File> {
        registeredObfFiles.clear()
        val obfList = mapsDir.listFiles { _, name -> name.endsWith(".obf", ignoreCase = true) }?.toList() ?: emptyList()

        for (obf in obfList) {
            if (obf.exists() && obf.length() > 0) {
                OsmAndNativeCore.registerObfMap(obf)
                registeredObfFiles.add(obf)
                Log.i(TAG, "Registered offline vector map: ${obf.name} (${obf.length() / 1024} KB)")
            }
        }
        return registeredObfFiles.toList()
    }

    fun isReady(): Boolean = _status.value == InitStatus.READY

    fun isNativeLoaded(): Boolean = isNativeLoaded

    fun getMapsDirectory(): File? = cachedMapsDir

    fun getAvailableObfFiles(): List<File> = registeredObfFiles.toList()
}
