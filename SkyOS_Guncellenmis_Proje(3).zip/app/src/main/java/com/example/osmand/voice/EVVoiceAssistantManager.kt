package com.example.osmand.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.osmand.ev.EVRoutingManager
import com.example.osmand.ev.EVVehicleProfile
import com.example.osmand.ev.GeoPoint
import com.example.osmand.search.OsmAndOfflineSearchEngine
import com.example.osmand.search.OsmLiveGeocoder
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.regex.Pattern

/**
 * Voice Assistant and TTS synthesizer integrated with OsmAnd Core EV Navigation.
 * Uses real live OpenStreetMap Nominatim geocoding and real OSRM driving routes.
 */
class EVVoiceAssistantManager(
    private val context: Context,
    private val routingManager: EVRoutingManager,
    private val searchEngine: OsmAndOfflineSearchEngine,
    private val getVehicleProfile: () -> EVVehicleProfile,
    // Varsayılan konum ARTIK YOK: arayan taraf gerçek GPS GeoPoint'i sağlar.
    // (0,0) = "konum bilinmiyor" — çağıran taraf bunu kontrol edip komutu reddeder.
    private val getCurrentLocation: () -> GeoPoint = { GeoPoint(0.0, 0.0) }
) : TextToSpeech.OnInitListener {

    private val TAG = "EVVoiceAssistant"
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val liveGeocoder = OsmLiveGeocoder(context)

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognitionAvailable = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _assistantMessage = MutableStateFlow("Sesli asistan hazır")
    val assistantMessage: StateFlow<String> = _assistantMessage.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e(TAG, "TTS initialization error: ${e.message}")
        }
        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        try {
            isRecognitionAvailable = SpeechRecognizer.isRecognitionAvailable(context)
            if (isRecognitionAvailable) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _assistantMessage.value = "Dinliyorum, nereye gitmek istersiniz?"
                        }

                        override fun onBeginningOfSpeech() {
                            _assistantMessage.value = "Ses algılandı..."
                        }

                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _assistantMessage.value = "Hedef aranıyor..."
                        }

                        override fun onError(error: Int) {
                            _isListening.value = false
                            val errText = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH -> "Ses eşleşmedi, lütfen tekrar deneyin."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ses algılanamadı, zaman aşımı."
                                else -> "Ses tanıma hatası ($error)."
                            }
                            _assistantMessage.value = errText
                        }

                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val query = matches?.firstOrNull() ?: ""
                            if (query.isNotBlank()) {
                                handleVoiceCommand(query)
                            } else {
                                _isListening.value = false
                                _assistantMessage.value = "Komut algılanamadı."
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                            if (!partial.isNullOrBlank()) {
                                _lastSpokenText.value = partial
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "SpeechRecognizer initialization error: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            val turkishLocale = Locale("tr", "TR")
            val result = tts?.setLanguage(turkishLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Turkish language missing in TTS, using default.")
                tts?.setLanguage(Locale.getDefault())
            }
            tts?.setSpeechRate(1.05f)
            tts?.setPitch(1.0f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {}
            })
            Log.i(TAG, "TTS initialized with Turkish language support.")
        }
    }

    fun speak(text: String, isManeuver: Boolean = false) {
        _assistantMessage.value = text
        if (!isTtsReady) {
            Log.w(TAG, "TTS not ready yet: $text")
            return
        }
        scope.launch {
            try {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "OSMAND_VOICE_${System.currentTimeMillis()}")
            } catch (e: Exception) {
                Log.e(TAG, "TTS speak failed: ${e.message}")
            }
        }
    }

    fun speakManeuver(instruction: String) {
        speak(instruction, isManeuver = true)
    }

    fun startListening() {
        _isListening.value = true
        _lastSpokenText.value = ""
        _assistantMessage.value = "Dinliyorum, lütfen konuşun..."

        if (speechRecognizer != null && isRecognitionAvailable) {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                }
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "startListening failed: ${e.message}")
            }
        }
    }

    fun stopListening() {
        _isListening.value = false
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
    }

    /**
     * Parses voice query, extracts destination, performs real live OpenStreetMap geocoding,
     * calculates real EV route, and announces real turn-by-turn guidance.
     */
    fun handleVoiceCommand(rawCommand: String) {
        _isListening.value = false
        _lastSpokenText.value = rawCommand
        val cmd = rawCommand.trim().lowercase(Locale("tr", "TR"))

        scope.launch {
            val destinationQuery = extractDestination(cmd)
            _assistantMessage.value = "'$destinationQuery' için canlı OpenStreetMap taranıyor..."

            val searchResults = withContext(Dispatchers.IO) {
                liveGeocoder.searchLive(destinationQuery)
            }

            val target = searchResults.firstOrNull()
            if (target != null) {
                val profile = getVehicleProfile()
                val startPoint = getCurrentLocation()

                // GPS fix yoksa (0,0) rota HESAPLANMAZ — sahte başlangıç noktası kullanılmaz
                if (startPoint.latitude == 0.0 && startPoint.longitude == 0.0) {
                    _assistantMessage.value = "Konum alınamadı"
                    speak("Araç konumu alınamıyor. GPS sinyali olmadan rota hesaplayamam.")
                    return@launch
                }

                _assistantMessage.value = "${target.name} için EV rotası hesaplanıyor..."
                val route = routingManager.calculateRoute(
                    start = startPoint,
                    destination = target.point,
                    destinationName = target.name,
                    vehicleProfile = profile
                )

                val distanceKm = (route.totalDistanceMeters / 1000.0).toInt()
                val arrivalBattery = route.arrivalSoCPercent.toInt()

                val firstTurn = route.maneuverSteps.firstOrNull { it.maneuverType != "depart" }?.instruction
                    ?: "Güzergah boyunca ilerleyin"

                val speechText = if (route.requiredChargeStops.isNotEmpty()) {
                    val stop = route.requiredChargeStops.first()
                    "Rota oluşturuldu. Mesafe $distanceKm kilometre. Batarya yetersiz olduğu için ${stop.name} (${stop.powerKw} kW) ara durak olarak eklendi. $firstTurn. Varışta bataryanız yüzde $arrivalBattery olacak."
                } else {
                    "Rota oluşturuldu. Mesafe $distanceKm kilometre. $firstTurn. Varışta bataryanız yüzde $arrivalBattery kalacak. Navigasyon başlatılıyor."
                }

                speak(speechText)
            } else {
                speak("Aradığınız '$destinationQuery' OpenStreetMap üzerinde bulunamadı. Lütfen tekrar deneyin.")
            }
        }
    }

    private fun extractDestination(text: String): String {
        val beniPattern = Pattern.compile("^beni\\s+(.+?)(?:'?(?:[eEaA]|[yY][eEaA]|[nN][eEaA]))?\\s+götür$", Pattern.CASE_INSENSITIVE)
        val matcher1 = beniPattern.matcher(text)
        if (matcher1.find()) {
            return matcher1.group(1)?.trim() ?: text
        }

        val gitPattern = Pattern.compile("^(.+?)(?:'?(?:[eEaA]|[yY][eEaA]|[nN][eEaA]))?\\s+git$", Pattern.CASE_INSENSITIVE)
        val matcher2 = gitPattern.matcher(text)
        if (matcher2.find()) {
            return matcher2.group(1)?.trim() ?: text
        }

        if (text.contains("rota")) {
            return text.replace("rota oluştur", "").replace("rota", "").replace("navigasyon başlat", "").trim()
        }

        if (text.contains("şarj")) {
            return "şarj istasyonu"
        }

        return text
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Log.e(TAG, "Release error: ${e.message}")
        }
    }
}
