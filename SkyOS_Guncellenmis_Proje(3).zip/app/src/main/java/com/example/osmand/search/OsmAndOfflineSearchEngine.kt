package com.example.osmand.search

import android.content.Context
import android.util.Log
import com.example.osmand.ev.GeoPoint
import java.util.Locale

data class SearchPoiResult(
    val title: String,
    val subtitle: String,
    val point: GeoPoint,
    val category: String,
    val isChargingStation: Boolean = false
)

/**
 * Offline POI and Geocoder Search Engine for OsmAnd.
 * Searches vector map POI database and offline address indices.
 */
class OsmAndOfflineSearchEngine(private val context: Context) {

    private val TAG = "OsmAndOfflineSearch"

    // Çevrimdışı POI indeksi YOK — sabit/uydurma adres üretilmez.
    // Arama yalnızca canlı OSM (Nominatim) üzerinden yapılır; sonuç yoksa boş liste döner.
    private val offlinePoiDatabase = emptyList<SearchPoiResult>()

    /**
     * Searches offline POIs matching query text.
     */
    fun search(query: String): List<SearchPoiResult> {
        val cleanQuery = query.trim().lowercase(Locale("tr", "TR"))
        if (cleanQuery.isEmpty()) return offlinePoiDatabase.take(5)

        val exactMatches = offlinePoiDatabase.filter {
            it.title.lowercase(Locale("tr", "TR")).contains(cleanQuery) ||
            it.subtitle.lowercase(Locale("tr", "TR")).contains(cleanQuery)
        }

        if (exactMatches.isNotEmpty()) return exactMatches

        // Fuzzy match: check token overlap
        val tokens = cleanQuery.split(" ").filter { it.length > 2 }
        val fuzzyMatches = offlinePoiDatabase.filter { poi ->
            val poiText = (poi.title + " " + poi.subtitle).lowercase(Locale("tr", "TR"))
            tokens.any { token -> poiText.contains(token) }
        }

        // Sonuç yoksa uydurma "varsayılan hedef" DÖNMEZ — boş liste = bulunamadı
        return fuzzyMatches
    }

    fun findChargingStationsNear(point: GeoPoint, radiusMeters: Double = 50000.0): List<SearchPoiResult> {
        return offlinePoiDatabase
            .filter { it.isChargingStation }
            .sortedBy { it.point.distanceTo(point) }
    }
}
