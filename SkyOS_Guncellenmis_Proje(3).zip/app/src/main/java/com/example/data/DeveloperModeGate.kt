package com.example.data

import android.content.Context
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Geliştirme Modu / ADB kapısı — SkyOS APK'sının (tr.halil.et5 v2.82) kurulum
 * akışının birebir karşılığı.
 *
 * APK akışı (kurulum ekranı):
 *   1. ADB kapalıysa kurulum DURUR ve kullanıcıya adım adım yol gösterilir:
 *      araç ayarları → Sistem → Coocaa OS logosuna 5 sn içinde ~20 kez dokun →
 *      "Lütfen Parolanı Girin" penceresi → şifre → "Geliştirme Modu" → "Aç adb".
 *   2. Şifre cihazdan hesaplanır: Base64(VIN.ilk3Karakter + skylinkSegmenti),
 *      sondaki '=' atılır. skylinkSegmenti = ro.build.skylinkversion'un
 *      '_' ile bölünen son parçasının '.' ile bölünen 3. elemanı.
 *   3. Uygulama Settings.Global.adb_enabled üzerine ContentObserver kurar;
 *      kullanıcı "Aç adb"ye dokununca observer tetiklenir ve kurulum
 *      KENDİLİĞİNDEN devam eder. (Biz de aynısını yapıyoruz.)
 *
 * Not: Bu sınıf root/su KULLANMAZ. ADB anahtarını araca kalıcı yazmak vb.
 * işlemler APK'da `su 0` ile yapılıyor; bizim güvenlik sınırımız gereği
 * kullanıcıdan geliştirici modunu kendisinin açması istenir (APK da bunu
 * kullanıcıya yaptırır).
 */
class DeveloperModeGate(private val context: Context) {

    private val tag = "DevModeGate"
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var pollJob: Job? = null

    /** Settings.Global adb_enabled == 1 */
    private val _adbEnabled = MutableStateFlow(false)
    val adbEnabled: StateFlow<Boolean> = _adbEnabled.asStateFlow()

    /** Settings.Global development_settings_enabled == 1 */
    private val _developmentEnabled = MutableStateFlow(false)
    val developmentEnabled: StateFlow<Boolean> = _developmentEnabled.asStateFlow()

    /** Geliştirme modu parolası; VIN/skylink henüz bilinmiyorsa null → UI "—" gösterir. */
    private val _developerPassword = MutableStateFlow<String?>(null)
    val developerPassword: StateFlow<String?> = _developerPassword.asStateFlow()

    /** Kurulum devam edebilir mi? (APK kuralı: ADB açılmadan devam edilmez) */
    private val _setupMayProceed = MutableStateFlow(false)
    val setupMayProceed: StateFlow<Boolean> = _setupMayProceed.asStateFlow()

    /** APK kurulum ekranındaki adım adım yönerge (birebir çeviri). */
    val setupInstructions: List<String> = listOf(
        "Aşağıdaki \"Aracın ayarlarını aç\" düğmesine dokunun ve sol menüden Sistem'e girin.",
        "Sağdaki Coocaa OS logosuna 5 saniye içinde hızlı hızlı (yaklaşık 20 kez) dokunun: \"Lütfen Parolanı Girin\" penceresi açılır.",
        "Aşağıdaki şifreyi yazıp Bitti'ye dokunun.",
        "Sistem sayfasında beliren \"Geliştirme Modu\"na dokunun; açılan listede \"Aç adb\"ye dokunun.",
        "Bu ekrana geri dönün. ADB açıldığında kurulum kendiliğinden devam eder."
    )

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) = refreshFromSettings()
    }

    fun start() {
        val cr = context.contentResolver
        try {
            cr.registerContentObserver(Settings.Global.getUriFor("adb_enabled"), false, observer)
            cr.registerContentObserver(
                Settings.Global.getUriFor("development_settings_enabled"), false, observer
            )
        } catch (t: Throwable) {
            Log.w(tag, "Settings observer kurulamadı: ${t.message}")
        }
        refreshFromSettings()
        // Observer kaçırırsa diye yavaş yedek poll (APK'daki watchdog mantığı)
        if (pollJob == null) {
            pollJob = scope.launch {
                while (isActive) {
                    refreshFromSettings()
                    delay(3000)
                }
            }
        }
    }

    fun stop() {
        try {
            context.contentResolver.unregisterContentObserver(observer)
        } catch (_: Throwable) {
        }
        pollJob?.cancel()
        pollJob = null
    }

    private fun refreshFromSettings() {
        val cr = context.contentResolver
        val adb = try {
            Settings.Global.getInt(cr, "adb_enabled", 0) == 1
        } catch (t: Throwable) {
            false
        }
        val dev = try {
            Settings.Global.getInt(cr, "development_settings_enabled", 0) == 1
        } catch (t: Throwable) {
            false
        }
        _adbEnabled.value = adb
        _developmentEnabled.value = dev
        _setupMayProceed.value = adb
    }

    /**
     * Geliştirme modu parolasını hesaplar (APK algoritması, AbstractC2297oa):
     *   Base64(VIN[0..2] + skylinkSegment), '=' karakterleri atılır.
     * skylinkSegment = ro.build.skylinkversion → '_' sonrası → '.' ile 3. parça.
     *
     * @param vin Araç VIN'i (car_service'ten okunmuş son değer); null ise "—".
     */
    fun computeDeveloperPassword(vin: String?): String? {
        if (vin == null || vin.length < 3) {
            _developerPassword.value = null
            return null
        }
        val skylink = readSystemProperty("ro.build.skylinkversion")
        val segment = skylink
            ?.substringAfter('_', "")
            ?.split('.')
            ?.getOrNull(2)
        if (segment.isNullOrEmpty()) {
            _developerPassword.value = null
            return null
        }
        val raw = vin.take(3) + segment
        val password = Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            .trimEnd('=')
        _developerPassword.value = password
        return password
    }

    /** ro.* özelliklerini shell'siz okur (android.os.SystemProperties yansıması). */
    private fun readSystemProperty(key: String): String? = try {
        val sp = Class.forName("android.os.SystemProperties")
        val get = sp.getMethod("get", String::class.java)
        (get.invoke(null, key) as? String)?.takeIf { it.isNotEmpty() }
    } catch (t: Throwable) {
        Log.w(tag, "SystemProperty okunamadı ($key): ${t.message}")
        null
    }
}
