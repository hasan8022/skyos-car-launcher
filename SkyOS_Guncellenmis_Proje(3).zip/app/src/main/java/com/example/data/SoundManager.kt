package com.example.data

import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Generates synthetic acoustic feedback for turn signals (tik-tak),
 * parking proximity radar beeps (DUR! tone), and driver alert chimes.
 */
class SoundManager {

    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private var signalJob: Job? = null
    private var parkJob: Job? = null

    // Signal volume level: 1 = Kısık, 2 = Normal, 3 = Yüksek, 4 = Çok Yüksek
    var signalVolumeLevel: Int = 2

    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
        } catch (_: Exception) {}
    }

    fun startSignalSound(isHazard: Boolean = false) {
        if (signalJob?.isActive == true) return
        signalJob = scope.launch {
            val volumeStream = when (signalVolumeLevel) {
                1 -> 40
                2 -> 65
                3 -> 85
                else -> 100
            }
            while (isActive) {
                // Tik (higher tone)
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
                } catch (_: Exception) {}
                delay(370)
                // Tak (lower tone)
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 35)
                } catch (_: Exception) {}
                delay(370)
            }
        }
    }

    fun stopSignalSound() {
        signalJob?.cancel()
        signalJob = null
    }

    fun playWarningDing() {
        scope.launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 150)
            } catch (_: Exception) {}
        }
    }

    fun playSosAlert() {
        scope.launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 400)
            } catch (_: Exception) {}
        }
    }

    fun playObstacleStopBeep() {
        scope.launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200)
            } catch (_: Exception) {}
        }
    }

    fun release() {
        signalJob?.cancel()
        parkJob?.cancel()
        toneGenerator?.release()
        toneGenerator = null
    }
}
