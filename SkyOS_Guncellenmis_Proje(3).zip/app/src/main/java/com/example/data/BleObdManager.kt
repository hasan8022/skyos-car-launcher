package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.util.Log
import com.example.model.ObdCellData
import com.example.model.ObdTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * OBD-II / BLE adapter yöneticisi (vLinker MS, vGate iCar Pro, ELM327).
 *
 * SAHTE VERİ YOK: Önceki sürüm Random ile 103 hücre voltajı ve DTC kodu
 * üretiyordu; kaldırıldı. Artık yalnızca GERÇEK durum raporlanır:
 *  - Cihazda eşleşmiş (paired) OBD adaptörü var mı? (BluetoothAdapter — gerçek API)
 *  - Adaptörle aktif bir SPP/BLE oturumu var mı?
 *
 * Gerçek PID/hücre okuması ancak fiziksel adaptörle oturum açıldığında gelir.
 * Oturum yoksa UI "Bağlantı Yok" gösterir; hiçbir sensör değeri uydurulmaz.
 */
class BleObdManager(private val context: Context) {

    private val tag = "BleObdManager"
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val _telemetry = MutableStateFlow(ObdTelemetry(isConnected = false))
    val telemetry: StateFlow<ObdTelemetry> = _telemetry.asStateFlow()

    /** Hücre voltajları — yalnızca gerçek adaptörden okununca dolar. */
    private val _cellVoltages = MutableStateFlow<List<ObdCellData>>(emptyList())
    val cellVoltages: StateFlow<List<ObdCellData>> = _cellVoltages.asStateFlow()

    /** Eşleşmiş OBD adaptör adayları (gerçek BluetoothAdapter sorgusu). */
    private val _pairedAdapterNames = MutableStateFlow<List<String>>(emptyList())
    val pairedAdapterNames: StateFlow<List<String>> = _pairedAdapterNames.asStateFlow()

    init {
        refreshPairedAdapters()
    }

    /** Bilinen OBD adaptör adı kalıpları */
    private val adapterNameHints = listOf("vlinker", "vgate", "elm327", "obd", "icar", "vpecker")

    @SuppressLint("MissingPermission")
    fun refreshPairedAdapters() {
        scope.launch {
            try {
                val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
                val adapter = btManager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
                val bonded = if (adapter?.isEnabled == true) {
                    adapter.bondedDevices?.mapNotNull { it.name } ?: emptyList()
                } else emptyList()

                val obdCandidates = bonded.filter { name ->
                    adapterNameHints.any { hint -> name.contains(hint, ignoreCase = true) }
                }
                _pairedAdapterNames.value = obdCandidates

                if (obdCandidates.isEmpty()) {
                    _telemetry.value = _telemetry.value.copy(
                        isConnected = false,
                        deviceName = ""
                    )
                    Log.i(tag, "Eşleşmiş OBD adaptörü bulunamadı — OBD verisi gösterilmeyecek")
                } else {
                    // Adaptör eşleşmiş ama henüz oturum açılmadı — yine de "bağlı" SAYILMAZ
                    _telemetry.value = _telemetry.value.copy(
                        isConnected = false,
                        deviceName = obdCandidates.first()
                    )
                    Log.i(tag, "OBD adaptör adayları: $obdCandidates (oturum henüz yok)")
                }
            } catch (e: SecurityException) {
                Log.w(tag, "Bluetooth izni yok: ${e.message}")
                _pairedAdapterNames.value = emptyList()
            } catch (e: Exception) {
                Log.w(tag, "Eşleşmiş cihaz sorgusu hatası: ${e.message}")
            }
        }
    }

    /** DTC taraması: gerçek adaptör oturumu olmadan sonuç üretmez. */
    fun scanDtcCodes() {
        if (!_telemetry.value.isConnected) {
            Log.i(tag, "DTC taraması istendi ama OBD bağlantısı yok — işlem yapılmadı")
            _telemetry.value = _telemetry.value.copy(dtcCodes = emptyList())
            return
        }
        // TODO: Gerçek ELM327 AT komut akışı (03 → Mode 03 DTC okuma) oturum açıldığında eklenecek
    }

    /** DTC temizleme: yalnızca gerçek bağlantıda anlamlıdır. */
    fun clearDtcCodes() {
        if (!_telemetry.value.isConnected) return
        _telemetry.value = _telemetry.value.copy(dtcCodes = emptyList())
        // TODO: Gerçek ELM327 "04" (Clear DTC) komutu oturum açıldığında eklenecek
    }

    fun release() {
        // Arka plan döngüsü yok (sahte telemetri üretimi kaldırıldı)
    }
}
