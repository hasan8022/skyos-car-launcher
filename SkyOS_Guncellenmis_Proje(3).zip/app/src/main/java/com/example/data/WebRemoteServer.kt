package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.Gear
import com.example.model.VehicleState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

/**
 * Built-in local HTTP Web Server running on port 8080.
 * Allows phones to connect via browser without installing an app, control the car (climate, locks, trunk, 220V, etc.),
 * view 3D status, and share locations directly to the car's navigation!
 */
class WebRemoteServer(
    private val context: Context,
    private val port: Int = 8080,
    private val getVehicleState: () -> VehicleState,
    private val onRemoteAction: (action: String, value: Any?) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    val isRunning = MutableStateFlow(false)
    val serverUrl = MutableStateFlow("http://127.0.0.1:$port")

    fun start() {
        if (serverJob != null) return
        serverJob = scope.launch {
            try {
                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                isRunning.value = true
                Log.i("WebRemoteServer", "SkyOS Remote server started on port $port")

                while (isActive && serverSocket?.isClosed == false) {
                    val client = serverSocket!!.accept()
                    scope.launch { handleClient(client) }
                }
            } catch (e: java.net.SocketException) {
                if (serverSocket?.isClosed == true || !isActive) {
                    Log.i("WebRemoteServer", "Server socket closed gracefully.")
                } else {
                    Log.w("WebRemoteServer", "Socket exception: ${e.message}")
                }
            } catch (e: Exception) {
                Log.e("WebRemoteServer", "Server exception: ${e.message}")
            } finally {
                isRunning.value = false
            }
        }
    }

    private fun handleClient(socket: Socket) {
        try {
            socket.use { s ->
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                val writer = PrintWriter(s.getOutputStream(), true)

                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(" ")
                val method = parts.getOrNull(0) ?: "GET"
                val path = parts.getOrNull(1) ?: "/"

                // Read headers
                var contentLength = 0
                var line = reader.readLine()
                while (!line.isNullOrEmpty()) {
                    if (line.lowercase().startsWith("content-length:")) {
                        contentLength = line.substring(15).trim().toIntOrNull() ?: 0
                    }
                    line = reader.readLine()
                }

                when {
                    path.startsWith("/api/status") -> {
                        val state = getVehicleState()
                        val json = JSONObject().apply {
                            put("battery", state.batteryPercent)
                            put("range", state.rangeKm)
                            put("gear", state.gear.name)
                            put("speed", state.speedKmh)
                            put("trunk", state.trunk)
                            put("hood", state.hood)
                            put("doorFL", state.doorFL)
                            put("doorFR", state.doorFR)
                            put("driverTemp", state.driverTemp)
                            put("acEnabled", state.acEnabled)
                            put("fanSpeed", state.fanSpeed)
                            put("outlet220V", state.outlet220V)
                            put("sunroof", state.sunroofOpen)
                            put("mirrorsFolded", state.mirrorsFolded)
                            put("charging", state.isCharging)
                            put("outsideTemp", state.outsideTempC)
                            put("insideTemp", state.insideTempC)
                        }.toString()
                        sendResponse(writer, "application/json", json)
                    }

                    path.startsWith("/api/action") && method == "POST" -> {
                        val body = CharArray(contentLength)
                        reader.read(body, 0, contentLength)
                        val bodyStr = String(body)
                        val json = JSONObject(bodyStr)
                        val action = json.optString("action")
                        val value = json.opt("value")

                        // Safety check: remote commands only in P gear
                        if (getVehicleState().gear == Gear.P) {
                            onRemoteAction(action, value)
                            sendResponse(writer, "application/json", """{"status":"ok"}""")
                        } else {
                            sendResponse(writer, "application/json", """{"status":"error","message":"Araç P vitesinde olmalıdır."}""", 403)
                        }
                    }

                    path.startsWith("/api/location") && method == "POST" -> {
                        val body = CharArray(contentLength)
                        reader.read(body, 0, contentLength)
                        val bodyStr = String(body)
                        val json = JSONObject(bodyStr)
                        val loc = json.optString("location")
                        onRemoteAction("send_location", loc)
                        sendResponse(writer, "application/json", """{"status":"ok","message":"Konum araca gönderildi"}""")
                    }

                    else -> {
                        sendResponse(writer, "text/html", generateRemoteHtml())
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("WebRemoteServer", "Client handling error: ${e.message}")
        }
    }

    private fun sendResponse(writer: PrintWriter, contentType: String, content: String, code: Int = 200) {
        val statusText = if (code == 200) "OK" else "Error"
        writer.println("HTTP/1.1 $code $statusText")
        writer.println("Content-Type: $contentType; charset=utf-8")
        writer.println("Content-Length: ${content.toByteArray(Charsets.UTF_8).size}")
        writer.println("Access-Control-Allow-Origin: *")
        writer.println("Connection: close")
        writer.println()
        writer.println(content)
        writer.flush()
    }

    private fun generateRemoteHtml(): String {
        return """
            <!DOCTYPE html>
            <html lang="tr">
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
                <title>SkyOS Telefondan Kontrol</title>
                <style>
                    body { margin: 0; background: #0E1116; color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
                    .header { padding: 20px 16px; background: #161A22; border-bottom: 1px solid #252B38; display: flex; justify-content: space-between; align-items: center; }
                    .title { font-size: 20px; font-weight: 700; color: #00D2FF; }
                    .status-badge { background: #00D2FF22; color: #00D2FF; padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: 600; }
                    .container { padding: 16px; }
                    .card { background: #181D27; border-radius: 16px; padding: 16px; margin-bottom: 16px; border: 1px solid #262E3E; }
                    .card-title { font-size: 14px; color: #8F9CAE; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
                    .stat-row { display: flex; justify-content: space-around; margin: 12px 0; }
                    .stat-item { text-align: center; }
                    .stat-value { font-size: 32px; font-weight: bold; color: #fff; }
                    .stat-unit { font-size: 14px; color: #8F9CAE; }
                    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
                    button { background: #222938; color: #fff; border: 1px solid #343E54; padding: 14px; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; transition: 0.2s; }
                    button:active { background: #00D2FF; color: #000; }
                    .input-box { width: 100%; box-sizing: border-box; padding: 12px; border-radius: 8px; border: 1px solid #343E54; background: #10141C; color: #fff; font-size: 14px; margin-bottom: 10px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="title">⚡ SkyOS Remote</div>
                    <div class="status-badge" id="connStatus">Bağlı (P Modu)</div>
                </div>
                <div class="container">
                    <div class="card">
                        <div class="card-title">Araç Durumu</div>
                        <div class="stat-row">
                            <div class="stat-item">
                                <div class="stat-value" id="batVal">--%</div>
                                <div class="stat-unit">Batarya</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="rangeVal">-- km</div>
                                <div class="stat-unit">Tahmini Menzil</div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-title">Hızlı Kontroller</div>
                        <div class="grid">
                            <button onclick="sendAction('toggle_trunk')">🚗 Bagaj Aç/Kapa</button>
                            <button onclick="sendAction('toggle_climate')">❄️ Klima Ön Isıtma</button>
                            <button onclick="sendAction('toggle_sunroof')">🪟 Cam Tavan Arala</button>
                            <button onclick="sendAction('toggle_outlet')">🔌 220V Priz</button>
                            <button onclick="sendAction('toggle_mirrors')">🔄 Ayna Katla</button>
                            <button onclick="sendAction('stop_charge')">🛑 Şarjı Bitir</button>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-title">Araca Konum Gönder</div>
                        <input class="input-box" id="locInput" placeholder="Adres veya Google Harita Bağlantısı...">
                        <button style="width: 100%;" onclick="sendLocation()">📍 Rota Olarak Gönder</button>
                    </div>
                </div>
                <script>
                    function fetchStatus() {
                        fetch('/api/status').then(r => r.json()).then(data => {
                            document.getElementById('batVal').innerText = '%' + data.battery;
                            document.getElementById('rangeVal').innerText = data.range + ' km';
                        }).catch(() => {});
                    }
                    function sendAction(act) {
                        fetch('/api/action', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({action: act})
                        }).then(r => r.json()).then(res => {
                            if (res.status === 'error') alert(res.message);
                            else fetchStatus();
                        });
                    }
                    function sendLocation() {
                        const val = document.getElementById('locInput').value;
                        if (!val) return;
                        fetch('/api/location', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({location: val})
                        }).then(r => r.json()).then(res => {
                            alert(res.message);
                            document.getElementById('locInput').value = '';
                        });
                    }
                    setInterval(fetchStatus, 3000);
                    fetchStatus();
                </script>
            </body>
            </html>
        """.trimIndent()
    }

    fun stop() {
        serverJob?.cancel()
        serverJob = null
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        isRunning.value = false
    }
}
