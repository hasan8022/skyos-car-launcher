package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.Gear
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * car_service üzerinden GERÇEK araç verisi okuyucu (ADB shell ile).
 *
 * Anlam eşlemesi ARTIK DOĞRULANMIŞTIR: SkyOS APK'sının (tr.halil.et5 v2.82)
 * jadx + smali çıktısındaki durum-güncelleme fonksiyonundan (EVT→VehicleState
 * eşlemesi) birebir çıkarıldı. Tahmin yok; her ID'nin anlamı APK kodundan kanıtlı:
 *
 *   0x11400460  int     VİTES — 1=R, 2=N, 3 veya 4=D, 5=P (diğer: son bilinen)
 *   0x11600207  float   HIZ — standart PERF_VEHICLE_SPEED, m/s; ×3.6 = km/h
 *   0x1160031b  float   SoC % — 0..100 (batarya yüzdesi + hassas SoC)
 *   0x1160049e  float   MENZİL km (birincil; yalnız >0 geçerli)
 *   0x11600333  float   MENZİL km (yedek; birincil ≤0 ise)
 *   0x1160049a  float   ODOMETRE km (yalnız >0 geçerli)
 *   0x1160049b  float   Deşarj sayacı kWh (yalnız >0 geçerli)
 *   0x11600331  float   Ortalama tüketim kWh/100km (yalnız 1..60 arası geçerli)
 *   0x1160031c  float   Paket gerilimi V (güç hesabı: >50V ise paket aktif)
 *   0x1160031d  float   Paket akımı A (ters akım ofseti tercihi açıksa −600)
 *   0x11400317  int     Şarj durumu A — ≠0 ⇒ şarj oluyor VE kablo takılı
 *   0x11400551  int     Şarj durumu B — ≠0 ⇒ şarj oluyor
 *   0x13200504  string  alan 1 = kablo takılı ("true"/"false"), alan 2 = şarj
 *   0x11200402  bool    EL FRENİ (standart PARKING_BRAKE_ON)
 *   0x11600517  float   İç sıcaklık °C
 *   0x11600518  float   Dış sıcaklık °C (25.0'a takılı kalırsa geçersiz sayılır)
 *   0x11400d2d  int     Hız limiti (yalnız 5..200 arası geçerli)
 *   0x11610497  float[] Lastik basınçları (bar) — OBD vLinker varsa OBD önceliklidir
 *
 * Güç kW = V × A / 1000 (APK'nın hesabı; akım >50 değil gerilim >50 kontrolü).
 * OBD (vLinker) taze verisi varsa APK güç/SoC/lastik için OBD'yi tercih eder;
 * burada OBD köprüsü BleObdManager'dadır, öncelik birleştirmesi VehicleRepository'de.
 */
class CarPropertyReader(
    context: Context,
    private val adbBridge: AdbBridgeManager
) {
    private val tag = "CarProperty"
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var pollJob: Job? = null

    private val prefs = context.applicationContext
        .getSharedPreferences("car_property_map", Context.MODE_PRIVATE)

    companion object {
        // --- Doğrulanmış anlamlı ID'ler (APK smali'sinden) ---
        const val ID_GEAR = "0x11400460"
        const val ID_SPEED_MS = "0x11600207"
        const val ID_SOC = "0x1160031b"
        const val ID_RANGE_PRIMARY = "0x1160049e"
        const val ID_RANGE_FALLBACK = "0x11600333"
        const val ID_ODOMETER = "0x1160049a"
        const val ID_DISCHARGE_KWH = "0x1160049b"
        const val ID_AVG_KWH_100 = "0x11600331"
        const val ID_PACK_VOLTAGE = "0x1160031c"
        const val ID_PACK_CURRENT = "0x1160031d"
        const val ID_CHARGE_STATUS_A = "0x11400317"
        const val ID_CHARGE_STATUS_B = "0x11400551"
        const val ID_CHARGE_STRING = "0x13200504"
        const val ID_PARKING_BRAKE = "0x11200402"
        const val ID_INSIDE_TEMP = "0x11600517"
        const val ID_OUTSIDE_TEMP = "0x11600518"
        const val ID_SPEED_LIMIT = "0x11400d2d"
        const val ID_TIRE_PRESSURES = "0x11610497"
        const val ID_VIN = "0x11100100" // standart INFO_VIN (string)

        /** Polling listesi — APK'nın WATCH listesindeki karşılıklarıyla aynı. */
        val POLL_IDS: List<String> = listOf(
            ID_GEAR, ID_SPEED_MS, ID_SOC, ID_RANGE_PRIMARY, ID_RANGE_FALLBACK,
            ID_ODOMETER, ID_DISCHARGE_KWH, ID_AVG_KWH_100, ID_PACK_VOLTAGE, ID_PACK_CURRENT,
            ID_CHARGE_STATUS_A, ID_CHARGE_STATUS_B, ID_PARKING_BRAKE,
            ID_INSIDE_TEMP, ID_OUTSIDE_TEMP, ID_SPEED_LIMIT, ID_TIRE_PRESSURES
        )

        /**
         * APK'nın "Enerji kaynakları" tanı komutundaki 8 ID.
         * Bunlardan 0x11600332, 0x11600498, 0x11600499 ve 0x11600204'ün anlamı
         * APK kaynağında ÇÖZÜLEMEDİ (yalnızca tanı amaçlı okunuyorlar) —
         * dürüstlük gereği ham değer olarak gösterilir, anlam ETİKETLENMEZ.
         */
        val APK_DIAG_IDS: List<String> = listOf(
            "0x1160049a", "0x1160049b", "0x11600331", "0x11600332",
            "0x11600498", "0x11600499", "0x11600204", "0x1160031b"
        )

        /** APK'daki dış sıcaklık "takılma" sentinel'i. */
        const val OUTSIDE_TEMP_STUCK_SENTINEL = 25.0f

        // Eski kalibrasyon slot'ları (geri uyumluluk; artık doğrulanmış sabitler var)
        const val SLOT_GEAR = "gear"
        const val SLOT_SPEED = "speed_kmh"
        const val SLOT_SOC = "soc_percent"
        const val SLOT_RANGE = "range_km"
        const val SLOT_CHARGING = "charging"
        const val SLOT_POWER = "power_kw"

        /**
         * Tanı ekranı etiketi: doğrulanmış ID'ler için Türkçe anlam döndürür.
         * Anlamı APK'da çözülemeyen 4 ID için null döner → UI "anlamı bilinmiyor"
         * diye işaretler; asla tahminî etiket basılmaz.
         */
        fun labelFor(idHex: String): String? = when (idHex.lowercase()) {
            ID_GEAR -> "Vites (1=G,2=B,3/4=İleri,5=P)"
            ID_SPEED_MS -> "Hız (m/s)"
            ID_SOC -> "Batarya SoC (%)"
            ID_RANGE_PRIMARY -> "Menzil km (birincil)"
            ID_RANGE_FALLBACK -> "Menzil km (yedek)"
            ID_ODOMETER -> "Odometre (km)"
            ID_DISCHARGE_KWH -> "Deşarj sayacı (kWh)"
            ID_AVG_KWH_100 -> "Ort. tüketim (kWh/100km)"
            ID_PACK_VOLTAGE -> "Paket gerilimi (V)"
            ID_PACK_CURRENT -> "Paket akımı (A)"
            ID_CHARGE_STATUS_A -> "Şarj durumu A"
            ID_CHARGE_STATUS_B -> "Şarj durumu B"
            ID_CHARGE_STRING -> "Şarj kablosu (string)"
            ID_PARKING_BRAKE -> "El freni"
            ID_INSIDE_TEMP -> "İç sıcaklık (°C)"
            ID_OUTSIDE_TEMP -> "Dış sıcaklık (°C)"
            ID_SPEED_LIMIT -> "Hız limiti (km/h)"
            ID_TIRE_PRESSURES -> "Lastik basınçları (bar)"
            ID_VIN -> "VIN"
            else -> null // 0x11600332 / 0x11600498 / 0x11600499 / 0x11600204 → anlamı çözülemedi
        }
    }

    data class RawProperty(
        val idHex: String,
        val area: Int,
        val floatValues: List<Float>,
        val intValues: List<Int>,
        val stringValue: String?,
        val rawOutput: String,
        val timestampMs: Long
    )

    /** Tek polling turunda okunan, anlamları doğrulanmış araç durumu. */
    data class VerifiedCarState(
        val gear: Gear? = null,
        val gearRawCode: Int? = null,
        val speedKmh: Float? = null,
        val socPercent: Float? = null,
        val rangeKm: Float? = null,
        val odometerKm: Float? = null,
        val dischargeKwh: Float? = null,
        val avgKwhPer100Km: Float? = null,
        val packVoltageV: Float? = null,
        val packCurrentA: Float? = null,
        val powerKw: Float? = null,
        val charging: Boolean? = null,
        val plugged: Boolean? = null,
        val parkingBrake: Boolean? = null,
        val insideTempC: Float? = null,
        val outsideTempC: Float? = null,
        val speedLimitKmh: Int? = null,
        val tirePressuresBar: List<Float>? = null
    )

    /** Tanı ekranı için ham snapshot (doğrulanmış + anlamı çözülemeyen tanı ID'leri). */
    private val _liveProperties = MutableStateFlow<Map<String, RawProperty>>(emptyMap())
    val liveProperties: StateFlow<Map<String, RawProperty>> = _liveProperties.asStateFlow()

    /** Anlamları doğrulanmış son durum — UI/Repository bunu tüketir. */
    private val _verifiedState = MutableStateFlow(VerifiedCarState())
    val verifiedState: StateFlow<VerifiedCarState> = _verifiedState.asStateFlow()

    /** En az bir gerçek car_service okuması başarılı oldu. */
    private val _carServiceReachable = MutableStateFlow(false)
    val carServiceReachable: StateFlow<Boolean> = _carServiceReachable.asStateFlow()

    // Dış sıcaklık "takılma" tespiti (APK mantığı): ilk okuma 25.0 ise ve hiç
    // değişmediyse değer şüphelidir → gösterilmez.
    private var outsideTempFirst: Float? = null
    private var outsideTempEverChanged = false

    /** Akım ofseti tercihi (APK'daki karşılık: "amper ofsetli" bayrağı). Varsayılan kapalı. */
    fun isCurrentBiasEnabled(): Boolean = prefs.getBoolean("current_bias_600", false)
    fun setCurrentBiasEnabled(enabled: Boolean) =
        prefs.edit().putBoolean("current_bias_600", enabled).apply()

    /** Son okunan VIN (geliştirici şifresi hesabı için saklanır). */
    var lastVin: String?
        get() = prefs.getString("last_vin", null)
        private set(value) = prefs.edit().putString("last_vin", value).apply()

    // ------------------------------------------------------------------
    // Okuma — APK ile aynı komut: cmd car_service get-property-value <id> <alan>
    // ------------------------------------------------------------------
    private val floatRegex = Regex("""floatValues:\s*\[?([-0-9.eE,\s]+)""")
    private val intRegex = Regex("""int32Values:\s*\[?([-0-9,\s]+)""")
    private val stringRegex = Regex("""stringValue:\s*([^,\]}]+)""")

    suspend fun readProperty(idHex: String, area: Int = 0): RawProperty? {
        val out = adbBridge.shell("cmd car_service get-property-value $idHex $area") ?: return null
        if (out.isBlank() || out.contains("Error", ignoreCase = true) ||
            out.contains("Exception", ignoreCase = true)
        ) return null

        val floats = floatRegex.find(out)?.groupValues?.getOrNull(1)
            ?.split(",")?.mapNotNull { it.trim().toFloatOrNull() } ?: emptyList()
        val ints = intRegex.find(out)?.groupValues?.getOrNull(1)
            ?.split(",")?.mapNotNull { it.trim().toIntOrNull() } ?: emptyList()
        val str = stringRegex.find(out)?.groupValues?.getOrNull(1)?.trim()

        if (floats.isEmpty() && ints.isEmpty() && str.isNullOrEmpty()) return null
        return RawProperty(idHex, area, floats, ints, str, out.trim(), System.currentTimeMillis())
    }

    private fun RawProperty?.floatOrNull(): Float? =
        this?.floatValues?.firstOrNull() ?: this?.intValues?.firstOrNull()?.toFloat()

    private fun RawProperty?.intOrNull(): Int? =
        this?.intValues?.firstOrNull() ?: this?.floatValues?.firstOrNull()?.toInt()

    // ------------------------------------------------------------------
    // Doğrulanmış anlam çözümü (APK d4.b eşlemesinden birebir)
    // ------------------------------------------------------------------

    /** APK: 1=R, 2=N, 3 veya 4=D, 5=P; bilinmeyen kod → null (son durum korunur). */
    fun gearFromCode(code: Int): Gear? = when (code) {
        1 -> Gear.R
        2 -> Gear.N
        3, 4 -> Gear.D
        5 -> Gear.P
        else -> null
    }

    /** Bir tur okuma yapar; hem ham snapshot'ı hem doğrulanmış durumu günceller. */
    suspend fun pollAllOnce(): VerifiedCarState {
        val raw = LinkedHashMap<String, RawProperty>()
        var anyOk = false
        suspend fun read(id: String, area: Int = 0): RawProperty? {
            val r = readProperty(id, area)
            if (r != null) {
                raw["$id/$area"] = r
                anyOk = true
            }
            return r
        }

        // Doğrulanmış set
        val gearRaw = read(ID_GEAR).intOrNull()
        val speedMs = read(ID_SPEED_MS).floatOrNull()
        val soc = read(ID_SOC).floatOrNull()
        val rangePrimary = read(ID_RANGE_PRIMARY).floatOrNull()
        val rangeFallback = if (rangePrimary == null || rangePrimary <= 0f) {
            read(ID_RANGE_FALLBACK).floatOrNull()
        } else null
        val odometer = read(ID_ODOMETER).floatOrNull()?.takeIf { it > 0f }
        val discharge = read(ID_DISCHARGE_KWH).floatOrNull()?.takeIf { it > 0f }
        val avg = read(ID_AVG_KWH_100).floatOrNull()?.takeIf { it in 1.0f..60.0f }
        val packV = read(ID_PACK_VOLTAGE).floatOrNull()
        var packA = read(ID_PACK_CURRENT).floatOrNull()
        if (packA != null && isCurrentBiasEnabled()) packA -= 600f
        val chargeA = read(ID_CHARGE_STATUS_A).intOrNull()
        val chargeB = read(ID_CHARGE_STATUS_B).intOrNull()
        val pluggedStr = read(ID_CHARGE_STRING, 1)?.stringValue
        val chargingStr = read(ID_CHARGE_STRING, 2)?.stringValue
        val parkingBrake = read(ID_PARKING_BRAKE).intOrNull()?.let { it != 0 }
        val insideT = read(ID_INSIDE_TEMP).floatOrNull()
        val outsideRaw = read(ID_OUTSIDE_TEMP).floatOrNull()
        val speedLimit = read(ID_SPEED_LIMIT).intOrNull()?.takeIf { it in 5..200 }
        val tires = read(ID_TIRE_PRESSURES)?.floatValues?.takeIf { it.isNotEmpty() }

        // Anlamı çözülemeyen tanı ID'leri — yalnız ham gösterim için okunur
        for (id in APK_DIAG_IDS) {
            if (raw.keys.none { it.startsWith(id) }) read(id)
        }

        // Dış sıcaklık takılma koruması (APK: 25.0 sabit kalırsa geçersiz)
        val outsideT = if (outsideRaw != null) {
            if (outsideTempFirst == null) outsideTempFirst = outsideRaw
            if (outsideTempFirst != outsideRaw) outsideTempEverChanged = true
            if (!outsideTempEverChanged && outsideRaw == OUTSIDE_TEMP_STUCK_SENTINEL) null else outsideRaw
        } else null

        // Güç: APK hesabı — paket gerilimi >50V ise V×A/1000
        val power = if (packV != null && packA != null && packV > 50f) {
            packA * packV / 1000f
        } else null

        val range = when {
            rangePrimary != null && rangePrimary > 0f -> rangePrimary
            rangeFallback != null -> rangeFallback
            else -> null
        }

        val charging = when {
            chargeA != null || chargeB != null -> (chargeA ?: 0) != 0 || (chargeB ?: 0) != 0
            chargingStr != null -> chargingStr.equals("true", ignoreCase = true)
            else -> null
        }
        val plugged = when {
            chargeA != null -> chargeA != 0
            pluggedStr != null -> pluggedStr.equals("true", ignoreCase = true)
            else -> null
        }

        val verified = VerifiedCarState(
            gear = gearRaw?.let { gearFromCode(it) },
            gearRawCode = gearRaw,
            speedKmh = speedMs?.let { it * 3.6f },
            socPercent = soc?.coerceIn(0f, 100f),
            rangeKm = range?.takeIf { it >= 0f },
            odometerKm = odometer,
            dischargeKwh = discharge,
            avgKwhPer100Km = avg,
            packVoltageV = packV,
            packCurrentA = packA,
            powerKw = power,
            charging = charging,
            plugged = plugged,
            parkingBrake = parkingBrake,
            insideTempC = insideT,
            outsideTempC = outsideT,
            speedLimitKmh = speedLimit,
            tirePressuresBar = tires
        )

        _liveProperties.value = raw
        _carServiceReachable.value = anyOk
        if (anyOk) _verifiedState.value = verified
        return verified
    }

    /** VIN okur ve saklar (geliştirici şifresi hesabında kullanılır). */
    suspend fun readVinOnce(): String? {
        val raw = readProperty(ID_VIN, 0) ?: return lastVin
        val vin = raw.stringValue?.takeIf { it.length >= 11 }
        if (vin != null) lastVin = vin
        return vin ?: lastVin
    }

    /** Kalibrasyon/tanı için tam döküm. */
    suspend fun dumpCarService(): String? =
        adbBridge.shell("dumpsys car_service | head -c 150000", timeoutMs = 10_000)

    fun startPolling(intervalMs: Long = 1000L) {
        if (pollJob != null) return
        pollJob = scope.launch {
            var vinTried = false
            while (isActive) {
                if (adbBridge.isConnected.value) {
                    try {
                        pollAllOnce()
                        if (!vinTried) {
                            vinTried = true
                            readVinOnce()
                        }
                    } catch (e: Exception) {
                        Log.w(tag, "poll hatası: ${e.message}")
                    }
                } else {
                    _carServiceReachable.value = false
                }
                delay(intervalMs)
            }
        }
    }

    fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    // ------------------------------------------------------------------
    // Eski kalibrasyon API'si — artık gerek yok (anlamlar APK'dan doğrulandı).
    // Geri uyumluluk için bırakıldı; her zaman doğrulanmış sabitleri döndürür.
    // ------------------------------------------------------------------
    fun getMapping(slot: String): String? = when (slot) {
        SLOT_GEAR -> ID_GEAR
        SLOT_SPEED -> ID_SPEED_MS
        SLOT_SOC -> ID_SOC
        SLOT_RANGE -> ID_RANGE_PRIMARY
        SLOT_CHARGING -> ID_CHARGE_STATUS_A
        SLOT_POWER -> "V*A/1000" // hesaplanır, tek ID değil
        else -> null
    }

    /** Anlamlar APK kaynağından doğrulandığı için eşleme her zaman tamam kabul edilir. */
    fun isMappingComplete(): Boolean = true

    // Kolaylık getter'ları (son doğrulanmış snapshot'tan)
    fun rawGearCode(): Float? = _verifiedState.value.gearRawCode?.toFloat()
    fun speedKmh(): Float? = _verifiedState.value.speedKmh
    fun socPercent(): Float? = _verifiedState.value.socPercent
    fun rangeKm(): Float? = _verifiedState.value.rangeKm
    fun chargingCode(): Float? = _verifiedState.value.charging?.let { if (it) 1f else 0f }
    fun powerKw(): Float? = _verifiedState.value.powerKw

    fun release() = stopPolling()
}
