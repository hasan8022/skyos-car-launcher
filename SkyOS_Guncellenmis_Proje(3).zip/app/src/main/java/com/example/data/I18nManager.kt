package com.example.data

import android.content.Context
import com.example.model.AppLanguage
import org.json.JSONObject
import java.io.InputStreamReader

/**
 * Manages 5 languages: Turkish, English, German, Spanish, Russian.
 */
class I18nManager(private val context: Context) {

    private var currentLanguage = AppLanguage.TR
    private val translations = mutableMapOf<AppLanguage, Map<String, String>>()

    init {
        loadTranslations()
    }

    private fun loadTranslations() {
        val langs = listOf(AppLanguage.EN, AppLanguage.DE, AppLanguage.ES, AppLanguage.RU)
        for (lang in langs) {
            try {
                val assetPath = "i18n/" + lang.code + ".json"
                context.assets.open(assetPath).use { stream ->
                    val reader = InputStreamReader(stream, Charsets.UTF_8)
                    val jsonStr = reader.readText()
                    val jsonObj = JSONObject(jsonStr)
                    val map = mutableMapOf<String, String>()
                    val keys = jsonObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        map[key] = jsonObj.optString(key, key)
                    }
                    translations[lang] = map
                }
            } catch (e: Exception) {
                // Ignore missing file, fallback to key
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        currentLanguage = language
    }

    fun getLanguage(): AppLanguage = currentLanguage

    fun translate(key: String, vararg args: Any): String {
        if (currentLanguage == AppLanguage.TR) {
            return formatString(key, *args)
        }
        val langMap = translations[currentLanguage]
        val translated = langMap?.get(key) ?: key
        return formatString(translated, *args)
    }

    private fun formatString(pattern: String, vararg args: Any): String {
        if (args.isEmpty()) return pattern
        var result = pattern
        for (i in args.indices) {
            result = result.replace("{$i}", args[i].toString())
        }
        return result
    }
}
