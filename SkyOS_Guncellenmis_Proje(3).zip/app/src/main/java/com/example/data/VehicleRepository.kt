package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class VehicleRepository(
    private val context: Context,
    val soundManager: SoundManager = SoundManager(),
    val i18nManager: I18nManager = I18nManager(context),
    val radioManager: RadioStreamManager = RadioStreamManager(context),
    val obdManager: BleObdManager = BleObdManager(context)
) {
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    // OsmAnd Core EV & Safety Managers
    val evRoutingManager = com.example.osmand.ev.EVRoutingManager(context)
    val safetyAlertManager = com.example.osmand.safety.SafetyAlertManager()
    val osmSearchEngine = com.example.osmand.search.OsmAndOfflineSearchEngine(context)
    val liveGeocoder = com.example.osmand.search.OsmLiveGeocoder(context)
    val mapDownloadManager = com.example.osmand.download.MapDownloadManager(context, com.example.osmand.tiles.OsmTileEngine(context))

    fun getVehicleEVProfile(): com.example.osmand.ev.EVVehicleProfile {
        val s = _vehicleState.value
        return com.example.osmand.ev.EVVehicleProfile(
            // Gerçek kapasite bilinmiyorsa (-1) araç üretici değeri 72 kWh kullanılır (ET5 72 kWh batarya)
            batteryCapacityKwh = (if (s.realCapacityKwh > 0f) s.realCapacityKwh.toDouble() else 72.0),
            // SoC bilinmiyorsa 0 döner — EV rota planlayıcı "bilinmiyor" olarak ele alır, uydurma değer yok
            currentSoCPercent = if (s.batteryPercent >= 0) s.batteryPercent.toFloat() else 0f,
            averageConsumptionWhPerKm = (if (s.avgConsumptionKwhPer100Km > 0f) s.avgConsumptionKwhPer100Km * 10.0 else 174.0),
            supportedPlugTypes = listOf(
                com.example.osmand.ev.PlugType.CCS,
                com.example.osmand.ev.PlugType.TYPE_2
            )
        )
    }

    private val _vehicleState = MutableStateFlow(VehicleState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()

    private val _activeScreen = MutableStateFlow(ActiveScreen.MAP)
    val activeScreen: StateFlow<ActiveScreen> = _activeScreen.asStateFlow()

    private val _smartScreenMode = MutableStateFlow(SmartScreenMode.NONE)
    val smartScreenMode: StateFlow<SmartScreenMode> = _smartScreenMode.asStateFlow()

    private val _isFullScreen = MutableStateFlow(false)
    val isFullScreen: StateFlow<Boolean> = _isFullScreen.asStateFlow()

    private val _temporaryNote = MutableStateFlow("0532 000 00 00 - Lütfen arayınız")
    val temporaryNote: StateFlow<String> = _temporaryNote.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Gerçek tüketim geçmişi — yalnızca doğrulanmış car_service ölçümleri eklenir
    private val _speedHistory = MutableStateFlow<List<Float>>(emptyList())
    val speedHistory: StateFlow<List<Float>> = _speedHistory.asStateFlow()

    private val _selectedObdKeys = MutableStateFlow(listOf("Batarya Sıcaklığı", "12V Akü", "Motor Devri", "Ön Sol Lastik"))
    val selectedObdKeys: StateFlow<List<String>> = _selectedObdKeys.asStateFlow()

    // 6 Custom Driver Profiles (kullanıcı yapılandırması — sensör verisi değildir)
    val driverProfiles = listOf(
        DriverProfile(1, "Sürücü", "S", "#00D2FF", preferredTemp = 22.0f, seatMemoryPos = 1, connectedPhoneName = "Bağlı değil"),
        DriverProfile(2, "Profil 2", "2", "#FF5252", preferredTemp = 21.0f, seatMemoryPos = 2, connectedPhoneName = "Bağlı değil"),
        DriverProfile(3, "Profil 3", "3", "#4CAF50", preferredTemp = 23.0f, seatMemoryPos = 3, connectedPhoneName = "Bağlı değil"),
        DriverProfile(4, "Profil 4", "4", "#E040FB", preferredTemp = 24.0f, seatMemoryPos = 1, connectedPhoneName = "Bağlı değil"),
        DriverProfile(5, "Misafir", "M", "#FF9800", preferredTemp = 22.5f, seatMemoryPos = 2, connectedPhoneName = "Bağlı değil"),
        DriverProfile(6, "Spor Mod", "S", "#FF1744", preferredTemp = 19.5f, seatMemoryPos = 1, preferredDriveMode = DriveMode.SPORT, connectedPhoneName = "Bağlı değil")
    )

    val telemetryHelper = SystemTelemetryHelper(context)

    data class WebBrowserState(val title: String, val url: String)
    private val _webBrowserState = MutableStateFlow<WebBrowserState?>(null)
    val webBrowserState: StateFlow<WebBrowserState?> = _webBrowserState.asStateFlow()

    fun openWebBrowser(title: String, url: String) {
        _webBrowserState.value = WebBrowserState(title, url)
    }

    fun closeWebBrowser() {
        _webBrowserState.value = null
    }

    // Local Web Remote Server (Phone app on port 8080)
    val webRemoteServer = WebRemoteServer(
        context = context,
        port = 8080,
        getVehicleState = { _vehicleState.value },
        onRemoteAction = { action, value ->
            handleRemoteAction(action, value)
        }
    )

    // Gerçek ADB protokolü köprüsü (dadb) — 127.0.0.1:5555 = aracın kendi adbd'si
    val adbBridge = AdbBridgeManager(
        context = context,
        host = "127.0.0.1",
        port = 5555
    )

    // car_service property okuyucu (ID→anlam eşlemesi APK smali'sinden doğrulanmış)
    val carPropertyReader = CarPropertyReader(context, adbBridge)

    // Geliştirme modu kapısı: adb_enabled izlenir, APK algoritmasıyla parola üretilir.
    // ADB açılmadan araç verisi okunamaz (APK kuralı: geliştirici modu yoksa devam yok).
    val developerModeGate = DeveloperModeGate(context)

    init {
        webRemoteServer.start()
        developerModeGate.start()
        adbBridge.start()
        carPropertyReader.startPolling(1000L)
        observeRealTelemetry()
        observeCarProperties()
        // VIN okunur okunmaz geliştirici parolasını hesapla (APK: Base64(VIN3+skylink))
        scope.launch {
            carPropertyReader.carServiceReachable.collect { reachable ->
                if (reachable) {
                    developerModeGate.computeDeveloperPassword(carPropertyReader.lastVin)
                }
            }
        }
    }

    private fun handleRemoteAction(action: String, value: Any?) {
        when (action) {
            "toggle_trunk" -> toggleTrunk()
            "toggle_climate" -> toggleClimatePower()
            "toggle_sunroof" -> toggleSunroof()
            "toggle_outlet" -> toggle220V()
            "toggle_mirrors" -> toggleMirrors()
            "stop_charge" -> stopCharging()
            "send_location" -> {
                val locStr = value?.toString() ?: ""
                _searchQuery.value = locStr
                _activeScreen.value = ActiveScreen.MAP
            }
        }
    }

    /**
     * car_service'den gelen DOĞRULANMIŞ araç durumunu VehicleState'e uygular.
     * ID→anlam eşlemesi APK'nın (tr.halil.et5 v2.82) smali kodundan kanıtlıdır
     * (bkz. CarPropertyReader başlık yorumu). Okunamayan değer null kalır →
     * UI "Bağlantı Yok"/"Veri Yok" gösterir; asla tahmin üretilmez.
     */
    private fun observeCarProperties() {
        scope.launch {
            carPropertyReader.verifiedState.collect { v ->
                val reachable = carPropertyReader.carServiceReachable.value
                val current = _vehicleState.value
                var newState = current.copy(
                    vehicleBusConnected = reachable,
                    carMappingVerified = reachable // anlamlar APK'dan doğrulandı
                )
                if (reachable) {
                    v.socPercent?.let {
                        newState = newState.copy(batteryPercent = it.toInt().coerceIn(0, 100))
                    }
                    v.rangeKm?.let {
                        newState = newState.copy(rangeKm = it.toInt().coerceAtLeast(0))
                    }
                    v.speedKmh?.let {
                        newState = newState.copy(speedKmh = it.toInt().coerceAtLeast(0), speedFromGps = false)
                    }
                    v.powerKw?.let {
                        newState = newState.copy(powerKw = it, isRegenActive = it < 0f)
                    }
                    v.gear?.let { g -> newState = newState.copy(gear = g) }
                    v.charging?.let { newState = newState.copy(isCharging = it) }
                    v.plugged?.let { newState = newState.copy(chargePort = it) }
                    v.insideTempC?.let { newState = newState.copy(insideTempC = it.toInt()) }
                    v.outsideTempC?.let { newState = newState.copy(outsideTempC = it.toInt()) }
                    v.speedLimitKmh?.let { newState = newState.copy(speedLimitKmh = it) }
                    v.avgKwhPer100Km?.let { newState = newState.copy(avgConsumptionKwhPer100Km = it) }
                    if (v.charging == true && v.powerKw != null) {
                        newState = newState.copy(chargePowerKw = kotlin.math.abs(v.powerKw))
                    }
                }
                _vehicleState.value = newState
            }
        }
    }

    private fun observeRealTelemetry() {
        scope.launch {
            telemetryHelper.telemetry.collect { real ->
                val current = _vehicleState.value
                // NOT: Bilgi-eğlence ünitesinin (tablet) kendi bataryası ARAÇ bataryası değildir.
                // Araç SoC'u yalnızca car_service üzerinden gelir (observeCarProperties).
                var newState = current.copy(
                    wifiConnected = real.wifiConnected,
                    wifiSsid = real.wifiSsid,
                    bluetoothConnected = real.bluetoothEnabled,
                    bluetoothDeviceName = real.bluetoothDeviceName,
                    volumeLevel = real.musicVolume,
                    hasGpsFix = real.hasGpsFix
                )
                // Hız: doğrulanmış car_service değeri önceliklidir; yoksa cihaz GPS'i
                // (GPS de gerçek sensör verisidir — APK da GPSSpeed kullanır) ve kaynak işaretlenir.
                if (!current.vehicleBusConnected || current.speedFromGps) {
                    newState = if (real.hasGpsFix) {
                        newState.copy(speedKmh = real.gpsSpeedKmh, speedFromGps = true)
                    } else {
                        newState.copy(speedKmh = 0)
                    }
                }
                _vehicleState.value = newState

                // OsmAnd yakınlık taraması yalnızca gerçek GPS fix varken güncellenir
                if (real.hasGpsFix) {
                    safetyAlertManager.updateVehicleLocation(
                        currentLat = real.currentLatitude,
                        currentLng = real.currentLongitude,
                        currentSpeedKmh = newState.speedKmh
                    )
                }

                // Gerçek hız 15 km/h üstüne çıkarsa oto-yıkama modundan çık
                if (_smartScreenMode.value == SmartScreenMode.CAR_WASH && newState.speedKmh > 15) {
                    setSmartMode(SmartScreenMode.NONE)
                }
            }
        }
    }

    fun setGear(gear: Gear) {
        val current = _vehicleState.value
        if (current.gear == gear) return

        // Araç veri yolu doğrulandıysa vites ARAÇTAN okunur; UI'dan vites "yazılmaz"
        // (APK da yalnızca okur: car_service'te set-gear diye bir komut yoktur).
        if (current.carMappingVerified) {
            Log.i("VehicleRepository", "Vites araçtan okunuyor; manuel değişiklik yok sayıldı ($gear)")
            return
        }

        // Bağlantı yokken vites seçici yalnızca ekran durumunu değiştirir.
        // Sahte hız/güç üretilmez; hız GPS/car_service'ten gelir.
        if (gear == Gear.S) {
            _vehicleState.value = current.copy(
                gear = gear,
                driveMode = DriveMode.SPORT,
                steeringMode = SteeringMode.SPORT,
                brakeMode = BrakeMode.SPORT
            )
            soundManager.playWarningDing()
        } else {
            _vehicleState.value = current.copy(gear = gear)
        }
    }

    /**
     * Hız UI'dan yazılmaz — gerçek kaynak car_service veya GPS'tir.
     * Bu fonksiyon artık yalnızca log bırakır (sahte güç/hız üretimi kaldırıldı).
     */
    fun setSpeed(kmh: Int) {
        Log.i("VehicleRepository", "setSpeed($kmh) çağrıldı — hız yalnızca gerçek sensörlerden okunur, yok sayıldı")
    }

    fun setDriveMode(mode: DriveMode) {
        _vehicleState.value = _vehicleState.value.copy(driveMode = mode)
    }

    fun setSteeringMode(mode: SteeringMode) {
        _vehicleState.value = _vehicleState.value.copy(steeringMode = mode)
    }

    fun setBrakeMode(mode: BrakeMode) {
        _vehicleState.value = _vehicleState.value.copy(brakeMode = mode)
    }

    fun toggleCreep() {
        _vehicleState.value = _vehicleState.value.copy(creepEnabled = !_vehicleState.value.creepEnabled)
    }

    fun toggleHillDescent() {
        _vehicleState.value = _vehicleState.value.copy(hillDescentEnabled = !_vehicleState.value.hillDescentEnabled)
    }

    fun setCarColor(hex: String) {
        _vehicleState.value = _vehicleState.value.copy(carColorHex = hex)
    }

    fun toggle3DView() {
        _vehicleState.value = _vehicleState.value.copy(is3DView = !_vehicleState.value.is3DView)
    }

    fun toggleDoor(door: String) {
        val cur = _vehicleState.value
        _vehicleState.value = when (door) {
            "dFL" -> cur.copy(doorFL = !cur.doorFL)
            "dFR" -> cur.copy(doorFR = !cur.doorFR)
            "dRL" -> cur.copy(doorRL = !cur.doorRL)
            "dRR" -> cur.copy(doorRR = !cur.doorRR)
            else -> cur
        }
    }

    fun toggleTrunk() {
        // Safety constraint: trunk opens only in P!
        if (_vehicleState.value.gear == Gear.P) {
            // NOT: car_service'te doğrulanmış bir "bagaj aç" komutu yok (APK yalnızca okur).
            // Gerçek aktüatör endpoint'i doğrulanana kadar yalnızca ekran durumu değişir.
            _vehicleState.value = _vehicleState.value.copy(trunk = !_vehicleState.value.trunk)
        } else {
            soundManager.playWarningDing()
        }
    }

    fun toggleHood() {
        if (_vehicleState.value.gear == Gear.P) {
            _vehicleState.value = _vehicleState.value.copy(hood = !_vehicleState.value.hood)
        }
    }

    fun toggleChargePort() {
        _vehicleState.value = _vehicleState.value.copy(chargePort = !_vehicleState.value.chargePort)
    }

    fun toggleSunroof() {
        _vehicleState.value = _vehicleState.value.copy(sunroofOpen = !_vehicleState.value.sunroofOpen)
    }

    fun toggleSunshade() {
        _vehicleState.value = _vehicleState.value.copy(sunshadeOpen = !_vehicleState.value.sunshadeOpen)
    }

    fun toggleMirrors() {
        _vehicleState.value = _vehicleState.value.copy(mirrorsFolded = !_vehicleState.value.mirrorsFolded)
    }

    fun toggle220V() {
        _vehicleState.value = _vehicleState.value.copy(outlet220V = !_vehicleState.value.outlet220V)
    }

    // Climate
    fun adjustDriverTemp(delta: Float) {
        val newTemp = ((_vehicleState.value.driverTemp + delta) * 2).toInt() / 2f
        _vehicleState.value = _vehicleState.value.copy(driverTemp = newTemp.coerceIn(16.0f, 28.0f))
    }

    fun adjustPassengerTemp(delta: Float) {
        val newTemp = ((_vehicleState.value.passengerTemp + delta) * 2).toInt() / 2f
        _vehicleState.value = _vehicleState.value.copy(passengerTemp = newTemp.coerceIn(16.0f, 28.0f))
    }

    fun setFanSpeed(speed: Int) {
        _vehicleState.value = _vehicleState.value.copy(fanSpeed = speed.coerceIn(0, 7))
    }

    fun toggleAC() {
        _vehicleState.value = _vehicleState.value.copy(acEnabled = !_vehicleState.value.acEnabled)
    }

    fun toggleAutoClimate() {
        _vehicleState.value = _vehicleState.value.copy(autoClimate = !_vehicleState.value.autoClimate)
    }

    fun toggleRecirc() {
        _vehicleState.value = _vehicleState.value.copy(recircEnabled = !_vehicleState.value.recircEnabled)
    }

    fun toggleVentFace() {
        _vehicleState.value = _vehicleState.value.copy(ventFace = !_vehicleState.value.ventFace)
    }

    fun toggleVentFoot() {
        _vehicleState.value = _vehicleState.value.copy(ventFoot = !_vehicleState.value.ventFoot)
    }

    fun toggleDefrostFront() {
        _vehicleState.value = _vehicleState.value.copy(ventDefrostFront = !_vehicleState.value.ventDefrostFront)
    }

    fun toggleDefrostRear() {
        _vehicleState.value = _vehicleState.value.copy(ventDefrostRear = !_vehicleState.value.ventDefrostRear)
    }

    fun toggleClimatePower() {
        val newPower = !_vehicleState.value.climatePower
        _vehicleState.value = _vehicleState.value.copy(
            climatePower = newPower,
            fanSpeed = if (newPower) 2 else 0
        )
    }

    fun cycleDriverSeatHeat() {
        val next = (_vehicleState.value.driverSeatHeat + 1) % 4
        _vehicleState.value = _vehicleState.value.copy(driverSeatHeat = next)
    }

    fun cycleDriverSeatVent() {
        val next = (_vehicleState.value.driverSeatVent + 1) % 4
        _vehicleState.value = _vehicleState.value.copy(driverSeatVent = next)
    }

    fun cyclePassengerSeatHeat() {
        val next = (_vehicleState.value.passengerSeatHeat + 1) % 4
        _vehicleState.value = _vehicleState.value.copy(passengerSeatHeat = next)
    }

    fun cyclePassengerSeatVent() {
        val next = (_vehicleState.value.passengerSeatVent + 1) % 4
        _vehicleState.value = _vehicleState.value.copy(passengerSeatVent = next)
    }

    // Signals & Hazards
    fun toggleLeftSignal() {
        val cur = _vehicleState.value
        val newState = !cur.leftSignal
        _vehicleState.value = cur.copy(leftSignal = newState, rightSignal = false, hazardLights = false)
        if (newState) soundManager.startSignalSound() else soundManager.stopSignalSound()
    }

    fun toggleRightSignal() {
        val cur = _vehicleState.value
        val newState = !cur.rightSignal
        _vehicleState.value = cur.copy(rightSignal = newState, leftSignal = false, hazardLights = false)
        if (newState) soundManager.startSignalSound() else soundManager.stopSignalSound()
    }

    fun toggleHazardLights() {
        val cur = _vehicleState.value
        val newState = !cur.hazardLights
        _vehicleState.value = cur.copy(hazardLights = newState, leftSignal = false, rightSignal = false)
        if (newState) soundManager.startSignalSound(isHazard = true) else soundManager.stopSignalSound()
    }

    fun setHeadlightHeight(h: Int) {
        _vehicleState.value = _vehicleState.value.copy(headlightHeight = h.coerceIn(0, 3))
    }

    fun setAmbientColor(hex: String) {
        _vehicleState.value = _vehicleState.value.copy(ambientColorHex = hex)
    }

    // Battery & Charging
    fun setChargeLimit(percent: Int) {
        _vehicleState.value = _vehicleState.value.copy(chargeLimitPercent = percent.coerceIn(50, 100))
    }

    fun stopCharging() {
        _vehicleState.value = _vehicleState.value.copy(isCharging = false, chargePowerKw = 0f)
        soundManager.playWarningDing()
    }

    fun startCharging() {
        // chargePowerKw uydurulmaz; gerçek şarj gücü car_service doğrulamasına kadar 0 (bilinmiyor)
        _vehicleState.value = _vehicleState.value.copy(isCharging = true, chargePowerKw = 0f, chargePort = true)
    }

    // Smart Modes
    fun setSmartMode(mode: SmartScreenMode) {
        _smartScreenMode.value = mode
        when (mode) {
            SmartScreenMode.CAR_WASH -> {
                // Fold mirrors, close sunroof, mute park radar, recirculate air
                _vehicleState.value = _vehicleState.value.copy(
                    mirrorsFolded = true,
                    sunroofOpen = false,
                    sunshadeOpen = false,
                    recircEnabled = true
                )
            }
            SmartScreenMode.CAMP_MODE -> {
                _vehicleState.value = _vehicleState.value.copy(
                    acEnabled = true,
                    climatePower = true,
                    fanSpeed = 2
                )
            }
            else -> {}
        }
    }

    fun setTemporaryNote(note: String) {
        _temporaryNote.value = note
    }

    fun setActiveScreen(screen: ActiveScreen) {
        _activeScreen.value = screen
    }

    fun toggleFullScreen() {
        _isFullScreen.value = !_isFullScreen.value
    }

    fun setVolume(vol: Int) {
        _vehicleState.value = _vehicleState.value.copy(volumeLevel = vol.coerceIn(0, 15))
    }

    fun selectDriverProfile(id: Int) {
        val profile = driverProfiles.find { it.id == id } ?: return
        _vehicleState.value = _vehicleState.value.copy(
            activeDriverProfileId = id,
            driverTemp = profile.preferredTemp,
            driveMode = profile.preferredDriveMode
        )
        soundManager.playWarningDing()
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    /** UI tarafından context erişimi için (geocoder vb.). */
    fun getContext(): Context = context

    // --- Kayıtlı konumlar (Ev / İş) — kullanıcı ayarlarından gelir, sabit YOK ---
    private val locationPrefs = context.applicationContext
        .getSharedPreferences("saved_locations", Context.MODE_PRIVATE)

    fun getSavedLocationName(key: String): String? =
        locationPrefs.getString(key, null)

    fun setSavedLocationName(key: String, name: String) =
        locationPrefs.edit().putString(key, name).apply()

    /**
     * Sesli komut hedefi için sorgu metni döndürür.
     * Kayıtlı konum varsa onu kullanır; yoksa genel sorguya düşer.
     * Sahte/sabit adres ASLA üretilmez.
     */
    fun getVoiceTargetQuery(kind: String): String {
        val savedName = when (kind) {
            "home" -> getSavedLocationName("home_address")
            "work" -> getSavedLocationName("work_address")
            else -> null
        }
        return savedName ?: when (kind) {
            "home" -> "ev"
            "work" -> "iş"
            "charger" -> "en yakın şarj istasyonu"
            else -> kind
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        _vehicleState.value = _vehicleState.value.copy(themeMode = mode)
    }

    fun cycleThemeMode() {
        val next = when (_vehicleState.value.themeMode) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.AUTO
            ThemeMode.AUTO -> ThemeMode.DARK
        }
        setThemeMode(next)
    }

    fun isDarkModeEffective(state: VehicleState = _vehicleState.value): Boolean {
        return when (state.themeMode) {
            ThemeMode.DARK -> true
            ThemeMode.LIGHT -> false
            ThemeMode.AUTO -> {
                // In auto theme: dark at night (before 7am, after 7pm) or when headlights are active
                val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                val isNight = hour < 7 || hour >= 19
                isNight || state.headlights
            }
        }
    }

    // Navigation Toggles
    fun toggleNavTraffic() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navTrafficEnabled = !curr.navTrafficEnabled)
    }

    fun toggleNavSpeedCameras() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navSpeedCamerasEnabled = !curr.navSpeedCamerasEnabled)
    }

    fun toggleNavAvoidTolls() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navAvoidTolls = !curr.navAvoidTolls)
    }

    fun toggleNavAvoidFerries() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navAvoidFerries = !curr.navAvoidFerries)
    }

    fun toggleNavAvoidHighways() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navAvoidHighways = !curr.navAvoidHighways)
    }

    fun toggleNavVoiceGuidance() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navVoiceGuidance = !curr.navVoiceGuidance)
    }

    fun toggleNavChargingStations() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navShowChargingStations = !curr.navShowChargingStations)
    }

    fun toggleNavParking() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navShowParking = !curr.navShowParking)
    }

    fun toggleNavLaneGuidance() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navLaneGuidance = !curr.navLaneGuidance)
    }

    fun toggleNav3DTilt() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(nav3DTilt = !curr.nav3DTilt)
    }

    fun toggleNavAutoZoom() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navAutoZoom = !curr.navAutoZoom)
    }

    fun toggleNavSpeedLimitWarning() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navSpeedLimitWarning = !curr.navSpeedLimitWarning)
    }

    fun toggleNavTrafficLights() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navTrafficLights = !curr.navTrafficLights)
    }

    fun toggleNavOfflineCache() {
        val curr = _vehicleState.value
        _vehicleState.value = curr.copy(navOfflineCache = !curr.navOfflineCache)
    }

    fun release() {
        webRemoteServer.stop()
        developerModeGate.stop()
        carPropertyReader.release()
        adbBridge.stop()
        radioManager.release()
        soundManager.release()
        obdManager.release()
        telemetryHelper.release()
    }
}
