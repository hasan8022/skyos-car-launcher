package com.example.data

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import com.example.model.RadioStation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RadioStreamManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentStation = MutableStateFlow<RadioStation?>(null)
    val currentStation: StateFlow<RadioStation?> = _currentStation.asStateFlow()

    private val _fmFrequency = MutableStateFlow(99.0f) // 87.5 .. 108.0 MHz
    val fmFrequency: StateFlow<Float> = _fmFrequency.asStateFlow()

    val popularStations = listOf(
        RadioStation("1", "Kral FM", "Arabesk, Türkçe", "128 kbps", "https://kral-fm.listenlive.com/kralfm.mp3", isFavorite = true),
        RadioStation("2", "Power POP", "Pop, 80s, 90s", "128 kbps", "https://listen.powerapp.com.tr/powerpop/mpeg/icecast.audio", isFavorite = true),
        RadioStation("3", "Damar Türk FM", "Damar, Arabesk", "128 kbps", "https://yayin.damarturk.com:8020/stream", isFavorite = false),
        RadioStation("4", "Virgin Radio Türkiye", "Pop, Rock", "64 kbps", "https://listen.powerapp.com.tr/virginradioturkiye/mpeg/icecast.audio", isFavorite = true),
        RadioStation("5", "Slow Türk", "Slow, Türkçe", "128 kbps", "https://listen.slowturk.com/slowturk/mpeg/icecast.audio", isFavorite = true),
        RadioStation("6", "TRT FM", "Genel, Türkçe", "128 kbps", "https://radyo.trt.net.tr/trtfm", isFavorite = false),
        RadioStation("7", "BBC World Service", "World, News", "96 kbps", "https://stream.live.vc.bbcmedia.co.uk/bbc_world_service", isDomestic = false, isFavorite = true),
        RadioStation("8", "Radio Paradise", "Rock, Eclectic", "192 kbps", "https://stream.radioparadise.com/mp3-192", isDomestic = false, isFavorite = false)
    )

    fun playStation(station: RadioStation) {
        _currentStation.value = station
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(station.streamUrl)
                setOnPreparedListener {
                    start()
                    _isPlaying.value = true
                }
                setOnErrorListener { _, what, extra ->
                    Log.w("RadioStream", "Playback error: what=$what, extra=$extra")
                    _isPlaying.value = false
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("RadioStream", "Failed to play station: ${e.message}")
            _isPlaying.value = false
        }
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            mediaPlayer?.pause()
            _isPlaying.value = false
        } else {
            if (_currentStation.value != null) {
                mediaPlayer?.start()
                _isPlaying.value = true
            } else if (popularStations.isNotEmpty()) {
                playStation(popularStations.first())
            }
        }
    }

    fun nextStation() {
        val current = _currentStation.value ?: popularStations.first()
        val index = popularStations.indexOfFirst { it.id == current.id }
        val nextIndex = if (index != -1 && index < popularStations.size - 1) index + 1 else 0
        playStation(popularStations[nextIndex])
    }

    fun previousStation() {
        val current = _currentStation.value ?: popularStations.first()
        val index = popularStations.indexOfFirst { it.id == current.id }
        val prevIndex = if (index > 0) index - 1 else popularStations.size - 1
        playStation(popularStations[prevIndex])
    }

    fun setFmFreq(freq: Float) {
        _fmFrequency.value = String.format(java.util.Locale.US, "%.1f", freq.coerceIn(87.5f, 108.0f)).toFloat()
    }

    fun scanFmUp() {
        var current = _fmFrequency.value + 0.2f
        if (current > 108.0f) current = 87.5f
        setFmFreq(current)
    }

    fun scanFmDown() {
        var current = _fmFrequency.value - 0.2f
        if (current < 87.5f) current = 108.0f
        setFmFreq(current)
    }

    fun release() {
        mediaPlayer?.release()
        mediaPlayer = null
        _isPlaying.value = false
    }
}
