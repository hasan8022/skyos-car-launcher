package com.example.data

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Real ADB bridge to the head unit's own adbd at 127.0.0.1:5555.
 *
 * Uses the dadb library, which implements the actual ADB wire protocol
 * (CNXN -> AUTH -> OPEN/OKAY/WRTE) in pure Kotlin. No external adb binary,
 * no root required.
 *
 * Behaviour verified from the SkyOS APK (tr.halil.et5 v2.82) analysis:
 *  - The car head unit runs its own adbd; 127.0.0.1:5555 is loopback to itself.
 *  - The APK keeps ADB enabled ("Et5AdbKoruma") and authorizes its own key.
 *  - Without root, the user must once enable developer mode / "Aç adb" and
 *    accept the RSA fingerprint prompt on the car screen. The generated
 *    keypair is persisted in app-private storage so the prompt appears once.
 *
 * This class never fakes connectivity: every state transition is driven by a
 * real socket/protocol event.
 */
class AdbBridgeManager(
    private val context: Context,
    private val host: String = "127.0.0.1",
    private val port: Int = 5555
) {
    enum class AuthState {
        UNKNOWN,          // Not attempted yet
        CONNECTED,        // Authenticated, shell usable
        AUTH_REQUIRED,    // adbd asked for RSA auth — user must accept on car screen
        ADB_DISABLED,     // USB debugging / adbd tcp port not enabled
        UNREACHABLE,      // Port closed / connection refused
        ERROR             // Any other transport error
    }

    private val tag = "AdbBridge"
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _isUsbDebuggingEnabled = MutableStateFlow(false)
    val isUsbDebuggingEnabled: StateFlow<Boolean> = _isUsbDebuggingEnabled.asStateFlow()

    private val _authState = MutableStateFlow(AuthState.UNKNOWN)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _connectionStatus = MutableStateFlow("127.0.0.1:5555 aranıyor...")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _lastLog = MutableStateFlow("ADB Modülü Başlatıldı (dadb — gerçek ADB protokolü)")
    val lastLog: StateFlow<String> = _lastLog.asStateFlow()

    /** Device identity read after a real handshake (ro.product.* etc.). Null until connected. */
    private val _deviceInfo = MutableStateFlow<Map<String, String>>(emptyMap())
    val deviceInfo: StateFlow<Map<String, String>> = _deviceInfo.asStateFlow()

    @Volatile
    private var dadb: Dadb? = null
    private var workerJob: Job? = null
    private val shellMutex = Mutex()

    init {
        checkUsbDebugging()
    }

    // ------------------------------------------------------------------
    // ADB keypair persisted in app-private storage (created once, so the
    // car screen's "allow USB debugging" fingerprint prompt appears once).
    // ------------------------------------------------------------------
    private fun loadOrCreateKeyPair(): AdbKeyPair {
        val dir = File(context.filesDir, "adb").apply { mkdirs() }
        val privateKeyFile = File(dir, "adbkey")
        val publicKeyFile = File(dir, "adbkey.pub")
        if (!privateKeyFile.exists()) {
            AdbKeyPair.generate(privateKeyFile, publicKeyFile)
            Log.i(tag, "Yeni ADB anahtar çifti üretildi: ${privateKeyFile.absolutePath}")
        }
        return AdbKeyPair.read(privateKeyFile, publicKeyFile)
    }

    fun checkUsbDebugging(): Boolean {
        val enabled = try {
            Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.ADB_ENABLED,
                0
            ) == 1
        } catch (e: Exception) {
            false
        }
        _isUsbDebuggingEnabled.value = enabled
        return enabled
    }

    fun openDeveloperSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {}
        }
    }

    fun start() {
        if (workerJob != null) return
        workerJob = scope.launch {
            while (isActive) {
                if (!checkUsbDebugging()) {
                    _isConnected.value = false
                    _authState.value = AuthState.ADB_DISABLED
                    _connectionStatus.value = "Hata Ayıklama Kapalı (Geliştirici Seçeneklerinden Açın)"
                    _lastLog.value = "ADB kapalı: $host:$port dinlenemiyor."
                    delay(3000)
                    continue
                }

                try {
                    _authState.value = AuthState.UNKNOWN
                    _connectionStatus.value = "$host:$port bağlanıyor (ADB el sıkışması)..."
                    val keyPair = loadOrCreateKeyPair()

                    Dadb.create(host, port, keyPair, connectTimeout = 2500, socketTimeout = 8000).use { conn ->
                        dadb = conn
                        _isConnected.value = true
                        _authState.value = AuthState.CONNECTED
                        _connectionStatus.value = "$host:$port Bağlandı (ADB shell aktif)"
                        Log.i(tag, "ADB bağlantısı kuruldu")

                        // Read real device identity to prove 127.0.0.1:5555 really is the car head unit
                        _deviceInfo.value = readDeviceIdentity(conn)
                        _lastLog.value = "Cihaz: ${_deviceInfo.value["ro.product.model"] ?: "?"} " +
                                "(Android ${_deviceInfo.value["ro.build.version.release"] ?: "?"})"

                        // Keep-alive loop: real protocol round-trip every 5 s
                        while (isActive) {
                            val pong = runCatching { conn.shell("echo SKYOS_PING") }.getOrNull()
                            if (pong == null || !pong.output.contains("SKYOS_PING")) {
                                Log.w(tag, "ADB keep-alive başarısız, yeniden bağlanılacak")
                                break
                            }
                            delay(5000)
                        }
                    }
                } catch (e: Exception) {
                    val name = e.javaClass.simpleName
                    _isConnected.value = false
                    when {
                        name.contains("Auth", ignoreCase = true) -> {
                            _authState.value = AuthState.AUTH_REQUIRED
                            _connectionStatus.value = "ADB yetkilendirme bekleniyor — araç ekranındaki izin penceresini onaylayın"
                            _lastLog.value = "RSA parmak izi onayı gerekli (bir kez): $name"
                        }
                        name.contains("Connect", ignoreCase = true) || e is java.net.ConnectException -> {
                            _authState.value = AuthState.UNREACHABLE
                            _connectionStatus.value = "$host:$port ulaşılamıyor (adbd kapalı?)"
                            _lastLog.value = "Bağlantı hatası: ${e.message ?: name}"
                        }
                        else -> {
                            _authState.value = AuthState.ERROR
                            _connectionStatus.value = "ADB hatası: $name"
                            _lastLog.value = "Hata: ${e.message ?: name}"
                        }
                    }
                    Log.w(tag, "ADB bağlantı hatası ($name): ${e.message}")
                } finally {
                    dadb = null
                    _isConnected.value = false
                }
                delay(3000)
            }
        }
    }

    private fun readDeviceIdentity(conn: Dadb): Map<String, String> {
        val props = listOf(
            "ro.product.model", "ro.product.brand", "ro.product.device",
            "ro.build.version.release", "ro.build.display.id"
        )
        val out = runCatching {
            conn.shell(props.joinToString("; ") { "getprop $it" }).output
        }.getOrDefault("")
        val lines = out.lines().map { it.trim() }
        val map = mutableMapOf<String, String>()
        props.forEachIndexed { i, p -> if (i < lines.size && lines[i].isNotEmpty()) map[p] = lines[i] }
        return map
    }

    /**
     * Executes a shell command on the connected head unit.
     * @return shell stdout, or null when not connected / transport failure.
     * Never falls back to local Runtime.exec — a local shell is NOT the car.
     */
    suspend fun shell(command: String, timeoutMs: Long = 4000): String? =
        withContext(Dispatchers.IO) {
            val conn = dadb ?: return@withContext null
            shellMutex.withLock {
                try {
                    kotlinx.coroutines.withTimeout(timeoutMs) {
                        val response = conn.shell(command)
                        _lastLog.value = "shell> $command ⇒ ${response.output.take(120).trim()}"
                        response.output
                    }
                } catch (e: Exception) {
                    Log.w(tag, "shell('$command') hatası: ${e.message}")
                    _lastLog.value = "shell hatası ($command): ${e.message}"
                    null
                }
            }
        }

    /** Convenience synchronous probe used by diagnostics screens. */
    fun isSessionAlive(): Boolean = dadb != null && _isConnected.value

    fun stop() {
        workerJob?.cancel()
        workerJob = null
        try {
            dadb?.close()
        } catch (_: Exception) {}
        dadb = null
        _isConnected.value = false
        _authState.value = AuthState.UNKNOWN
    }
}
