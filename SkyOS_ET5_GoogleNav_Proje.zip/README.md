# SkyOS Otomotiv Kokpit & Google Maps Navigation SDK

Skywell ET5 ve Android 9–12+ (API 26–36) araç multimedya üniteleri için geliştirilmiş, **sıfır demo veri** prensibiyle çalışan ve **resmî Google Navigation SDK for Android** içeren tam kapsamlı araç arayüzü.

## 1. Google Maps & Navigation SDK API Yapılandırması

1. **Google Cloud Console** üzerinden projenizde aşağıdaki 3 servisi etkinleştirin ve Billing (Faturalandırma) hesabınızı bağlayın:
   - **Navigation SDK for Android**
   - **Maps SDK for Android**
   - **Places API**
2. Uygulama kısıtlamalarında paket adını (`com.aistudio.skyos.etcar`) ve SHA-1 imzanızı yetkilendirin.
3. Projenin kök dizinindeki `local.properties` (veya `.env`) dosyasına API anahtarınızı ekleyin (kaynak koda veya GitHub'a asla doğrudan yazmayın):
   ```properties
   MAPS_API_KEY=AIzaSyYourRealGoogleMapsAndNavigationKey
   ```

## 2. Temel Özellikler

- **Birebir Ana Sayfa Kokpit Tasarımı:** Sol panelde entegre vites (`P R N D`), bağlantı, batarya ve bordo `SOS` durum alanı; yarım daire kadran çizgili hız göstergesi (`km/h`) ve 3D/2D Skywell SUV; 4'lü yumuşak kapsül buton satırı (`ÖN/ARKA BAGAJ`, `SÜRÜCÜ`, gerçek sistem saati, direksiyon asistanı); albüm kapaklı müzik kartı; en altta ortada pastel ses dalgalı **`SESLİ ASİSTAN`** mikrofonu.
- **Gerçek Google Navigation SDK (`GoogleNavigationManager.kt`, `GoogleMapNavigationView.kt`):**
  - Uygulama açıldığında sabit hiçbir şehre/koordinata kilitlenmez; `FusedLocationProviderClient` ile cihazın gerçek GPS konumunu alır ve haritayı doğrudan bulunduğunuz yere odaklar.
  - 3 farklı hedef belirleme yöntemi: (1) Google Places API / Geocoder ile adres arama, (2) Enlem ve boylam (Lat/Lng) girme, (3) Haritadan dokunarak hedef seçme.
  - Uygulama içi `NavigationView` üzerinde tam ekran Google sesli ve görsel araç navigasyonu (Türkçe sesli yönlendirme, şerit/kavşak/hız bilgisi, kalan km ve tahmini varış süresi, otomatik yeniden rota hesaplama, Normal/Uydu/Hibrit ve Gece/Gündüz modları).
- **Sıfır Demo Veri Prensibi:** Araç veri yolu (`car_service` / ADB / OBD) veya cihaz sensörleri bağlı değilken hiçbir uydurma hız, batarya yüzdesi, sıcaklık veya sahte koordinat üretilmez.
