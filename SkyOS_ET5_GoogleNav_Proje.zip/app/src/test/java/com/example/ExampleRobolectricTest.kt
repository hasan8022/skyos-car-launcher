package com.example

import com.example.model.Gear
import com.example.model.VehicleState
import com.example.navigation.GoogleNavUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun `test initial vehicle state has zero demo data`() {
        val state = VehicleState()
        assertEquals(Gear.P, state.gear)
        // Demo veri yasak: car_service bağlanana kadar batarya ve menzil -1 (Veri Yok) başlar
        assertEquals(-1, state.batteryPercent)
        assertEquals(-1, state.rangeKm)
        assertNull(state.outsideTempC)
        assertNull(state.insideTempC)
        assertFalse(state.trunk)
        assertFalse(state.hood)
    }

    @Test
    fun `test initial google navigation state has no hardcoded city or coordinates`() {
        val navState = GoogleNavUiState()
        // Harita sabit bir şehir veya koordinata kilitlenmez; gerçek GPS gelene kadar null başlar
        assertNull(navState.currentLocation)
        assertTrue(navState.isWaitingForFirstLocation)
        assertFalse(navState.isGuidanceActive)
    }

    @Test
    fun `test vehicle gear and safety logic`() {
        var state = VehicleState()
        assertEquals(Gear.P, state.gear)

        // Trunk opens in P
        state = state.copy(trunk = true)
        assertTrue(state.trunk)

        // Switch to D
        state = state.copy(gear = Gear.D, trunk = false)
        assertEquals(Gear.D, state.gear)
        assertFalse(state.trunk)
    }
}
