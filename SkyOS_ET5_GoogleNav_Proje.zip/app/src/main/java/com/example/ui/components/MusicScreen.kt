package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.ui.theme.LocalSkyPalette
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun MusicScreen(
    repository: VehicleRepository,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    val isPlaying by repository.radioManager.isPlaying.collectAsState()
    val currentStation by repository.radioManager.currentStation.collectAsState()

    var selectedSource by remember { mutableStateOf("internet_radyo") }
    var selectedGenreTab by remember { mutableStateOf("Türkiye") }

    val allStations = repository.radioManager.popularStations
    val genreTabs = buildList {
        add("Favoriler")
        add("Türkiye")
        add("Dünya")
        listOf("Pop", "Rock", "Türkü", "Arabesk", "Jazz").forEach { genre ->
            if (allStations.any { it.genre.contains(genre, ignoreCase = true) }) add(genre)
        }
    }

    val eqTransition = rememberInfiniteTransition(label = "musicEq")
    val eqPhase by eqTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "eqPhase"
    )

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(palette.backgroundBrush)
    ) {
        // Left Side Music Sources Sidebar
        Column(
            modifier = Modifier
                .width(215.dp)
                .fillMaxHeight()
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle)
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.accentSoftBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.LibraryMusic, contentDescription = null, tint = palette.accent, modifier = Modifier.size(17.dp))
                }
                Text("MEDYA MERKEZİ", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }

            Text("CANLI RADYO & AKIM", color = palette.textMuted, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(6.dp))
            MusicSourceItem("İnternet Radyosu", Icons.Default.Radio, selectedSource == "internet_radyo") { selectedSource = "internet_radyo" }
            MusicSourceItem("FM Radyo", Icons.Default.Sensors, selectedSource == "fm_radyo") { selectedSource = "fm_radyo" }
            MusicSourceItem("USB Müzik", Icons.Default.Usb, selectedSource == "usb_muzik") { selectedSource = "usb_muzik" }

            Spacer(modifier = Modifier.height(16.dp))

            Text("SPOTIFY WEB PLAYER", color = palette.textMuted, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(6.dp))
            MusicSourceItem("Ana Sayfa", Icons.Default.Home, selectedSource == "spotify_home") { selectedSource = "spotify_home" }
            MusicSourceItem("Şarkı Ara", Icons.Default.Search, selectedSource == "spotify_search") { selectedSource = "spotify_search" }
            MusicSourceItem("Beğenilenler", Icons.Default.FavoriteBorder, selectedSource == "spotify_fav") { selectedSource = "spotify_fav" }
            MusicSourceItem("Çalma Listelerim", Icons.Default.QueueMusic, selectedSource == "spotify_playlists") { selectedSource = "spotify_playlists" }
        }

        // Right Content Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            // Header + Now Playing Hero Banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = when (selectedSource) {
                            "fm_radyo" -> "FM Radyo Alıcısı"
                            "usb_muzik" -> "USB Medya Sürücüsü"
                            "internet_radyo" -> "Canlı İnternet Radyosu"
                            else -> "Spotify Araç İçi Web Oynatıcı"
                        },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = "Kesintisiz dijital ses akışı ve direksiyon tuşu kontrolü",
                        fontSize = 12.sp,
                        color = palette.textSecondary
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(palette.surfaceElevated)
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = palette.textPrimary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedSource.startsWith("spotify")) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(palette.surface)
                        .border(1.dp, Color(0xFF1DB954).copy(alpha = 0.45f), RoundedCornerShape(22.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1DB954)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null, tint = Color.Black, modifier = Modifier.size(46.dp))
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Spotify Araç İçi Web Player", color = palette.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Çalma listeleriniz, favori şarkılarınız ve podcastleriniz", color = palette.textSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { repository.openWebBrowser("Spotify", "https://open.spotify.com") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DB954)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Spotify Web Oynatıcısını Aç", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            } else if (selectedSource == "fm_radyo") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.borderSubtle, RoundedCornerShape(22.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SensorsOff,
                        contentDescription = null,
                        tint = palette.statusWarning,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("FM Radyo Kullanılamıyor", color = palette.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Aracın FM tuner donanımına uygulama üzerinden erişilemiyor. FM dinlemek için aracın kendi radyo uygulamasını kullanın; internet üzerinden yayın yapan gerçek istasyonlar için \"İnternet Radyosu\" sekmesini açın.",
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { selectedSource = "internet_radyo" },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text("İnternet Radyosunu Aç", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            } else if (selectedSource == "usb_muzik") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.borderSubtle, RoundedCornerShape(22.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.UsbOff,
                        contentDescription = null,
                        tint = palette.statusWarning,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("USB Müzik Desteklenmiyor", color = palette.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "USB depolamadaki müzik dosyalarını tarama özelliği bu sürümde bulunmuyor. Spotify Web veya internet radyosu gerçek yayın kaynakları olarak kullanılabilir.",
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            } else {
                // Genre Filter Pills
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(genreTabs) { tab ->
                        val isSelected = selectedGenreTab == tab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) palette.accent else palette.surfaceElevated)
                                .border(1.dp, if (isSelected) palette.accent else palette.borderSubtle, RoundedCornerShape(20.dp))
                                .clickable { selectedGenreTab = tab }
                                .padding(horizontal = 16.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = tab,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                color = if (isSelected) Color.Black else palette.textSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val stations = allStations.filter {
                    when (selectedGenreTab) {
                        "Favoriler" -> it.isFavorite
                        "Dünya" -> !it.isDomestic
                        "Türkiye" -> it.isDomestic
                        else -> it.genre.contains(selectedGenreTab, ignoreCase = true)
                    }
                }

                if (stations.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Bu türde kayıtlı istasyon yok.",
                            color = palette.textSecondary,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(stations) { station ->
                            val isCurrent = currentStation?.id == station.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isCurrent) palette.accentSoftBg else palette.surface)
                                    .border(
                                        1.dp,
                                        if (isCurrent) palette.accent.copy(alpha = 0.6f) else palette.borderSubtle,
                                        RoundedCornerShape(16.dp)
                                    )
                                    .clickable { repository.radioManager.playStation(station) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    if (isCurrent) listOf(palette.accent, palette.accentSecondary)
                                                    else listOf(Color(0xFF6366F1), Color(0xFFA855F7))
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isCurrent && isPlaying) Icons.Default.GraphicEq else Icons.Default.Radio,
                                            contentDescription = null,
                                            tint = if (isCurrent) Color.Black else Color.White
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = station.name,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = palette.textPrimary
                                        )
                                        Text(
                                            text = "${station.genre}  •  ${station.bitrate}  •  Canlı Akış",
                                            fontSize = 12.sp,
                                            color = if (isCurrent) palette.accent else palette.textSecondary
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    if (isCurrent && isPlaying) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = palette.statusSuccess.copy(alpha = 0.18f)
                                        ) {
                                            Text(
                                                text = "CANLI",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = palette.statusSuccess,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    Icon(
                                        imageVector = if (station.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Favori",
                                        tint = if (station.isFavorite) Color(0xFFFBBF24) else palette.textMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Glass Now Playing Bar with Animated Equalizer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.accentSoftBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = palette.accent)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentStation?.name ?: "İstasyon Seçilmedi",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentStation?.let { "${it.genre} • ${it.bitrate}" } ?: "Dinlemek için listeden bir istasyona dokunun",
                            fontSize = 11.sp,
                            color = palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Live Equalizer Bars
                Canvas(
                    modifier = Modifier
                        .width(90.dp)
                        .height(28.dp)
                        .padding(horizontal = 8.dp)
                ) {
                    val bars = 12
                    val bw = 4.dp.toPx()
                    val step = size.width / bars
                    for (i in 0 until bars) {
                        val amp = if (isPlaying) abs(sin(i * 0.6f + eqPhase)).toFloat() else 0.15f
                        val bh = (4f + amp * (size.height - 6f)).coerceAtMost(size.height)
                        drawRoundRect(
                            color = palette.accent,
                            topLeft = Offset(i * step, (size.height - bh) / 2f),
                            size = Size(bw, bh),
                            cornerRadius = CornerRadius(2f, 2f)
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = { repository.radioManager.previousStation() }) {
                        Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "Geri", tint = palette.textPrimary)
                    }

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(palette.accent)
                            .clickable { repository.radioManager.togglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Oynat/Durdur",
                            tint = Color.Black
                        )
                    }

                    IconButton(onClick = { repository.radioManager.nextStation() }) {
                        Icon(imageVector = Icons.Default.SkipNext, contentDescription = "İleri", tint = palette.textPrimary)
                    }
                }
            }
        }
    }
}

@Composable
fun MusicSourceItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalSkyPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) palette.accentSoftBg else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) palette.accent else palette.textSecondary,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = title,
            fontSize = 13.sp,
            color = if (isSelected) palette.textPrimary else palette.textSecondary,
            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
        )
    }
}
