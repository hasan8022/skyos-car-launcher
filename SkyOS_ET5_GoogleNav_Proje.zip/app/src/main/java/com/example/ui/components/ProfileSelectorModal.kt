package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DriverProfile
import com.example.ui.theme.LocalSkyPalette

@Composable
fun ProfileSelectorModal(
    profiles: List<DriverProfile>,
    activeProfileId: Int,
    onProfileSelected: (Int) -> Unit,
    onOpenProfileSettings: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomStart
    ) {
        Column(
            modifier = Modifier
                .padding(start = 18.dp, bottom = 70.dp)
                .width(340.dp)
                .clickable(enabled = false) {}
                .clip(RoundedCornerShape(22.dp))
                .background(palette.surface)
                .border(1.5.dp, palette.accent.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "SÜRÜCÜ PROFİLİ SEÇİMİ",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = palette.accent
            )

            profiles.forEach { profile ->
                val isSelected = profile.id == activeProfileId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) palette.accentSoftBg else palette.surfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) palette.accent.copy(alpha = 0.5f) else palette.borderSubtle,
                            RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            onProfileSelected(profile.id)
                            onDismiss()
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(profile.avatarColorHex))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = profile.initial, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Column {
                            Text(text = profile.name, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "${profile.preferredTemp}°C • ${profile.connectedPhoneName}", color = palette.textSecondary, fontSize = 11.sp)
                        }
                    }

                    if (isSelected) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Aktif", tint = palette.accent, modifier = Modifier.size(20.dp))
                    }
                }
            }

            HorizontalDivider(color = palette.borderSubtle)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable {
                        onOpenProfileSettings()
                        onDismiss()
                    }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Person, contentDescription = "Profil ayarları", tint = palette.accent, modifier = Modifier.size(18.dp))
                Text(text = "Tüm Profil Ayarlarını Yönet", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
