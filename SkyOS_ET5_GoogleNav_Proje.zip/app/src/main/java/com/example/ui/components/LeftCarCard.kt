package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DriverProfile
import com.example.model.Gear
import com.example.model.VehicleState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 156821.jpg (a2990357.jpeg) referans görseli ile birebir (1:1) Sol Araç ve Durum Paneli:
 * 1. Üst Durum Satırı: P R N D | Wi-Fi | Bluetooth | Yatay Batarya İkonu + %78 - 312 km
 * 2. İkinci Satır: Dıs 16° 🌡️ İç 22° ⛅  |  Bordo [SOS] Kapsül Butonu (#6D1A29)
 * 3. Orta Alan: Yarım daire kadranlı hız göstergesi (58 km/h) ve 1:1 Buz Mavisi 3D Skywell ET5 SUV
 * 4. 4'lü Yumuşak Neumorphic Kapsül Satırı: [ÖN/ARKA BAGAJ] [SÜRÜCÜ: EMİR] [10:28] [Direksiyon]
 * 5. Alt Müzik Kartı: Orijinal albüm görseli, MÜZİK / Dinle Beni Bi / Yüzyüzeyken Konuşuruz, ♡, |◁ ▷ ▷|, 1:24 / -2:18 ve 🔀
 */
@Composable
fun LeftCarCard(
    vehicleState: VehicleState,
    currentProfile: DriverProfile,
    currentStationName: String?,
    currentStationGenre: String? = null,
    isPlayingMusic: Boolean,
    onGearSelected: (Gear) -> Unit = {},
    onSosClicked: () -> Unit = {},
    onBatteryToggleRemaining: () -> Unit = {},
    showRemainingKm: Boolean = false,
    onToggleDoor: (String) -> Unit,
    onToggleTrunk: () -> Unit,
    onToggleHood: () -> Unit,
    onToggleChargePort: () -> Unit,
    onToggle2D3D: () -> Unit,
    onOpenVoiceAssistant: () -> Unit,
    onOpenProfileSelector: () -> Unit,
    onPlayPauseMusic: () -> Unit,
    onNextMusic: () -> Unit,
    onPrevMusic: () -> Unit,
    onOpenMusicScreen: () -> Unit,
    onToggle220V: () -> Unit,
    onToggleDefrostFront: () -> Unit,
    onToggleDefrostRear: () -> Unit,
    onToggleMirrors: () -> Unit,
    onOpenQuickSettings: () -> Unit = {},
    isDark: Boolean = false,
    modifier: Modifier = Modifier
) {
    var currentTime by remember {
        mutableStateOf(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
    }
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(10_000L)
        }
    }

    var elapsedSeconds by remember(currentStationName) { mutableIntStateOf(84) } // 1:24 başlangıç
    LaunchedEffect(isPlayingMusic, currentStationName) {
        while (isPlayingMusic) {
            delay(1000L)
            elapsedSeconds++
        }
    }

    var isFavoriteStation by remember(currentStationName) { mutableStateOf(false) }

    // 156821.jpg ile birebir renk paleti (#ECEBE6 sıcak sedef gri)
    val panelBg = if (isDark) Color(0xFF0E131D) else Color(0xFFECEBE6)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF22252C)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF72767F)
    val pillBg = if (isDark) Color(0xFF182030) else Color(0xFFEDECE8)
    val pillBorder = if (isDark) Color(0xFF28344B) else Color(0xFFF9F9F7)
    val cardBg = if (isDark) Color(0xFF151C2A) else Color(0xFFF4F4F0)

    val dispBattery = if (vehicleState.batteryPercent in 0..100) vehicleState.batteryPercent else 78
    val dispRange = if (vehicleState.rangeKm >= 0) vehicleState.rangeKm else 312
    val dispOutTemp = vehicleState.outsideTempC ?: 16
    val dispInTemp = vehicleState.insideTempC ?: 22

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(panelBg)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. ÜST DURUM ALANI (P R N D + Wi-Fi/BT/Batarya + Sıcaklık + SOS)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Satır 1: P R N D  |  Wi-Fi  Bluetooth  [Batarya] %78 - 312 km
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val gears = listOf(Gear.P, Gear.R, Gear.N, Gear.D)
                    gears.forEach { gear ->
                        val isSelected = vehicleState.gear == gear || (gear == Gear.D && vehicleState.gear == Gear.S)
                        Text(
                            text = if (gear == Gear.D && vehicleState.gear == Gear.S) "S" else gear.name,
                            fontSize = 23.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) textPrimary else Color(0xFF7E828A),
                            modifier = Modifier
                                .testTag("gear_button_${gear.name}")
                                .clickable { onGearSelected(gear) }
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "Wi-Fi",
                        tint = Color(0xFF6B7078),
                        modifier = Modifier.size(18.dp)
                    )

                    Icon(
                        imageVector = Icons.Default.Bluetooth,
                        contentDescription = "Bluetooth",
                        tint = Color(0xFF6B7078),
                        modifier = Modifier.size(17.dp)
                    )

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onBatteryToggleRemaining() }
                            .padding(horizontal = 2.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val socFraction = (dispBattery / 100f).coerceIn(0f, 1f)

                        Canvas(modifier = Modifier.size(width = 30.dp, height = 14.dp)) {
                            val bodyW = size.width - 3.dp.toPx()
                            val bodyH = size.height
                            drawRoundRect(
                                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF5A5E66),
                                topLeft = Offset.Zero,
                                size = Size(bodyW, bodyH),
                                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                                style = Stroke(width = 1.4.dp.toPx())
                            )
                            drawRoundRect(
                                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF5A5E66),
                                topLeft = Offset(bodyW + 1.dp.toPx(), bodyH * 0.28f),
                                size = Size(2.dp.toPx(), bodyH * 0.44f),
                                cornerRadius = CornerRadius(1.dp.toPx(), 1.dp.toPx())
                            )
                            val pad = 2.2.dp.toPx()
                            val fillW = (bodyW - pad * 2) * socFraction
                            drawRoundRect(
                                color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF555962),
                                topLeft = Offset(pad, pad),
                                size = Size(fillW, bodyH - pad * 2),
                                cornerRadius = CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx())
                            )
                        }

                        Text(
                            text = buildAnnotatedString {
                                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = textPrimary)) {
                                    append("%$dispBattery")
                                }
                                withStyle(SpanStyle(fontWeight = FontWeight.Normal, color = Color(0xFF52565E))) {
                                    append(" - $dispRange km")
                                }
                            },
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Satır 2: Dıs 16° 🌡️ İç 22° ⛅  |  Bordo [SOS] Hap Butonu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Dıs ${dispOutTemp}°",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal,
                        color = textPrimary
                    )
                    Icon(
                        imageVector = Icons.Default.Thermostat,
                        contentDescription = null,
                        tint = Color(0xFF5D626A),
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "İç ${dispInTemp}°",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal,
                        color = textPrimary
                    )
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = null,
                        tint = Color(0xFF5D626A),
                        modifier = Modifier.size(15.dp)
                    )
                }

                // 156821.jpg'deki Bordo SOS Kapsül Butonu (#6D1A29)
                Box(
                    modifier = Modifier
                        .testTag("sos_button")
                        .shadow(4.dp, RoundedCornerShape(18.dp))
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF6D1A29))
                        .clickable { onSosClicked() }
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "SOS",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // 2. ORTA ALAN: YARIM DAİRE HIZ KADRANI (58 km/h) + 1:1 BUZ MAVİSİ 3D ARAÇ
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            CarView(
                vehicleState = vehicleState,
                onToggleDoor = onToggleDoor,
                onToggleTrunk = onToggleTrunk,
                onToggleHood = onToggleHood,
                onToggleChargePort = onToggleChargePort,
                onToggle2D3D = onToggle2D3D,
                isDark = isDark,
                modifier = Modifier.fillMaxSize()
            )
        }

        // 3. ARAÇ ALTI 4'LÜ YUMUŞAK NEUMORPHIC KAPSÜL SATIRI
        // [ 🚗 ÖN/ARKA BAGAJ ]  [ 📍 SÜRÜCÜ: EMİR ]  [ 10:28 ]  [ 🛞 ]
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. ÖN/ARKA BAGAJ
            Row(
                modifier = Modifier
                    .weight(1.38f)
                    .height(50.dp)
                    .testTag("trunk_pill_button")
                    .shadow(3.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (vehicleState.trunk || vehicleState.hood) Color(0xFFFEE2E2) else pillBg)
                    .border(1.dp, pillBorder, RoundedCornerShape(16.dp))
                    .clickable { onToggleTrunk() }
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsCar,
                    contentDescription = "Ön/Arka Bagaj",
                    tint = if (vehicleState.trunk) Color(0xFFDC2626) else textPrimary,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (vehicleState.trunk) "BAGAJ AÇIK" else "ÖN/ARKA BAGAJ",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (vehicleState.trunk) Color(0xFFDC2626) else textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // 2. SÜRÜCÜ PROFİLİ (SÜRÜCÜ: EMİR)
            Row(
                modifier = Modifier
                    .weight(1.05f)
                    .height(50.dp)
                    .testTag("profile_pill_button")
                    .shadow(3.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(pillBg)
                    .border(1.dp, pillBorder, RoundedCornerShape(16.dp))
                    .clickable { onOpenProfileSelector() }
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Sürücü",
                    tint = textPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Column(verticalArrangement = Arrangement.Center) {
                    Text(
                        text = "SÜRÜCÜ:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Normal,
                        color = textPrimary,
                        lineHeight = 11.sp
                    )
                    Text(
                        text = currentProfile.name.ifBlank { "EMİR" }.uppercase(Locale("tr", "TR")),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 12.sp
                    )
                }
            }

            // 3. SAAT (10:28)
            Box(
                modifier = Modifier
                    .weight(0.85f)
                    .height(50.dp)
                    .shadow(3.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(pillBg)
                    .border(1.dp, pillBorder, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentTime,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    color = textPrimary
                )
            }

            // 4. DİREKSİYON İKON BUTONU
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .shadow(3.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(pillBg)
                    .border(1.dp, pillBorder, RoundedCornerShape(16.dp))
                    .clickable { onOpenQuickSettings() },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(20.dp)) {
                    val c = if (isDark) Color.White else Color(0xFF232730)
                    val r = size.minDimension / 2f
                    drawCircle(color = c, radius = r, style = Stroke(width = 1.7.dp.toPx()))
                    drawCircle(color = c, radius = r * 0.28f, style = Stroke(width = 1.4.dp.toPx()))
                    drawLine(c, Offset(r * 0.15f, r * 0.9f), Offset(r * 0.72f, r), strokeWidth = 1.5.dp.toPx())
                    drawLine(c, Offset(size.width - r * 0.15f, r * 0.9f), Offset(size.width - r * 0.72f, r), strokeWidth = 1.5.dp.toPx())
                    drawLine(c, Offset(r, r * 1.28f), Offset(r, size.height), strokeWidth = 1.5.dp.toPx())
                }
            }
        }

        // 4. ALT MÜZİK KARTI (156821.jpg İle Birebir Tasarım)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(4.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(cardBg)
                .border(1.dp, pillBorder, RoundedCornerShape(22.dp))
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Sol Orijinal Albüm Görseli (156821.jpg'den birebir)
                    Image(
                        painter = painterResource(id = R.drawable.album_dinle_beni_bi),
                        contentDescription = "Albüm Kapağı",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(66.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onOpenMusicScreen() }
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    // Orta Parça Bilgisi ("MÜZİK" / "Dinle Beni Bi" / "Yüzyüzeyken Konuşuruz")
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onOpenMusicScreen() }
                    ) {
                        Text(
                            text = "MÜZİK",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = textSecondary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = currentStationName ?: "Dinle Beni Bi",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentStationGenre ?: "Yüzyüzeyken Konuşuruz",
                            fontSize = 12.5.sp,
                            color = textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Sağ Oynatma Kontrolleri: ♡ üstte, |◁   ( ▷ )   ▷| altta
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = if (isFavoriteStation) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favori",
                            tint = if (isFavoriteStation) Color(0xFFE11D48) else Color(0xFF434852),
                            modifier = Modifier
                                .size(18.dp)
                                .clickable { isFavoriteStation = !isFavoriteStation }
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = onPrevMusic,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Önceki",
                                    tint = textPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (isDark) Color(0xFF38BDF8) else Color(0xFF484E58))
                                    .clickable { onPlayPauseMusic() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPlayingMusic) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Oynat/Duraklat",
                                    tint = if (isDark) Color.Black else Color.White,
                                    modifier = Modifier.size(21.dp)
                                )
                            }

                            IconButton(
                                onClick = onNextMusic,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Sonraki",
                                    tint = textPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // Alt İlerleme Çubuğu (1:24 / -2:18) + Karıştır (🔀)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val totalSecs = 222 // 3:42 toplam
                    val curSecs = elapsedSeconds.coerceIn(0, totalSecs)
                    val remSecs = (totalSecs - curSecs).coerceAtLeast(0)
                    val progressFraction = (curSecs / totalSecs.toFloat()).coerceIn(0.05f, 1f)

                    Column(modifier = Modifier.weight(1f)) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                        ) {
                            val midY = size.height / 2f
                            drawLine(
                                color = if (isDark) Color(0xFF334155) else Color(0xFFD0D3DA),
                                start = Offset(0f, midY),
                                end = Offset(size.width, midY),
                                strokeWidth = 2.5.dp.toPx()
                            )
                            val activeX = size.width * progressFraction
                            drawLine(
                                color = if (isDark) Color(0xFF38BDF8) else Color(0xFF484E58),
                                start = Offset(0f, midY),
                                end = Offset(activeX, midY),
                                strokeWidth = 2.5.dp.toPx()
                            )
                            drawCircle(
                                color = if (isDark) Color(0xFF38BDF8) else Color(0xFF484E58),
                                radius = 4.5.dp.toPx(),
                                center = Offset(activeX, midY)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = String.format(Locale.US, "%d:%02d", curSecs / 60, curSecs % 60),
                                fontSize = 10.5.sp,
                                color = textPrimary
                            )
                            Text(
                                text = String.format(Locale.US, "-%d:%02d", remSecs / 60, remSecs % 60),
                                fontSize = 10.5.sp,
                                color = textPrimary
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Karıştır",
                        tint = textPrimary,
                        modifier = Modifier
                            .size(17.dp)
                            .clickable { onNextMusic() }
                    )
                }
            }
        }
    }
}
