package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.ui.theme.LocalSkyPalette

/**
 * SkyOS İlk Açılış Kurulum Sihirbazı (Tam Tasarım).
 *
 * Gerçek durum gösterir, sahte "hazır" mesajı vermez:
 * - Mikrofon/konum izni durumu cihazdan canlı okunur
 * - GPS fix durumu telemetriden canlı okunur
 * - Sesli asistan desteği cihazdan canlı okunur
 * - Ev/İş adresleri kullanıcının girdiği GERÇEK değerlerdir
 */
@Composable
fun SetupWizardScreen(
    repository: VehicleRepository,
    speechAvailable: Boolean,
    onDeviceRecognition: Boolean,
    onRequestPermissions: () -> Unit,
    onFinish: () -> Unit
) {
    val palette = LocalSkyPalette.current
    var step by remember { mutableStateOf(0) }
    var homeAddress by remember { mutableStateOf(repository.getSavedLocationName("home_address") ?: "") }
    var workAddress by remember { mutableStateOf(repository.getSavedLocationName("work_address") ?: "") }

    val telemetry by repository.telemetryHelper.telemetry.collectAsState()

    val context = repository.getContext()
    fun granted(p: String) = androidx.core.content.ContextCompat.checkSelfPermission(
        context, p
    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    val micGranted = granted(android.Manifest.permission.RECORD_AUDIO)
    val locGranted = granted(android.Manifest.permission.ACCESS_FINE_LOCATION)
    val btGranted = if (android.os.Build.VERSION.SDK_INT >= 31)
        granted(android.Manifest.permission.BLUETOOTH_CONNECT) && granted(android.Manifest.permission.BLUETOOTH_SCAN)
    else true
    val notifGranted = if (android.os.Build.VERSION.SDK_INT >= 33)
        granted(android.Manifest.permission.POST_NOTIFICATIONS)
    else true
    val phoneGranted = granted(android.Manifest.permission.READ_PHONE_STATE) &&
        granted(android.Manifest.permission.CALL_PHONE) &&
        granted(android.Manifest.permission.READ_CONTACTS) &&
        granted(android.Manifest.permission.READ_CALL_LOG)
    val storageGranted = granted(android.Manifest.permission.READ_EXTERNAL_STORAGE)
    val cameraGranted = granted(android.Manifest.permission.CAMERA)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.backgroundBrush),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.74f)
                .clip(RoundedCornerShape(28.dp))
                .background(palette.surface)
                .border(1.5.dp, palette.accent.copy(alpha = 0.45f), RoundedCornerShape(28.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header & Step Indicator Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.accentSoftBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.DirectionsCar, contentDescription = null, tint = palette.accent, modifier = Modifier.size(26.dp))
                    }
                    Column {
                        Text(
                            text = "SkyOS Kokpit Kurulumu",
                            color = palette.textPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Adım ${step + 1} / 3",
                            color = palette.accent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(3) { idx ->
                        Box(
                            modifier = Modifier
                                .width(if (step == idx) 28.dp else 10.dp)
                                .height(8.dp)
                                .clip(CircleShape)
                                .background(if (idx <= step) palette.accent else palette.surfaceElevated)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            when (step) {
                0 -> {
                    Text(
                        text = "SkyOS Yeni Nesil Otomotiv Arayüzüne Hoş Geldiniz",
                        color = palette.textPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Başlamadan önce birkaç hızlı adımı tamamlayalım:\n\n" +
                                "• Mikrofon, GPS konum, Bluetooth ve telefon izinleri\n" +
                                "• Sesli asistan ve hızlı rota için Ev & İş adresleriniz\n\n" +
                                "Tüm verileriniz yalnızca aracınızın yerel belleğinde saklanır.",
                        color = palette.textSecondary,
                        fontSize = 16.sp,
                        lineHeight = 24.sp
                    )
                    Spacer(modifier = Modifier.height(26.dp))
                    Button(
                        onClick = { step = 1 },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) {
                        Text("Kuruluma Başla", color = Color.Black, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }

                1 -> {
                    Text(
                        text = "Donanım ve Sistem İzinleri",
                        color = palette.textPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    SetupStatusRow("Mikrofon (Sesli Asistan)", micGranted)
                    SetupStatusRow("Konum (GPS Navigasyon)", locGranted)
                    SetupStatusRow("Bluetooth (Telefon ve Medya)", btGranted)
                    SetupStatusRow("Bildirimler (Yol Uyarıları)", notifGranted)
                    SetupStatusRow("Telefon, Rehber ve Arama Kaydı", phoneGranted)
                    SetupStatusRow("Depolama (Medya ve Harita Önbelleği)", storageGranted)
                    SetupStatusRow("Kamera (Geri Görüş / ADAS)", cameraGranted)
                    SetupStatusRow("Sesli Tanıma Servisi", speechAvailable, falseText = "Bu cihazda desteklenmiyor")
                    if (speechAvailable) {
                        SetupStatusRow(
                            "Cihaz İçi Tanıma (Çevrimdışı)",
                            onDeviceRecognition,
                            trueText = "Destekleniyor",
                            falseText = "Yok — internet gerekli"
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val allGranted = micGranted && locGranted && btGranted && notifGranted && phoneGranted
                    if (!allGranted) {
                        Button(
                            onClick = { onRequestPermissions() },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Text("Tüm İzinleri Ver", color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    } else {
                        Text(
                            text = "Tüm kritik izinler hazır ✓",
                            color = palette.statusSuccess,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { step = 0 }) {
                            Text("Geri", color = palette.textSecondary, fontSize = 15.sp)
                        }
                        Button(
                            onClick = { step = 2 },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Devam Et", color = Color.Black, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }

                2 -> {
                    Text(
                        text = "Ev ve İş Adresleri",
                        color = palette.textPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "\"Eve git\" ve \"İşe git\" sesli komutları bu adresleri kullanır. Boş bırakırsanız sahte adres kullanılmaz.",
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = homeAddress,
                        onValueChange = { homeAddress = it },
                        label = { Text("Ev adresi (örn: Kadıköy, Moda Caddesi)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.accent,
                            focusedLabelColor = palette.accent,
                            unfocusedTextColor = palette.textPrimary,
                            focusedTextColor = palette.textPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = workAddress,
                        onValueChange = { workAddress = it },
                        label = { Text("İş adresi (opsiyonel)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.accent,
                            focusedLabelColor = palette.accent,
                            unfocusedTextColor = palette.textPrimary,
                            focusedTextColor = palette.textPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    SetupStatusRow(
                        label = "Canlı GPS Konumu",
                        ok = telemetry.hasGpsFix,
                        trueText = "Aktif",
                        falseText = "Henüz yok (açık alanda otomatik bağlanır)"
                    )

                    Spacer(modifier = Modifier.height(18.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { step = 1 }) {
                            Text("Geri", color = palette.textSecondary, fontSize = 15.sp)
                        }
                        Button(
                            onClick = {
                                if (homeAddress.isNotBlank()) {
                                    repository.setSavedLocationName("home_address", homeAddress.trim())
                                }
                                if (workAddress.isNotBlank()) {
                                    repository.setSavedLocationName("work_address", workAddress.trim())
                                }
                                repository.markSetupCompleted()
                                onFinish()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Kokpiti Başlat", color = Color.Black, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupStatusRow(
    label: String,
    ok: Boolean,
    trueText: String = "Verildi",
    falseText: String = "Verilmedi"
) {
    val palette = LocalSkyPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = palette.textSecondary, fontSize = 14.sp)
        Text(
            text = if (ok) "✓ $trueText" else "✗ $falseText",
            color = if (ok) palette.statusSuccess else palette.statusDanger,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
