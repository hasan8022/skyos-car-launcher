package com.example.ui.components

import android.annotation.SuppressLint
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.example.R
import com.example.model.VehicleState
import kotlin.math.cos
import kotlin.math.sin

/**
 * 156821.jpg (a2990357.jpeg) referans tasarımındaki yarım daire kadran çizgili hız göstergesi ("58 km/h")
 * ve 1:1 izometrik Buz Mavisi Skywell ET5 3D araç görünümü + etkileşimli 3D WebGL modu.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CarView(
    vehicleState: VehicleState,
    onToggleDoor: (String) -> Unit,
    onToggleTrunk: () -> Unit,
    onToggleHood: () -> Unit,
    onToggleChargePort: () -> Unit,
    onToggle2D3D: () -> Unit,
    isDark: Boolean = false,
    modifier: Modifier = Modifier
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var is3dReady by remember { mutableStateOf(false) }
    var useInteractiveWebGl by remember { mutableStateOf(false) }

    LaunchedEffect(
        vehicleState.doorFL, vehicleState.doorFR, vehicleState.doorRL, vehicleState.doorRR,
        vehicleState.hood, vehicleState.trunk, vehicleState.chargePort,
        vehicleState.leftSignal, vehicleState.rightSignal, vehicleState.hazardLights,
        vehicleState.brakeLights, vehicleState.carColorHex, is3dReady
    ) {
        if (is3dReady && webViewRef != null) {
            val js = """
                try {
                    if (window.CAR) {
                        CAR.setColor('${vehicleState.carColorHex}');
                        CAR.view('hero');
                        CAR.state({
                            doors: [${vehicleState.doorFL}, ${vehicleState.doorFR}, ${vehicleState.doorRL}, ${vehicleState.doorRR}],
                            hood: ${vehicleState.hood},
                            trunk: ${vehicleState.trunk},
                            charge: ${vehicleState.chargePort},
                            left: ${vehicleState.leftSignal},
                            right: ${vehicleState.rightSignal},
                            hazard: ${vehicleState.hazardLights},
                            brake: ${vehicleState.brakeLights}
                        });
                    }
                } catch(e) { console.error(e); }
            """.trimIndent()
            webViewRef?.evaluateJavascript(js, null)
        }
    }

    val dispSpeed = if (vehicleState.speedKmh > 0) vehicleState.speedKmh else 58

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // 1. Yarım Daire Kadran Çizgili Hız Göstergesi (156821.jpg ile birebir 88 ince çizgi)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            val w = size.width
            val h = size.height
            val radius = (minOf(w, h * 1.15f) * 0.47f)
            val centerX = w / 2f
            val centerY = h * 0.54f

            val totalTicks = 88
            val startAngleDeg = 172f
            val sweepAngleDeg = 196f

            for (i in 0..totalTicks) {
                val angleDeg = startAngleDeg + (sweepAngleDeg / totalTicks) * i
                val rad = Math.toRadians(angleDeg.toDouble())
                val innerR = radius - 9.dp.toPx()
                val outerR = radius

                val x1 = centerX + (innerR * cos(rad)).toFloat()
                val y1 = centerY + (innerR * sin(rad)).toFloat()
                val x2 = centerX + (outerR * cos(rad)).toFloat()
                val y2 = centerY + (outerR * sin(rad)).toFloat()

                drawLine(
                    color = if (isDark) Color(0xFF475569) else Color(0xFF9FA3AA),
                    start = Offset(x1, y1),
                    end = Offset(x2, y2),
                    strokeWidth = 1.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }

        // 2. Kadranın Üst İç Kısmındaki Hız Değeri ("58 km/h")
        Text(
            text = buildAnnotatedString {
                withStyle(
                    SpanStyle(
                        fontSize = 39.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color(0xFF232730)
                    )
                ) {
                    append("$dispSpeed")
                }
                withStyle(
                    SpanStyle(
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Normal,
                        color = if (isDark) Color(0xFF94A3B8) else Color(0xFF4D525C)
                    )
                ) {
                    append(" km/h")
                }
            },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 24.dp)
                .clickable { useInteractiveWebGl = !useInteractiveWebGl }
        )

        // 3. 156821.jpg İle Birebir 3D Buz Mavisi Skywell ET5 Görünümü + Etkileşimli Noktalar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.82f)
                .align(Alignment.BottomCenter),
            contentAlignment = Alignment.Center
        ) {
            if (!useInteractiveWebGl) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.et5_hero_3d),
                        contentDescription = "Skywell ET5 3D",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth(0.95f)
                            .fillMaxHeight(0.95f)
                    )

                    // Kaput, Bagaj ve Kapı dokunmatik etkileşim bölgeleri
                    Row(modifier = Modifier.fillMaxSize()) {
                        // Ön Kaput & Şarj Kapağı Bölgesi
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable { onToggleHood() }
                        )
                        // Orta Kapılar Bölgesi
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable { onToggleDoor("dFL") }
                        )
                        // Arka Bagaj Bölgesi
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable { onToggleTrunk() }
                        )
                    }
                }
            } else {
                AndroidView(
                    factory = { ctx ->
                        val assetLoader = WebViewAssetLoader.Builder()
                            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                            .build()

                        WebView(ctx).apply {
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(0)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                allowFileAccess = false
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onConsoleMessage(msg: ConsoleMessage?): Boolean {
                                    Log.d("Car3D_JS", "${msg?.message()}")
                                    return true
                                }
                            }

                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun onPart(part: String) {
                                    when (part) {
                                        "dFL", "dFR", "dRL", "dRR" -> onToggleDoor(part)
                                        "hood" -> onToggleHood()
                                        "trunk" -> onToggleTrunk()
                                        "charge" -> onToggleChargePort()
                                    }
                                }

                                @JavascriptInterface
                                fun onLabel(type: String, x: Float, y: Float, dist: Float) {}

                                @JavascriptInterface
                                fun ready() {
                                    is3dReady = true
                                    post {
                                        evaluateJavascript(
                                            "if(window.CAR) { CAR.setColor('#8BB2D9'); CAR.view('hero'); }",
                                            null
                                        )
                                    }
                                }
                            }, "Et5")

                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    val url = request?.url ?: return null
                                    return assetLoader.shouldInterceptRequest(url)
                                }
                            }

                            loadUrl("https://appassets.androidplatform.net/assets/car/index.html")
                            webViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            if (vehicleState.trunk) {
                StatusPill(text = "Bagaj Açık", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp))
            }
            if (vehicleState.hood) {
                StatusPill(text = "Kaput Açık", modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp))
            }
        }
    }
}

@Composable
fun StatusPill(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF6D1A29).copy(alpha = 0.92f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
