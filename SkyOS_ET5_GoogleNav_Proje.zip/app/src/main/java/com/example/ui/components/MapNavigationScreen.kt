package com.example.ui.components

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.model.VehicleState
import com.example.osmand.ev.SocDataSource
import com.google.android.gms.maps.GoogleMap
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * BÖLÜM 13, 14, 15, 16, 17 Uyumlu Google Maps & Navigation SDK Ekranı:
 * - Gerçek Google Navigation SDK (`GoogleMapNavigationView`)
 * - 156821.jpg ile birebir üst buzlu cam `"Nereye Gitmek İstersiniz?"` arama kapsülü + `"GİT"` butonu
 * - BÖLÜM 14: "GİT" komutu veya hedef seçimi sonrası zorunlu Adres Onay Ekranı:
 *   "Bu adrese gitmek istiyor musunuz?" -> ["EVET, ROTAYI OLUŞTUR"] / ["VAZGEÇ"]
 * - BÖLÜM 15: SKYWELL ET5 LR Legend (2023) çok parametreli gerçekçi enerji hesaplama motoru
 *   (Araçtan batarya yüzdesi okunamıyorsa kullanıcı girişi zorunludur; tüm tahminler "TAHMİNİ" etiketlidir)
 */
@Composable
fun MapNavigationScreen(
    vehicleState: VehicleState,
    repository: VehicleRepository,
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    onVoiceSearchClicked: () -> Unit,
    onToggleFullScreen: () -> Unit,
    isFullScreen: Boolean,
    isDark: Boolean = false,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val navManager = repository.googleNavigationManager
    val navState by navManager.uiState.collectAsState()
    val suggestions by navManager.placeSuggestions.collectAsState()

    var showOptionsSheet by remember { mutableStateOf(false) }
    var showCoordinateDialog by remember { mutableStateOf(false) }
    var showEvConfigDialog by remember { mutableStateOf(false) }
    var latInput by remember { mutableStateOf("") }
    var lngInput by remember { mutableStateOf("") }
    var manualSocInput by remember(vehicleState.userManualBatteryPercent) {
        mutableStateOf(vehicleState.userManualBatteryPercent?.toString() ?: "")
    }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    // Android 9 (API 28) ve Android 12 (API 31) uyumlu çalışma zamanı konum izni istemcisi
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        navManager.refreshSystemStatus()
        navManager.startRealLocationUpdates()
    }

    LaunchedEffect(searchQuery) {
        searchJob?.cancel()
        if (searchQuery.isNotBlank()) {
            searchJob = coroutineScope.launch {
                delay(300)
                navManager.searchAddressPredictions(searchQuery)
            }
        } else {
            navManager.searchAddressPredictions("")
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("map_navigation_container")
    ) {
        // 1. GERÇEK GOOGLE NAVIGATION SDK & GOOGLE MAPS GÖRÜNÜMÜ
        GoogleMapNavigationView(
            navigationManager = navManager,
            modifier = Modifier.fillMaxSize()
        )

        // 2. ÜSTTE YÜZEN BUZLU CAM "Nereye Gitmek İstersiniz?" ARAMA KAPSÜLÜ VE "GİT" BUTONU (156821.jpg)
        AnimatedVisibility(
            visible = !navState.isGuidanceActive,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 20.dp, top = 16.dp, end = 20.dp)
                .fillMaxWidth(0.84f)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .shadow(10.dp, RoundedCornerShape(22.dp))
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            if (isDark) Color(0xE6161D2A)
                            else Color(0xEBF3F4F6)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isDark) Color(0xFF2B364B) else Color.White.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(22.dp)
                        )
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Ara",
                        tint = if (isDark) Color(0xFF94A3B8) else Color(0xFF5A606A),
                        modifier = Modifier.size(24.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    TextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChanged,
                        placeholder = {
                            Text(
                                text = "Nereye Gitmek İstersiniz?",
                                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF525864),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Normal
                            )
                        },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = if (isDark) Color.White else Color(0xFF1F232B),
                            unfocusedTextColor = if (isDark) Color.White else Color(0xFF1F232B)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("map_search_input")
                    )

                    if (searchQuery.isNotEmpty()) {
                        // BÖLÜM 14: "GİT" Butonu (Hemen navigasyon başlatmaz; önce Adres Onay Ekranını açar!)
                        Button(
                            onClick = { navManager.proposeDestinationByQuery(searchQuery) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("search_go_button")
                        ) {
                            Text("GİT", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = { onSearchQueryChanged("") },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Temizle",
                                tint = if (isDark) Color(0xFF94A3B8) else Color(0xFF5A606A)
                            )
                        }
                    }

                    // Sesli Arama Mikrofon İkonu
                    IconButton(
                        onClick = onVoiceSearchClicked,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("voice_assistant_mic_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Mic,
                            contentDescription = "Sesli Arama",
                            tint = if (isDark) Color(0xFFCBD5E1) else Color(0xFF5A606A),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Harita & Araç Enerji Ayarları İkonu
                    IconButton(
                        onClick = { showOptionsSheet = !showOptionsSheet },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("nav_options_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "Harita ve Hedef Ayarları",
                            tint = if (isDark) Color(0xFFCBD5E1) else Color(0xFF5A606A),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Adres Arama Öneri Listesi (Her satırda "GİT" -> Adres Onay Ekranı açar)
                if (suggestions.isNotEmpty() && searchQuery.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isDark) Color(0xF5151C28) else Color(0xFAFFFFFF),
                        shadowElevation = 12.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LazyColumn(modifier = Modifier.heightIn(max = 250.dp)) {
                            items(suggestions) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onSearchQueryChanged(item.title)
                                            navManager.proposeDestinationFromSuggestion(item)
                                        }
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Place,
                                        contentDescription = null,
                                        tint = Color(0xFF2563EB),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = if (isDark) Color.White else Color(0xFF1E293B)
                                        )
                                        Text(
                                            text = item.subtitle,
                                            fontSize = 12.sp,
                                            color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            onSearchQueryChanged(item.title)
                                            navManager.proposeDestinationFromSuggestion(item)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("GİT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                                HorizontalDivider(color = Color.Gray.copy(alpha = 0.15f))
                            }
                        }
                    }
                }
            }
        }

        // 3. KONUM YÜKLENİYOR / İZİN (ANDROID 9 & 12) / GPS / İNTERNET / SDK DURUM KARTI
        val statusMsg = navState.sdkErrorMessage ?: navState.statusBannerMessage
        val showLoadingGps = navState.isWaitingForFirstLocation && navState.hasLocationPermission && navState.isGpsEnabled
        if (statusMsg != null || showLoadingGps || navState.isVerifyingAddress) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 86.dp, start = 20.dp, end = 20.dp)
                    .widthIn(max = 560.dp),
                shape = RoundedCornerShape(16.dp),
                color = if (isDark) Color(0xF0161E2E) else Color(0xF8FFFFFF),
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (navState.isVerifyingAddress || (showLoadingGps && statusMsg == null)) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp,
                            color = Color(0xFF2563EB)
                        )
                        Text(
                            text = if (navState.isVerifyingAddress)
                                "Hedef adres ve gerçek yol verisi doğrulanıyor…"
                            else
                                "Gerçek GPS konumunuz alınıyor…",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isDark) Color.White else Color(0xFF1E293B)
                        )
                    } else if (statusMsg != null) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = statusMsg,
                            fontSize = 12.sp,
                            color = if (isDark) Color.White else Color(0xFF1E293B),
                            modifier = Modifier.weight(1f)
                        )
                        if (!navState.hasLocationPermission || navState.isAndroid12ApproximateOnlyWarning) {
                            Button(
                                onClick = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Tam Konum İzni Ver", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        } else if (!navState.isGpsEnabled) {
                            Button(
                                onClick = {
                                    try {
                                        context.startActivity(
                                            Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    } catch (_: Exception) {}
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("GPS Aç", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 4. BÖLÜM 14 — ZORUNLU ADRES ONAY EKRANI ("Bu adrese gitmek istiyor musunuz?")
        navState.pendingConfirmation?.let { pending ->
            val energy = pending.energyPreview
            val socMissing = energy.socSource == SocDataSource.MISSING_REQUIRED

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 20.dp, bottom = 20.dp, end = 80.dp)
                    .widthIn(min = 380.dp, max = 560.dp)
                    .testTag("address_confirmation_card"),
                shape = RoundedCornerShape(24.dp),
                color = if (isDark) Color(0xFA141B29) else Color(0xFCFFFFFF),
                shadowElevation = 18.dp,
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF2563EB))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "ADRES VE ROTA ONAYI",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF2563EB)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF16A34A).copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Hedef İşaretçisi Haritada Gösteriliyor",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16A34A),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // 1. Seçilen Hedefin Açık Adresi
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = pending.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Açık Adres: ${pending.openAddress}",
                            fontSize = 12.sp,
                            color = if (isDark) Color(0xFFCBD5E1) else Color(0xFF334155)
                        )
                        Text(
                            text = String.format(
                                Locale.US,
                                "Hedef Koordinatı: %.5f° K, %.5f° D",
                                pending.targetLatLng.latitude,
                                pending.targetLatLng.longitude
                            ),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    // 2. Mevcut GPS Konumundan Hedefe Gerçek Yol Uzaklığı ve Tahmini Süre
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isDark) Color(0xFF1E293B) else Color(0xFFEFF6FF)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("GERÇEK YOL MESAFESİ", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                Text(
                                    text = String.format(Locale("tr", "TR"), "%.1f km", pending.roadDistanceMeters / 1000.0),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isDark) Color.White else Color(0xFF0F172A)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isDark) Color(0xFF1E293B) else Color(0xFFF0FDF4)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("TAHMİNİ SÜRÜŞ SÜRESİ", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                Text(
                                    text = "${(pending.roadDurationSeconds / 60).coerceAtLeast(1)} dk",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isDark) Color.White else Color(0xFF0F172A)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isDark) Color(0xFF1E293B) else Color(0xFFFFFBEB)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("TÜKETİM (TAHMİNİ)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                                Text(
                                    text = String.format(Locale("tr", "TR"), "%.1f kWh", energy.estimatedTotalEnergyKwh),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isDark) Color.White else Color(0xFF0F172A)
                                )
                            }
                        }
                    }

                    // 3. BÖLÜM 15: Araçtan gerçek batarya yüzdesi okunamıyorsa kullanıcı girişi zorunludur!
                    if (vehicleState.batteryPercent < 0) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFFEF3C7))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Başlangıç Batarya Yüzdesi (%) — Giriş Zorunlu",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    text = "Araçtan gerçek SoC okunamıyor. SKYWELL ET5 LR Legend (84,2 kWh TAHMİNİ) varış hesabı için mevcut % girin:",
                                    fontSize = 10.sp,
                                    color = Color(0xFF78350F)
                                )
                            }
                            OutlinedTextField(
                                value = manualSocInput,
                                onValueChange = { txt ->
                                    val filtered = txt.filter { it.isDigit() }.take(3)
                                    manualSocInput = filtered
                                    val v = filtered.toIntOrNull()
                                    if (v != null && v in 1..100) {
                                        repository.setUserManualBatteryPercent(v)
                                    }
                                },
                                placeholder = { Text("%", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.width(82.dp)
                            )
                        }
                    }

                    // 4. Zorunlu Onay Sorusu (Bölüm 14 - Madde 6)
                    Text(
                        text = "Bu adrese gitmek istiyor musunuz?",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isDark) Color.White else Color(0xFF0F172A)
                    )

                    // 5. İki Zorunlu Seçenek: "EVET, ROTAYI OLUŞTUR" ve "VAZGEÇ" (Bölüm 14 - Madde 7)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                navManager.confirmAddressAndCreateRoute(
                                    avoidTolls = vehicleState.navAvoidTolls,
                                    avoidHighways = vehicleState.navAvoidHighways,
                                    avoidFerries = vehicleState.navAvoidFerries
                                )
                            },
                            enabled = !socMissing,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1.4f)
                                .height(46.dp)
                                .testTag("confirm_address_yes_button")
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "EVET, ROTAYI OLUŞTUR",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { navManager.cancelAddressConfirmation() },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(0.9f)
                                .height(46.dp)
                                .testTag("confirm_address_cancel_button")
                        ) {
                            Text(
                                text = "VAZGEÇ",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // 5. ONAYLANMIŞ ROTA & SKYWELL ET5 LR LEGEND (2023) ENERJİ ANALİZ KARTI (Bölüm 14 Adım 9-10 & Bölüm 15)
        if (navState.isAddressConfirmed && navState.pendingConfirmation == null) {
            val energy = navState.routeEnergyEstimate
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 20.dp, bottom = 20.dp, end = 80.dp)
                    .widthIn(min = 380.dp, max = 560.dp)
                    .testTag("active_ev_route_card"),
                shape = RoundedCornerShape(22.dp),
                color = if (isDark) Color(0xF5151C28) else Color(0xFAFFFFFF),
                shadowElevation = 16.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0xFF2B364B) else Color(0xFFCBD5E1))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Başlık ve Sesli Yönlendirme Kontrolü
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (navState.isGuidanceActive)
                                    "GOOGLE NAVIGATION SDK AKTİF • SKYWELL ET5 LR LEGEND (2023)"
                                else
                                    "ONAYLANMIŞ SÜRÜŞ ROTASI • SKYWELL ET5 LR LEGEND (2023)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF2563EB)
                            )
                            Text(
                                text = navState.destinationTitle ?: "Hedef",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isDark) Color.White else Color(0xFF0F172A),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            navState.destinationOpenAddress?.let { addr ->
                                Text(
                                    text = addr,
                                    fontSize = 11.sp,
                                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showEvConfigDialog = true }, modifier = Modifier.size(34.dp)) {
                                Icon(
                                    imageVector = Icons.Default.ElectricCar,
                                    contentDescription = "EV Enerji Parametreleri",
                                    tint = Color(0xFF16A34A)
                                )
                            }
                            IconButton(onClick = { navManager.toggleAudioGuidanceMute() }, modifier = Modifier.size(34.dp)) {
                                Icon(
                                    imageVector = if (navState.isAudioMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Sesli Yönlendirme",
                                    tint = if (navState.isAudioMuted) Color.Gray else Color(0xFF2563EB)
                                )
                            }
                        }
                    }

                    // BÖLÜM 15: Gerçekçi EV Enerji Hesaplama Tablosu (Açıkça "TAHMİNİ" Etiketli)
                    if (energy != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Mevcut SoC: ${energy.initialSocPercent?.let { "%$it" } ?: "Girilmedi"} (${energy.socSource.labelTr})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else Color(0xFF1E293B)
                                )
                                Text(
                                    text = "Kapasite: ${"%.1f".format(energy.config.effectiveUsableCapacityKwh)} kWh (${if (energy.config.isUsableCapacityEstimated) "TAHMİNİ" else "DOĞRULANMIŞ"})",
                                    fontSize = 10.sp,
                                    color = Color(0xFF64748B)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("MESAFE / SÜRE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                    Text(
                                        text = "${"%.1f".format(energy.routeDistanceKm)} km • ${energy.routeDurationMinutes} dk",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isDark) Color.White else Color(0xFF0F172A)
                                    )
                                }
                                Column {
                                    Text("TÜKETİLECEK (TAHMİNİ)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                    Text(
                                        text = "${"%.1f".format(energy.estimatedTotalEnergyKwh)} kWh",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF2563EB)
                                    )
                                }
                                Column {
                                    Text("VARIŞ SoC (TAHMİNİ)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                    Text(
                                        text = if (energy.initialSocPercent != null) "%${energy.estimatedArrivalSocPercent.toInt()}" else "—",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (energy.requiresChargingStop) Color(0xFFDC2626) else Color(0xFF16A34A)
                                    )
                                }
                                Column {
                                    Text("KALAN MENZİL (TAHMİNİ)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                    Text(
                                        text = if (energy.initialSocPercent != null) "${energy.estimatedRemainingRangeKm.toInt()} km" else "—",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isDark) Color.White else Color(0xFF0F172A)
                                    )
                                }
                            }

                            Text(
                                text = energy.summaryWarningTr,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (energy.requiresChargingStop) Color(0xFFDC2626) else Color(0xFF15803D)
                            )

                            // Şarj ihtiyacı varsa gerçek şarj istasyonu alternatiflerini göster
                            if (energy.requiresChargingStop) {
                                if (navState.isSearchingChargers) {
                                    Text(
                                        text = "Rota üzerindeki gerçek şarj istasyonları aranıyor…",
                                        fontSize = 11.sp,
                                        color = Color(0xFF2563EB)
                                    )
                                } else if (navState.liveRouteChargingStations.isNotEmpty()) {
                                    val firstStation = navState.liveRouteChargingStations.first()
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF16A34A).copy(alpha = 0.12f))
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "⚡ Gerçek Şarj İstasyonu: ${firstStation.name}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDark) Color.White else Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = "${firstStation.operator} • ${firstStation.powerKw} kW",
                                                fontSize = 10.sp,
                                                color = Color(0xFF64748B)
                                            )
                                        }
                                        Button(
                                            onClick = { navManager.addChargingStationWaypointToRoute(firstStation) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Text(
                                                text = if (navState.selectedChargerStop?.name == firstStation.name) "Eklendi ✓" else "Rotaya Ekle",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                } else {
                                    Text(
                                        text = "Rota çevresinde doğrulanmış canlı şarj istasyonu verisi alınamadı.",
                                        fontSize = 10.sp,
                                        color = Color(0xFFD97706)
                                    )
                                }
                            }
                        }
                    }

                    // Aksiyon Butonları: Navigasyonu Başlat / Duraklat / Bitir
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (!navState.isGuidanceActive) {
                            Button(
                                onClick = { navManager.startNavigationGuidance() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("start_google_navigation_button")
                            ) {
                                Icon(imageVector = Icons.Default.Navigation, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Navigasyonu Başlat", color = Color.White, fontWeight = FontWeight.ExtraBold)
                            }
                        } else {
                            Button(
                                onClick = { navManager.pauseNavigationGuidance() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                            ) {
                                Text("Navigasyonu Durdur", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedButton(
                            onClick = { navManager.stopAndExitNavigation() },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Text("Navigasyondan Çık", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 6. SAĞ ALT HARİTA KONTROLLERİ (156821.jpg temiz görünümünü korumak için ⚙️ menüsü veya tam ekranda görünür)
        if (showOptionsSheet || isFullScreen || navState.isAddressConfirmed) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // SKYWELL ET5 LR Legend (2023) Enerji & Batarya Parametreleri
            FloatingActionButton(
                onClick = { showEvConfigDialog = true },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xEE182030) else Color(0xF5FFFFFF),
                contentColor = Color(0xFF16A34A),
                modifier = Modifier.size(44.dp)
            ) {
                Icon(imageVector = Icons.Default.ElectricCar, contentDescription = "SKYWELL ET5 Enerji Ayarları", modifier = Modifier.size(20.dp))
            }

            // Enlem / Boylam ile Hedef Belirleme
            FloatingActionButton(
                onClick = { showCoordinateDialog = true },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xEE182030) else Color(0xF5FFFFFF),
                contentColor = if (isDark) Color.White else Color(0xFF1F232B),
                modifier = Modifier.size(44.dp)
            ) {
                Icon(imageVector = Icons.Default.PinDrop, contentDescription = "Koordinat Gir", modifier = Modifier.size(20.dp))
            }

            // Konumuma Dön
            FloatingActionButton(
                onClick = { navManager.recenterToMyLocation() },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xEE182030) else Color(0xF5FFFFFF),
                contentColor = Color(0xFF2563EB),
                modifier = Modifier
                    .size(44.dp)
                    .testTag("recenter_button")
            ) {
                Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Konumuma Dön", modifier = Modifier.size(21.dp))
            }

            // Yakınlaştır (+)
            FloatingActionButton(
                onClick = { navManager.zoomIn() },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xEE182030) else Color(0xF5FFFFFF),
                contentColor = if (isDark) Color.White else Color(0xFF1F232B),
                modifier = Modifier.size(40.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Yakınlaştır", modifier = Modifier.size(19.dp))
            }

            // Uzaklaştır (-)
            FloatingActionButton(
                onClick = { navManager.zoomOut() },
                shape = CircleShape,
                containerColor = if (isDark) Color(0xEE182030) else Color(0xF5FFFFFF),
                contentColor = if (isDark) Color.White else Color(0xFF1F232B),
                modifier = Modifier.size(40.dp)
            ) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = "Uzaklaştır", modifier = Modifier.size(19.dp))
            }

            // Tam Ekran
            FloatingActionButton(
                onClick = onToggleFullScreen,
                shape = CircleShape,
                containerColor = if (isDark) Color(0xEE182030) else Color(0xF5FFFFFF),
                contentColor = if (isDark) Color.White else Color(0xFF1F232B),
                modifier = Modifier
                    .size(40.dp)
                    .testTag("fullscreen_toggle_button")
            ) {
                Icon(
                    imageVector = if (isFullScreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                    contentDescription = "Tam Ekran",
                    modifier = Modifier.size(19.dp)
                )
            }
        }
        }

        // 7. HARİTA GÖRÜNÜMÜ VE SEÇENEKLERİ PANELİ (⚙️)
        if (showOptionsSheet) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 82.dp, end = 20.dp)
                    .width(340.dp),
                shape = RoundedCornerShape(20.dp),
                color = if (isDark) Color(0xF8151C28) else Color(0xFCFFFFFF),
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Harita, Hedef & Tablet Uyum",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isDark) Color.White else Color(0xFF1E293B)
                        )
                        IconButton(onClick = { showOptionsSheet = false }, modifier = Modifier.size(28.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat")
                        }
                    }

                    Button(
                        onClick = { navManager.toggleMapType() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val typeName = when (navState.mapType) {
                            GoogleMap.MAP_TYPE_SATELLITE -> "Uydu Görünümü"
                            GoogleMap.MAP_TYPE_HYBRID -> "Hibrit Görünüm"
                            else -> "Normal Harita Görünümü"
                        }
                        Text("Harita Tipi: $typeName", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { navManager.cycleNightMode() },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val modeName = when (navState.nightModeSetting) {
                            1 -> "Gündüz Görünümü"
                            2 -> "Gece Görünümü"
                            else -> "Otomatik Gece/Gündüz"
                        }
                        Text("Navigasyon: $modeName", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            showOptionsSheet = false
                            showCoordinateDialog = true
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Enlem ve Boylam ile Hedef Seç", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            showOptionsSheet = false
                            showEvConfigDialog = true
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SKYWELL ET5 LR Legend Enerji Ayarları", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Bölüm 16: Android 9 & 12 Tablet Uyumluluk Durum Bilgisi
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Cihaz: Android ${navState.compatibility.releaseName} (API ${navState.compatibility.sdkInt})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color.White else Color(0xFF0F172A)
                            )
                            Text(
                                text = "Google Navigation SDK Desteği: ${if (navState.compatibility.isNavSdkSupportedOnThisApi) "Destekleniyor (API 24+)" else "Desteklenmiyor"}",
                                fontSize = 10.sp,
                                color = Color(0xFF16A34A)
                            )
                            Text(
                                text = "Kesin Konum (FINE): ${if (navState.compatibility.isFineLocationGranted) "Verildi" else "Verilmedi"}",
                                fontSize = 10.sp,
                                color = if (navState.compatibility.isFineLocationGranted) Color(0xFF16A34A) else Color(0xFFD97706)
                            )
                        }
                    }
                }
            }
        }

        // 8. ENLEM VE BOYLAM İLE HEDEF BELİRLEME PENCERESİ (Onay Ekranına Yönlendirir)
        if (showCoordinateDialog) {
            AlertDialog(
                onDismissRequest = { showCoordinateDialog = false },
                title = { Text("Enlem ve Boylam ile Hedef Belirle", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Koordinat doğrulandıktan sonra 'Bu adrese gitmek istiyor musunuz?' onay ekranı açılır.",
                            fontSize = 12.sp
                        )
                        OutlinedTextField(
                            value = latInput,
                            onValueChange = { latInput = it },
                            label = { Text("Enlem (Latitude)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = lngInput,
                            onValueChange = { lngInput = it },
                            label = { Text("Boylam (Longitude)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val lat = latInput.replace(",", ".").trim().toDoubleOrNull()
                            val lng = lngInput.replace(",", ".").trim().toDoubleOrNull()
                            if (lat != null && lng != null) {
                                navManager.proposeDestinationByCoordinates(lat, lng)
                                showCoordinateDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                    ) {
                        Text("GİT (Adresi Doğrula)", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCoordinateDialog = false }) {
                        Text("Vazgeç")
                    }
                }
            )
        }

        // 9. BÖLÜM 13 & 15: SKYWELL ET5 LR LEGEND (2023) ENERJİ VE SOKET YAPILANDIRMA PENCERESİ
        if (showEvConfigDialog) {
            var consumptionInput by remember {
                mutableStateOf(vehicleState.userEstimatedConsumptionKwhPer100Km.toString())
            }
            var reserveInput by remember {
                mutableStateOf(vehicleState.safetyReserveSocPercent.toString())
            }
            var payloadInput by remember {
                mutableStateOf(vehicleState.extraPayloadKg.toString())
            }
            var ccs2Checked by remember { mutableStateOf(vehicleState.socketCcs2Verified) }
            var type2Checked by remember { mutableStateOf(vehicleState.socketType2Verified) }

            AlertDialog(
                onDismissRequest = { showEvConfigDialog = false },
                title = {
                    Column {
                        Text("SKYWELL ET5 LR Legend (2023)", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        Text(
                            "Brüt: 86 kWh • Kullanılabilir: ~84,2 kWh (TAHMİNİ) • AC: 11 kW • DC: ${vehicleState.verifiedDcMaxChargePowerKw?.let { "$it kW" } ?: "Doğrulanmadı"}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = manualSocInput,
                            onValueChange = { manualSocInput = it.filter { c -> c.isDigit() }.take(3) },
                            label = {
                                Text(
                                    if (vehicleState.batteryPercent >= 0)
                                        "Mevcut Batarya % (Araçtan okunan: %${vehicleState.batteryPercent})"
                                    else
                                        "Mevcut Batarya % (Araç verisi yok — Kullanıcı Girişi Zorunlu)"
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = consumptionInput,
                            onValueChange = { consumptionInput = it },
                            label = { Text("Tahmini Enerji Tüketimi (kWh / 100 km — Başlangıç: 17.5)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = reserveInput,
                                onValueChange = { reserveInput = it.filter { c -> c.isDigit() }.take(2) },
                                label = { Text("Güvenlik Rezervi (%)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = payloadInput,
                                onValueChange = { payloadInput = it.filter { c -> c.isDigit() }.take(3) },
                                label = { Text("Ek Yük (kg)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text(
                            text = "Araç Üzerindeki Şarj Soketi Doğrulaması (Doğrulanmadan kesin kabul edilmez):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = ccs2Checked, onCheckedChange = { ccs2Checked = it })
                                Text("CCS2 (DC) Doğrulandı", fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = type2Checked, onCheckedChange = { type2Checked = it })
                                Text("Type 2 (AC) Doğrulandı", fontSize = 12.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            manualSocInput.toIntOrNull()?.let { repository.setUserManualBatteryPercent(it) }
                            consumptionInput.replace(",", ".").toFloatOrNull()?.let { repository.setUserEstimatedConsumption(it) }
                            reserveInput.toIntOrNull()?.let { repository.setSafetyReservePercent(it) }
                            payloadInput.toIntOrNull()?.let { repository.setExtraPayloadKg(it) }
                            repository.setSocketVerification(ccs2Checked, type2Checked)
                            showEvConfigDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) {
                        Text("Kaydet ve Hesapla", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEvConfigDialog = false }) {
                        Text("Kapat")
                    }
                }
            )
        }
    }
}
