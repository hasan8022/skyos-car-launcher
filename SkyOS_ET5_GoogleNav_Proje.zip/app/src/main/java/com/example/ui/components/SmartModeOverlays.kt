package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SmartScreenMode
import com.example.model.VehicleState
import com.example.ui.theme.LocalSkyPalette

@Composable
fun SmartModeOverlays(
    smartMode: SmartScreenMode,
    vehicleState: VehicleState,
    temporaryNote: String,
    onNoteChange: (String) -> Unit,
    onExitMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (smartMode == SmartScreenMode.NONE) return
    val palette = LocalSkyPalette.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF05070B), Color(0xFF0D1422), Color(0xFF06080E))
                )
            )
    ) {
        when (smartMode) {
            SmartScreenMode.PET_MODE -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp)
                ) {
                    Row(
                        modifier = Modifier.align(Alignment.TopStart),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(palette.accentSoftBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pets,
                                contentDescription = "Evcil Hayvan",
                                tint = palette.accent,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Column {
                            Text("EVCİL HAYVAN KONFOR MODU", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = palette.accent)
                            Text("İklimlendirme Kesintisiz Aktif", fontSize = 12.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    IconButton(
                        onClick = onExitMode,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                    }

                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = vehicleState.insideTempC?.let { "$it°C" }
                                ?: String.format(java.util.Locale.US, "%.1f°C", vehicleState.driverTemp).replace(".", ","),
                            fontSize = 104.sp,
                            fontWeight = FontWeight.Black,
                            color = palette.accent
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Sahibim birazdan dönecek.",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = vehicleState.insideTempC?.let { "Endişelenmeyin! Klima açık ve araç içi $it°C." }
                                ?: "Endişelenmeyin! Klima açık ve kabin sıcaklığı sabit tutuluyor.",
                            fontSize = 17.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Text(
                        text = "Hedef İklim: ${String.format(java.util.Locale.US, "%.1f°C", vehicleState.driverTemp).replace(".", ",")}  •  " +
                                (if (vehicleState.batteryPercent >= 0) "Batarya: %${vehicleState.batteryPercent}" else "Batarya: Veri Yok"),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.align(Alignment.BottomStart)
                    )
                }
            }

            SmartScreenMode.CAR_WASH -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(40.dp),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(palette.accentSoftBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.LocalCarWash, contentDescription = null, tint = palette.accent, modifier = Modifier.size(32.dp))
                        }
                        Column {
                            Text("Oto Yıkama Koruma Modu", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            Text("Dış yıkama için tüm sızdırmazlık ve sensör tedbirleri alındı", fontSize = 13.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    CarWashCheckItem("Yan aynalar otomatik katlandı")
                    CarWashCheckItem("Klima iç hava sirkülasyonuna alındı")
                    CarWashCheckItem("Ön/arka park radar sesleri susturuldu")
                    CarWashCheckItem("Panoramik cam tavan ve şarj kapağı kilitlendi")

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Yıkama bitince \"Bitir\"e basın; 15 km/sa üstünde kendiliğinden biter. Her şey eski haline döner.",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onExitMode,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .width(260.dp)
                            .height(50.dp)
                    ) {
                        Text("Yıkama Modunu Bitir", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                    }
                }
            }

            SmartScreenMode.TEMP_NOTE -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Note, contentDescription = null, tint = palette.accent, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("ARAÇ SAHİBİ BİLGİ NOTU", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = palette.accent)
                    Spacer(modifier = Modifier.height(14.dp))
                    if (temporaryNote.isBlank()) {
                        Text(
                            text = "Henüz not girilmedi",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF94A3B8)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        var draft by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            placeholder = { Text("Örn: 0532 ... — 10 dakikaya geliyorum", color = Color(0xFF6B7280)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = palette.accent,
                                unfocusedBorderColor = Color(0xFF374151)
                            ),
                            modifier = Modifier.fillMaxWidth(0.6f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { if (draft.isNotBlank()) onNoteChange(draft.trim()) },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Notu Ekrana Yansıt", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(22.dp))
                                .background(Color(0xFF131B2E))
                                .border(1.5.dp, palette.accent.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                                .padding(horizontal = 32.dp, vertical = 24.dp)
                        ) {
                            Text(text = temporaryNote, fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(onClick = { onNoteChange("") }) {
                            Text("Notu Değiştir / Temizle", color = palette.accent)
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = onExitMode,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Kapat", color = Color.White)
                    }
                }
            }

            SmartScreenMode.SCREEN_CLEAN -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { onExitMode() }
                            )
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.CleaningServices, contentDescription = null, tint = palette.accent, modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Ekran Temizleme Modu", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Çıkmak için ekrana 3 saniye basılı tutun", fontSize = 14.sp, color = Color(0xFF94A3B8))
                }
            }

            else -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Nightlight, contentDescription = null, tint = palette.accent, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = when (smartMode) {
                            SmartScreenMode.CAMP_MODE -> "Kamp & Konaklama Modu Aktif"
                            SmartScreenMode.SLEEP_MODE -> "Kabin Dinlenme & Uyku Modu"
                            SmartScreenMode.WATCH_MODE -> "Batarya & Şarj İzleme Modu"
                            else -> "Akıllı Mod Aktif"
                        },
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onExitMode,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Moddan Çık", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CarWashCheckItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(Color(0xFF10B981)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
        }
        Text(text = text, fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}
