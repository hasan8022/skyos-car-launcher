package com.example.ui.components

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.VehicleRepository
import com.example.data.VoiceAssistantManager
import com.example.model.*
import com.example.ui.theme.LocalSkyPalette

/**
 * 156821.jpg referans görseliyle birebir aynı Ana Sayfa Düzeni + Android 9 & 12 Tablet Yatay/Dikey Uyumu:
 * - Yatay (Landscape) tablet görünümünde sol araç paneli (~35.5%) ve sağ tam boy Google Maps Navigation ekranı (~64.5%) yan yana yer alır.
 * - Dikey (Portrait) tablet görünümünde üstte araç paneli, altta tam boy Google Maps Navigation ekranı yer alır.
 * - En altta tam genişlikli `BottomControlBar` ve ortasında renkli ses dalgalı `SESLİ ASİSTAN` mikrofonu bulunur.
 */
@Composable
fun HomeScreen(
    repository: VehicleRepository,
    assistantManager: VoiceAssistantManager,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    val vehicleState by repository.vehicleState.collectAsState()
    val activeScreen by repository.activeScreen.collectAsState()
    val smartMode by repository.smartScreenMode.collectAsState()
    val isFullScreen by repository.isFullScreen.collectAsState()
    val tempNote by repository.temporaryNote.collectAsState()
    val searchQuery by repository.searchQuery.collectAsState()
    val isPlayingMusic by repository.radioManager.isPlaying.collectAsState()
    val currentStation by repository.radioManager.currentStation.collectAsState()
    val webBrowserState by repository.webBrowserState.collectAsState()

    var showProfileModal by remember { mutableStateOf(false) }
    var showVoiceOrb by remember { mutableStateOf(false) }
    var showAutoParkDialog by remember { mutableStateOf(false) }
    var showSosDialog by remember { mutableStateOf(false) }
    var sosCallError by remember { mutableStateOf<String?>(null) }
    var showRemainingKm by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val currentProfile = remember(vehicleState.activeDriverProfileId) {
        repository.driverProfiles.find { it.id == vehicleState.activeDriverProfileId }
            ?: repository.driverProfiles.first()
    }

    val isDark = repository.isDarkModeEffective(vehicleState)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(if (isDark) Color(0xFF0A0E17) else Color(0xFFF2F3F5))
    ) {
        val isLandscapeTablet = maxWidth >= maxHeight || maxWidth >= 700.dp
        val leftPanelWidth = (maxWidth * 0.355f).coerceIn(330.dp, 440.dp)

        Column(modifier = Modifier.fillMaxSize()) {
            if (isLandscapeTablet) {
                // YATAY (LANDSCAPE) TABLET DÜZENİ (156821.jpg İle Birebir)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    AnimatedVisibility(
                        visible = !isFullScreen,
                        enter = expandHorizontally() + fadeIn(),
                        exit = shrinkHorizontally() + fadeOut()
                    ) {
                        Row(modifier = Modifier.fillMaxHeight()) {
                            Box(
                                modifier = Modifier
                                    .width(leftPanelWidth)
                                    .fillMaxHeight()
                            ) {
                                LeftCarCard(
                                    vehicleState = vehicleState,
                                    currentProfile = currentProfile,
                                    currentStationName = currentStation?.name,
                                    currentStationGenre = currentStation?.genre,
                                    isPlayingMusic = isPlayingMusic,
                                    onGearSelected = { repository.setGear(it) },
                                    onSosClicked = { showSosDialog = true },
                                    onBatteryToggleRemaining = { showRemainingKm = !showRemainingKm },
                                    showRemainingKm = showRemainingKm,
                                    onToggleDoor = { repository.toggleDoor(it) },
                                    onToggleTrunk = { repository.toggleTrunk() },
                                    onToggleHood = { repository.toggleHood() },
                                    onToggleChargePort = { repository.toggleChargePort() },
                                    onToggle2D3D = { repository.toggle3DView() },
                                    onOpenVoiceAssistant = {
                                        assistantManager.startListening()
                                        showVoiceOrb = true
                                    },
                                    onOpenProfileSelector = { showProfileModal = true },
                                    onPlayPauseMusic = { repository.radioManager.togglePlayPause() },
                                    onNextMusic = { repository.radioManager.nextStation() },
                                    onPrevMusic = { repository.radioManager.previousStation() },
                                    onOpenMusicScreen = { repository.setActiveScreen(ActiveScreen.MUSIC) },
                                    onToggle220V = { repository.toggle220V() },
                                    onToggleDefrostFront = { repository.toggleDefrostFront() },
                                    onToggleDefrostRear = { repository.toggleDefrostRear() },
                                    onToggleMirrors = { repository.toggleMirrors() },
                                    onOpenQuickSettings = { repository.setActiveScreen(ActiveScreen.SETTINGS) },
                                    isDark = isDark,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .fillMaxHeight()
                                    .background(if (isDark) Color(0xFF1E293B) else Color(0xFFDCDFE5))
                            )
                        }
                    }

                    // Sağ Tam Boy Harita & Ekran Alanı
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        RightWorkspaceContent(
                            vehicleState = vehicleState,
                            repository = repository,
                            searchQuery = searchQuery,
                            isFullScreen = isFullScreen,
                            isDark = isDark,
                            activeScreen = activeScreen,
                            webBrowserState = webBrowserState,
                            onVoiceSearchClicked = {
                                assistantManager.startListening()
                                showVoiceOrb = true
                            },
                            onShowAutoPark = { showAutoParkDialog = true }
                        )
                    }
                }
            } else {
                // DİKEY (PORTRAIT) TABLET DÜZENİ (Bölüm 16 Tablet Dikey Uyumluluğu)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    AnimatedVisibility(
                        visible = !isFullScreen,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(380.dp)
                            ) {
                                LeftCarCard(
                                    vehicleState = vehicleState,
                                    currentProfile = currentProfile,
                                    currentStationName = currentStation?.name,
                                    currentStationGenre = currentStation?.genre,
                                    isPlayingMusic = isPlayingMusic,
                                    onGearSelected = { repository.setGear(it) },
                                    onSosClicked = { showSosDialog = true },
                                    onBatteryToggleRemaining = { showRemainingKm = !showRemainingKm },
                                    showRemainingKm = showRemainingKm,
                                    onToggleDoor = { repository.toggleDoor(it) },
                                    onToggleTrunk = { repository.toggleTrunk() },
                                    onToggleHood = { repository.toggleHood() },
                                    onToggleChargePort = { repository.toggleChargePort() },
                                    onToggle2D3D = { repository.toggle3DView() },
                                    onOpenVoiceAssistant = {
                                        assistantManager.startListening()
                                        showVoiceOrb = true
                                    },
                                    onOpenProfileSelector = { showProfileModal = true },
                                    onPlayPauseMusic = { repository.radioManager.togglePlayPause() },
                                    onNextMusic = { repository.radioManager.nextStation() },
                                    onPrevMusic = { repository.radioManager.previousStation() },
                                    onOpenMusicScreen = { repository.setActiveScreen(ActiveScreen.MUSIC) },
                                    onToggle220V = { repository.toggle220V() },
                                    onToggleDefrostFront = { repository.toggleDefrostFront() },
                                    onToggleDefrostRear = { repository.toggleDefrostRear() },
                                    onToggleMirrors = { repository.toggleMirrors() },
                                    onOpenQuickSettings = { repository.setActiveScreen(ActiveScreen.SETTINGS) },
                                    isDark = isDark,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(if (isDark) Color(0xFF1E293B) else Color(0xFFDCDFE5))
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        RightWorkspaceContent(
                            vehicleState = vehicleState,
                            repository = repository,
                            searchQuery = searchQuery,
                            isFullScreen = isFullScreen,
                            isDark = isDark,
                            activeScreen = activeScreen,
                            webBrowserState = webBrowserState,
                            onVoiceSearchClicked = {
                                assistantManager.startListening()
                                showVoiceOrb = true
                            },
                            onShowAutoPark = { showAutoParkDialog = true }
                        )
                    }
                }
            }

            // Alt Kontrol Çubuğu
            BottomControlBar(
                vehicleState = vehicleState,
                activeScreen = activeScreen,
                onScreenSelected = { screen ->
                    if (screen == ActiveScreen.AUTO_PARK) {
                        showAutoParkDialog = true
                    } else if (activeScreen == screen && screen != ActiveScreen.MAP) {
                        repository.setActiveScreen(ActiveScreen.MAP)
                    } else {
                        repository.setActiveScreen(screen)
                    }
                },
                onAdjustDriverTemp = { repository.adjustDriverTemp(it) },
                onCycleDriverSeatHeat = { repository.cycleDriverSeatHeat() },
                onCyclePassengerSeatHeat = { repository.cyclePassengerSeatHeat() },
                onToggleDefrostFront = { repository.toggleDefrostFront() },
                onToggleDefrostRear = { repository.toggleDefrostRear() },
                onToggleRecirc = { repository.toggleRecirc() },
                onAdjustVolume = { repository.setVolume(it) },
                onOpenVoiceAssistant = {
                    assistantManager.startListening()
                    showVoiceOrb = true
                },
                isDark = isDark
            )
        }

        if (showVoiceOrb) {
            VoiceAssistantOrb(
                assistantManager = assistantManager,
                isDark = isDark,
                onDismiss = {
                    showVoiceOrb = false
                    assistantManager.stopListening()
                }
            )
        }

        if (showProfileModal) {
            ProfileSelectorModal(
                profiles = repository.driverProfiles,
                activeProfileId = vehicleState.activeDriverProfileId,
                onProfileSelected = { repository.selectDriverProfile(it) },
                onOpenProfileSettings = { repository.setActiveScreen(ActiveScreen.SETTINGS) },
                onDismiss = { showProfileModal = false }
            )
        }

        if (showAutoParkDialog) {
            AutoParkDialog(
                onDismiss = { showAutoParkDialog = false }
            )
        }

        if (showSosDialog) {
            AlertDialog(
                onDismissRequest = { showSosDialog = false },
                confirmButton = {
                    Button(
                        onClick = {
                            sosCallError = null
                            val canCall = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.CALL_PHONE
                            ) == PackageManager.PERMISSION_GRANTED
                            val intent = Intent(
                                if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL,
                                Uri.parse("tel:112")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            try {
                                context.startActivity(intent)
                                showSosDialog = false
                            } catch (e: ActivityNotFoundException) {
                                sosCallError = "Bu cihazda arama uygulaması bulunamadı."
                            } catch (e: SecurityException) {
                                sosCallError = "Arama izni verilmedi."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6E1423)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("112 Acil Ara", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSosDialog = false }) {
                        Text("Vazgeç", color = palette.textPrimary)
                    }
                },
                title = { Text("Acil Durum (SOS)", color = palette.textPrimary, fontWeight = FontWeight.ExtraBold) },
                text = {
                    val navLoc = repository.googleNavigationManager.uiState.collectAsState().value.currentLocation
                    val gps = repository.telemetryHelper.telemetry.collectAsState().value
                    Text(
                        buildString {
                            when {
                                navLoc != null -> append(
                                    "Konumunuz: ${"%.5f".format(navLoc.latitude)}° K, ${"%.5f".format(navLoc.longitude)}° D\n"
                                )
                                gps.hasGpsFix -> append(
                                    "Konumunuz: ${"%.5f".format(gps.currentLatitude)}° K, ${"%.5f".format(gps.currentLongitude)}° D\n"
                                )
                                else -> append("Konum alınamıyor (GPS sinyali bekleniyor).\n")
                            }
                            append("Onaylarsanız cihazın arama uygulaması ile 112 aranır.")
                            sosCallError?.let { append("\n\nHata: $it") }
                        },
                        color = palette.textSecondary
                    )
                },
                containerColor = palette.surface
            )
        }

        SmartModeOverlays(
            smartMode = smartMode,
            vehicleState = vehicleState,
            temporaryNote = tempNote,
            onNoteChange = { repository.setTemporaryNote(it) },
            onExitMode = { repository.setSmartMode(SmartScreenMode.NONE) }
        )
    }
}

@Composable
private fun RightWorkspaceContent(
    vehicleState: VehicleState,
    repository: VehicleRepository,
    searchQuery: String,
    isFullScreen: Boolean,
    isDark: Boolean,
    activeScreen: ActiveScreen,
    webBrowserState: VehicleRepository.WebBrowserState?,
    onVoiceSearchClicked: () -> Unit,
    onShowAutoPark: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        MapNavigationScreen(
            vehicleState = vehicleState,
            repository = repository,
            searchQuery = searchQuery,
            onSearchQueryChanged = { repository.setSearchQuery(it) },
            onVoiceSearchClicked = onVoiceSearchClicked,
            onToggleFullScreen = { repository.toggleFullScreen() },
            isFullScreen = isFullScreen,
            isDark = isDark,
            modifier = Modifier.fillMaxSize()
        )

        if (webBrowserState != null) {
            InCarWebBrowserScreen(
                title = webBrowserState.title,
                initialUrl = webBrowserState.url,
                onClose = { repository.closeWebBrowser() },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            when (activeScreen) {
                ActiveScreen.MAP -> {}
                ActiveScreen.SETTINGS, ActiveScreen.ENERGY, ActiveScreen.OBD -> {
                    val tabIdx = when (activeScreen) {
                        ActiveScreen.ENERGY -> 11
                        ActiveScreen.OBD -> 12
                        else -> 0
                    }
                    SettingsScreen(
                        repository = repository,
                        initialTabIndex = tabIdx,
                        onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.CLIMATE -> {
                    ClimateModal(
                        vehicleState = vehicleState,
                        onAdjustDriverTemp = { repository.adjustDriverTemp(it) },
                        onSetFanSpeed = { repository.setFanSpeed(it) },
                        onToggleAC = { repository.toggleAC() },
                        onToggleAuto = { repository.toggleAutoClimate() },
                        onToggleRecirc = { repository.toggleRecirc() },
                        onToggleVentFace = { repository.toggleVentFace() },
                        onToggleVentFoot = { repository.toggleVentFoot() },
                        onToggleDefrostFront = { repository.toggleDefrostFront() },
                        onTogglePower = { repository.toggleClimatePower() },
                        onCycleDriverSeatHeat = { repository.cycleDriverSeatHeat() },
                        onCycleDriverSeatVent = { repository.cycleDriverSeatVent() },
                        onCyclePassengerSeatHeat = { repository.cyclePassengerSeatHeat() },
                        onCyclePassengerSeatVent = { repository.cyclePassengerSeatVent() },
                        onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.PHONE -> {
                    PhoneScreen(
                        repository = repository,
                        onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.MUSIC -> {
                    MusicScreen(
                        repository = repository,
                        onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.APPS -> {
                    AppsScreen(
                        onNavigate = { screen -> repository.setActiveScreen(screen) },
                        onOpenWebBrowser = { title, url -> repository.openWebBrowser(title, url) },
                        onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.VISUAL_DRIVE -> {
                    VisualDriveScreen(
                        vehicleState = vehicleState,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.CAMERA -> {
                    CameraPreviewScreen(
                        onClose = { repository.setActiveScreen(ActiveScreen.MAP) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                ActiveScreen.AUTO_PARK -> {
                    onShowAutoPark()
                }
            }
        }
    }
}
