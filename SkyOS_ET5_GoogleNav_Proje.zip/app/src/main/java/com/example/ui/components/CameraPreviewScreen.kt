package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalSkyPalette

@Composable
fun CameraPreviewScreen(
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    var selectedCam by remember { mutableStateOf("Ön Kamera (ADAS)") }
    var showGuidelines by remember { mutableStateOf(true) }

    val context = androidx.compose.ui.platform.LocalContext.current
    val cameraHardwarePresent = remember {
        try {
            val cm = context.getSystemService(android.content.Context.CAMERA_SERVICE) as? android.hardware.camera2.CameraManager
            (cm?.cameraIdList?.isNotEmpty() == true)
        } catch (_: Exception) { false }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.backgroundBrush)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Top Camera Selector & Status Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (cameraHardwarePresent) palette.statusSuccess.copy(alpha = 0.18f)
                                else palette.statusWarning.copy(alpha = 0.18f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = if (cameraHardwarePresent) palette.statusSuccess else palette.statusWarning,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = if (cameraHardwarePresent) "Kamera Donanımı Algılandı" else "Kamera Bağlı Değil",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Camera2 / UVC Görüntüleme ve Park Kılavuzu",
                            color = palette.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Ön Kamera (ADAS)", "Geri Görüş", "360° Çevre").forEach { cam ->
                        val isSelected = selectedCam.startsWith(cam.take(5))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) palette.accent else palette.surfaceElevated)
                                .border(1.dp, if (isSelected) palette.accent else palette.borderSubtle, RoundedCornerShape(10.dp))
                                .clickable { selectedCam = cam }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = cam,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else palette.textPrimary
                            )
                        }
                    }

                    // Toggle Parking Guidelines
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (showGuidelines) palette.accentSoftBg else palette.surfaceElevated)
                            .border(1.dp, if (showGuidelines) palette.accent else palette.borderSubtle, RoundedCornerShape(10.dp))
                            .clickable { showGuidelines = !showGuidelines }
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = "Kılavuz Çizgileri",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (showGuidelines) palette.accent else palette.textSecondary
                        )
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = palette.textPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Center Camera Viewport with Trajectory Parking Guidelines Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFF0A0E17))
                    .border(1.dp, palette.border, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (showGuidelines) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val bottomY = h * 0.92f
                        val topY = h * 0.56f
                        val midY1 = h * 0.78f
                        val midY2 = h * 0.66f

                        // Left & Right Trajectory rails
                        val leftRail = Path().apply {
                            moveTo(w * 0.24f, bottomY)
                            lineTo(w * 0.36f, topY)
                        }
                        val rightRail = Path().apply {
                            moveTo(w * 0.76f, bottomY)
                            lineTo(w * 0.64f, topY)
                        }
                        drawPath(leftRail, color = Color(0xFF10B981).copy(alpha = 0.65f), style = Stroke(width = 4.dp.toPx()))
                        drawPath(rightRail, color = Color(0xFF10B981).copy(alpha = 0.65f), style = Stroke(width = 4.dp.toPx()))

                        // Distance rungs (Red 0.5m, Amber 1.0m, Green 2.0m)
                        drawLine(
                            color = Color(0xFFEF4444).copy(alpha = 0.8f),
                            start = Offset(w * 0.26f, bottomY - 24f),
                            end = Offset(w * 0.74f, bottomY - 24f),
                            strokeWidth = 4.dp.toPx()
                        )
                        drawLine(
                            color = Color(0xFFF59E0B).copy(alpha = 0.75f),
                            start = Offset(w * 0.30f, midY1),
                            end = Offset(w * 0.70f, midY1),
                            strokeWidth = 3.dp.toPx()
                        )
                        drawLine(
                            color = Color(0xFF10B981).copy(alpha = 0.7f),
                            start = Offset(w * 0.335f, midY2),
                            end = Offset(w * 0.665f, midY2),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = palette.glassSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = if (cameraHardwarePresent) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = null,
                            tint = if (cameraHardwarePresent) palette.accent else palette.statusWarning,
                            modifier = Modifier.size(46.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (cameraHardwarePresent) "$selectedCam — Donanım Algılandı" else "Kamera Bulunamadı",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (cameraHardwarePresent)
                                "Canlı önizleme için UVC/Camera2 akış entegrasyonu gerekli"
                            else
                                "USB ADAS / UVC kamera takılı değil — simüle görüntü gösterilmiyor",
                            fontSize = 12.sp,
                            color = palette.textSecondary
                        )
                    }
                }
            }

            // 3. Bottom Hardware Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (cameraHardwarePresent)
                        "Durum: Kamera donanımı mevcut (Camera2) — canlı akış ve kayıt henüz entegre edilmedi"
                    else
                        "Durum: Kamera donanımı algılanmadı",
                    fontSize = 12.sp,
                    color = if (cameraHardwarePresent) palette.statusSuccess else palette.statusWarning,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Mesafe Çizgileri: 0.5m • 1.0m • 2.0m",
                    fontSize = 11.sp,
                    color = palette.textSecondary
                )
            }
        }
    }
}
