package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DriveMode
import com.example.model.VehicleState
import com.example.ui.theme.LocalSkyPalette

@Composable
fun VisualDriveScreen(
    vehicleState: VehicleState,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current

    val infiniteTransition = rememberInfiniteTransition(label = "laneAnim")
    val laneOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 70f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 550, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "laneOffset"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF070A12), Color(0xFF0F172A), Color(0xFF0B101C))
                )
            )
    ) {
        // 1. 3D Perspective Road & ADAS Lane Corridor Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val centerX = width * 0.5f
            val horizonY = height * 0.14f

            // Perspective Asphalt Corridor Polygon
            val roadPath = Path().apply {
                moveTo(centerX - width * 0.10f, horizonY)
                lineTo(centerX + width * 0.10f, horizonY)
                lineTo(centerX + width * 0.36f, height)
                lineTo(centerX - width * 0.36f, height)
                close()
            }
            drawPath(
                path = roadPath,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF131C2E).copy(alpha = 0.4f),
                        Color(0xFF1E293B).copy(alpha = 0.85f)
                    )
                )
            )

            // Active Lane Guidance Carpet Glow
            val carpetPath = Path().apply {
                moveTo(centerX - width * 0.045f, horizonY)
                lineTo(centerX + width * 0.045f, horizonY)
                lineTo(centerX + width * 0.16f, height)
                lineTo(centerX - width * 0.16f, height)
                close()
            }
            drawPath(
                path = carpetPath,
                brush = Brush.verticalGradient(
                    listOf(
                        palette.accent.copy(alpha = 0.04f),
                        palette.accent.copy(alpha = 0.20f),
                        palette.accent.copy(alpha = 0.05f)
                    )
                )
            )

            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(42f, 28f), laneOffset)

            // Left & Right Main Lane Lines (Perspective)
            drawLine(
                color = palette.accent.copy(alpha = 0.9f),
                start = Offset(centerX - width * 0.048f, horizonY),
                end = Offset(centerX - width * 0.165f, height),
                strokeWidth = 5f,
                pathEffect = dashEffect
            )
            drawLine(
                color = palette.accent.copy(alpha = 0.9f),
                start = Offset(centerX + width * 0.048f, horizonY),
                end = Offset(centerX + width * 0.165f, height),
                strokeWidth = 5f,
                pathEffect = dashEffect
            )

            // Outer Highway Guard Lines
            drawLine(
                color = Color.White.copy(alpha = 0.25f),
                start = Offset(centerX - width * 0.10f, horizonY),
                end = Offset(centerX - width * 0.35f, height),
                strokeWidth = 3f
            )
            drawLine(
                color = Color.White.copy(alpha = 0.25f),
                start = Offset(centerX + width * 0.10f, horizonY),
                end = Offset(centerX + width * 0.35f, height),
                strokeWidth = 3f
            )

            // Host Vehicle Ultrasonic Shield Rings
            drawCircle(
                color = palette.accent.copy(alpha = pulseAlpha * 0.35f),
                radius = 96.dp.toPx(),
                center = Offset(centerX, height * 0.62f)
            )
        }

        // 2. Host Vehicle in Center
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 32.dp)
                .size(width = 92.dp, height = 172.dp),
            contentAlignment = Alignment.Center
        ) {
            val resId = when {
                vehicleState.hazardLights -> R.drawable.arac_ust_dortlu
                vehicleState.leftSignal -> R.drawable.arac_ust_sol
                vehicleState.rightSignal -> R.drawable.arac_ust_sag
                vehicleState.brakeLights -> R.drawable.arac_ust_stop
                else -> R.drawable.arac_ust
            }
            Image(
                painter = painterResource(id = resId),
                contentDescription = "Araç",
                modifier = Modifier.fillMaxSize()
            )
        }

        // 3. Top Status Banner (Real ADAS Sensor Notice)
        if (!vehicleState.vehicleBusConnected) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 14.dp),
                shape = RoundedCornerShape(16.dp),
                color = palette.glassSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, palette.statusWarning.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sensors,
                        contentDescription = null,
                        tint = palette.statusWarning,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Çevre sensörü verisi yok — yalnızca kendi aracınız gösteriliyor",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = palette.statusWarning
                    )
                }
            }
        }

        // 4. Top-Left ADAS & Power Telemetry HUD Card
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 20.dp, start = 20.dp),
            shape = RoundedCornerShape(20.dp),
            color = palette.glassSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, palette.border)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "SÜRÜŞ TELEMETRİSİ",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.accent
                )
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column {
                        Text("VİTES", fontSize = 10.sp, color = palette.textSecondary)
                        Text(vehicleState.gear.name, fontSize = 20.sp, fontWeight = FontWeight.Black, color = palette.textPrimary)
                    }
                    Column {
                        Text("SÜRÜŞ MODU", fontSize = 10.sp, color = palette.textSecondary)
                        Text(
                            when (vehicleState.driveMode) {
                                DriveMode.NORMAL -> "Normal"
                                DriveMode.ECO -> "Eko"
                                DriveMode.SPORT -> "Spor"
                                DriveMode.WINTER -> "Kış"
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.accent
                        )
                    }
                    Column {
                        Text("GÜÇ", fontSize = 10.sp, color = palette.textSecondary)
                        Text(
                            "${vehicleState.powerKw.toInt()} kW",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (vehicleState.powerKw < 0) palette.statusSuccess else palette.textPrimary
                        )
                    }
                }
            }
        }

        // 5. Large Speed & Speed Limit HUD at Top-Right
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 20.dp, end = 24.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = "${vehicleState.speedKmh}",
                fontSize = 64.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Text(
                text = "KM/SA",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = palette.accent
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (vehicleState.speedLimitKmh > 0) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(4.dp, Color(0xFFEF4444), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${vehicleState.speedLimitKmh}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black
                    )
                }
            }
        }
    }
}
