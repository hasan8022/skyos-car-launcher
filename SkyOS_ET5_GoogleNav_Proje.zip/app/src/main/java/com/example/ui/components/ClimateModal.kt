package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VehicleState
import com.example.ui.theme.LocalSkyPalette
import kotlin.math.sin

@Composable
fun ClimateModal(
    vehicleState: VehicleState,
    onAdjustDriverTemp: (Float) -> Unit,
    onSetFanSpeed: (Int) -> Unit,
    onToggleAC: () -> Unit,
    onToggleAuto: () -> Unit,
    onToggleRecirc: () -> Unit,
    onToggleVentFace: () -> Unit,
    onToggleVentFoot: () -> Unit,
    onToggleDefrostFront: () -> Unit,
    onTogglePower: () -> Unit,
    onCycleDriverSeatHeat: () -> Unit,
    onCycleDriverSeatVent: () -> Unit,
    onCyclePassengerSeatHeat: () -> Unit,
    onCyclePassengerSeatVent: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    var syncDualZone by remember { mutableStateOf(true) }
    var passengerTempLocal by remember(vehicleState.passengerTemp) { mutableFloatStateOf(vehicleState.passengerTemp) }

    val infiniteTransition = rememberInfiniteTransition(label = "airflowAnim")
    val airPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "airPhase"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.backgroundBrush)
            .padding(18.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Header Bar with Quick Presets & Close Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.accentSoftBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Air, contentDescription = null, tint = palette.accent)
                }
                Column {
                    Text(
                        text = "Akıllı İklimlendirme & Kabin Konforu",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = if (vehicleState.climatePower)
                            "Çift Bölge Aktif • PM2.5 Kabin Filtresi Devrede"
                        else "İklimlendirme Sistemi Kapalı",
                        fontSize = 12.sp,
                        color = if (vehicleState.climatePower) palette.accent else palette.textSecondary
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Quick Presets: Hızlı Soğut (18°C), Konfor (22°C), Hızlı Isıt (26°C)
                ClimateQuickPresetPill("❄️ Max Soğut", Color(0xFF38BDF8)) {
                    onAdjustDriverTemp(18.0f - vehicleState.driverTemp)
                    passengerTempLocal = 18.0f
                    onSetFanSpeed(6)
                }
                ClimateQuickPresetPill("✨ 22° Konfor", palette.accent) {
                    onAdjustDriverTemp(22.0f - vehicleState.driverTemp)
                    passengerTempLocal = 22.0f
                    onSetFanSpeed(3)
                }
                ClimateQuickPresetPill("🔥 Max Isıt", Color(0xFFF97316)) {
                    onAdjustDriverTemp(26.5f - vehicleState.driverTemp)
                    passengerTempLocal = 26.5f
                    onSetFanSpeed(5)
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(palette.surfaceElevated)
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = palette.textPrimary)
                }
            }
        }

        // 2. Main 3-Column Climate Cockpit
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // LEFT: DRIVER ZONE CARD
            Column(
                modifier = Modifier
                    .weight(0.28f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(22.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(22.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "SÜRÜCÜ BÖLGESİ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.accent
                )

                // Driver Temp Dial
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(
                        onClick = {
                            onAdjustDriverTemp(-0.5f)
                            if (syncDualZone) passengerTempLocal = (vehicleState.driverTemp - 0.5f).coerceIn(16f, 32f)
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Azalt", tint = Color(0xFF38BDF8))
                    }

                    Text(
                        text = String.format(java.util.Locale.US, "%.1f°", vehicleState.driverTemp).replace(".", ","),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )

                    IconButton(
                        onClick = {
                            onAdjustDriverTemp(+0.5f)
                            if (syncDualZone) passengerTempLocal = (vehicleState.driverTemp + 0.5f).coerceIn(16f, 32f)
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Artır", tint = Color(0xFFF97316))
                    }
                }

                SeatControlRow(
                    label = "Koltuk Isıtma",
                    icon = Icons.Default.AirlineSeatReclineNormal,
                    activeColor = Color(0xFFF97316),
                    level = vehicleState.driverSeatHeat,
                    onLevelSelected = { onCycleDriverSeatHeat() }
                )

                SeatControlRow(
                    label = "Koltuk Soğutma",
                    icon = Icons.Default.AcUnit,
                    activeColor = Color(0xFF38BDF8),
                    level = vehicleState.driverSeatVent,
                    onLevelSelected = { onCycleDriverSeatVent() }
                )
            }

            // CENTER: Animated Cabin Airflow Visualizer & Fan Speed Bar
            Column(
                modifier = Modifier
                    .weight(0.44f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(22.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(22.dp))
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Animated Airflow Stream Stage
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(palette.surfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    val streamColor = when {
                        !vehicleState.climatePower -> Color.Gray.copy(alpha = 0.25f)
                        vehicleState.driverTemp <= 20.5f -> Color(0xFF38BDF8)
                        vehicleState.driverTemp >= 24.5f -> Color(0xFFF97316)
                        else -> palette.accent
                    }

                    Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        val w = size.width
                        val h = size.height
                        val lines = 5
                        for (lineIdx in 0 until lines) {
                            val baseY = h * (0.2f + 0.15f * lineIdx)
                            val path = Path()
                            path.moveTo(0f, baseY)
                            val steps = 40
                            for (s in 0..steps) {
                                val x = (w / steps) * s
                                val norm = s.toFloat() / steps
                                val amp = if (vehicleState.climatePower) (6f + vehicleState.fanSpeed * 1.5f) else 2f
                                val y = baseY + sin(norm * 3f * Math.PI - airPhase + lineIdx * 0.7f).toFloat() * amp
                                path.lineTo(x, y)
                            }
                            drawPath(
                                path = path,
                                brush = Brush.horizontalGradient(
                                    listOf(
                                        streamColor.copy(alpha = 0.15f),
                                        streamColor.copy(alpha = 0.75f),
                                        streamColor.copy(alpha = 0.15f)
                                    )
                                ),
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = String.format(java.util.Locale.US, "%.1f°C", vehicleState.driverTemp).replace(".", ","),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            color = palette.textPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = palette.surface.copy(alpha = 0.85f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (vehicleState.climatePower) "Kabin Hava Akışı Aktif" else "İklim Kapalı",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = streamColor
                                )
                                Text(
                                    text = "• SYNC",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (syncDualZone) palette.statusSuccess else palette.textMuted,
                                    modifier = Modifier.clickable { syncDualZone = !syncDualZone }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Fan Speed Slider Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { onSetFanSpeed((vehicleState.fanSpeed - 1).coerceAtLeast(0)) },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Azalt", tint = palette.textPrimary)
                    }

                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = "Fan",
                        tint = palette.accent,
                        modifier = Modifier.size(20.dp)
                    )

                    Slider(
                        value = vehicleState.fanSpeed.toFloat(),
                        onValueChange = { onSetFanSpeed(it.toInt()) },
                        valueRange = 0f..7f,
                        steps = 6,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("climate_fan_slider"),
                        colors = SliderDefaults.colors(
                            thumbColor = palette.accent,
                            activeTrackColor = palette.accent,
                            inactiveTrackColor = palette.surfaceElevated
                        )
                    )

                    Text(
                        text = "Kademe ${vehicleState.fanSpeed}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary
                    )

                    IconButton(
                        onClick = { onSetFanSpeed((vehicleState.fanSpeed + 1).coerceAtMost(7)) },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Artır", tint = palette.textPrimary)
                    }
                }
            }

            // RIGHT: PASSENGER ZONE CARD
            Column(
                modifier = Modifier
                    .weight(0.28f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(22.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(22.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "YOLCU BÖLGESİ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.accent
                )

                val shownPassTemp = if (syncDualZone) vehicleState.driverTemp else passengerTempLocal
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(
                        onClick = {
                            syncDualZone = false
                            passengerTempLocal = (passengerTempLocal - 0.5f).coerceIn(16f, 32f)
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Azalt", tint = Color(0xFF38BDF8))
                    }

                    Text(
                        text = String.format(java.util.Locale.US, "%.1f°", shownPassTemp).replace(".", ","),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )

                    IconButton(
                        onClick = {
                            syncDualZone = false
                            passengerTempLocal = (passengerTempLocal + 0.5f).coerceIn(16f, 32f)
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Artır", tint = Color(0xFFF97316))
                    }
                }

                SeatControlRow(
                    label = "Koltuk Isıtma",
                    icon = Icons.Default.AirlineSeatReclineNormal,
                    activeColor = Color(0xFFF97316),
                    level = vehicleState.passengerSeatHeat,
                    onLevelSelected = { onCyclePassengerSeatHeat() }
                )

                SeatControlRow(
                    label = "Koltuk Soğutma",
                    icon = Icons.Default.AcUnit,
                    activeColor = Color(0xFF38BDF8),
                    level = vehicleState.passengerSeatVent,
                    onLevelSelected = { onCyclePassengerSeatVent() }
                )
            }
        }

        // 3. Bottom Control Buttons Dock
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(18.dp))
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            ClimateModeBtn(
                title = "Otomatik",
                icon = Icons.Default.AutoAwesome,
                isActive = vehicleState.autoClimate,
                activeColor = palette.accent,
                onClick = onToggleAuto
            )
            ClimateModeBtn(
                title = "A/C Soğutma",
                icon = Icons.Default.AcUnit,
                isActive = vehicleState.acEnabled,
                activeColor = Color(0xFF38BDF8),
                onClick = onToggleAC
            )
            ClimateModeBtn(
                title = "İç Hava",
                icon = Icons.Default.Sync,
                isActive = vehicleState.recircEnabled,
                activeColor = palette.accent,
                onClick = onToggleRecirc
            )
            ClimateModeBtn(
                title = "Yüz Yönü",
                icon = Icons.Default.ArrowForward,
                isActive = vehicleState.ventFace,
                activeColor = palette.accent,
                onClick = onToggleVentFace
            )
            ClimateModeBtn(
                title = "Ayak Yönü",
                icon = Icons.Default.ArrowDownward,
                isActive = vehicleState.ventFoot,
                activeColor = palette.accent,
                onClick = onToggleVentFoot
            )
            ClimateModeBtn(
                title = "Ön Cam Buğu",
                icon = Icons.Default.VerticalAlignTop,
                isActive = vehicleState.ventDefrostFront,
                activeColor = Color(0xFFF59E0B),
                onClick = onToggleDefrostFront
            )
            ClimateModeBtn(
                title = if (vehicleState.climatePower) "Sistemi Kapat" else "Sistemi Aç",
                icon = Icons.Default.PowerSettingsNew,
                isActive = !vehicleState.climatePower,
                activeColor = palette.statusDanger,
                onClick = onTogglePower
            )
        }
    }
}

@Composable
private fun ClimateQuickPresetPill(label: String, color: Color, onClick: () -> Unit) {
    val palette = LocalSkyPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceElevated)
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = palette.textPrimary
        )
    }
}

@Composable
fun SeatControlRow(
    label: String,
    icon: ImageVector,
    activeColor: Color,
    level: Int,
    onLevelSelected: () -> Unit
) {
    val palette = LocalSkyPalette.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(bottom = 6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = activeColor, modifier = Modifier.size(16.dp))
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = palette.textSecondary)
        }

        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(palette.surfaceElevated)
                .padding(3.dp)
        ) {
            val levels = listOf(0 to "Kapalı", 1 to "1", 2 to "2", 3 to "3")
            levels.forEach { (lvl, title) ->
                val isSelected = level == lvl
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) activeColor else Color.Transparent)
                        .clickable(onClick = onLevelSelected)
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else palette.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun ClimateModeBtn(
    title: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color = Color(0xFF00D2FF),
    onClick: () -> Unit
) {
    val palette = LocalSkyPalette.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) activeColor else palette.surfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isActive) Color.Black else palette.textPrimary,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) Color.Black else palette.textSecondary,
            modifier = Modifier.padding(top = 3.dp)
        )
    }
}
