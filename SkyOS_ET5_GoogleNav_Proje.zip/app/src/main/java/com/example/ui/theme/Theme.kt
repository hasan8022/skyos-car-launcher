package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * SkyOS Zengin Kokpit Tema Paleti (Glassmorphism, Neon Glow & Surface Tokens)
 */
@Immutable
data class SkyThemePalette(
    val isDark: Boolean,
    val preset: AccentThemePreset,
    val background: Color,
    val backgroundSecondary: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val surfaceHighlight: Color,
    val glassSurface: Color,
    val border: Color,
    val borderSubtle: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val accent: Color,
    val accentSecondary: Color,
    val accentTertiary: Color,
    val accentSoftBg: Color,
    val statusSuccess: Color = StatusSuccessGreen,
    val statusWarning: Color = StatusWarningAmber,
    val statusDanger: Color = StatusAlertRed
) {
    val backgroundBrush: Brush
        get() = if (isDark) {
            Brush.verticalGradient(
                listOf(
                    Color(0xFF070A10),
                    Color(0xFF0B101B),
                    Color(0xFF080B12)
                )
            )
        } else {
            Brush.verticalGradient(
                listOf(
                    Color(0xFFF1F5F9),
                    Color(0xFFE2E8F0),
                    Color(0xFFF8FAFC)
                )
            )
        }

    val cardBrush: Brush
        get() = if (isDark) {
            Brush.linearGradient(
                listOf(
                    Color(0xFF151C2C),
                    Color(0xFF101622)
                )
            )
        } else {
            Brush.linearGradient(
                listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF8FAFC)
                )
            )
        }

    val accentGradientBrush: Brush
        get() = Brush.horizontalGradient(
            listOf(accent, accentSecondary, accentTertiary)
        )

    val topBarBrush: Brush
        get() = if (isDark) {
            Brush.horizontalGradient(
                listOf(
                    Color(0xFF090D15),
                    Color(0xFF111827),
                    Color(0xFF090D15)
                )
            )
        } else {
            Brush.horizontalGradient(
                listOf(
                    Color(0xFFE2E8F0),
                    Color(0xFFF8FAFC),
                    Color(0xFFE2E8F0)
                )
            )
        }
}

val LocalSkyPalette = staticCompositionLocalOf {
    buildSkyPalette(isDark = true, preset = AccentThemePreset.SKY_CYAN)
}

fun buildSkyPalette(
    isDark: Boolean,
    preset: AccentThemePreset = AccentThemePreset.SKY_CYAN
): SkyThemePalette {
    val primaryAccent = if (isDark) preset.primary else preset.secondary
    return if (isDark) {
        SkyThemePalette(
            isDark = true,
            preset = preset,
            background = DarkBackground,
            backgroundSecondary = DarkBackgroundSecondary,
            surface = DarkSurface,
            surfaceElevated = DarkSurfaceElevated,
            surfaceHighlight = DarkSurfaceHighlight,
            glassSurface = DarkGlassSurface,
            border = DarkBorder,
            borderSubtle = Color(0xFF1E293B),
            textPrimary = DarkTextPrimary,
            textSecondary = DarkTextSecondary,
            textMuted = DarkTextMuted,
            accent = primaryAccent,
            accentSecondary = preset.secondary,
            accentTertiary = preset.tertiary,
            accentSoftBg = primaryAccent.copy(alpha = 0.16f)
        )
    } else {
        SkyThemePalette(
            isDark = false,
            preset = preset,
            background = LightBackground,
            backgroundSecondary = LightBackgroundSecondary,
            surface = LightSurface,
            surfaceElevated = LightSurfaceElevated,
            surfaceHighlight = LightSurfaceHighlight,
            glassSurface = LightGlassSurface,
            border = LightBorder,
            borderSubtle = Color(0xFFE2E8F0),
            textPrimary = LightTextPrimary,
            textSecondary = LightTextSecondary,
            textMuted = LightTextMuted,
            accent = primaryAccent,
            accentSecondary = preset.primary,
            accentTertiary = preset.tertiary,
            accentSoftBg = primaryAccent.copy(alpha = 0.12f)
        )
    }
}

val SkyOsDarkColorScheme = darkColorScheme(
    primary = SkyCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF0C4A6E),
    onPrimaryContainer = Color(0xFFBAE6FD),
    secondary = Color(0xFF38BDF8),
    onSecondary = Color.Black,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    error = StatusAlertRed,
    onError = Color.White
)

val SkyOsLightColorScheme = lightColorScheme(
    primary = SkyBlueLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceHighlight,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    error = StatusAlertRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    accentPresetId: String = "sky_cyan",
    content: @Composable () -> Unit
) {
    val preset = AccentThemePreset.fromId(accentPresetId)
    val palette = buildSkyPalette(isDark = darkTheme, preset = preset)
    val baseScheme = if (darkTheme) SkyOsDarkColorScheme else SkyOsLightColorScheme
    val colorScheme = baseScheme.copy(
        primary = palette.accent,
        secondary = palette.accentSecondary,
        background = palette.background,
        surface = palette.surface,
        surfaceVariant = palette.surfaceElevated,
        outline = palette.border
    )

    CompositionLocalProvider(LocalSkyPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
