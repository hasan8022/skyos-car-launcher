package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleRepository
import com.example.model.*
import com.example.ui.theme.AccentThemePreset
import com.example.ui.theme.LocalSkyPalette

@Composable
fun SettingsScreen(
    repository: VehicleRepository,
    initialTabIndex: Int = 0,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    val vehicleState by repository.vehicleState.collectAsState()
    val telemetry by repository.obdManager.telemetry.collectAsState()
    val cellVoltages by repository.obdManager.cellVoltages.collectAsState()
    val adbConnected by repository.adbBridge.isConnected.collectAsState()
    val adbStatus by repository.adbBridge.connectionStatus.collectAsState()

    val isDark = repository.isDarkModeEffective(vehicleState)
    var selectedTabIndex by remember(initialTabIndex) { mutableIntStateOf(initialTabIndex) }
    var searchQuery by remember { mutableStateOf("") }

    val tabs = listOf(
        SettingsTabItem("Hızlı Kontroller", Icons.Default.DirectionsCar, "ARAÇ & KONTROL"),
        SettingsTabItem("Ekran ve Tema", Icons.Default.Palette, "ARAÇ & KONTROL"),
        SettingsTabItem("Profiller", Icons.Default.Person, "ARAÇ & KONTROL"),
        SettingsTabItem("Akıllı Mod", Icons.Default.Nightlight, "ARAÇ & KONTROL"),
        SettingsTabItem("Klima", Icons.Default.Air, "KONFOR & SÜRÜŞ"),
        SettingsTabItem("Sürüş", Icons.Default.Speed, "KONFOR & SÜRÜŞ"),
        SettingsTabItem("Navigasyon", Icons.Default.Navigation, "KONFOR & SÜRÜŞ"),
        SettingsTabItem("Koltuklar ve Aynalar", Icons.Default.AirlineSeatReclineNormal, "KONFOR & SÜRÜŞ"),
        SettingsTabItem("Işıklar", Icons.Default.Highlight, "KONFOR & SÜRÜŞ"),
        SettingsTabItem("Kilitler", Icons.Default.Lock, "KONFOR & SÜRÜŞ"),
        SettingsTabItem("Şarj ve Batarya", Icons.Default.Bolt, "ENERJİ & SERVİS"),
        SettingsTabItem("Enerji", Icons.Default.ShowChart, "ENERJİ & SERVİS"),
        SettingsTabItem("OBD & Servis", Icons.Default.Build, "ENERJİ & SERVİS"),
        SettingsTabItem("Yazılım", Icons.Default.SystemUpdate, "ENERJİ & SERVİS")
    )

    val filteredTabs = remember(searchQuery) {
        if (searchQuery.isBlank()) tabs
        else tabs.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(palette.backgroundBrush)
    ) {
        // Left Settings Navigation Sidebar
        Column(
            modifier = Modifier
                .width(245.dp)
                .fillMaxHeight()
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle)
                .padding(vertical = 12.dp, horizontal = 10.dp)
        ) {
            // Search Field
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text("Ayarlarda ara…", color = palette.textMuted, fontSize = 13.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Ara",
                        tint = palette.accent,
                        modifier = Modifier.size(18.dp)
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = palette.surfaceElevated,
                    unfocusedContainerColor = palette.surfaceElevated,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(filteredTabs.indices.toList()) { idx ->
                    val tab = filteredTabs[idx]
                    val realIdx = tabs.indexOf(tab).let { if (it < 0) idx else it }
                    val isSelected = selectedTabIndex == realIdx

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) palette.accentSoftBg else Color.Transparent)
                            .border(
                                width = if (isSelected) 1.dp else 0.dp,
                                color = if (isSelected) palette.accent.copy(alpha = 0.45f) else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedTabIndex = realIdx }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(18.dp)
                                    .clip(CircleShape)
                                    .background(palette.accent)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) palette.accent else palette.textSecondary,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = tab.title,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                            color = if (isSelected) palette.textPrimary else palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Right Settings Content Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(20.dp)
        ) {
            val activeTab = tabs.getOrNull(selectedTabIndex)
            // Header with Title and Close (X)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.accentSoftBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = activeTab?.icon ?: Icons.Default.Settings,
                            contentDescription = null,
                            tint = palette.accent,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = activeTab?.group ?: "SKYOS AYARLARI",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.accent
                        )
                        Text(
                            text = activeTab?.title ?: "Ayarlar",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                    }
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(palette.surfaceElevated)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Kapat",
                        tint = palette.textPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> QuickControlsContent(repository, vehicleState)
                    1 -> DisplayAndThemeContent(repository, vehicleState, isDark)
                    2 -> ProfilesContent(repository, vehicleState)
                    3 -> SmartModesContent(repository)
                    4 -> ClimateSettingsContent(repository, vehicleState)
                    5 -> DriveDynamicsContent(repository, vehicleState)
                    6 -> NavigationSettingsContent(repository, vehicleState)
                    7 -> SeatsAndMirrorsContent(repository, vehicleState)
                    8 -> LightsContent(repository, vehicleState)
                    9 -> LocksContent(repository, vehicleState)
                    10 -> BatteryChargingContent(repository, vehicleState)
                    11 -> EnergyAnalyticsContent(repository, vehicleState)
                    12 -> ObdServiceContent(repository, telemetry, cellVoltages, adbConnected, adbStatus)
                    13 -> SoftwareUpdateContent(repository)
                }
            }
        }
    }
}

data class SettingsTabItem(val title: String, val icon: ImageVector, val group: String = "")

// --- SUB-CONTENTS ---

@Composable
fun QuickControlsContent(repository: VehicleRepository, state: VehicleState) {
    val palette = LocalSkyPalette.current
    Column {
        Text(
            "Sık kullanılan araç gövde, aydınlatma ve akıllı mod kontrolleri tek dokunuşta",
            color = palette.textSecondary,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(14.dp))

        val items = listOf(
            QuickControlCardData("Bagaj Kapağı", if (state.trunk) "Açık • Kapatmak için dokun" else "Kapalı • Açmak için dokun", Icons.Default.DirectionsCar, state.trunk) { repository.toggleTrunk() },
            QuickControlCardData("Ön Kaput", if (state.hood) "Açık" else "Kapalı", Icons.Default.CarRepair, state.hood) { repository.toggleHood() },
            QuickControlCardData("Şarj Kapağı", if (state.chargePort) "Açık" else "Kapalı", Icons.Default.EvStation, state.chargePort) { repository.toggleChargePort() },
            QuickControlCardData("Ön Cam Buğu", if (state.ventDefrostFront) "Aktif" else "Kapalı", Icons.Default.VerticalAlignTop, state.ventDefrostFront) { repository.toggleDefrostFront() },
            QuickControlCardData("Arka Cam Buğu", if (state.ventDefrostRear) "Aktif" else "Kapalı", Icons.Default.VerticalAlignBottom, state.ventDefrostRear) { repository.toggleDefrostRear() },
            QuickControlCardData("220 V V2L Priz", if (state.outlet220V) "Güç Çıkışı Aktif" else "Kapalı", Icons.Default.Power, state.outlet220V) { repository.toggle220V() },
            QuickControlCardData("Panoramik Tavan", if (state.sunroofOpen) "Açık" else "Kapalı", Icons.Default.Window, state.sunroofOpen) { repository.toggleSunroof() },
            QuickControlCardData("Yan Aynalar", if (state.mirrorsFolded) "Katlanmış" else "Açık", Icons.Default.CompareArrows, state.mirrorsFolded) { repository.toggleMirrors() },
            QuickControlCardData("Dörtlü Flaşör", if (state.hazardLights) "Yanıyor" else "Kapalı", Icons.Default.Warning, state.hazardLights) { repository.toggleHazardLights() },
            QuickControlCardData("Evcil Hayvan", "Kabin iklimini sabit tutar", Icons.Default.Pets, false) { repository.setSmartMode(SmartScreenMode.PET_MODE) },
            QuickControlCardData("Geçici Not", "Ekranda iletişim notu göster", Icons.Default.Note, false) { repository.setSmartMode(SmartScreenMode.TEMP_NOTE) },
            QuickControlCardData("Oto Yıkama", "Aynalar, radar ve cam koruması", Icons.Default.LocalCarWash, false) { repository.setSmartMode(SmartScreenMode.CAR_WASH) }
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items) { item ->
                Box(
                    modifier = Modifier
                        .height(102.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (item.isActive) palette.accentSoftBg else palette.surface)
                        .border(
                            1.dp,
                            if (item.isActive) palette.accent.copy(alpha = 0.6f) else palette.borderSubtle,
                            RoundedCornerShape(18.dp)
                        )
                        .clickable(onClick = item.onClick)
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = if (item.isActive) palette.accent else palette.textPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (item.isActive) palette.accent else palette.border)
                            )
                        }
                        Column {
                            Text(text = item.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                            Text(text = item.subtitle, fontSize = 11.sp, color = if (item.isActive) palette.accent else palette.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

data class QuickControlCardData(val title: String, val subtitle: String, val icon: ImageVector, val isActive: Boolean, val onClick: () -> Unit)

@Composable
fun DisplayAndThemeContent(
    repository: VehicleRepository,
    state: VehicleState,
    isDark: Boolean
) {
    val palette = LocalSkyPalette.current
    var brightness by remember { mutableFloatStateOf(0.85f) }
    var selectedUiSize by remember { mutableIntStateOf(0) }
    var selectedTextSize by remember { mutableIntStateOf(0) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "Kokpit aydınlatma modu, 6 özel neon tema paketi, 3D araç rengi ve ekran ölçekleme",
                color = palette.textSecondary,
                fontSize = 13.sp
            )
        }

        // 1. Day / Night / Auto Mode Selection
        item {
            Text(
                text = "Aydınlatma Modu",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val themeOptions = listOf(
                    Triple(ThemeMode.DARK, "Siyah (Gece Kokpiti)", Icons.Default.DarkMode),
                    Triple(ThemeMode.LIGHT, "Beyaz (Gündüz Kristal)", Icons.Default.LightMode),
                    Triple(ThemeMode.AUTO, "Otomatik (Far & Saat)", Icons.Default.BrightnessAuto)
                )

                themeOptions.forEach { (mode, title, icon) ->
                    val isSelected = state.themeMode == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) palette.accentSoftBg else palette.surface)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) palette.accent else palette.borderSubtle,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { repository.setThemeMode(mode) }
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = if (isSelected) palette.accent else palette.textSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                            Text(
                                text = when (mode) {
                                    ThemeMode.DARK -> "Göz yormayan derin obsidyen yüzeyler"
                                    ThemeMode.LIGHT -> "Güneş altında yüksek kontrastlı beyaz"
                                    ThemeMode.AUTO -> "Farlara ve gün batımına göre geçiş"
                                },
                                fontSize = 11.sp,
                                color = palette.textSecondary
                            )
                        }
                    }
                }
            }
        }

        // 2. 6 Accent Theme Presets (Skywell Cyan, Cyber Neon, Regen Emerald, GT Sport, Luxury Gold, Arctic Ice)
        item {
            Text(
                text = "Kokpit Vurgu Teması (6 Özel Tasarım Paketi)",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AccentThemePreset.entries.chunked(3).forEach { rowPresets ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowPresets.forEach { preset ->
                            val isSelected = state.accentPresetId == preset.id
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isSelected) preset.primary.copy(alpha = 0.16f) else palette.surface)
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) preset.primary else palette.borderSubtle,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { repository.setAccentPreset(preset.id) }
                                    .padding(12.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(preset.primary))
                                            Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(preset.secondary))
                                            Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(preset.tertiary))
                                        }
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = preset.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = preset.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = palette.textPrimary
                                    )
                                    Text(
                                        text = preset.subtitle,
                                        fontSize = 10.sp,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. 3D Vehicle Body Paint Color Selector
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "3D Araç Gövde Rengi (Canlı Sahne)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary
                    )
                    val carColors = listOf(
                        "#7BA4C7" to "Skywell Buz Mavisi",
                        "#F8FAFC" to "İnci Beyazı",
                        "#1E293B" to "Gece Yarısı Siyahı",
                        "#64748B" to "Titanyum Gri",
                        "#DC2626" to "GT Kırmızı",
                        "#059669" to "Zümrüt Yeşili"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        carColors.forEach { (hex, label) ->
                            val isSel = state.carColorHex.equals(hex, ignoreCase = true)
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSel) palette.accentSoftBg else palette.surfaceElevated)
                                    .border(1.dp, if (isSel) palette.accent else palette.borderSubtle, RoundedCornerShape(12.dp))
                                    .clickable { repository.setCarColor(hex) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(hex)))
                                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                                )
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    color = palette.textPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Screen Brightness Slider
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Brightness6, contentDescription = "Parlaklık", tint = palette.accent)
                            Text(
                                text = "Ekran Parlaklığı",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                        }
                        Text(
                            text = "%${(brightness * 100).toInt()}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.accent
                        )
                    }

                    Slider(
                        value = brightness,
                        onValueChange = { brightness = it },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = palette.accent,
                            activeTrackColor = palette.accent,
                            inactiveTrackColor = palette.surfaceElevated
                        )
                    )
                }
            }
        }

        // 5. UI & Text Scaling
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Arayüz Boyutu",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.textPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Orta", "Büyük", "Çok Büyük").forEachIndexed { index, label ->
                                val sel = selectedUiSize == index
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (sel) palette.accent else palette.surfaceElevated)
                                        .clickable { selectedUiSize = index }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (sel) Color.Black else palette.textSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Yazı Boyutu",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.textPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Klasik", "Büyük").forEachIndexed { index, label ->
                                val sel = selectedTextSize == index
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (sel) palette.accent else palette.surfaceElevated)
                                        .clickable { selectedTextSize = index }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (sel) Color.Black else palette.textSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfilesContent(repository: VehicleRepository, state: VehicleState) {
    val palette = LocalSkyPalette.current
    Column {
        Text("Her sürücüye özel ayna, koltuk, sıcaklık ve sürüş ayarları", color = palette.textSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(repository.driverProfiles) { profile ->
                val isSelected = state.activeDriverProfileId == profile.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) palette.accentSoftBg else palette.surface)
                        .border(
                            1.dp,
                            if (isSelected) palette.accent.copy(alpha = 0.55f) else palette.borderSubtle,
                            RoundedCornerShape(16.dp)
                        )
                        .clickable { repository.selectDriverProfile(profile.id) }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(profile.avatarColorHex))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = profile.initial, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        }

                        Column {
                            Text(text = profile.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                            Text(
                                text = "Telefon: ${profile.connectedPhoneName}  •  İklim: ${profile.preferredTemp}°C  •  Koltuk Hafıza #${profile.seatMemoryPos}",
                                fontSize = 12.sp,
                                color = palette.textSecondary
                            )
                        }
                    }

                    if (isSelected) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Aktif", tint = palette.accent)
                    }
                }
            }
        }
    }
}

@Composable
fun SmartModesContent(repository: VehicleRepository) {
    val palette = LocalSkyPalette.current
    Column {
        Text("Akıllı Durum ve Kabin Senaryo Modları", color = palette.textSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(14.dp))

        val modes = listOf(
            Triple(SmartScreenMode.PET_MODE, "Evcil Hayvan Modu", "Klima açık kalır, ekranda mesaj ve derece gösterilir"),
            Triple(SmartScreenMode.CAR_WASH, "Oto Yıkama Modu", "Aynalar katlanır, cam tavan kapanır, park sensörü susar"),
            Triple(SmartScreenMode.CAMP_MODE, "Kamp Modu", "Klima gece boyunca açık kalır, 220V V2L priz aktif edilir"),
            Triple(SmartScreenMode.TEMP_NOTE, "Geçici Not Modu", "Ekranda büyük iletişim notu gösterilir"),
            Triple(SmartScreenMode.SCREEN_CLEAN, "Ekran Temizleme", "Ekran kararır, dokunuşları almaz (çıkış: 3 sn basılı tut)"),
            Triple(SmartScreenMode.SLEEP_MODE, "Uyku Modu", "Ekran kararır, koltuk dinlenme konumuna geçer"),
            Triple(SmartScreenMode.WATCH_MODE, "İzleme Modu", "Büyük batarya yüzdesi ve şarj durumu görünür")
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(modes) { (mode, title, desc) ->
                Box(
                    modifier = Modifier
                        .height(104.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                        .clickable { repository.setSmartMode(mode) }
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                            Icon(imageVector = Icons.Default.ArrowForwardIos, contentDescription = null, tint = palette.accent, modifier = Modifier.size(14.dp))
                        }
                        Text(text = desc, fontSize = 11.sp, color = palette.textSecondary)
                    }
                }
            }
        }
    }
}

@Composable
fun DriveDynamicsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsRowWithSegmented(
            title = "Sürüş Modu",
            desc = "Aracın gaz tepkisini, güç dağılımını ve rejenerasyon karakterini belirler",
            options = listOf("Normal", "Eko", "Kış", "Spor"),
            selectedIndex = when (state.driveMode) {
                DriveMode.NORMAL -> 0
                DriveMode.ECO -> 1
                DriveMode.WINTER -> 2
                DriveMode.SPORT -> 3
            },
            onSelect = {
                val mode = when (it) {
                    0 -> DriveMode.NORMAL
                    1 -> DriveMode.ECO
                    2 -> DriveMode.WINTER
                    else -> DriveMode.SPORT
                }
                repository.setDriveMode(mode)
            }
        )

        SettingsRowWithSegmented(
            title = "Direksiyon Hassasiyeti (EPS)",
            desc = "Direksiyon sertliğini ve yol geri bildirimini ayarlar",
            options = listOf("Konfor", "Standart", "Spor"),
            selectedIndex = when (state.steeringMode) {
                SteeringMode.COMFORT -> 0
                SteeringMode.STANDARD -> 1
                SteeringMode.SPORT -> 2
            },
            onSelect = {
                val m = when (it) { 0 -> SteeringMode.COMFORT 1 -> SteeringMode.STANDARD else -> SteeringMode.SPORT }
                repository.setSteeringMode(m)
            }
        )

        SettingsToggleRow(
            title = "Emekleme Modu (Creep)",
            desc = "Fren bırakıldığında araç D veya R vitesinde yavaşça ilerler",
            checked = state.creepEnabled,
            onCheckedChange = { repository.toggleCreep() }
        )

        SettingsToggleRow(
            title = "Yokuş İniş Desteği (HDC)",
            desc = "Dik eğimlerde hızı otomatik sınırlandırır",
            checked = state.hillDescentEnabled,
            onCheckedChange = { repository.toggleHillDescent() }
        )
    }
}

@Composable
fun NavigationSettingsContent(repository: VehicleRepository, state: VehicleState) {
    val palette = LocalSkyPalette.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Harita katmanları, hız radarları ve EV rota filtreleri (30 FPS)",
                color = palette.textSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        item {
            SettingsToggleRow("Canlı Trafik", "Yollardaki yoğunluğu yeşil, turuncu, kırmızı renklerle gösterir", state.navTrafficEnabled) {
                repository.toggleNavTraffic()
            }
        }
        item {
            SettingsToggleRow("Radar ve Hız Kameraları", "EDS ve sabit hız kameralarını haritada gösterir", state.navSpeedCamerasEnabled) {
                repository.toggleNavSpeedCameras()
            }
        }
        item {
            SettingsToggleRow("Şarj İstasyonları", "Rota üstündeki ve yakındaki Trugo, Eşarj ve ZES şarj noktaları", state.navShowChargingStations) {
                repository.toggleNavChargingStations()
            }
        }
        item {
            SettingsToggleRow("Yakın Otoparklar", "Çevredeki otoparkları haritada gösterir", state.navShowParking) {
                repository.toggleNavParking()
            }
        }
        item {
            SettingsToggleRow("Ücretli Yollardan Kaçın", "Köprü ve otoyollar yerine ücretsiz alternatif güzergah çizer", state.navAvoidTolls) {
                repository.toggleNavAvoidTolls()
            }
        }
        item {
            SettingsToggleRow("Feribotlardan Kaçın", "Araba vapuru ve feribot seferlerini rota dışı bırakır", state.navAvoidFerries) {
                repository.toggleNavAvoidFerries()
            }
        }
        item {
            SettingsToggleRow("Otoyollardan Kaçın", "Otoyol yerine ana arter ve çevre yollarını tercih eder", state.navAvoidHighways) {
                repository.toggleNavAvoidHighways()
            }
        }
        item {
            SettingsToggleRow("3D Binalar ve Eğik Kamera", "Sürüş esnasında 30° perspektif açısı ve 3D binalar", state.nav3DTilt) {
                repository.toggleNav3DTilt()
            }
        }
        item {
            SettingsToggleRow("Sesli Yönlendirme", "Dönüş anonsları esnasında medya sesini otomatik kısar", state.navVoiceGuidance) {
                repository.toggleNavVoiceGuidance()
            }
        }
        item {
            SettingsToggleRow("Şerit Rehberi", "Dönüş ve kavşaklardan önce geçilmesi gereken şeridi gösterir", state.navLaneGuidance) {
                repository.toggleNavLaneGuidance()
            }
        }
        item {
            SettingsToggleRow("Hız Sınırı Uyarısı", "Yol hız sınırı aşıldığında görsel ve sesli uyarı verir", state.navSpeedLimitWarning) {
                repository.toggleNavSpeedLimitWarning()
            }
        }
        item {
            SettingsToggleRow("Trafik Işıkları", "Kavşaklardaki ışık durumunu ve bekleme süresini haritada gösterir", state.navTrafficLights) {
                repository.toggleNavTrafficLights()
            }
        }
        item {
            SettingsToggleRow("Otomatik Yakınlaştırma", "Araç hızına göre harita yakınlaştırma seviyesini ayarlar", state.navAutoZoom) {
                repository.toggleNavAutoZoom()
            }
        }
        item {
            SettingsToggleRow("Çevrimdışı Harita Ön Belleği", "İnternet kesintisi ve tüneller için harita karelerini kaydeder", state.navOfflineCache) {
                repository.toggleNavOfflineCache()
            }
        }
    }
}

@Composable
fun SeatsAndMirrorsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsToggleRow("Otomatik Ayna Katlama", "Kilitlendiğinde aynaları otomatik katlar", !state.mirrorsFolded) { repository.toggleMirrors() }
        SettingsToggleRow("Kolay Giriş / Çıkış", "Araç kapanınca sürücü koltuğu geriye çekilir", true) {}
        SettingsToggleRow("Yan Ayna Isıtma", "Arka cam buğu çözme ile birlikte yan aynaları ısıtır", state.ventDefrostRear) { repository.toggleDefrostRear() }
    }
}

@Composable
fun LightsContent(repository: VehicleRepository, state: VehicleState) {
    val palette = LocalSkyPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsRowWithSegmented(
            title = "Far Yükseklik Ayarı",
            desc = "Araç yük durumuna göre far huzme seviyesi (0 - 3)",
            options = listOf("0", "1", "2", "3"),
            selectedIndex = state.headlightHeight,
            onSelect = { repository.setHeadlightHeight(it) }
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Kabin Ambiyans Aydınlatması (64 Renk LED)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = palette.textPrimary)
                val colors = listOf("#00D2FF", "#10B981", "#F59E0B", "#EF4444", "#EC4899", "#8B5CF6", "#FFFFFF")
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    colors.forEach { hex ->
                        val isSel = state.ambientColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(hex)))
                                .border(if (isSel) 3.dp else 1.dp, if (isSel) Color.White else Color.Transparent, CircleShape)
                                .clickable { repository.setAmbientColor(hex) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LocksContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsToggleRow("Yaklaşınca Kilit Aç", "Akıllı anahtar yaklaştığında kapı kilitlerini otomatik açar", true) {}
        SettingsToggleRow("Uzaklaşınca Otomatik Kilitle", "Aracın yanından ayrılınca kapıları otomatik kilitler", true) {}
        SettingsToggleRow("Çocuk Güvenlik Kilidi", "Arka kapı ve cam kontrollerini kilitler", false) {}
    }
}

@Composable
fun BatteryChargingContent(repository: VehicleRepository, state: VehicleState) {
    val palette = LocalSkyPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Visual Battery Pack Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (state.batteryPercent >= 0) "Batarya Doluluğu: %${state.batteryPercent}" else "Batarya Verisi Bekleniyor",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                        Text(
                            text = "Hedef Şarj Limiti: %${state.chargeLimitPercent} (Günlük kullanım için %80 önerilir)",
                            fontSize = 12.sp,
                            color = palette.textSecondary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = palette.accentSoftBg
                    ) {
                        Text(
                            text = "Limit: %${state.chargeLimitPercent}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.accent,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                Slider(
                    value = state.chargeLimitPercent.toFloat(),
                    onValueChange = { repository.setChargeLimit(it.toInt()) },
                    valueRange = 50f..100f,
                    steps = 49,
                    colors = SliderDefaults.colors(
                        thumbColor = palette.accent,
                        activeTrackColor = palette.accent,
                        inactiveTrackColor = palette.surfaceElevated
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { if (state.isCharging) repository.stopCharging() else repository.startCharging() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.isCharging) palette.statusDanger else palette.accent
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (state.isCharging) "Şarjı Bitir" else "Şarjı Başlat",
                            fontWeight = FontWeight.ExtraBold,
                            color = if (state.isCharging) Color.White else Color.Black
                        )
                    }

                    Button(
                        onClick = { repository.toggle220V() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.outlet220V) palette.statusSuccess else palette.surfaceElevated
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (state.outlet220V) "220V V2L Priz: Açık" else "220V V2L Priz: Kapalı",
                            fontWeight = FontWeight.Bold,
                            color = if (state.outlet220V) Color.Black else palette.textPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EnergyAnalyticsContent(repository: VehicleRepository, state: VehicleState) {
    val palette = LocalSkyPalette.current
    val et5Config = repository.getSkywellET5Config()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Bölüm 13: SKYWELL ET5 LR Legend (2023) Teknik Kimlik Kartı
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "${et5Config.brand} ${et5Config.model} (${et5Config.modelYear})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.textPrimary
                )
                Text(
                    text = "Brüt Batarya: ${et5Config.grossBatteryCapacityKwh} kWh • Kullanılabilir: ~${et5Config.effectiveUsableCapacityKwh} kWh (${if (et5Config.isUsableCapacityEstimated) "TAHMİNİ" else "DOĞRULANMIŞ"})",
                    fontSize = 12.sp,
                    color = palette.textSecondary
                )
                Text(
                    text = "Başlangıç Tüketim: ~${et5Config.effectiveBaseConsumptionKwhPer100Km} kWh/100 km (${if (et5Config.isConsumptionEstimated) "TAHMİNİ" else "DOĞRULANMIŞ"}) • AC Şarj: ${et5Config.acChargingPowerKw.toInt()} kW • DC Şarj: ${et5Config.dcChargingStatusText}",
                    fontSize = 11.sp,
                    color = palette.textSecondary
                )
                Text(
                    text = "Soket Durumu: ${et5Config.socketStatusText}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (et5Config.isCcs2SocketVerified && et5Config.isType2SocketVerified) palette.statusSuccess else palette.statusWarning
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            EnergyStatCard(
                title = "ANLIK GÜÇ",
                value = "${state.powerKw.toInt()} kW",
                subtitle = if (state.powerKw < 0) "Rejenerasyon" else "Tüketim",
                accent = if (state.powerKw < 0) palette.statusSuccess else palette.accent,
                modifier = Modifier.weight(1f)
            )
            EnergyStatCard(
                title = "ORTALAMA / 100 KM",
                value = if (state.avgConsumptionKwhPer100Km >= 0f) "${state.avgConsumptionKwhPer100Km} kWh" else "—",
                subtitle = "Canlı Veri Yolu",
                accent = palette.accent,
                modifier = Modifier.weight(1f)
            )
            EnergyStatCard(
                title = "AKILLI MENZİL",
                value = if (state.rangeKm >= 0) "${state.rangeKm} km" else "Veri Yok",
                subtitle = if (state.batteryPercent >= 0) "SoC %${state.batteryPercent}" else "Sensör Bekleniyor",
                accent = if (state.rangeKm >= 0) palette.statusSuccess else palette.statusWarning,
                modifier = Modifier.weight(1f)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(18.dp))
                .padding(18.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (state.avgConsumptionKwhPer100Km >= 0f)
                    "Tüketim Grafiği (ortalama: ${state.avgConsumptionKwhPer100Km} kWh/100km)"
                else
                    "Tüketim Grafiği — gerçek araç verisi bekleniyor (car_service bağlı değil)",
                color = palette.textSecondary,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun EnergyStatCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .border(1.dp, palette.borderSubtle, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(title, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = palette.textSecondary)
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.Black, color = accent)
        Text(subtitle, fontSize = 11.sp, color = palette.textMuted)
    }
}

@Composable
fun ClimateSettingsContent(repository: VehicleRepository, state: VehicleState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SettingsToggleRow("Kilidi Açınca Otomatik İklim", "Soğukta ısıtır, sıcakta kabini serinletir", true) {}
        SettingsToggleRow("Sabah İklim Planlama", "Her sabah 08:00'de aracı 22°C konfor sıcaklığına hazırlar", true) {}
    }
}

@Composable
fun ObdServiceContent(
    repository: VehicleRepository,
    telemetry: ObdTelemetry,
    cellVoltages: List<ObdCellData>,
    adbConnected: Boolean,
    adbStatus: String
) {
    val palette = LocalSkyPalette.current
    val isUsbDebug by repository.adbBridge.isUsbDebuggingEnabled.collectAsState()
    val realTelemetry by repository.telemetryHelper.telemetry.collectAsState()
    val liveCarProps by repository.carPropertyReader.liveProperties.collectAsState()
    val carReachable by repository.carPropertyReader.carServiceReachable.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // ADB & USB Debugging Status Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "USB Hata Ayıklama:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = if (isUsbDebug) "AÇIK" else "KAPALI",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isUsbDebug) palette.statusSuccess else palette.statusDanger
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ADB Soketi (127.0.0.1:5555): $adbStatus",
                    fontSize = 11.sp,
                    color = if (adbConnected) palette.statusSuccess else palette.statusWarning
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { repository.adbBridge.openDeveloperSettings() },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Geliştirici Ayarlarını Aç", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { repository.adbBridge.start() },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceElevated),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("5555 Portunu Yenile", color = palette.textPrimary, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val gateAdbEnabled by repository.developerModeGate.adbEnabled.collectAsState()
        val gatePassword by repository.developerModeGate.developerPassword.collectAsState()
        if (!gateAdbEnabled) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.statusDanger.copy(alpha = 0.14f))
                    .border(1.dp, palette.statusDanger.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    "GELİŞTİRİCİ MODU KAPALI — DEVAM EDİLEMEZ",
                    fontSize = 12.sp, fontWeight = FontWeight.Black, color = palette.statusDanger
                )
                Text(
                    "Araç verisi (vites/hız/SoC) yalnızca ADB üzerinden okunur. Geliştirici modu açılmadan kurulum devam etmez.",
                    fontSize = 11.sp, color = palette.textSecondary
                )
                Text(
                    "Geliştirici Şifresi: ${gatePassword ?: "— (VIN okunamadı, ADB kapalı)"}",
                    fontSize = 13.sp, fontWeight = FontWeight.Bold, color = palette.statusWarning
                )
            }
        } else {
            Text(
                "Geliştirici modu aktif — ADB açık, araç verisi okunabilir.",
                fontSize = 11.sp, color = palette.statusSuccess
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Hardware Diagnostics Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(12.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text(
                "Ünite Gerilimi: ${if (realTelemetry.batteryVoltageMv >= 0) "${realTelemetry.batteryVoltageMv} mV" else "Veri Yok"}",
                color = palette.textSecondary, fontSize = 11.sp
            )
            Text(
                "Ünite Sıcaklık: ${if (realTelemetry.batteryTempC >= 0f) "${realTelemetry.batteryTempC} °C" else "Veri Yok"}",
                color = palette.textSecondary, fontSize = 11.sp
            )
            Text(
                "GPS Hızı: ${if (realTelemetry.hasGpsFix) "${realTelemetry.gpsSpeedKmh} km/sa" else "GPS Yok"}",
                color = palette.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold
            )
            Text(
                "12V Akü: ${if (telemetry.isConnected && telemetry.battery12vVoltage > 0f) "${telemetry.battery12vVoltage} V" else "Bağlantı Yok"}",
                color = palette.textPrimary, fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Cell Stats: Min, Max, Delta
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text("Min: ${if (telemetry.isConnected && telemetry.minCellMv > 0) "${telemetry.minCellMv} mV" else "—"}", color = palette.textPrimary, fontSize = 12.sp)
            Text("Maks: ${if (telemetry.isConnected && telemetry.maxCellMv > 0) "${telemetry.maxCellMv} mV" else "—"}", color = palette.textPrimary, fontSize = 12.sp)
            Text("Delta: ${if (telemetry.isConnected && telemetry.deltaCellMv >= 0) "${telemetry.deltaCellMv} mV" else "—"}", color = palette.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("OBD Durumu: ${if (telemetry.isConnected) "Bağlı" else "Bağlı Değil"}", color = if (telemetry.isConnected) palette.statusSuccess else palette.textSecondary, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (cellVoltages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Bağlantı Yok — OBD adaptörü (vLinker/ELM327) bağlanınca\nhücre gerilimleri burada gerçek zamanlı gösterilir.",
                    color = palette.statusWarning,
                    fontSize = 12.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(10),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(cellVoltages) { cell ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(palette.surfaceElevated)
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${cell.voltageMv}",
                            fontSize = 9.sp,
                            color = palette.accent,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            "Araç Veri Yolu (car_service): ${if (carReachable) "BAĞLI" else "BAĞLI DEĞİL"}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (carReachable) palette.statusSuccess else palette.statusDanger
        )
        if (liveCarProps.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.surface)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                liveCarProps.values.sortedBy { it.idHex }.forEach { prop ->
                    val label = com.example.data.CarPropertyReader.labelFor(prop.idHex)
                    Text(
                        if (label != null)
                            "$label [${prop.idHex}] → float=${prop.floatValues} int=${prop.intValues}"
                        else
                            "ANLAMI BİLİNMİYOR (ham) [${prop.idHex}] → float=${prop.floatValues} int=${prop.intValues}",
                        fontSize = 10.sp,
                        color = if (label != null) palette.accent else palette.statusWarning
                    )
                }
            }
        }
    }
}

@Composable
fun SoftwareUpdateContent(repository: VehicleRepository) {
    val palette = LocalSkyPalette.current
    var launcherError by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(18.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SkyOS Sürümü: 2026.44.2 (Full Kokpit Tasarımı)", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = palette.textPrimary)
                Text(
                    "OTA güncelleme sunucusu bu sürümde bulunmuyor. Yeni APK yayınlandığında GitHub üzerinden manuel güncelleme yapılır.",
                    fontSize = 13.sp,
                    color = palette.textSecondary
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(18.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Ana Ekran (Launcher) Yönetimi", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(
                "SkyOS'u ana ekran yapmak için sistem ayarlarından varsayılan başlatıcıyı seçin. Aracın orijinal ekranına dönmek için aşağıdaki düğmeyi kullanın.",
                color = palette.textSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
            Button(
                onClick = { launcherError = repository.openOriginalLauncher() },
                colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Orijinal Launcher'a Dön", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
            launcherError?.let {
                Text(it, color = palette.statusWarning, fontSize = 12.sp)
            }
        }
    }
}

// Helpers
@Composable
fun SettingsToggleRow(title: String, desc: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val palette = LocalSkyPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(palette.surface)
            .border(1.dp, if (checked) palette.accent.copy(alpha = 0.35f) else palette.borderSubtle, RoundedCornerShape(14.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(desc, color = palette.textSecondary, fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = palette.accent
            )
        )
    }
}

@Composable
fun SettingsRowWithSegmented(
    title: String,
    desc: String,
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    val palette = LocalSkyPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(palette.surface)
            .border(1.dp, palette.borderSubtle, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Text(title, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(desc, color = palette.textSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(palette.surfaceElevated)
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            options.forEachIndexed { i, opt ->
                val isSelected = i == selectedIndex
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (isSelected) palette.accent else Color.Transparent)
                        .clickable { onSelect(i) }
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = opt,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else palette.textSecondary
                    )
                }
            }
        }
    }
}
