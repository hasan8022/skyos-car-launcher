package com.example.ui.components

import android.app.Activity
import android.os.Bundle
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.navigation.GoogleNavigationManager
import com.google.android.libraries.navigation.NavigationView

/**
 * Google Navigation SDK'nın resmî `NavigationView` bileşenini Jetpack Compose içerisine
 * tam yaşam döngüsü (Lifecycle) korumasıyla gömen bileşen.
 *
 * Bellek sızıntısını önlemek için `onCreate`, `onStart`, `onResume`, `onPause`, `onStop`
 * ve `onDestroy` çağrılarını Activity yaşam döngüsüyle birebir eşler.
 */
@Composable
fun GoogleMapNavigationView(
    navigationManager: GoogleNavigationManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val navigationView = remember {
        NavigationView(context).apply {
            onCreate(Bundle())
            isNavigationUiEnabled = false
        }
    }

    DisposableEffect(lifecycleOwner, navigationView) {
        val activity = context as? Activity
        if (activity != null) {
            navigationManager.attachNavigationView(activity, navigationView)
        }

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    try { navigationView.onStart() } catch (_: Exception) {}
                    navigationManager.startRealLocationUpdates()
                }
                Lifecycle.Event.ON_RESUME -> {
                    try { navigationView.onResume() } catch (_: Exception) {}
                }
                Lifecycle.Event.ON_PAUSE -> {
                    try { navigationView.onPause() } catch (_: Exception) {}
                }
                Lifecycle.Event.ON_STOP -> {
                    try { navigationView.onStop() } catch (_: Exception) {}
                }
                Lifecycle.Event.ON_DESTROY -> {
                    try { navigationView.onDestroy() } catch (_: Exception) {}
                }
                else -> {}
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            try {
                navigationView.onPause()
                navigationView.onStop()
                navigationView.onDestroy()
            } catch (_: Exception) {}
        }
    }

    AndroidView(
        factory = { navigationView },
        modifier = modifier.fillMaxSize()
    )
}
