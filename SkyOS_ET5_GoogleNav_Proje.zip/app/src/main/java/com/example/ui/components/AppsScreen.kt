package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveScreen
import com.example.ui.theme.LocalSkyPalette

data class SkyAppItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val targetScreen: ActiveScreen? = null,
    val webUrl: String? = null,
    val subtitle: String? = null,
    val category: String = "Sistem"
)

@Composable
fun AppsScreen(
    onNavigate: (ActiveScreen) -> Unit,
    onOpenWebBrowser: (title: String, url: String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    var selectedCategory by remember { mutableStateOf("Tümü") }

    val allApps = remember {
        listOf(
            // SkyOS System Apps
            SkyAppItem("Harita & Rota", Icons.Default.Navigation, Color(0xFF00D2FF), targetScreen = ActiveScreen.MAP, subtitle = "EV Navigasyon", category = "SkyOS Sistem"),
            SkyAppItem("Müzik & Radyo", Icons.Default.MusicNote, Color(0xFFA855F7), targetScreen = ActiveScreen.MUSIC, subtitle = "Canlı Akış", category = "SkyOS Sistem"),
            SkyAppItem("Telefon", Icons.Default.Phone, Color(0xFF10B981), targetScreen = ActiveScreen.PHONE, subtitle = "Bluetooth Arama", category = "SkyOS Sistem"),
            SkyAppItem("İklimlendirme", Icons.Default.Air, Color(0xFF38BDF8), targetScreen = ActiveScreen.CLIMATE, subtitle = "Çift Bölge Klima", category = "SkyOS Sistem"),
            SkyAppItem("Kamera & Park", Icons.Default.Videocam, Color(0xFFF59E0B), targetScreen = ActiveScreen.CAMERA, subtitle = "360° & ADAS", category = "SkyOS Sistem"),
            SkyAppItem("Sürüş Görünümü", Icons.Default.Speed, Color(0xFFEC4899), targetScreen = ActiveScreen.VISUAL_DRIVE, subtitle = "Dijital Kokpit", category = "SkyOS Sistem"),
            SkyAppItem("Enerji & Şarj", Icons.Default.Bolt, Color(0xFF22C55E), targetScreen = ActiveScreen.ENERGY, subtitle = "Tüketim Analizi", category = "SkyOS Sistem"),
            SkyAppItem("Araç Ayarları", Icons.Default.Settings, Color(0xFF6366F1), targetScreen = ActiveScreen.SETTINGS, subtitle = "Tam Kontrol", category = "SkyOS Sistem"),
            // Music & Video Web Apps
            SkyAppItem("Spotify", Icons.Default.PlayCircle, Color(0xFF1DB954), webUrl = "https://open.spotify.com", subtitle = "Web Player", category = "Medya & Eğlence"),
            SkyAppItem("YouTube", Icons.Default.SmartDisplay, Color(0xFFFF0000), webUrl = "https://m.youtube.com", subtitle = "Video & Müzik", category = "Medya & Eğlence"),
            SkyAppItem("Apple Music", Icons.Default.MusicNote, Color(0xFFFA243C), webUrl = "https://music.apple.com", subtitle = "Web Player", category = "Medya & Eğlence"),
            SkyAppItem("Deezer", Icons.Default.Favorite, Color(0xFFA238FF), webUrl = "https://www.deezer.com", subtitle = "Web Player", category = "Medya & Eğlence"),
            SkyAppItem("SoundCloud", Icons.Default.CloudQueue, Color(0xFFFF5500), webUrl = "https://m.soundcloud.com", subtitle = "Web Player", category = "Medya & Eğlence"),
            // Navigation & EV Charging Portals
            SkyAppItem("Yandex Harita", Icons.Default.Explore, Color(0xFFFF3333), webUrl = "https://yandex.com.tr/harita", subtitle = "Canlı Trafik", category = "Şarj & Harita"),
            SkyAppItem("Eşarj İstasyonları", Icons.Default.EvStation, Color(0xFF00D2FF), webUrl = "https://esarj.com", subtitle = "DC Hızlı Şarj", category = "Şarj & Harita"),
            SkyAppItem("ZES Şarj", Icons.Default.Bolt, Color(0xFFFF9800), webUrl = "https://zes.net", subtitle = "Şarj Haritası", category = "Şarj & Harita")
        )
    }

    val categories = listOf("Tümü", "SkyOS Sistem", "Medya & Eğlence", "Şarj & Harita")
    val filteredApps = remember(selectedCategory) {
        if (selectedCategory == "Tümü") allApps
        else allApps.filter { it.category == selectedCategory }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.backgroundBrush)
            .padding(20.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.accentSoftBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Apps, contentDescription = null, tint = palette.accent)
                }
                Column {
                    Text(
                        text = "SkyOS Uygulama Merkezi",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = "Araç içi yerleşik modüller ve web tabanlı multimedya servisleri",
                        fontSize = 12.sp,
                        color = palette.textSecondary
                    )
                }
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(palette.surfaceElevated)
            ) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = palette.textPrimary)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Category Filter Pills
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                val isSel = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSel) palette.accent else palette.surface)
                        .border(1.dp, if (isSel) palette.accent else palette.borderSubtle, RoundedCornerShape(16.dp))
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = cat,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.Black else palette.textSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Responsive App Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filteredApps) { app ->
                AppGridCard(
                    app = app,
                    onClick = {
                        if (app.webUrl != null) {
                            onOpenWebBrowser(app.title, app.webUrl)
                        } else {
                            app.targetScreen?.let { onNavigate(it) }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun AppGridCard(app: SkyAppItem, onClick: () -> Unit) {
    val palette = LocalSkyPalette.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(98.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .border(1.dp, palette.borderSubtle, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(app.color, app.color.copy(alpha = 0.65f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = app.icon,
                    contentDescription = app.title,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = app.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (app.subtitle != null) {
                Text(
                    text = app.subtitle,
                    fontSize = 10.sp,
                    color = palette.accent,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
