package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveScreen
import com.example.model.VehicleState
import kotlin.math.sin

/**
 * 156821.jpg referans tasarımındaki Alt Kontrol Çubuğu:
 * Sol:  [🚗]  [< 22,0° >]  [🌀 2]  [💺 •••]  [⊞]  [♨️]  [🪟]
 * Orta: "SESLİ ASİSTAN" başlığı + Çok katmanlı pastel ses dalgası + Beyaz yuvarlak 4-renk mikrofon butonu
 * Sağ:  [🎵]  [📹]  [⏲️]  [🔄]  [ESC]  [💺 •••]  [< 🔊 5 >]
 */
@Composable
fun BottomControlBar(
    vehicleState: VehicleState,
    activeScreen: ActiveScreen,
    onScreenSelected: (ActiveScreen) -> Unit,
    onAdjustDriverTemp: (Float) -> Unit,
    onCycleDriverSeatHeat: () -> Unit,
    onCyclePassengerSeatHeat: () -> Unit,
    onToggleDefrostFront: () -> Unit,
    onToggleDefrostRear: () -> Unit,
    onToggleRecirc: () -> Unit,
    onAdjustVolume: (Int) -> Unit,
    onOpenVoiceAssistant: () -> Unit = {},
    isDark: Boolean = false,
    modifier: Modifier = Modifier
) {
    val barBg = if (isDark) Color(0xFF101520) else Color(0xFFF6F7F9)
    val borderCol = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E5EC)
    val iconTint = if (isDark) Color(0xFFD1D5DB) else Color(0xFF3B404A)
    val mutedTint = if (isDark) Color(0xFF64748B) else Color(0xFF9AA0AA)

    val waveTransition = rememberInfiniteTransition(label = "bottomVoiceWave")
    val wavePhase by waveTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(74.dp)
            .background(barBg)
            .border(width = 1.dp, color = borderCol)
    ) {
        // 1. ORTADAKİ YUMUŞAK PASTEL SES DALGASI AURA (156821.jpg'deki pembe/mor/mavi dalga)
        Canvas(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.46f)
                .height(64.dp)
        ) {
            val w = size.width
            val h = size.height
            val baseLine = h * 0.72f

            // Dalga 1: Pastel Pembe / Şeftali
            val pathPink = Path().apply {
                moveTo(0f, h)
                val steps = 60
                for (i in 0..steps) {
                    val x = (w / steps) * i
                    val norm = i.toFloat() / steps
                    val bell = sin(norm * Math.PI).toFloat()
                    val y = baseLine - (sin(norm * 3 * Math.PI + wavePhase).toFloat() * 14f + 16f) * bell * bell
                    lineTo(x, y)
                }
                lineTo(w, h)
                close()
            }
            drawPath(
                path = pathPink,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        Color(0xFFF3B6C8).copy(alpha = if (isDark) 0.25f else 0.45f),
                        Color(0xFFD4B8F0).copy(alpha = if (isDark) 0.28f else 0.50f),
                        Color.Transparent
                    )
                )
            )

            // Dalga 2: Pastel Mavi / Lavanta
            val pathBlue = Path().apply {
                moveTo(0f, h)
                val steps = 60
                for (i in 0..steps) {
                    val x = (w / steps) * i
                    val norm = i.toFloat() / steps
                    val bell = sin(norm * Math.PI).toFloat()
                    val y = baseLine - (sin(norm * 4 * Math.PI - wavePhase * 0.8f).toFloat() * 12f + 14f) * bell * bell
                    lineTo(x, y)
                }
                lineTo(w, h)
                close()
            }
            drawPath(
                path = pathBlue,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        Color(0xFFB5D6F6).copy(alpha = if (isDark) 0.22f else 0.42f),
                        Color(0xFFE8C2D8).copy(alpha = if (isDark) 0.25f else 0.45f),
                        Color.Transparent
                    )
                )
            )
        }

        // 2. ANA İKON VE KONTROL SATIRI
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // SOL GRUP (7 Kontrol)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Araç İkonu
                BottomBarIconButton(
                    icon = Icons.Outlined.DirectionsCar,
                    contentDescription = "Araç Kontrolleri",
                    isSelected = activeScreen == ActiveScreen.SETTINGS,
                    testTag = "bottom_car_btn",
                    isDark = isDark,
                    onClick = { onScreenSelected(ActiveScreen.SETTINGS) }
                )

                // 2. Sürücü Sıcaklığı (< 22,0° >)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onScreenSelected(ActiveScreen.CLIMATE) }
                        .padding(horizontal = 2.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = { onAdjustDriverTemp(-0.5f) },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "Sıcaklık Azalt",
                            tint = mutedTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Text(
                        text = String.format(java.util.Locale.US, "%.1f°", vehicleState.driverTemp).replace(".", ","),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Normal,
                        color = iconTint,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = { onAdjustDriverTemp(+0.5f) },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Sıcaklık Artır",
                            tint = mutedTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // 3. Fan Hızı (🌀 2)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onScreenSelected(ActiveScreen.CLIMATE) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = "Fan",
                        tint = iconTint,
                        modifier = Modifier.size(19.dp)
                    )
                    Text(
                        text = "${vehicleState.fanSpeed}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        color = iconTint
                    )
                }

                // 4. Sol Koltuk Isıtma
                SeatHeatButton(
                    level = vehicleState.driverSeatHeat,
                    testTag = "seat_heat_driver",
                    isDark = isDark,
                    onClick = onCycleDriverSeatHeat
                )

                // 5. Uygulamalar (4 Kare Grid)
                BottomBarIconButton(
                    icon = Icons.Outlined.GridView,
                    contentDescription = "Uygulamalar",
                    isSelected = activeScreen == ActiveScreen.APPS,
                    testTag = "bottom_apps_btn",
                    isDark = isDark,
                    onClick = { onScreenSelected(ActiveScreen.APPS) }
                )

                // 6. Ön Cam Buğu Çözücü
                BottomBarIconButton(
                    icon = Icons.Default.VerticalAlignTop,
                    contentDescription = "Ön Cam Buğu",
                    isSelected = vehicleState.ventDefrostFront,
                    activeColor = Color(0xFF0284C7),
                    testTag = "bottom_defrost_front",
                    isDark = isDark,
                    onClick = onToggleDefrostFront
                )

                // 7. Arka Cam Rezistansı
                BottomBarIconButton(
                    icon = Icons.Default.CropLandscape,
                    contentDescription = "Arka Cam Buğu",
                    isSelected = vehicleState.ventDefrostRear,
                    activeColor = Color(0xFFF59E0B),
                    testTag = "bottom_defrost_rear",
                    isDark = isDark,
                    onClick = onToggleDefrostRear
                )
            }

            // ORTA: SESLİ ASİSTAN BAŞLIĞI VE YUVARLAK 4-RENK MİKROFON BUTONU
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .clickable { onOpenVoiceAssistant() }
            ) {
                Text(
                    text = "SESLİ ASİSTAN",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF6B707B),
                    letterSpacing = 0.6.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF1E293B) else Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    // 4-Renk Mikrofon Çizimi (156821.jpg ile birebir)
                    Canvas(modifier = Modifier.size(22.dp)) {
                        val w = size.width
                        val h = size.height
                        val cx = w / 2f
                        // Mikrofon kapsülü (Mavi/Kırmızı)
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF4285F4), Color(0xFFEA4335))
                            ),
                            topLeft = Offset(cx - 3.5.dp.toPx(), h * 0.10f),
                            size = Size(7.dp.toPx(), h * 0.48f),
                            cornerRadius = CornerRadius(3.5.dp.toPx(), 3.5.dp.toPx())
                        )
                        // Alt yay (Sarı/Mavi)
                        drawArc(
                            color = Color(0xFFFBBC05),
                            startAngle = 0f,
                            sweepAngle = 180f,
                            useCenter = false,
                            topLeft = Offset(cx - 6.5.dp.toPx(), h * 0.25f),
                            size = Size(13.dp.toPx(), h * 0.48f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                        )
                        // Alt ayak (Yeşil)
                        drawLine(
                            color = Color(0xFF34A853),
                            start = Offset(cx, h * 0.73f),
                            end = Offset(cx, h * 0.92f),
                            strokeWidth = 2.dp.toPx()
                        )
                    }
                }
            }

            // SAĞ GRUP (7 Kontrol)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 8. Müzik Notası
                BottomBarIconButton(
                    icon = Icons.Outlined.MusicNote,
                    contentDescription = "Müzik",
                    isSelected = activeScreen == ActiveScreen.MUSIC,
                    testTag = "bottom_music_btn",
                    isDark = isDark,
                    onClick = { onScreenSelected(ActiveScreen.MUSIC) }
                )

                // 9. Kamera
                BottomBarIconButton(
                    icon = Icons.Outlined.Videocam,
                    contentDescription = "Kamera",
                    isSelected = activeScreen == ActiveScreen.CAMERA,
                    testTag = "bottom_camera_btn",
                    isDark = isDark,
                    onClick = { onScreenSelected(ActiveScreen.CAMERA) }
                )

                // 10. Hız Göstergesi / Sürüş Görünümü
                BottomBarIconButton(
                    icon = Icons.Outlined.Speed,
                    contentDescription = "Sürüş Görünümü",
                    isSelected = activeScreen == ActiveScreen.VISUAL_DRIVE,
                    testTag = "bottom_drive_visual_btn",
                    isDark = isDark,
                    onClick = { onScreenSelected(ActiveScreen.VISUAL_DRIVE) }
                )

                // 11. İç Hava Sirkülasyonu
                BottomBarIconButton(
                    icon = Icons.Default.Sync,
                    contentDescription = "İç Hava",
                    isSelected = vehicleState.recircEnabled,
                    testTag = "bottom_recirc_btn",
                    isDark = isDark,
                    onClick = onToggleRecirc
                )

                // 12. ESC Metin Butonu
                Text(
                    text = "ESC",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = iconTint,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onScreenSelected(ActiveScreen.SETTINGS) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )

                // 13. Sağ (Yolcu) Koltuk Isıtma
                SeatHeatButton(
                    level = vehicleState.passengerSeatHeat,
                    testTag = "seat_heat_passenger",
                    isDark = isDark,
                    onClick = onCyclePassengerSeatHeat
                )

                // 14. Ses Seviyesi (< 🔊 5 >)
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onAdjustVolume(vehicleState.volumeLevel - 1) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "Ses Azalt",
                            tint = mutedTint,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Icon(
                        imageVector = if (vehicleState.volumeLevel == 0) Icons.Outlined.VolumeOff else Icons.Outlined.VolumeUp,
                        contentDescription = "Ses Seviyesi",
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${vehicleState.volumeLevel}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        color = iconTint
                    )

                    IconButton(
                        onClick = { onAdjustVolume(vehicleState.volumeLevel + 1) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Ses Artır",
                            tint = mutedTint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BottomBarIconButton(
    icon: ImageVector,
    contentDescription: String,
    isSelected: Boolean,
    testTag: String,
    activeColor: Color = Color(0xFF0284C7),
    isDark: Boolean = false,
    onClick: () -> Unit
) {
    val defaultTint = if (isDark) Color(0xFFD1D5DB) else Color(0xFF3B404A)
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .testTag(testTag)
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) activeColor.copy(alpha = 0.16f) else Color.Transparent)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (isSelected) activeColor else defaultTint,
            modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
fun SeatHeatButton(
    level: Int,
    testTag: String,
    isDark: Boolean = false,
    onClick: () -> Unit
) {
    val defaultTint = if (isDark) Color(0xFFD1D5DB) else Color(0xFF3B404A)
    Column(
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.AirlineSeatReclineNormal,
            contentDescription = "Koltuk Isıtma",
            tint = if (level > 0) Color(0xFFF97316) else defaultTint,
            modifier = Modifier.size(20.dp)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            modifier = Modifier.padding(top = 2.dp)
        ) {
            repeat(3) { index ->
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(
                            if (index < level) Color(0xFFF97316)
                            else if (isDark) Color(0xFF475569) else Color(0xFFC4C8D0)
                        )
                )
            }
        }
    }
}
