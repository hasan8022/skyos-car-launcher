package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VoiceAssistantManager
import com.example.ui.theme.LocalSkyPalette
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VoiceAssistantOrb(
    assistantManager: VoiceAssistantManager,
    isDark: Boolean = true,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    val isListening by assistantManager.isListening.collectAsState()
    val spokenText by assistantManager.lastSpokenText.collectAsState()
    val assistantResponse by assistantManager.assistantResponse.collectAsState()

    var typedCommand by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tümü") }

    val categories = listOf("Tümü", "İklim & Konfor", "Navigasyon", "Medya & Radyo", "Araç & Modlar", "Çoklu Komut")
    val commandSuggestions = remember(selectedCategory) {
        when (selectedCategory) {
            "İklim & Konfor" -> listOf(
                "Klimayı 22 derece yap",
                "Koltuk ısıtmayı aç",
                "Ön cam buğu çöz",
                "Fanı 4 yap",
                "Klimayı kapat"
            )
            "Navigasyon" -> listOf(
                "Eve git",
                "İşe git",
                "En yakın şarj istasyonu",
                "Haritayı aç",
                "Navigasyonu kapat"
            )
            "Medya & Radyo" -> listOf(
                "Kral FM aç",
                "Power Türk aç",
                "TRT FM aç",
                "Sonraki şarkı",
                "Müziği durdur",
                "Spotify aç"
            )
            "Araç & Modlar" -> listOf(
                "Bagajı aç",
                "Cam tavanı aç",
                "Aynaları katla",
                "Evcil hayvan modunu aç",
                "Kamp modunu aç",
                "Menzilim ne kadar?"
            )
            "Çoklu Komut" -> listOf(
                "⚡ Klimayı 22 derece yap, perdeyi aç, eve git",
                "⚡ Koltuk ısıtmayı aç, Kral FM aç, haritayı aç",
                "⚡ Klimayı 21 derece yap, aynaları aç, işe git"
            )
            else -> listOf(
                "Klimayı 22 derece yap",
                "Eve git",
                "Kral FM aç",
                "Menzilim ne kadar?",
                "Koltuk ısıtmayı aç",
                "En yakın şarj istasyonu",
                "⚡ Klimayı 22 derece yap, perdeyi aç, eve git"
            )
        }
    }

    // Pulsing & Rotating Holographic Orb Animations
    val infiniteTransition = rememberInfiniteTransition(label = "orbPulse")
    val scaleAnim by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orbScale"
    )

    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(5200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringRotation"
    )

    val rippleScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(1350, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rippleScale"
    )

    val rippleAlpha by infiniteTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1350, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rippleAlpha"
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    val speechSupported = remember { assistantManager.isRecognitionSupported() }
    val onDeviceSpeech = remember { assistantManager.isOnDeviceRecognition() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.72f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.68f)
                .padding(bottom = 64.dp)
                .clickable(enabled = false) {}
                .clip(RoundedCornerShape(28.dp))
                .background(palette.surface.copy(alpha = 0.97f))
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        listOf(palette.accent, Color(0xFFA855F7), palette.accentSecondary)
                    ),
                    shape = RoundedCornerShape(28.dp)
                )
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Header Row with Status Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(palette.accentSoftBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Asistan",
                            tint = palette.accent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "SkyOS AI Sesli Kokpit Asistanı",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = palette.textPrimary
                        )
                        Text(
                            text = when {
                                isListening -> "Canlı Mikrofon Dinlemede • Türkçe Doğal Dil"
                                onDeviceSpeech -> "Cihaz İçi Tanıma Hazır • Çevrimdışı Destekli"
                                speechSupported -> "Ses Tanıma & Türkçe TTS Aktif"
                                else -> "Yazılı Komut & Türkçe TTS Modu"
                            },
                            fontSize = 11.sp,
                            color = if (isListening) palette.accent else palette.textSecondary
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Status Pill
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isListening) palette.statusSuccess.copy(alpha = 0.18f) else palette.surfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isListening) palette.statusSuccess.copy(alpha = 0.5f) else palette.borderSubtle
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isListening) palette.statusSuccess else palette.accent)
                            )
                            Text(
                                text = if (isListening) "DİNLİYOR" else "HAZIR",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isListening) palette.statusSuccess else palette.textSecondary
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Kapat",
                            tint = palette.textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // 2. Center Row: Holographic Orb + Dual Spectrum Visualizer + Live Dialogue Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(palette.surfaceElevated.copy(alpha = 0.75f))
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(20.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Multi-Layered Holographic Orb
                Box(
                    modifier = Modifier
                        .size(104.dp)
                        .clickable {
                            if (isListening) assistantManager.stopListening()
                            else assistantManager.startListening()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Outward Concentric Ripple
                    Box(
                        modifier = Modifier
                            .size(74.dp)
                            .scale(rippleScale)
                            .clip(CircleShape)
                            .border(
                                width = 2.dp,
                                brush = Brush.radialGradient(
                                    listOf(
                                        palette.accent.copy(alpha = rippleAlpha),
                                        Color(0xFFA855F7).copy(alpha = rippleAlpha * 0.6f),
                                        Color.Transparent
                                    )
                                ),
                                shape = CircleShape
                            )
                    )

                    // Rotating Plasma Halo
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .rotate(ringRotation)
                            .scale(scaleAnim)
                            .clip(CircleShape)
                            .background(
                                Brush.sweepGradient(
                                    listOf(
                                        palette.accent.copy(alpha = 0.75f),
                                        Color(0xFFA855F7).copy(alpha = 0.65f),
                                        Color(0xFFEC4899).copy(alpha = 0.55f),
                                        palette.accent.copy(alpha = 0.75f)
                                    )
                                )
                            )
                    )

                    // Core Holographic Sphere
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color.White, palette.accent, Color(0xFF9333EA))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = "Mikrofon",
                            tint = Color.Black,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Right of Orb: Live Dialogue & Real-time Waveform + Equalizer Bars
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (assistantResponse.isNotEmpty()) assistantResponse
                        else if (isListening) "Dinliyorum, komutunuzu söyleyin…"
                        else "Küreye dokunup konuşun veya hızlı komut seçin",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (spokenText.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = null,
                                tint = palette.accent,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "\"$spokenText\"",
                                fontSize = 13.sp,
                                color = palette.accent,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Combined Sine Harmonics & Equalizer Spectrum Canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                    ) {
                        val width = size.width
                        val height = size.height
                        val midY = height / 2f

                        // 1. Subtle Spectrum Equalizer Bars
                        val barCount = 28
                        val barWidth = (width / (barCount * 1.8f)).coerceAtLeast(3f)
                        val spacing = width / barCount
                        for (i in 0 until barCount) {
                            val norm = i.toFloat() / barCount
                            val env = sin(norm * Math.PI).toFloat()
                            val amp = abs(sin(norm * 5f * Math.PI + wavePhase * 1.2f)).toFloat() * env
                            val barH = (6f + amp * (if (isListening) 28f else 14f)).coerceAtMost(height)
                            drawRoundRect(
                                color = palette.accent.copy(alpha = 0.28f),
                                topLeft = Offset(i * spacing, midY - barH / 2f),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(3f, 3f)
                            )
                        }

                        // 2. Primary Cyan Sine Wave
                        val path1 = Path()
                        path1.moveTo(0f, midY)
                        val points = 64
                        val ampFactor = if (isListening) 15f else 9f
                        for (i in 0..points) {
                            val x = (width / points) * i
                            val normalizedX = (i.toFloat() / points)
                            val envelope = sin(normalizedX * Math.PI).toFloat()
                            val y = midY + sin(normalizedX * 4 * Math.PI + wavePhase).toFloat() * ampFactor * envelope
                            path1.lineTo(x, y)
                        }
                        drawPath(
                            path = path1,
                            brush = Brush.horizontalGradient(
                                listOf(palette.accent, Color(0xFF38BDF8), Color(0xFFA855F7))
                            ),
                            style = Stroke(width = 2.8.dp.toPx())
                        )

                        // 3. Secondary Magenta Harmonics
                        val path2 = Path()
                        path2.moveTo(0f, midY)
                        for (i in 0..points) {
                            val x = (width / points) * i
                            val normalizedX = (i.toFloat() / points)
                            val envelope = sin(normalizedX * Math.PI).toFloat()
                            val y = midY + cos(normalizedX * 6 * Math.PI - wavePhase * 1.3f).toFloat() * (ampFactor * 0.65f) * envelope
                            path2.lineTo(x, y)
                        }
                        drawPath(
                            path = path2,
                            brush = Brush.horizontalGradient(
                                listOf(Color(0xFFEC4899).copy(alpha = 0.75f), Color(0xFF8B5CF6).copy(alpha = 0.75f))
                            ),
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }
                }
            }

            // 3. Natural Language Command Input Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surfaceElevated)
                    .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = palette.accent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                TextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    placeholder = {
                        Text(
                            "Komut yazın veya söyleyin (örn: Klimayı 22 derece yap, eve git)…",
                            color = palette.textSecondary,
                            fontSize = 13.sp
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("voice_command_text_input"),
                    singleLine = true
                )

                IconButton(
                    onClick = {
                        if (typedCommand.isNotBlank()) {
                            assistantManager.processVoiceCommand(typedCommand)
                            typedCommand = ""
                        }
                    },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.accent)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Gönder",
                        tint = Color.Black,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }

            // 4. Category Filter Pills & Quick Voice Command Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) palette.accent else palette.surfaceElevated)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = cat,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.Black else palette.textSecondary
                        )
                    }
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(commandSuggestions) { cmd ->
                    val cleanCmd = cmd.removePrefix("⚡ ").trim()
                    AssistantChip(
                        text = cmd,
                        isDark = isDark,
                        onClick = { assistantManager.processVoiceCommand(cleanCmd) }
                    )
                }
            }
        }
    }
}

@Composable
fun AssistantChip(text: String, isDark: Boolean = true, onClick: () -> Unit) {
    val palette = LocalSkyPalette.current
    val isCompound = text.startsWith("⚡")
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isCompound) palette.accentSoftBg else palette.surfaceElevated)
            .border(
                width = 1.dp,
                color = if (isCompound) palette.accent.copy(alpha = 0.5f) else palette.borderSubtle,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            color = if (isCompound) palette.accent else palette.textPrimary,
            fontWeight = FontWeight.SemiBold
        )
    }
}
