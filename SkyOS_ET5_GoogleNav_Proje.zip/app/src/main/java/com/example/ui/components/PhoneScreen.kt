package com.example.ui.components

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.VehicleRepository
import com.example.ui.theme.LocalSkyPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Contact(val name: String, val phone: String, val isFavorite: Boolean = false)

data class CallLogEntry(
    val name: String?,
    val number: String,
    val type: Int,
    val dateMillis: Long,
    val durationSec: Long
)

private fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

private fun loadDeviceContacts(context: Context): List<Contact> {
    val result = LinkedHashMap<String, Contact>()
    val projection = arrayOf(
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone.STARRED
    )
    context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        projection, null, null,
        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
    )?.use { cursor ->
        val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val starredIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED)
        while (cursor.moveToNext()) {
            val name = if (nameIdx >= 0) cursor.getString(nameIdx) else null
            val number = if (numberIdx >= 0) cursor.getString(numberIdx) else null
            if (name.isNullOrBlank() || number.isNullOrBlank()) continue
            val starred = starredIdx >= 0 && cursor.getInt(starredIdx) == 1
            val key = "${name.trim()}|${number.trim()}"
            val existing = result[key]
            if (existing == null || (starred && !existing.isFavorite)) {
                result[key] = Contact(name.trim(), number.trim(), starred)
            }
        }
    }
    return result.values.toList()
}

private fun loadDeviceCallLog(context: Context): List<CallLogEntry> {
    val result = mutableListOf<CallLogEntry>()
    val projection = arrayOf(
        CallLog.Calls.CACHED_NAME,
        CallLog.Calls.NUMBER,
        CallLog.Calls.TYPE,
        CallLog.Calls.DATE,
        CallLog.Calls.DURATION
    )
    context.contentResolver.query(
        CallLog.Calls.CONTENT_URI,
        projection, null, null,
        CallLog.Calls.DATE + " DESC"
    )?.use { cursor ->
        val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
        val numberIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
        val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)
        val dateIdx = cursor.getColumnIndex(CallLog.Calls.DATE)
        val durationIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
        while (cursor.moveToNext() && result.size < 50) {
            val number = if (numberIdx >= 0) cursor.getString(numberIdx) else null
            if (number.isNullOrBlank()) continue
            result.add(
                CallLogEntry(
                    name = if (nameIdx >= 0) cursor.getString(nameIdx) else null,
                    number = number.trim(),
                    type = if (typeIdx >= 0) cursor.getInt(typeIdx) else CallLog.Calls.OUTGOING_TYPE,
                    dateMillis = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L,
                    durationSec = if (durationIdx >= 0) cursor.getLong(durationIdx) else 0L
                )
            )
        }
    }
    return result
}

private fun formatCallDate(millis: Long): String {
    if (millis <= 0L) return ""
    return SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date(millis))
}

private fun formatCallDuration(seconds: Long): String {
    if (seconds <= 0L) return ""
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "$m dk $s sn" else "$s sn"
}

private fun callTypeLabel(type: Int): String = when (type) {
    CallLog.Calls.INCOMING_TYPE -> "Gelen"
    CallLog.Calls.OUTGOING_TYPE -> "Giden"
    CallLog.Calls.MISSED_TYPE -> "Cevapsız"
    CallLog.Calls.REJECTED_TYPE -> "Reddedilen"
    CallLog.Calls.BLOCKED_TYPE -> "Engellenen"
    else -> "Arama"
}

private fun callTypeColor(type: Int): Color = when (type) {
    CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> Color(0xFFEF4444)
    CallLog.Calls.INCOMING_TYPE -> Color(0xFF10B981)
    else -> Color(0xFF00D2FF)
}

@Composable
fun PhoneScreen(
    repository: VehicleRepository,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current
    val vehicleState by repository.vehicleState.collectAsState()
    val context = LocalContext.current

    var selectedTab by remember { mutableStateOf("Tuşlar") }
    var dialedNumber by remember { mutableStateOf("") }
    var callError by remember { mutableStateOf<String?>(null) }

    var contactsGranted by remember { mutableStateOf(hasPermission(context, Manifest.permission.READ_CONTACTS)) }
    var callLogGranted by remember { mutableStateOf(hasPermission(context, Manifest.permission.READ_CALL_LOG)) }

    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var contactsLoaded by remember { mutableStateOf(false) }
    var callLog by remember { mutableStateOf<List<CallLogEntry>>(emptyList()) }
    var callLogLoaded by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        contactsGranted = hasPermission(context, Manifest.permission.READ_CONTACTS)
        callLogGranted = hasPermission(context, Manifest.permission.READ_CALL_LOG)
    }

    LaunchedEffect(contactsGranted) {
        if (contactsGranted) {
            contactsLoaded = false
            contacts = withContext(Dispatchers.IO) { loadDeviceContacts(context) }
            contactsLoaded = true
        } else {
            contacts = emptyList()
            contactsLoaded = false
        }
    }

    LaunchedEffect(callLogGranted) {
        if (callLogGranted) {
            callLogLoaded = false
            callLog = withContext(Dispatchers.IO) { loadDeviceCallLog(context) }
            callLogLoaded = true
        } else {
            callLog = emptyList()
            callLogLoaded = false
        }
    }

    fun placeCall(number: String) {
        callError = null
        val canCall = hasPermission(context, Manifest.permission.CALL_PHONE)
        val intent = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            callError = "Bu cihazda arama uygulaması bulunamadı."
        } catch (e: SecurityException) {
            callError = "Arama izni verilmedi."
        }
    }

    fun requestPhonePermissions() {
        val needed = mutableListOf<String>()
        if (!contactsGranted) needed.add(Manifest.permission.READ_CONTACTS)
        if (!callLogGranted) needed.add(Manifest.permission.READ_CALL_LOG)
        if (!hasPermission(context, Manifest.permission.CALL_PHONE)) needed.add(Manifest.permission.CALL_PHONE)
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.backgroundBrush)
            .padding(18.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.statusSuccess.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = palette.statusSuccess)
                }
                Column {
                    Text(
                        text = "Telefon & İletişim",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = if (vehicleState.bluetoothConnected) "Bluetooth: ${vehicleState.bluetoothDeviceName} bağlı" else "Bluetooth telefonu bağlı değil",
                        fontSize = 12.sp,
                        color = if (vehicleState.bluetoothConnected) palette.statusSuccess else palette.textSecondary
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Emergency Quick Call Pill (112)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = palette.statusDanger.copy(alpha = 0.18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, palette.statusDanger.copy(alpha = 0.45f)),
                    modifier = Modifier.clickable { placeCall("112") }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Emergency, contentDescription = null, tint = palette.statusDanger, modifier = Modifier.size(15.dp))
                        Text("112 Acil", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = palette.statusDanger)
                    }
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(palette.surfaceElevated)
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = palette.textPrimary)
                }
            }
        }

        callError?.let { error ->
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.statusDanger.copy(alpha = 0.2f))
                    .border(1.dp, palette.statusDanger.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = error, color = palette.textPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { callError = null }, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = palette.textPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Segmented Tabs: [Favoriler] [Son aramalar] [Rehber] [Tuşlar]
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("Tuşlar", "Favoriler", "Son aramalar", "Rehber").forEach { tab ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) palette.accent else Color.Transparent)
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 18.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = tab,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                        color = if (isSelected) Color.Black else palette.textSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tab Contents
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                "Tuşlar" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Dialed Number Display Box
                        Row(
                            modifier = Modifier
                                .fillMaxWidth(0.58f)
                                .height(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(palette.surface)
                                .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (dialedNumber.isEmpty()) "Numara girin…" else dialedNumber,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = if (dialedNumber.isEmpty()) palette.textMuted else palette.textPrimary
                            )

                            if (dialedNumber.isNotEmpty()) {
                                IconButton(onClick = { dialedNumber = dialedNumber.dropLast(1) }) {
                                    Icon(imageVector = Icons.Default.Backspace, contentDescription = "Sil", tint = palette.accent)
                                }
                            }
                        }

                        // Dialpad Grid (3x4)
                        val keypad = listOf(
                            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                            listOf("*" to "", "0" to "+", "#" to "")
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            keypad.forEach { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    row.forEach { (digit, letters) ->
                                        Box(
                                            modifier = Modifier
                                                .size(width = 84.dp, height = 48.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(palette.surface)
                                                .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp))
                                                .clickable { dialedNumber += digit },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(text = digit, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = palette.textPrimary)
                                                if (letters.isNotEmpty()) {
                                                    Text(text = letters, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = palette.accent)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Green Call Action Button
                        Box(
                            modifier = Modifier
                                .size(width = 190.dp, height = 48.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(palette.statusSuccess)
                                .clickable {
                                    if (dialedNumber.isNotEmpty()) {
                                        placeCall(dialedNumber)
                                        dialedNumber = ""
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(imageVector = Icons.Default.Phone, contentDescription = "Ara", tint = Color.Black)
                                Text(text = "Aramayı Başlat", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                            }
                        }
                    }
                }

                "Rehber" -> {
                    when {
                        !contactsGranted -> PermissionNeededPanel(
                            message = "Rehberi göstermek için kişi erişim izni gerekli. İzin verilmezse rehber boş gösterilir; uydurma kişi listesi kullanılmaz.",
                            onRequest = { requestPhonePermissions() }
                        )
                        !contactsLoaded -> LoadingPanel("Rehber okunuyor…")
                        contacts.isEmpty() -> EmptyPanel("Rehberde kişi bulunamadı.")
                        else -> ContactList(contacts = contacts, onCall = { placeCall(it.phone) })
                    }
                }

                "Favoriler" -> {
                    when {
                        !contactsGranted -> PermissionNeededPanel(
                            message = "Favorileri göstermek için kişi erişim izni gerekli.",
                            onRequest = { requestPhonePermissions() }
                        )
                        !contactsLoaded -> LoadingPanel("Rehber okunuyor…")
                        else -> {
                            val favorites = contacts.filter { it.isFavorite }
                            if (favorites.isEmpty()) {
                                EmptyPanel("Favori kişi yok. Telefonunuzun rehberinde yıldızladığınız kişiler burada görünür.")
                            } else {
                                ContactList(contacts = favorites, onCall = { placeCall(it.phone) })
                            }
                        }
                    }
                }

                "Son aramalar" -> {
                    when {
                        !callLogGranted -> PermissionNeededPanel(
                            message = "Son aramaları göstermek için arama kaydı izni gerekli.",
                            onRequest = { requestPhonePermissions() }
                        )
                        !callLogLoaded -> LoadingPanel("Arama kaydı okunuyor…")
                        callLog.isEmpty() -> EmptyPanel("Arama kaydı yok.")
                        else -> CallLogList(entries = callLog, onRedial = { placeCall(it.number) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactList(contacts: List<Contact>, onCall: (Contact) -> Unit) {
    val palette = LocalSkyPalette.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(contacts) { c ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp))
                    .clickable { onCall(c) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(palette.accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = c.name.take(1).uppercase(Locale("tr", "TR")), color = Color.Black, fontWeight = FontWeight.Black)
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(text = c.name, fontWeight = FontWeight.Bold, color = palette.textPrimary, fontSize = 15.sp)
                            if (c.isFavorite) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Favori",
                                    tint = Color(0xFFFBBF24),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Text(text = c.phone, color = palette.textSecondary, fontSize = 12.sp)
                    }
                }

                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Ara",
                    tint = palette.statusSuccess
                )
            }
        }
    }
}

@Composable
private fun CallLogList(entries: List<CallLogEntry>, onRedial: (CallLogEntry) -> Unit) {
    val palette = LocalSkyPalette.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(entries) { entry ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderSubtle, RoundedCornerShape(14.dp))
                    .clickable { onRedial(entry) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(palette.surfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (entry.type) {
                                CallLog.Calls.INCOMING_TYPE -> Icons.Default.CallReceived
                                CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Icons.Default.CallMissed
                                else -> Icons.Default.CallMade
                            },
                            contentDescription = callTypeLabel(entry.type),
                            tint = callTypeColor(entry.type),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = entry.name?.takeIf { it.isNotBlank() } ?: entry.number,
                            fontWeight = FontWeight.Bold,
                            color = palette.textPrimary,
                            fontSize = 15.sp
                        )
                        Text(
                            text = buildString {
                                append(callTypeLabel(entry.type))
                                formatCallDate(entry.dateMillis).takeIf { it.isNotEmpty() }?.let { append(" · $it") }
                                formatCallDuration(entry.durationSec).takeIf { it.isNotEmpty() }?.let { append(" · $it") }
                            },
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Tekrar ara",
                    tint = palette.statusSuccess
                )
            }
        }
    }
}

@Composable
private fun PermissionNeededPanel(message: String, onRequest: () -> Unit) {
    val palette = LocalSkyPalette.current
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = palette.statusWarning,
            modifier = Modifier.size(44.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = message,
            color = palette.textPrimary,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onRequest,
            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("İzin Ver", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LoadingPanel(message: String) {
    val palette = LocalSkyPalette.current
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = palette.accent, modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = message, color = palette.textSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun EmptyPanel(message: String) {
    val palette = LocalSkyPalette.current
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.PersonOff,
            contentDescription = null,
            tint = palette.textMuted,
            modifier = Modifier.size(44.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = message,
            color = palette.textSecondary,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
    }
}
