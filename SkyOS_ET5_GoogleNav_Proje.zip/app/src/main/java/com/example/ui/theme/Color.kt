package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Primary SkyOS Accents & Preset Theme Palettes
val SkyCyan = Color(0xFF00D2FF)
val SkyCyanBright = Color(0xFF38BDF8)
val SkyBlueLight = Color(0xFF0284C7)
val SkyCyanDark = Color(0xFF0369A1)
val SkySportRed = Color(0xFFFF2A2A)
val SkyRegenGreen = Color(0xFF10B981)
val SkyCyberPurple = Color(0xFFA855F7)
val SkyCyberPink = Color(0xFFEC4899)
val SkyLuxuryGold = Color(0xFFF59E0B)
val SkyArcticIce = Color(0xFF67E8F9)

// Dark Automotive Cockpit Colors (Deep Obsidian & Glass Slate)
val DarkBackground = Color(0xFF07090E)
val DarkBackgroundSecondary = Color(0xFF0B0F17)
val DarkSurface = Color(0xFF111622)
val DarkSurfaceElevated = Color(0xFF182030)
val DarkSurfaceHighlight = Color(0xFF222D42)
val DarkGlassSurface = Color(0xD9121824)
val DarkBorder = Color(0xFF253248)
val DarkBorderGlow = Color(0x4D00D2FF)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Light Automotive Cockpit Colors (Crisp Pearl Day Mode)
val LightBackground = Color(0xFFEEF2F6)
val LightBackgroundSecondary = Color(0xFFE2E8F0)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF8FAFC)
val LightSurfaceHighlight = Color(0xFFE2E8F0)
val LightGlassSurface = Color(0xE6FFFFFF)
val LightBorder = Color(0xFFCBD5E1)
val LightBorderGlow = Color(0x4D0284C7)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF64748B)

// Status & Telemetry Colors
val StatusAlertRed = Color(0xFFEF4444)
val StatusWarningAmber = Color(0xFFF59E0B)
val StatusSuccessGreen = Color(0xFF10B981)
val StatusInfoBlue = Color(0xFF3B82F6)

/**
 * 6 Seçilebilir Kokpit Vurgu Teması (Accent Theme Presets)
 */
enum class AccentThemePreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color
) {
    SKY_CYAN(
        id = "sky_cyan",
        title = "Skywell Cyan",
        subtitle = "Orijinal elektrikli mavisi ve buz parıltısı",
        primary = Color(0xFF00D2FF),
        secondary = Color(0xFF0284C7),
        tertiary = Color(0xFF38BDF8)
    ),
    CYBER_NEON(
        id = "cyber_neon",
        title = "Cyberpresa Neon",
        subtitle = "Gece sürüşü için holografik mor ve macenta",
        primary = Color(0xFFA855F7),
        secondary = Color(0xFFEC4899),
        tertiary = Color(0xFF00D2FF)
    ),
    EMERALD_ECO(
        id = "emerald_eco",
        title = "Regen Emerald",
        subtitle = "Verimli sürüş ve doğa dostu zümrüt yeşili",
        primary = Color(0xFF10B981),
        secondary = Color(0xFF059669),
        tertiary = Color(0xFF34D399)
    ),
    CRIMSON_SPORT(
        id = "crimson_sport",
        title = "GT Performans",
        subtitle = "Yüksek dinamizm için yarış kırmızısı ve karbon",
        primary = Color(0xFFFF2A4B),
        secondary = Color(0xFFDC2626),
        tertiary = Color(0xFFF97316)
    ),
    LUXURY_GOLD(
        id = "luxury_gold",
        title = "Executive Lounge",
        subtitle = "Sıcak şampanya altını ve prestijli bronz",
        primary = Color(0xFFF59E0B),
        secondary = Color(0xFFD97706),
        tertiary = Color(0xFFFBBF24)
    ),
    ARCTIC_ICE(
        id = "arctic_ice",
        title = "Arctic Glacier",
        subtitle = "Kuzey ışıkları esintili kristal turkuaz",
        primary = Color(0xFF22D3EE),
        secondary = Color(0xFF06B6D4),
        tertiary = Color(0xFF818CF8)
    );

    companion object {
        fun fromId(id: String): AccentThemePreset =
            entries.find { it.id == id } ?: SKY_CYAN
    }
}
