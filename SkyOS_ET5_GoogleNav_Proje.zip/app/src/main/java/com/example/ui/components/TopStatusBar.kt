package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DriveMode
import com.example.model.Gear
import com.example.model.ThemeMode
import com.example.model.VehicleState
import com.example.ui.theme.LocalSkyPalette

@Composable
fun TopStatusBar(
    vehicleState: VehicleState,
    onGearSelected: (Gear) -> Unit,
    onSosClicked: () -> Unit,
    onBatteryToggleRemaining: () -> Unit,
    showRemainingKm: Boolean,
    isDark: Boolean = true,
    onCycleTheme: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val palette = LocalSkyPalette.current

    val infiniteTransition = rememberInfiniteTransition(label = "sportPulse")
    val sportGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sportAlpha"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(palette.topBarBrush)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Glass Gear Selector Capsule (P R N D S) + Drive Mode Pill + Temps
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Gear Capsule
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.surfaceElevated)
                        .border(1.dp, palette.borderSubtle, RoundedCornerShape(12.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val gears = listOf(Gear.P, Gear.R, Gear.N, Gear.D, Gear.S)
                    gears.forEach { gear ->
                        val isSelected = vehicleState.gear == gear
                        val isSport = gear == Gear.S

                        val activeBg = when {
                            !isSelected -> Color.Transparent
                            isSport -> Color(0xFFFF2A4B).copy(alpha = 0.25f)
                            gear == Gear.R -> Color(0xFFF59E0B).copy(alpha = 0.25f)
                            else -> palette.accent.copy(alpha = 0.22f)
                        }

                        val gearColor = when {
                            isSelected && isSport -> Color(0xFFFF2A4B)
                            isSelected && gear == Gear.R -> Color(0xFFF59E0B)
                            isSelected -> palette.accent
                            else -> palette.textMuted
                        }

                        Box(
                            modifier = Modifier
                                .testTag("gear_button_${gear.name}")
                                .clip(RoundedCornerShape(8.dp))
                                .background(activeBg)
                                .clickable { onGearSelected(gear) }
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = gear.name,
                                fontSize = 16.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                color = gearColor.copy(alpha = if (isSelected && isSport) sportGlowAlpha else 1f)
                            )
                        }
                    }
                }

                // Drive Mode Badge
                val modeColor = when (vehicleState.driveMode) {
                    DriveMode.ECO -> Color(0xFF10B981)
                    DriveMode.SPORT -> Color(0xFFFF2A4B)
                    DriveMode.WINTER -> Color(0xFF38BDF8)
                    DriveMode.NORMAL -> palette.accent
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(modeColor.copy(alpha = 0.15f))
                        .border(1.dp, modeColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = when (vehicleState.driveMode) {
                            DriveMode.NORMAL -> "KONFOR"
                            DriveMode.ECO -> "EKO"
                            DriveMode.SPORT -> "SPOR"
                            DriveMode.WINTER -> "KIŞ"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = modeColor
                    )
                }

                // Temperatures Capsule
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.surfaceElevated.copy(alpha = 0.7f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Thermostat,
                        contentDescription = null,
                        tint = palette.accent,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Dış ${vehicleState.outsideTempC?.let { "$it°" } ?: "—"}  •  İç ${vehicleState.insideTempC?.let { "$it°" } ?: "—"}",
                        fontSize = 12.sp,
                        color = palette.textSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Right: Connectivity Icons, Battery Capsule, Theme Switcher, SOS
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Connectivity Capsule (Wi-Fi + BT)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.surfaceElevated.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (vehicleState.wifiConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                        contentDescription = "Wi-Fi",
                        tint = if (vehicleState.wifiConnected) palette.accent else palette.textMuted,
                        modifier = Modifier.size(15.dp)
                    )
                    Icon(
                        imageVector = if (vehicleState.bluetoothConnected) Icons.Default.Bluetooth else Icons.Default.BluetoothDisabled,
                        contentDescription = "Bluetooth",
                        tint = if (vehicleState.bluetoothConnected) palette.accent else palette.textMuted,
                        modifier = Modifier.size(15.dp)
                    )
                }

                // Battery % & Range Interactive Capsule
                val batColor = when {
                    vehicleState.batteryPercent < 0 -> palette.statusWarning
                    vehicleState.batteryPercent <= 20 -> palette.statusDanger
                    vehicleState.isCharging -> palette.statusSuccess
                    else -> palette.statusSuccess
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.surfaceElevated)
                        .border(1.dp, batColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                        .clickable { onBatteryToggleRemaining() }
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = when {
                            vehicleState.batteryPercent < 0 -> Icons.Default.BatteryUnknown
                            vehicleState.isCharging -> Icons.Default.BatteryChargingFull
                            vehicleState.batteryPercent > 80 -> Icons.Default.BatteryFull
                            vehicleState.batteryPercent > 50 -> Icons.Default.Battery5Bar
                            else -> Icons.Default.Battery3Bar
                        },
                        contentDescription = "Batarya",
                        tint = batColor,
                        modifier = Modifier.size(17.dp)
                    )

                    Text(
                        text = when {
                            vehicleState.batteryPercent < 0 -> "Veri Yok"
                            showRemainingKm && vehicleState.rangeKm >= 0 -> "${vehicleState.rangeKm} km"
                            vehicleState.rangeKm >= 0 -> "%${vehicleState.batteryPercent} • ${vehicleState.rangeKm} km"
                            else -> "%${vehicleState.batteryPercent}"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (vehicleState.batteryPercent < 0) palette.statusWarning else palette.textPrimary
                    )
                }

                // Theme Switcher Button (Siyah / Beyaz / Oto)
                Row(
                    modifier = Modifier
                        .testTag("theme_switcher_button")
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.surfaceElevated)
                        .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                        .clickable { onCycleTheme() }
                        .padding(horizontal = 9.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = when (vehicleState.themeMode) {
                            ThemeMode.DARK -> Icons.Default.DarkMode
                            ThemeMode.LIGHT -> Icons.Default.LightMode
                            ThemeMode.AUTO -> Icons.Default.BrightnessAuto
                        },
                        contentDescription = "Tema Değiştir",
                        tint = when (vehicleState.themeMode) {
                            ThemeMode.DARK -> palette.accent
                            ThemeMode.LIGHT -> Color(0xFFF59E0B)
                            ThemeMode.AUTO -> Color(0xFF10B981)
                        },
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = when (vehicleState.themeMode) {
                            ThemeMode.DARK -> "Gece"
                            ThemeMode.LIGHT -> "Gündüz"
                            ThemeMode.AUTO -> "Oto"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                }

                // SOS Emergency Pill
                Box(
                    modifier = Modifier
                        .testTag("sos_button")
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFFEF4444), Color(0xFFB91C1C))
                            )
                        )
                        .clickable { onSosClicked() }
                        .padding(horizontal = 11.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Emergency,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "SOS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Subtle glowing bottom divider line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            palette.accent.copy(alpha = 0.45f),
                            palette.border,
                            palette.accent.copy(alpha = 0.45f),
                            Color.Transparent
                        )
                    )
                )
        )
    }
}
