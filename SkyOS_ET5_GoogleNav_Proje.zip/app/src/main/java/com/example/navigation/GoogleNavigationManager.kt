package com.example.navigation

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import com.example.osmand.ev.ChargingWaypoint
import com.example.osmand.ev.EVRouteEnergyEstimate
import com.example.osmand.ev.GeoPoint
import com.example.osmand.ev.PlugType
import com.example.osmand.ev.SkywellET5Config
import com.example.osmand.ev.SkywellET5EnergyEngine
import com.example.osmand.routing.OsrmLiveRoutingService
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.libraries.navigation.DisplayOptions
import com.google.android.libraries.navigation.ForceNightMode
import com.google.android.libraries.navigation.ListenableResultFuture
import com.google.android.libraries.navigation.NavigationApi
import com.google.android.libraries.navigation.NavigationView
import com.google.android.libraries.navigation.Navigator
import com.google.android.libraries.navigation.RoutingOptions
import com.google.android.libraries.navigation.SpeedAlertOptions
import com.google.android.libraries.navigation.Waypoint
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

data class PlaceSuggestionItem(
    val placeId: String?,
    val title: String,
    val subtitle: String,
    val latLng: LatLng? = null
)

/**
 * BÖLÜM 14: "GİT" Komutu Sonrası Açılan Zorunlu Adres Onay Modeli.
 * Kullanıcı "EVET, ROTAYI OLUŞTUR" demeden rota kesinleştirilmez ve navigasyon başlatılmaz.
 */
data class PendingAddressConfirmation(
    val title: String,
    val openAddress: String,
    val placeId: String?,
    val targetLatLng: LatLng,
    val originLatLng: LatLng,
    val roadDistanceMeters: Double,
    val roadDurationSeconds: Long,
    val previewRoutePoints: List<LatLng>,
    val isRealRoadGeometry: Boolean,
    val energyPreview: EVRouteEnergyEstimate
)

/**
 * BÖLÜM 16: Android 9 (API 28) ve Android 12 (API 31) Tablet Uyumluluk Durumu.
 */
data class AndroidTabletCompatibilityState(
    val sdkInt: Int = Build.VERSION.SDK_INT,
    val releaseName: String = Build.VERSION.RELEASE ?: "Bilinmiyor",
    val isFineLocationGranted: Boolean = false,
    val isCoarseLocationGranted: Boolean = false,
    val isAndroid12ApproximateOnly: Boolean = false,
    val isNavSdkSupportedOnThisApi: Boolean = Build.VERSION.SDK_INT >= 24
)

data class GoogleNavUiState(
    val hasLocationPermission: Boolean = false,
    val isPreciseLocationGranted: Boolean = false,
    val isAndroid12ApproximateOnlyWarning: Boolean = false,
    val isGpsEnabled: Boolean = false,
    val isNetworkAvailable: Boolean = true,
    val isWaitingForFirstLocation: Boolean = true,
    val currentLocation: LatLng? = null,
    val currentSpeedKmh: Int = 0,
    val currentBearing: Float = 0f,
    val isSdkInitialized: Boolean = false,
    val sdkErrorMessage: String? = null,
    // Bölüm 14: Onay bekleyen hedef (Kullanıcı "GİT" dediğinde önce burası dolar)
    val isVerifyingAddress: Boolean = false,
    val pendingConfirmation: PendingAddressConfirmation? = null,
    // Onaylanmış ("EVET, ROTAYI OLUŞTUR" denmiş) hedef ve rota
    val isAddressConfirmed: Boolean = false,
    val destinationTitle: String? = null,
    val destinationOpenAddress: String? = null,
    val destinationLatLng: LatLng? = null,
    val isCalculatingRoute: Boolean = false,
    val isRouteReady: Boolean = false,
    val isGuidanceActive: Boolean = false,
    val hasArrived: Boolean = false,
    val remainingDistanceMeters: Int? = null,
    val remainingTimeSeconds: Long? = null,
    // Bölüm 15: Skywell ET5 LR Legend (2023) Enerji Hesaplama Çıktısı
    val routeEnergyEstimate: EVRouteEnergyEstimate? = null,
    val liveRouteChargingStations: List<ChargingWaypoint> = emptyList(),
    val isSearchingChargers: Boolean = false,
    val selectedChargerStop: ChargingWaypoint? = null,
    val isAudioMuted: Boolean = false,
    val mapType: Int = GoogleMap.MAP_TYPE_NORMAL,
    val nightModeSetting: Int = 0,
    val statusBannerMessage: String? = null,
    val compatibility: AndroidTabletCompatibilityState = AndroidTabletCompatibilityState()
)

class GoogleNavigationManager(private val context: Context) {

    private val TAG = "GoogleNavManager"
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    private val osrmRoutingService = OsrmLiveRoutingService()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private var placesClient: PlacesClient? = null
    private var navigator: Navigator? = null
    private var googleMap: GoogleMap? = null
    private var navigationViewRef: NavigationView? = null
    private var destinationMarker: Marker? = null
    private var chargerMarker: Marker? = null
    private var previewPolyline: Polyline? = null
    private var pendingRouteFuture: ListenableResultFuture<Navigator.RouteStatus>? = null

    private var hasCenteredOnInitialLocation = false

    // Güncel araç ve batarya durumunu enerji motoruna iletmek için sağlayıcılar
    var vehicleConfigProvider: () -> SkywellET5Config = { SkywellET5Config() }
    var verifiedSocProvider: () -> Int? = { null }
    var manualSocProvider: () -> Int? = { null }
    var outsideTempProvider: () -> Int? = { null }
    var climateStateProvider: () -> Pair<Boolean, Float> = { false to 22.0f }

    private val _uiState = MutableStateFlow(GoogleNavUiState())
    val uiState: StateFlow<GoogleNavUiState> = _uiState.asStateFlow()

    private val _placeSuggestions = MutableStateFlow<List<PlaceSuggestionItem>>(emptyList())
    val placeSuggestions: StateFlow<List<PlaceSuggestionItem>> = _placeSuggestions.asStateFlow()

    private val arrivalListener = Navigator.ArrivalListener { _ ->
        _uiState.value = _uiState.value.copy(
            hasArrived = true,
            isGuidanceActive = false,
            statusBannerMessage = "Hedefe ulaştınız."
        )
        navigator?.stopGuidance()
        navigationViewRef?.isNavigationUiEnabled = false
    }

    private val routeChangedListener = Navigator.RouteChangedListener {
        refreshTimeAndDistance()
    }

    private val timeAndDistanceListener = Navigator.RemainingTimeOrDistanceChangedListener { _, _ ->
        refreshTimeAndDistance()
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc: Location = result.lastLocation ?: return
            val latLng = LatLng(loc.latitude, loc.longitude)
            val speedKmh = if (loc.hasSpeed()) (loc.speed * 3.6f).toInt().coerceAtLeast(0) else 0
            val bearing = if (loc.hasBearing()) loc.bearing else 0f

            _uiState.value = _uiState.value.copy(
                isWaitingForFirstLocation = false,
                currentLocation = latLng,
                currentSpeedKmh = speedKmh,
                currentBearing = bearing
            )

            // İlk gerçek GPS konumu alındığında haritayı otomatik olarak kullanıcının bulunduğu yere odakla
            if (!hasCenteredOnInitialLocation && googleMap != null) {
                hasCenteredOnInitialLocation = true
                googleMap?.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f))
            }
        }
    }

    init {
        initPlacesSdkIfConfigured()
        refreshSystemStatus()
    }

    private fun initPlacesSdkIfConfigured() {
        val apiKey = BuildConfig.MAPS_API_KEY
        if (apiKey.isNotBlank() && !apiKey.startsWith("YOUR_")) {
            try {
                if (!Places.isInitialized()) {
                    Places.initialize(context.applicationContext, apiKey, Locale("tr", "TR"))
                }
                placesClient = Places.createClient(context)
            } catch (e: Exception) {
                Log.w(TAG, "Places SDK başlatılamadı: ${e.message}")
            }
        }
    }

    /**
     * İzin (Android 9 ve Android 12 tam/yaklaşık konum ayrımları dahil), GPS ve İnternet durumunu denetler.
     */
    fun refreshSystemStatus() {
        val fineGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasPerm = fineGranted || coarseGranted
        val isAndroid12ApproxOnly = Build.VERSION.SDK_INT >= 31 && coarseGranted && !fineGranted

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val gpsEnabled = try {
            if (Build.VERSION.SDK_INT >= 28) {
                lm?.isLocationEnabled == true
            } else {
                lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true ||
                    lm?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
            }
        } catch (_: Exception) {
            false
        }

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val netAvailable = try {
            val net = cm?.activeNetwork
            val caps = if (net != null) cm.getNetworkCapabilities(net) else null
            caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } catch (_: Exception) {
            true
        }

        val apiKey = BuildConfig.MAPS_API_KEY
        val keyMissing = apiKey.isBlank() || apiKey.startsWith("YOUR_")

        val errorMsg = when {
            keyMissing -> "MAPS_API_KEY tanımlanmamış. Lütfen local.properties dosyasına Google Maps & Navigation SDK API anahtarınızı ekleyin."
            !hasPerm -> "Konum izni verilmedi. Haritanın bulunduğunuz yeri göstermesi için konum izni gereklidir."
            isAndroid12ApproxOnly -> "Android 12 Yaklaşık Konum algılandı: Araç navigasyonu için 'Tam Konum' (ACCESS_FINE_LOCATION) izni vermeniz gerekir."
            !gpsEnabled -> "GPS kapalı. Bulunduğunuz konumun alınabilmesi için cihazın konum servislerini açın."
            !netAvailable -> "İnternet bağlantısı yok. Canlı harita, adres doğrulama ve rota hesaplama için internet bağlantısı gereklidir."
            else -> null
        }

        _uiState.value = _uiState.value.copy(
            hasLocationPermission = hasPerm,
            isPreciseLocationGranted = fineGranted,
            isAndroid12ApproximateOnlyWarning = isAndroid12ApproxOnly,
            isGpsEnabled = gpsEnabled,
            isNetworkAvailable = netAvailable,
            sdkErrorMessage = if (keyMissing) errorMsg else _uiState.value.sdkErrorMessage,
            statusBannerMessage = if (!keyMissing) errorMsg else null,
            compatibility = AndroidTabletCompatibilityState(
                sdkInt = Build.VERSION.SDK_INT,
                releaseName = Build.VERSION.RELEASE ?: "",
                isFineLocationGranted = fineGranted,
                isCoarseLocationGranted = coarseGranted,
                isAndroid12ApproximateOnly = isAndroid12ApproxOnly,
                isNavSdkSupportedOnThisApi = Build.VERSION.SDK_INT >= 24
            )
        )

        if (hasPerm && gpsEnabled) {
            startRealLocationUpdates()
        }
    }

    @SuppressLint("MissingPermission")
    fun startRealLocationUpdates() {
        refreshSystemStatus()
        if (!_uiState.value.hasLocationPermission) return

        try {
            fusedLocationClient.lastLocation.addOnSuccessListener { loc: Location? ->
                if (loc != null) {
                    val latLng = LatLng(loc.latitude, loc.longitude)
                    _uiState.value = _uiState.value.copy(
                        isWaitingForFirstLocation = false,
                        currentLocation = latLng
                    )
                    if (!hasCenteredOnInitialLocation && googleMap != null) {
                        hasCenteredOnInitialLocation = true
                        googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f))
                    }
                }
            }

            val priority = if (_uiState.value.isPreciseLocationGranted) {
                Priority.PRIORITY_HIGH_ACCURACY
            } else {
                Priority.PRIORITY_BALANCED_POWER_ACCURACY
            }

            val request = LocationRequest.Builder(priority, 1500L)
                .setMinUpdateIntervalMillis(800L)
                .setWaitForAccurateLocation(false)
                .build()

            fusedLocationClient.requestLocationUpdates(
                request,
                locationCallback,
                Looper.getMainLooper()
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "Konum izni hatası: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "GPS başlatma hatası: ${e.message}")
        }
    }

    fun stopLocationUpdates() {
        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    fun attachNavigationView(activity: Activity, navView: NavigationView) {
        this.navigationViewRef = navView
        refreshSystemStatus()

        navView.getMapAsync { map ->
            this.googleMap = map
            map.mapType = _uiState.value.mapType
            map.isTrafficEnabled = true
            map.isBuildingsEnabled = true
            map.uiSettings.apply {
                isCompassEnabled = true
                isZoomGesturesEnabled = true
                isScrollGesturesEnabled = true
                isRotateGesturesEnabled = true
                isTiltGesturesEnabled = true
                isMyLocationButtonEnabled = false
                isZoomControlsEnabled = false
            }

            if (_uiState.value.hasLocationPermission) {
                try {
                    map.isMyLocationEnabled = true
                } catch (_: SecurityException) {}
            }

            _uiState.value.currentLocation?.let { realLatLng ->
                if (!hasCenteredOnInitialLocation) {
                    hasCenteredOnInitialLocation = true
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(realLatLng, 16.0f))
                }
            }

            // Haritaya dokunarak veya uzun basarak gerçek hedef seçme -> Önce Adres Onay Ekranı açılır!
            map.setOnMapClickListener { tappedLatLng ->
                proposeDestinationOnMap(tappedLatLng)
            }
            map.setOnMapLongClickListener { tappedLatLng ->
                proposeDestinationOnMap(tappedLatLng)
            }
        }

        initializeNavigatorSdk(activity)
    }

    fun initializeNavigatorSdk(activity: Activity) {
        if (Build.VERSION.SDK_INT < 24) {
            _uiState.value = _uiState.value.copy(
                isSdkInitialized = false,
                sdkErrorMessage = "Bu Android sürümü (API ${Build.VERSION.SDK_INT}) Google Navigation SDK tarafından desteklenmiyor."
            )
            return
        }

        val apiKey = BuildConfig.MAPS_API_KEY
        if (apiKey.isBlank() || apiKey.startsWith("YOUR_")) {
            _uiState.value = _uiState.value.copy(
                isSdkInitialized = false,
                sdkErrorMessage = "MAPS_API_KEY eksik. Lütfen local.properties içine geçerli Google Maps & Navigation SDK anahtarınızı ekleyin."
            )
            return
        }

        val app: Application = activity.application
        if (!NavigationApi.areTermsAccepted(app)) {
            try {
                NavigationApi.showTermsAndConditionsDialog(
                    activity,
                    "SkyOS Otomotiv",
                    "Google Navigasyon Hizmet Şartları"
                ) { accepted ->
                    if (accepted) {
                        requestNavigatorInstance(activity)
                    } else {
                        _uiState.value = _uiState.value.copy(
                            isSdkInitialized = false,
                            sdkErrorMessage = "Google Navigasyon kullanım şartları kabul edilmedi."
                        )
                    }
                }
            } catch (_: Exception) {
                requestNavigatorInstance(activity)
            }
        } else {
            requestNavigatorInstance(activity)
        }
    }

    private fun requestNavigatorInstance(activity: Activity) {
        try {
            NavigationApi.getNavigator(
                activity,
                object : NavigationApi.NavigatorListener {
                    override fun onNavigatorReady(nav: Navigator) {
                        navigator = nav
                        nav.addArrivalListener(arrivalListener)
                        nav.addRouteChangedListener(routeChangedListener)
                        nav.addRemainingTimeOrDistanceChangedListener(1, 1, timeAndDistanceListener)

                        nav.setAudioGuidance(Navigator.AudioGuidance.VOICE_ALERTS_AND_GUIDANCE)

                        try {
                            val speedAlertOptions = SpeedAlertOptions.Builder()
                                .setSpeedAlertThresholdPercentage(Navigator.SpeedAlertSeverity.MINOR, 5f)
                                .setSpeedAlertThresholdPercentage(Navigator.SpeedAlertSeverity.MAJOR, 10f)
                                .setSeverityUpgradeDurationSeconds(5.0)
                                .build()
                            nav.setSpeedAlertOptions(speedAlertOptions)
                        } catch (_: Exception) {}

                        _uiState.value = _uiState.value.copy(
                            isSdkInitialized = true,
                            sdkErrorMessage = null
                        )
                    }

                    override fun onError(@NavigationApi.ErrorCode errorCode: Int) {
                        val reason = when (errorCode) {
                            NavigationApi.ErrorCode.NOT_AUTHORIZED ->
                                "API anahtarı Navigation SDK için yetkilendirilmemiş (NOT_AUTHORIZED). Google Cloud Console'da Navigation SDK for Android'i etkinleştirin."
                            NavigationApi.ErrorCode.TERMS_NOT_ACCEPTED ->
                                "Google Navigasyon kullanım şartları onaylanmadı (TERMS_NOT_ACCEPTED)."
                            NavigationApi.ErrorCode.NETWORK_ERROR ->
                                "Ağ hatası nedeniyle Google Navigation SDK başlatılamadı (NETWORK_ERROR)."
                            NavigationApi.ErrorCode.LOCATION_PERMISSION_MISSING ->
                                "Konum izni eksik olduğu için Navigation SDK başlatılamadı."
                            else -> "Google Navigation SDK hatası (Kod: $errorCode)."
                        }
                        _uiState.value = _uiState.value.copy(
                            isSdkInitialized = false,
                            sdkErrorMessage = reason
                        )
                    }
                }
            )
        } catch (e: Exception) {
            _uiState.value = _uiState.value.copy(
                isSdkInitialized = false,
                sdkErrorMessage = "Navigation SDK başlatma hatası: ${e.message}"
            )
        }
    }

    /**
     * Kural 11: Kullanıcı hedefi değiştirdiğinde eski rota derhal geçersiz kılınır.
     */
    private fun invalidatePreviousRoute() {
        pendingRouteFuture?.cancel(true)
        navigator?.stopGuidance()
        navigator?.clearDestinations()
        navigationViewRef?.isNavigationUiEnabled = false
        destinationMarker?.remove()
        destinationMarker = null
        chargerMarker?.remove()
        chargerMarker = null
        previewPolyline?.remove()
        previewPolyline = null
    }

    /**
     * Adres araması önerileri (Google Places API + Android Geocoder).
     */
    fun searchAddressPredictions(query: String) {
        if (query.isBlank()) {
            _placeSuggestions.value = emptyList()
            return
        }
        scope.launch {
            val results = mutableListOf<PlaceSuggestionItem>()
            val client = placesClient
            if (client != null) {
                try {
                    results.addAll(fetchPlacesPredictions(client, query))
                } catch (e: Exception) {
                    Log.w(TAG, "Places autocomplete uyarısı: ${e.message}")
                }
            }
            if (results.isEmpty()) {
                results.addAll(geocodeSearch(query))
            }
            _placeSuggestions.value = results
        }
    }

    /**
     * BÖLÜM 14 — Yöntem 1a: Kullanıcı arama kutusuna adres yazıp "GİT" butonuna bastığında
     * adresi doğrular ve Adres Onay Ekranını açar (hemen navigasyon başlatmaz).
     */
    fun proposeDestinationByQuery(query: String) {
        val clean = query.trim()
        if (clean.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                statusBannerMessage = "Lütfen gitmek istediğiniz adresi veya hedefi yazın."
            )
            return
        }
        _placeSuggestions.value = emptyList()
        scope.launch {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = true,
                statusBannerMessage = "Hedef adres doğrulanıyor…"
            )
            // Önce Places API, yoksa Geocoder ile doğrula
            val suggestions = mutableListOf<PlaceSuggestionItem>()
            placesClient?.let { client ->
                try {
                    suggestions.addAll(fetchPlacesPredictions(client, clean))
                } catch (_: Exception) {}
            }
            if (suggestions.isEmpty()) {
                suggestions.addAll(geocodeSearch(clean))
            }

            val best = suggestions.firstOrNull()
            if (best == null) {
                _uiState.value = _uiState.value.copy(
                    isVerifyingAddress = false,
                    statusBannerMessage = "Adres doğrulanamadı: \"$clean\" için gerçek harita verisi bulunamadı. Rota oluşturulmadı."
                )
                return@launch
            }
            proposeDestinationFromSuggestion(best)
        }
    }

    /**
     * BÖLÜM 14 — Yöntem 1b: Kullanıcı öneri listesinden bir adrese veya "GİT" butonuna tıkladığında
     * adresi doğrular ve Adres Onay Ekranını açar.
     */
    fun proposeDestinationFromSuggestion(item: PlaceSuggestionItem) {
        _placeSuggestions.value = emptyList()
        scope.launch {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = true,
                statusBannerMessage = "Seçilen adres ve konum doğrulanıyor…"
            )
            var resolvedLatLng = item.latLng
            var resolvedAddress = item.subtitle.ifBlank { item.title }

            if (resolvedLatLng == null && item.placeId != null && placesClient != null) {
                val pair = fetchPlaceDetails(placesClient!!, item.placeId)
                resolvedLatLng = pair?.first
                if (!pair?.second.isNullOrBlank()) {
                    resolvedAddress = pair!!.second!!
                }
            }

            if (resolvedLatLng == null) {
                val geo = geocodeSearch("${item.title} ${item.subtitle}").firstOrNull()
                resolvedLatLng = geo?.latLng
                if (geo != null && geo.subtitle.isNotBlank()) {
                    resolvedAddress = geo.subtitle
                }
            }

            if (resolvedLatLng == null) {
                _uiState.value = _uiState.value.copy(
                    isVerifyingAddress = false,
                    statusBannerMessage = "Seçilen adresin koordinatları doğrulanamadı. Rota oluşturulmadı."
                )
                return@launch
            }

            prepareAddressConfirmation(
                title = item.title,
                openAddress = resolvedAddress,
                placeId = item.placeId,
                targetLatLng = resolvedLatLng
            )
        }
    }

    /**
     * BÖLÜM 14 — Yöntem 2: Enlem ve Boylam (Lat/Lng) girerek hedef belirleme -> Adres Onay Ekranı açar.
     */
    fun proposeDestinationByCoordinates(lat: Double, lng: Double) {
        if (lat !in -90.0..90.0 || lng !in -180.0..180.0 || (lat == 0.0 && lng == 0.0)) {
            _uiState.value = _uiState.value.copy(
                statusBannerMessage = "Geçersiz koordinat! Enlem -90..90, Boylam -180..180 aralığında gerçek bir nokta olmalıdır."
            )
            return
        }
        val target = LatLng(lat, lng)
        scope.launch {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = true,
                statusBannerMessage = "Koordinat adresi doğrulanıyor…"
            )
            val revAddress = reverseGeocodeTitle(target)
            val coordString = String.format(Locale.US, "%.5f° K, %.5f° D", lat, lng)
            prepareAddressConfirmation(
                title = revAddress?.substringBefore(",") ?: "Koordinat Hedefi",
                openAddress = revAddress?.let { "$it ($coordString)" } ?: "Açık Koordinat: $coordString",
                placeId = null,
                targetLatLng = target
            )
        }
    }

    /**
     * BÖLÜM 14 — Yöntem 3: Haritadan dokunarak hedef seçme -> Adres Onay Ekranı açar.
     */
    fun proposeDestinationOnMap(tappedLatLng: LatLng) {
        scope.launch {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = true,
                statusBannerMessage = "Haritadan seçilen nokta doğrulanıyor…"
            )
            val revAddress = reverseGeocodeTitle(tappedLatLng)
            val coordString = String.format(Locale.US, "%.5f°, %.5f°", tappedLatLng.latitude, tappedLatLng.longitude)
            prepareAddressConfirmation(
                title = revAddress?.substringBefore(",") ?: "Haritadan Seçilen Konum",
                openAddress = revAddress ?: "Harita Konumu ($coordString)",
                placeId = null,
                targetLatLng = tappedLatLng
            )
        }
    }

    /**
     * BÖLÜM 14 (Adım 2..8):
     * - Eski rotayı geçersiz kılar.
     * - Mevcut gerçek GPS konumunu kontrol eder (yoksa hata verir, sahte konum kullanmaz).
     * - Hedef işaretçisini haritada gösterir.
     * - Gerçek yol üzerinden mesafe, tahmini süre ve önizleme rotasını hesaplar.
     * - "Bu adrese gitmek istiyor musunuz?" onay ekranını açar.
     */
    private suspend fun prepareAddressConfirmation(
        title: String,
        openAddress: String,
        placeId: String?,
        targetLatLng: LatLng
    ) {
        refreshSystemStatus()
        invalidatePreviousRoute()

        val origin = _uiState.value.currentLocation
        if (origin == null) {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = false,
                pendingConfirmation = null,
                isAddressConfirmed = false,
                statusBannerMessage = "Mevcut GPS konumunuz henüz doğrulanamadı. Konum olmadan rota oluşturulamaz."
            )
            return
        }

        if (!_uiState.value.isNetworkAvailable) {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = false,
                pendingConfirmation = null,
                isAddressConfirmed = false,
                statusBannerMessage = "İnternet bağlantısı yok. Gerçek yol rotası ve adres doğrulanamıyor."
            )
            return
        }

        // Gerçek karayolu rotası önizlemesini çek (OSRM gerçek yol ağı)
        val liveRoadRoute = osrmRoutingService.fetchLiveDrivingRoute(
            start = GeoPoint(origin.latitude, origin.longitude),
            destination = GeoPoint(targetLatLng.latitude, targetLatLng.longitude)
        )

        if (liveRoadRoute == null || liveRoadRoute.totalDistanceMeters <= 0.0) {
            _uiState.value = _uiState.value.copy(
                isVerifyingAddress = false,
                pendingConfirmation = null,
                isAddressConfirmed = false,
                statusBannerMessage = "Bu adrese gerçek karayolu sürüş rotası hesaplanamadı. Lütfen ulaşılabilir bir yol noktası seçin."
            )
            return
        }

        val roadPts = liveRoadRoute.pathCoordinates.map { LatLng(it.latitude, it.longitude) }

        // Haritada hedef işaretçisini ve gerçek önizleme rotasını göster
        googleMap?.let { map ->
            destinationMarker = map.addMarker(
                MarkerOptions()
                    .position(targetLatLng)
                    .title(title)
                    .snippet(openAddress)
            )
            destinationMarker?.showInfoWindow()

            if (roadPts.size >= 2) {
                previewPolyline = map.addPolyline(
                    PolylineOptions()
                        .addAll(roadPts)
                        .width(12f)
                        .color(android.graphics.Color.parseColor("#2563EB"))
                        .geodesic(true)
                )
            }

            try {
                val bounds = LatLngBounds.Builder()
                    .include(origin)
                    .include(targetLatLng)
                    .build()
                map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 120))
            } catch (_: Exception) {
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(targetLatLng, 14f))
            }
        }

        val climate = climateStateProvider()
        val energyEst = SkywellET5EnergyEngine.calculateRouteEnergy(
            config = vehicleConfigProvider(),
            verifiedVehicleSocPercent = verifiedSocProvider(),
            userManualSocPercent = manualSocProvider(),
            routeDistanceMeters = liveRoadRoute.totalDistanceMeters,
            routeDurationSeconds = liveRoadRoute.totalDurationSeconds,
            elevationGainMeters = null, // Rakım verisi yoksa uydurulmaz
            elevationLossMeters = null,
            realOutsideTempC = outsideTempProvider(),
            isClimateActive = climate.first,
            targetClimateTempC = climate.second
        )

        val confirmation = PendingAddressConfirmation(
            title = title,
            openAddress = openAddress,
            placeId = placeId,
            targetLatLng = targetLatLng,
            originLatLng = origin,
            roadDistanceMeters = liveRoadRoute.totalDistanceMeters,
            roadDurationSeconds = liveRoadRoute.totalDurationSeconds,
            previewRoutePoints = roadPts,
            isRealRoadGeometry = true,
            energyPreview = energyEst
        )

        _uiState.value = _uiState.value.copy(
            isVerifyingAddress = false,
            pendingConfirmation = confirmation,
            isAddressConfirmed = false,
            destinationTitle = null,
            destinationOpenAddress = null,
            destinationLatLng = null,
            isRouteReady = false,
            isGuidanceActive = false,
            statusBannerMessage = null
        )
    }

    /**
     * Kullanıcı başlangıç batarya yüzdesi girdiğinde veya ayar değiştirdiğinde enerji hesabını yeniler.
     */
    fun recalculateEnergyForCurrentState() {
        val cur = _uiState.value
        val climate = climateStateProvider()

        cur.pendingConfirmation?.let { pending ->
            val updatedEnergy = SkywellET5EnergyEngine.calculateRouteEnergy(
                config = vehicleConfigProvider(),
                verifiedVehicleSocPercent = verifiedSocProvider(),
                userManualSocPercent = manualSocProvider(),
                routeDistanceMeters = pending.roadDistanceMeters,
                routeDurationSeconds = pending.roadDurationSeconds,
                realOutsideTempC = outsideTempProvider(),
                isClimateActive = climate.first,
                targetClimateTempC = climate.second
            )
            _uiState.value = _uiState.value.copy(
                pendingConfirmation = pending.copy(energyPreview = updatedEnergy)
            )
        }

        if (cur.isAddressConfirmed && cur.remainingDistanceMeters != null && cur.remainingTimeSeconds != null) {
            val updatedEnergy = SkywellET5EnergyEngine.calculateRouteEnergy(
                config = vehicleConfigProvider(),
                verifiedVehicleSocPercent = verifiedSocProvider(),
                userManualSocPercent = manualSocProvider(),
                routeDistanceMeters = cur.remainingDistanceMeters.toDouble(),
                routeDurationSeconds = cur.remainingTimeSeconds,
                realOutsideTempC = outsideTempProvider(),
                isClimateActive = climate.first,
                targetClimateTempC = climate.second
            )
            _uiState.value = _uiState.value.copy(routeEnergyEstimate = updatedEnergy)
        }
    }

    /**
     * BÖLÜM 14 (Adım 7 & 9): Kullanıcı "EVET, ROTAYI OLUŞTUR" butonuna bastığında çağrılır.
     * Gerçek sürüş rotasını oluşturur ve kullanıcıya gösterir (Navigasyonu henüz otomatik başlatmaz;
     * kullanıcı Adım 10'da "Navigasyonu Başlat" dediğinde Google Navigation SDK devreye girer).
     */
    fun confirmAddressAndCreateRoute(
        avoidTolls: Boolean = false,
        avoidHighways: Boolean = false,
        avoidFerries: Boolean = true
    ) {
        val pending = _uiState.value.pendingConfirmation ?: return
        val climate = climateStateProvider()
        val energyEst = SkywellET5EnergyEngine.calculateRouteEnergy(
            config = vehicleConfigProvider(),
            verifiedVehicleSocPercent = verifiedSocProvider(),
            userManualSocPercent = manualSocProvider(),
            routeDistanceMeters = pending.roadDistanceMeters,
            routeDurationSeconds = pending.roadDurationSeconds,
            realOutsideTempC = outsideTempProvider(),
            isClimateActive = climate.first,
            targetClimateTempC = climate.second
        )

        _uiState.value = _uiState.value.copy(
            pendingConfirmation = null,
            isAddressConfirmed = true,
            destinationTitle = pending.title,
            destinationOpenAddress = pending.openAddress,
            destinationLatLng = pending.targetLatLng,
            isCalculatingRoute = true,
            isRouteReady = true,
            remainingDistanceMeters = pending.roadDistanceMeters.toInt(),
            remainingTimeSeconds = pending.roadDurationSeconds,
            routeEnergyEstimate = energyEst,
            liveRouteChargingStations = emptyList(),
            selectedChargerStop = null,
            statusBannerMessage = null
        )

        // Şarj ihtiyacı varsa rota çevresindeki gerçek şarj istasyonlarını Overpass API'den ara
        if (energyEst.requiresChargingStop) {
            searchRealChargingStationsAlongRoute(pending.originLatLng, pending.targetLatLng)
        }

        // Google Navigation SDK Navigator hazırsa resmi hedefi de bağla
        val nav = navigator
        if (nav != null) {
            try {
                val waypoint: Waypoint = if (!pending.placeId.isNullOrBlank()) {
                    Waypoint.builder()
                        .setPlaceIdString(pending.placeId)
                        .setTitle(pending.title)
                        .build()
                } else {
                    Waypoint.builder()
                        .setLatLng(pending.targetLatLng.latitude, pending.targetLatLng.longitude)
                        .setTitle(pending.title)
                        .build()
                }

                val routingOptions = RoutingOptions()
                    .travelMode(RoutingOptions.TravelMode.DRIVING)
                    .avoidTolls(avoidTolls)
                    .avoidHighways(avoidHighways)
                    .avoidFerries(avoidFerries)
                    .alternateRoutesStrategy(RoutingOptions.AlternateRoutesStrategy.SHOW_ALL)

                val displayOptions = DisplayOptions()
                    .showStopSigns(true)
                    .showTrafficLights(true)

                pendingRouteFuture?.cancel(true)
                val future = nav.setDestination(waypoint, routingOptions, displayOptions)
                pendingRouteFuture = future

                future.setOnResultListener { code ->
                    when (code) {
                        Navigator.RouteStatus.OK -> {
                            previewPolyline?.remove()
                            previewPolyline = null
                            refreshTimeAndDistance()
                            _uiState.value = _uiState.value.copy(
                                isCalculatingRoute = false,
                                isRouteReady = true
                            )
                        }
                        Navigator.RouteStatus.NO_ROUTE_FOUND -> {
                            _uiState.value = _uiState.value.copy(
                                isCalculatingRoute = false,
                                statusBannerMessage = "Google Navigation SDK bu hedefe uygun sürüş rotası bulamadı."
                            )
                        }
                        Navigator.RouteStatus.NETWORK_ERROR -> {
                            _uiState.value = _uiState.value.copy(
                                isCalculatingRoute = false,
                                statusBannerMessage = "Google Navigation SDK ağ hatası bildirdi."
                            )
                        }
                        else -> {
                            _uiState.value = _uiState.value.copy(
                                isCalculatingRoute = false
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isCalculatingRoute = false,
                    statusBannerMessage = "Navigator rota hatası: ${e.message}"
                )
            }
        } else {
            _uiState.value = _uiState.value.copy(
                isCalculatingRoute = false
            )
        }
    }

    /**
     * BÖLÜM 14 (Adım 7): Kullanıcı "VAZGEÇ" butonuna bastığında çağrılır.
     * Onay bekleyen hedefi ve harita önizlemesini iptal eder.
     */
    fun cancelAddressConfirmation() {
        invalidatePreviousRoute()
        _uiState.value = _uiState.value.copy(
            isVerifyingAddress = false,
            pendingConfirmation = null,
            isAddressConfirmed = false,
            destinationTitle = null,
            destinationOpenAddress = null,
            destinationLatLng = null,
            isCalculatingRoute = false,
            isRouteReady = false,
            isGuidanceActive = false,
            routeEnergyEstimate = null,
            statusBannerMessage = null
        )
        recenterToMyLocation()
    }

    /**
     * BÖLÜM 15: Rota üzerinde şarj ihtiyacı doğduğunda gerçek şarj istasyonlarını Overpass API'den çeker.
     * Sabit veya uydurma istasyon listesi ASLA kullanılmaz.
     */
    fun searchRealChargingStationsAlongRoute(origin: LatLng, destination: LatLng) {
        scope.launch {
            _uiState.value = _uiState.value.copy(isSearchingChargers = true)
            val midLat = (origin.latitude + destination.latitude) / 2.0
            val midLng = (origin.longitude + destination.longitude) / 2.0
            val stations = fetchLiveChargingStations(midLat, midLng, 35000)
            _uiState.value = _uiState.value.copy(
                isSearchingChargers = false,
                liveRouteChargingStations = stations
            )
        }
    }

    /**
     * Kullanıcının seçtiği gerçek şarj istasyonunu rotaya ara durak (Waypoint) olarak ekler.
     */
    fun addChargingStationWaypointToRoute(station: ChargingWaypoint) {
        val destLatLng = _uiState.value.destinationLatLng ?: return
        val destTitle = _uiState.value.destinationTitle ?: "Hedef"

        chargerMarker?.remove()
        googleMap?.let { map ->
            chargerMarker = map.addMarker(
                MarkerOptions()
                    .position(LatLng(station.location.latitude, station.location.longitude))
                    .title("⚡ Şarj Durağı: ${station.name}")
                    .snippet("${station.operator} • ${station.powerKw} kW")
            )
        }

        _uiState.value = _uiState.value.copy(selectedChargerStop = station)

        val nav = navigator ?: return
        try {
            val chargerWp = Waypoint.builder()
                .setLatLng(station.location.latitude, station.location.longitude)
                .setTitle(station.name)
                .build()
            val finalWp = Waypoint.builder()
                .setLatLng(destLatLng.latitude, destLatLng.longitude)
                .setTitle(destTitle)
                .build()
            val routingOptions = RoutingOptions().travelMode(RoutingOptions.TravelMode.DRIVING)
            pendingRouteFuture?.cancel(true)
            pendingRouteFuture = nav.setDestinations(listOf(chargerWp, finalWp), routingOptions)
        } catch (e: Exception) {
            Log.w(TAG, "Şarj ara durağı eklenemedi: ${e.message}")
        }
    }

    /**
     * BÖLÜM 14 (Adım 10): Kullanıcı adres onayından sonra "Navigasyonu Başlat" dediğinde
     * uygulama içindeki Google Navigation SDK devreye girer.
     */
    @SuppressLint("MissingPermission")
    fun startNavigationGuidance() {
        if (!_uiState.value.isAddressConfirmed) {
            _uiState.value = _uiState.value.copy(
                statusBannerMessage = "Adres onayı alınmadan navigasyon başlatılamaz!"
            )
            return
        }
        val nav = navigator
        if (nav == null) {
            _uiState.value = _uiState.value.copy(
                statusBannerMessage = _uiState.value.sdkErrorMessage
                    ?: "Google Navigation SDK hazır değil. Lütfen API anahtarınızı ve bağlantınızı kontrol edin."
            )
            return
        }

        previewPolyline?.remove()
        previewPolyline = null
        navigationViewRef?.isNavigationUiEnabled = true
        nav.setAudioGuidance(
            if (_uiState.value.isAudioMuted) Navigator.AudioGuidance.SILENT
            else Navigator.AudioGuidance.VOICE_ALERTS_AND_GUIDANCE
        )
        nav.startGuidance()

        try {
            googleMap?.followMyLocation(GoogleMap.CameraPerspective.TILTED)
        } catch (_: SecurityException) {}

        _uiState.value = _uiState.value.copy(
            isGuidanceActive = true,
            hasArrived = false,
            statusBannerMessage = null
        )
        refreshTimeAndDistance()
    }

    fun pauseNavigationGuidance() {
        navigator?.stopGuidance()
        _uiState.value = _uiState.value.copy(isGuidanceActive = false)
    }

    @SuppressLint("MissingPermission")
    fun stopAndExitNavigation() {
        invalidatePreviousRoute()
        _uiState.value = _uiState.value.copy(
            pendingConfirmation = null,
            isAddressConfirmed = false,
            destinationTitle = null,
            destinationOpenAddress = null,
            destinationLatLng = null,
            isCalculatingRoute = false,
            isRouteReady = false,
            isGuidanceActive = false,
            hasArrived = false,
            remainingDistanceMeters = null,
            remainingTimeSeconds = null,
            routeEnergyEstimate = null,
            liveRouteChargingStations = emptyList(),
            selectedChargerStop = null,
            statusBannerMessage = null
        )
        recenterToMyLocation()
    }

    @SuppressLint("MissingPermission")
    fun recenterToMyLocation() {
        val map = googleMap ?: return
        if (_uiState.value.isGuidanceActive) {
            try {
                map.followMyLocation(GoogleMap.CameraPerspective.TILTED)
                return
            } catch (_: Exception) {}
        }
        val loc = _uiState.value.currentLocation
        if (loc != null) {
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 16.5f))
        } else {
            startRealLocationUpdates()
        }
    }

    fun zoomIn() {
        googleMap?.animateCamera(CameraUpdateFactory.zoomIn())
    }

    fun zoomOut() {
        googleMap?.animateCamera(CameraUpdateFactory.zoomOut())
    }

    fun toggleMapType() {
        val nextType = when (_uiState.value.mapType) {
            GoogleMap.MAP_TYPE_NORMAL -> GoogleMap.MAP_TYPE_SATELLITE
            GoogleMap.MAP_TYPE_SATELLITE -> GoogleMap.MAP_TYPE_HYBRID
            else -> GoogleMap.MAP_TYPE_NORMAL
        }
        googleMap?.mapType = nextType
        _uiState.value = _uiState.value.copy(mapType = nextType)
    }

    fun cycleNightMode() {
        val next = (_uiState.value.nightModeSetting + 1) % 3
        val forceMode = when (next) {
            1 -> ForceNightMode.FORCE_DAY
            2 -> ForceNightMode.FORCE_NIGHT
            else -> ForceNightMode.AUTO
        }
        try {
            navigationViewRef?.setForceNightMode(forceMode)
        } catch (_: Exception) {}
        _uiState.value = _uiState.value.copy(nightModeSetting = next)
    }

    fun toggleAudioGuidanceMute() {
        val muted = !_uiState.value.isAudioMuted
        navigator?.setAudioGuidance(
            if (muted) Navigator.AudioGuidance.SILENT
            else Navigator.AudioGuidance.VOICE_ALERTS_AND_GUIDANCE
        )
        _uiState.value = _uiState.value.copy(isAudioMuted = muted)
    }

    private fun refreshTimeAndDistance() {
        val nav = navigator ?: return
        val td = nav.currentTimeAndDistance
        if (td != null) {
            val climate = climateStateProvider()
            val updatedEnergy = SkywellET5EnergyEngine.calculateRouteEnergy(
                config = vehicleConfigProvider(),
                verifiedVehicleSocPercent = verifiedSocProvider(),
                userManualSocPercent = manualSocProvider(),
                routeDistanceMeters = td.meters.toDouble(),
                routeDurationSeconds = td.seconds.toLong(),
                realOutsideTempC = outsideTempProvider(),
                isClimateActive = climate.first,
                targetClimateTempC = climate.second
            )
            _uiState.value = _uiState.value.copy(
                remainingDistanceMeters = td.meters,
                remainingTimeSeconds = td.seconds.toLong(),
                routeEnergyEstimate = updatedEnergy
            )
        }
    }

    private suspend fun fetchLiveChargingStations(
        lat: Double,
        lon: Double,
        radiusMeters: Int
    ): List<ChargingWaypoint> = withContext(Dispatchers.IO) {
        try {
            val query = """
                [out:json][timeout:12];
                node["amenity"="charging_station"](around:$radiusMeters,$lat,$lon);
                out body 12;
            """.trimIndent()
            val body = query.toRequestBody("text/plain".toMediaType())
            val req = Request.Builder()
                .url("https://overpass-api.de/api/interpreter")
                .post(body)
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext emptyList()
                val json = JSONObject(resp.body?.string() ?: return@withContext emptyList())
                val els = json.optJSONArray("elements") ?: return@withContext emptyList()
                val list = mutableListOf<ChargingWaypoint>()
                for (i in 0 until els.length()) {
                    val el = els.getJSONObject(i)
                    val sLat = el.optDouble("lat", Double.NaN)
                    val sLon = el.optDouble("lon", Double.NaN)
                    if (sLat.isNaN() || sLon.isNaN()) continue
                    val tags = el.optJSONObject("tags") ?: continue
                    val name = tags.optString("name", "").ifEmpty {
                        tags.optString("operator", "Şarj İstasyonu")
                    }
                    val op = tags.optString("operator", "Belirtilmemiş")
                    val kw = tags.optString("socket:ccs:output", "")
                        .ifEmpty { tags.optString("socket:type2:output", "") }
                        .filter { it.isDigit() }
                        .take(3)
                        .toIntOrNull() ?: 50
                    list.add(
                        ChargingWaypoint(
                            name = name,
                            location = GeoPoint(sLat, sLon, 0.0),
                            operator = op,
                            powerKw = kw,
                            plugTypes = listOf(PlugType.CCS, PlugType.TYPE_2),
                            addedAutomatically = false
                        )
                    )
                }
                list
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private suspend fun fetchPlacesPredictions(
        client: PlacesClient,
        query: String
    ): List<PlaceSuggestionItem> = suspendCancellableCoroutine { cont ->
        val reqBuilder = FindAutocompletePredictionsRequest.builder().setQuery(query)
        _uiState.value.currentLocation?.let { loc -> reqBuilder.setOrigin(loc) }
        client.findAutocompletePredictions(reqBuilder.build())
            .addOnSuccessListener { response ->
                val list = response.autocompletePredictions.map { pred ->
                    PlaceSuggestionItem(
                        placeId = pred.placeId,
                        title = pred.getPrimaryText(null).toString(),
                        subtitle = pred.getSecondaryText(null).toString()
                    )
                }
                if (cont.isActive) cont.resume(list)
            }
            .addOnFailureListener {
                if (cont.isActive) cont.resume(emptyList())
            }
    }

    private suspend fun fetchPlaceDetails(
        client: PlacesClient,
        placeId: String
    ): Pair<LatLng?, String?>? = suspendCancellableCoroutine { cont ->
        val fields = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG, Place.Field.ADDRESS)
        val req = FetchPlaceRequest.newInstance(placeId, fields)
        client.fetchPlace(req)
            .addOnSuccessListener { resp ->
                if (cont.isActive) cont.resume(resp.place.latLng to resp.place.address)
            }
            .addOnFailureListener {
                if (cont.isActive) cont.resume(null)
            }
    }

    @Suppress("DEPRECATION")
    private suspend fun geocodeSearch(query: String): List<PlaceSuggestionItem> =
        withContext(Dispatchers.IO) {
            try {
                if (!Geocoder.isPresent()) return@withContext emptyList()
                val geocoder = Geocoder(context, Locale("tr", "TR"))
                val addresses: List<Address> = geocoder.getFromLocationName(query, 6) ?: emptyList()
                addresses.mapNotNull { addr ->
                    if (!addr.hasLatitude() || !addr.hasLongitude()) return@mapNotNull null
                    val title = addr.featureName
                        ?: addr.thoroughfare
                        ?: addr.subAdminArea
                        ?: addr.adminArea
                        ?: query
                    val fullLine = (0..addr.maxAddressLineIndex)
                        .mapNotNull { addr.getAddressLine(it) }
                        .joinToString(", ")
                    PlaceSuggestionItem(
                        placeId = null,
                        title = title,
                        subtitle = fullLine.ifBlank { "${addr.latitude}, ${addr.longitude}" },
                        latLng = LatLng(addr.latitude, addr.longitude)
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Geocoder arama uyarısı: ${e.message}")
                emptyList()
            }
        }

    @Suppress("DEPRECATION")
    private suspend fun reverseGeocodeTitle(latLng: LatLng): String? =
        withContext(Dispatchers.IO) {
            try {
                if (!Geocoder.isPresent()) return@withContext null
                val geocoder = Geocoder(context, Locale("tr", "TR"))
                val list = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
                val first = list?.firstOrNull() ?: return@withContext null
                first.getAddressLine(0)
                    ?: listOfNotNull(first.thoroughfare, first.subAdminArea, first.adminArea)
                        .joinToString(", ")
                        .takeIf { it.isNotBlank() }
            } catch (_: Exception) {
                null
            }
        }

    fun release() {
        stopLocationUpdates()
        invalidatePreviousRoute()
        navigator?.let { nav ->
            try {
                nav.removeArrivalListener(arrivalListener)
                nav.removeRouteChangedListener(routeChangedListener)
                nav.removeRemainingTimeOrDistanceChangedListener(timeAndDistanceListener)
                nav.stopGuidance()
                nav.clearDestinations()
                nav.cleanup()
            } catch (_: Exception) {}
        }
        navigator = null
        googleMap = null
        navigationViewRef = null
    }
}
