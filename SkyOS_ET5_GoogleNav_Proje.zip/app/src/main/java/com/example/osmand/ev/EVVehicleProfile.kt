package com.example.osmand.ev

enum class PlugType(val label: String) {
    CCS("CCS2"),
    TYPE_2("Type 2"),
    CHADEMO("CHAdeMO"),
    GB_T("GB/T"),
    TESLA_NACS("NACS");

    fun isCompatibleWith(stationPlug: String): Boolean {
        val s = stationPlug.lowercase()
        return when (this) {
            CCS -> s.contains("ccs") || s.contains("combo") || s.contains("dc")
            TYPE_2 -> s.contains("type2") || s.contains("type 2") || s.contains("mennekes") || s.contains("ac")
            CHADEMO -> s.contains("chademo")
            GB_T -> s.contains("gbt") || s.contains("gb/t")
            TESLA_NACS -> s.contains("nacs") || s.contains("tesla")
        }
    }
}

/**
 * SKYWELL ET5 LR Legend (2023) Araç ve Batarya Profili (Bölüm 13).
 *
 * - Marka: SKYWELL
 * - Model: ET5 LR Legend (2023)
 * - Brüt batarya kapasitesi: 86,0 kWh
 * - Kullanılabilir batarya kapasitesi: yaklaşık 84,2 kWh (TAHMİNİ başlangıç; doğrulanmış araç verisiyle güncellenebilir)
 * - Başlangıç enerji tüketimi: yaklaşık 17,5 kWh / 100 km (175 Wh/km TAHMİNİ; kullanıcı tarafından değiştirilebilir)
 * - AC şarj gücü: 11,0 kW
 * - DC şarj gücü: doğrulanmış araç verisi yoksa kesin değer olarak gösterilmez (null)
 * - Soket: Araç üzerindeki gerçek soket (CCS2 / Type 2) doğrulanmadan kesin kabul edilmez.
 */
data class EVVehicleProfile(
    val brand: String = "SKYWELL",
    val model: String = "ET5 LR Legend",
    val modelYear: Int = 2023,
    val grossBatteryCapacityKwh: Double = 86.0,
    val batteryCapacityKwh: Double = 84.2,          // Yaklaşık 84,2 kWh kullanılabilir (TAHMİNİ başlangıç)
    val isCapacityVerifiedFromVehicle: Boolean = false,
    val currentSoCPercent: Float = -1.0f,           // -1 = Veri Yok (sahte %78 ASLA kullanılmaz)
    val isSoCVerifiedFromVehicle: Boolean = false,
    val averageConsumptionWhPerKm: Double = 175.0,  // 17,5 kWh/100 km (TAHMİNİ başlangıç)
    val acChargePowerKw: Double = 11.0,             // 11 kW AC
    val verifiedDcChargePowerKw: Double? = null,    // Doğrulanmış araç verisi yoksa null
    val isSocketVerified: Boolean = false,
    val supportedPlugTypes: List<PlugType> = emptyList(), // Doğrulanmadan kesin kabul edilmez
    val vehicleWeightKg: Double = 2120.0,
    val regenEfficiency: Double = 0.65,
    val minSafeSoCPercent: Float = 15.0f
) {
    fun remainingEnergyKwh(): Double {
        if (currentSoCPercent < 0f) return 0.0
        return (currentSoCPercent / 100.0) * batteryCapacityKwh
    }

    fun usableEnergyToReserveKwh(): Double {
        if (currentSoCPercent < 0f) return 0.0
        val usableSoC = (currentSoCPercent - minSafeSoCPercent).coerceAtLeast(0f)
        return (usableSoC / 100.0) * batteryCapacityKwh
    }

    fun calculateNominalRangeKm(): Double {
        val kwh = remainingEnergyKwh()
        return if (kwh > 0.0 && averageConsumptionWhPerKm > 0.0) {
            (kwh * 1000.0) / averageConsumptionWhPerKm
        } else 0.0
    }
}
