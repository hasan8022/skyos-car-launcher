package com.example.osmand.ev

import kotlin.math.abs
import kotlin.math.max

/**
 * Başlangıç batarya yüzdesinin (SoC) kaynağı.
 * Gerçek araç verisi ile kullanıcı girişini kesin olarak ayırır.
 */
enum class SocDataSource(val labelTr: String) {
    VERIFIED_VEHICLE_TELEMETRY("DOĞRULANMIŞ ARAÇ VERİSİ (car_service / OBD)"),
    USER_MANUAL_INPUT("KULLANICI GİRİŞİ (Manuel %)"),
    MISSING_REQUIRED("VERİ YOK (Kullanıcı Girişi Zorunlu)")
}

/**
 * BÖLÜM 13: SKYWELL ET5 LR Legend (2023) Araç Yapılandırması.
 *
 * Kurallar:
 * - Marka: SKYWELL
 * - Model: ET5 LR Legend
 * - Model yılı: 2023
 * - Brüt batarya kapasitesi: 86,0 kWh
 * - Kullanılabilir batarya kapasitesi: yaklaşık 84,2 kWh (TAHMİNİ başlangıç; doğrulanmış araç verisiyle güncellenebilir)
 * - Başlangıç enerji tüketimi: yaklaşık 17,5 kWh/100 km (TAHMİNİ; kullanıcı tarafından değiştirilebilir)
 * - AC şarj gücü: 11,0 kW
 * - DC şarj gücü: doğrulanmış araç verisi yoksa kesin değer olarak gösterilmez (null).
 * - Soket: Araç üzerindeki gerçek soket doğrulanmadan CCS2 ve Type 2 kesin kabul edilmez.
 */
data class SkywellET5Config(
    val brand: String = "SKYWELL",
    val model: String = "ET5 LR Legend",
    val modelYear: Int = 2023,
    val grossBatteryCapacityKwh: Double = 86.0,
    val estimatedUsableCapacityKwh: Double = 84.2,
    val verifiedUsableCapacityKwh: Double? = null,
    val userEstimatedConsumptionKwhPer100Km: Double = 17.5,
    val verifiedAvgConsumptionKwhPer100Km: Double? = null,
    val acChargingPowerKw: Double = 11.0,
    val verifiedDcChargingPowerKw: Double? = null,
    val isCcs2SocketVerified: Boolean = false,
    val isType2SocketVerified: Boolean = false,
    val safetyReserveSocPercent: Int = 15,
    val extraPayloadKg: Int = 0,
    val estimatedTargetSpeedKmh: Int = 90
) {
    val effectiveUsableCapacityKwh: Double
        get() = verifiedUsableCapacityKwh?.takeIf { it > 0.0 } ?: estimatedUsableCapacityKwh

    val isUsableCapacityEstimated: Boolean
        get() = verifiedUsableCapacityKwh == null || verifiedUsableCapacityKwh <= 0.0

    val effectiveBaseConsumptionKwhPer100Km: Double
        get() = verifiedAvgConsumptionKwhPer100Km?.takeIf { it > 0.0 } ?: userEstimatedConsumptionKwhPer100Km

    val isConsumptionEstimated: Boolean
        get() = verifiedAvgConsumptionKwhPer100Km == null || verifiedAvgConsumptionKwhPer100Km <= 0.0

    val dcChargingStatusText: String
        get() = verifiedDcChargingPowerKw?.let { "${it.toInt()} kW (Doğrulanmış Araç Verisi)" }
            ?: "Doğrulanmadı (Gerçek araç verisi yok)"

    val socketStatusText: String
        get() = when {
            isCcs2SocketVerified && isType2SocketVerified -> "CCS2 (DC) + Type 2 (AC) — Kullanıcı/Araç Doğrulamalı"
            isCcs2SocketVerified -> "CCS2 Doğrulandı • Type 2 Doğrulanmadı"
            isType2SocketVerified -> "Type 2 Doğrulandı • CCS2 Doğrulanmadı"
            else -> "Doğrulanmadı (CCS2 / Type 2 araç üzerinde doğrulanmalı)"
        }
}

/**
 * BÖLÜM 15: SKYWELL ET5 LR Legend (2023) Rota Enerji Hesaplama Sonucu.
 * Tüm tahmini çıktılar açıkça "TAHMİNİ" olarak işaretlenir; gerçek batarya ölçümü gibi sunulmaz.
 */
data class EVRouteEnergyEstimate(
    val config: SkywellET5Config,
    val socSource: SocDataSource,
    val initialSocPercent: Int?, // null ise hesaplama yapılamaz, kullanıcı girişi zorunludur
    val routeDistanceKm: Double,
    val routeDurationMinutes: Int,
    val elevationGainMeters: Double?, // null = eğim verisi mevcut değil
    val elevationLossMeters: Double?,
    val outsideTempC: Int?, // null = sensör verisi yok
    val isTempFromRealSensor: Boolean,
    val isClimateActive: Boolean,
    val targetClimateTempC: Float,
    val trafficMultiplier: Double,
    val estimatedConsumptionKwhPer100Km: Double,
    val estimatedTotalEnergyKwh: Double,
    val estimatedArrivalSocPercent: Double,
    val estimatedRemainingRangeKm: Double,
    val safetyReservePercent: Int,
    val requiresChargingStop: Boolean,
    val isReachableWithoutCharge: Boolean,
    val minRequiredChargeKwh: Double,
    val summaryWarningTr: String
)

object SkywellET5EnergyEngine {

    /**
     * Skywell ET5 LR Legend (2023) için gerçek rota mesafesi, yol eğimi/rakım değişimi (varsa),
     * trafik yoğunluğu, dış hava sıcaklığı, tahmini hız, klima/ısıtma durumu, araçtaki yük
     * ve güvenlik batarya rezervini dikkate alarak TAHMİNİ enerji tüketimini hesaplar.
     */
    fun calculateRouteEnergy(
        config: SkywellET5Config,
        verifiedVehicleSocPercent: Int?,
        userManualSocPercent: Int?,
        routeDistanceMeters: Double,
        routeDurationSeconds: Long,
        elevationGainMeters: Double? = null,
        elevationLossMeters: Double? = null,
        realOutsideTempC: Int? = null,
        isClimateActive: Boolean = false,
        targetClimateTempC: Float = 22.0f
    ): EVRouteEnergyEstimate {
        val distanceKm = (routeDistanceMeters / 1000.0).coerceAtLeast(0.0)
        val durationMin = (routeDurationSeconds / 60L).toInt().coerceAtLeast(1)

        // 1. Başlangıç batarya yüzdesi kaynağı belirleme (uydurma değer YASAK)
        val (socPercent, socSource) = when {
            verifiedVehicleSocPercent != null && verifiedVehicleSocPercent in 0..100 ->
                verifiedVehicleSocPercent to SocDataSource.VERIFIED_VEHICLE_TELEMETRY
            userManualSocPercent != null && userManualSocPercent in 0..100 ->
                userManualSocPercent to SocDataSource.USER_MANUAL_INPUT
            else -> null to SocDataSource.MISSING_REQUIRED
        }

        val baseKwhPer100Km = config.effectiveBaseConsumptionKwhPer100Km

        // 2. Hız faktörü (WLTP/baz tüketim ~85 km/sa referans alınarak aerodinamik direnç etkisi)
        val avgRouteSpeedKmh = if (routeDurationSeconds > 60) {
            (distanceKm / (routeDurationSeconds / 3600.0)).coerceIn(15.0, 150.0)
        } else {
            config.estimatedTargetSpeedKmh.toDouble()
        }
        val effectiveSpeed = max(avgRouteSpeedKmh, config.estimatedTargetSpeedKmh.toDouble() * 0.85)
        val speedFactor = when {
            effectiveSpeed > 110.0 -> 1.0 + ((effectiveSpeed - 110.0) * 0.0085)
            effectiveSpeed < 40.0 -> 1.04 // Düşük hız dur-kalk etkisi
            else -> 1.0
        }

        // 3. Trafik faktörü (Serbest akışa kıyasla gecikme varsa dur-kalk tüketim artışı)
        val freeFlowSeconds = (distanceKm / 80.0) * 3600.0
        val trafficMultiplier = if (freeFlowSeconds > 60 && routeDurationSeconds > freeFlowSeconds * 1.25) {
            (1.0 + ((routeDurationSeconds / freeFlowSeconds - 1.25) * 0.12)).coerceIn(1.0, 1.22)
        } else {
            1.0
        }

        // 4. Dış sıcaklık faktörü (Yalnızca gerçek sensör verisi varsa uygulanır)
        val tempFactor = if (realOutsideTempC != null) {
            when {
                realOutsideTempC < 0 -> 1.24 // Soğuk hava batarya iç direnci + ısıtma
                realOutsideTempC < 10 -> 1.12
                realOutsideTempC > 32 -> 1.10 // Yüksek sıcaklık batarya soğutma
                else -> 1.0
            }
        } else {
            1.0
        }

        // 5. Klima ve kabin ısıtma tüketimi (süreye bağlı kWh)
        val durationHours = (routeDurationSeconds / 3600.0).coerceAtLeast(0.05)
        val hvacPowerKw = if (isClimateActive) {
            val deltaTemp = if (realOutsideTempC != null) abs(targetClimateTempC - realOutsideTempC) else 6f
            (0.9 + (deltaTemp * 0.08)).coerceIn(0.8, 2.8)
        } else {
            0.0
        }
        val hvacEnergyKwh = hvacPowerKw * durationHours

        // 6. Araçtaki ekstra yük faktörü (her 100 kg için yaklaşık +%1.8 tüketim)
        val payloadFactor = 1.0 + ((config.extraPayloadKg.coerceAtLeast(0) / 100.0) * 0.018)

        // 7. Yol eğimi ve rakım değişimi (Gerçek rakım verisi varsa potansiyel enerji + %65 rejenerasyon)
        val vehicleMassKg = 2120.0 + config.extraPayloadKg.coerceAtLeast(0)
        val elevationNetKwh = if (elevationGainMeters != null && elevationLossMeters != null) {
            val uphillKwh = (vehicleMassKg * 9.81 * elevationGainMeters) / 3_600_000.0 / 0.88
            val regenKwh = ((vehicleMassKg * 9.81 * elevationLossMeters) / 3_600_000.0) * 0.62
            uphillKwh - regenKwh
        } else {
            0.0
        }

        val adjustedKwhPer100Km = baseKwhPer100Km * speedFactor * trafficMultiplier * tempFactor * payloadFactor
        val drivingEnergyKwh = (distanceKm / 100.0) * adjustedKwhPer100Km
        val totalEstimatedEnergyKwh = (drivingEnergyKwh + hvacEnergyKwh + elevationNetKwh).coerceAtLeast(0.1)
        val effectiveRateKwhPer100Km = if (distanceKm > 0.1) {
            (totalEstimatedEnergyKwh / distanceKm) * 100.0
        } else {
            adjustedKwhPer100Km
        }

        // Eğer başlangıç batarya yüzdesi henüz girilmemişse:
        if (socPercent == null) {
            return EVRouteEnergyEstimate(
                config = config,
                socSource = SocDataSource.MISSING_REQUIRED,
                initialSocPercent = null,
                routeDistanceKm = distanceKm,
                routeDurationMinutes = durationMin,
                elevationGainMeters = elevationGainMeters,
                elevationLossMeters = elevationLossMeters,
                outsideTempC = realOutsideTempC,
                isTempFromRealSensor = realOutsideTempC != null,
                isClimateActive = isClimateActive,
                targetClimateTempC = targetClimateTempC,
                trafficMultiplier = trafficMultiplier,
                estimatedConsumptionKwhPer100Km = effectiveRateKwhPer100Km,
                estimatedTotalEnergyKwh = totalEstimatedEnergyKwh,
                estimatedArrivalSocPercent = 0.0,
                estimatedRemainingRangeKm = 0.0,
                safetyReservePercent = config.safetyReserveSocPercent,
                requiresChargingStop = false,
                isReachableWithoutCharge = false,
                minRequiredChargeKwh = 0.0,
                summaryWarningTr = "Araçtan gerçek batarya yüzdesi okunamıyor. Tahmini varış bataryası ve menzil hesabı için lütfen mevcut batarya yüzdenizi (%) girin."
            )
        }

        val usableCapKwh = config.effectiveUsableCapacityKwh
        val initialAvailableKwh = usableCapKwh * (socPercent / 100.0)
        val remainingEnergyKwh = initialAvailableKwh - totalEstimatedEnergyKwh
        val arrivalSocPercent = ((remainingEnergyKwh / usableCapKwh) * 100.0).coerceIn(-100.0, 100.0)
        val remainingRangeKm = if (remainingEnergyKwh > 0 && effectiveRateKwhPer100Km > 1.0) {
            (remainingEnergyKwh / effectiveRateKwhPer100Km) * 100.0
        } else {
            0.0
        }

        val reserveKwh = usableCapKwh * (config.safetyReserveSocPercent / 100.0)
        val requiresCharge = arrivalSocPercent < config.safetyReserveSocPercent
        val reachableWithoutCharge = arrivalSocPercent > 2.0
        val deficitKwh = if (remainingEnergyKwh < reserveKwh) (reserveKwh - remainingEnergyKwh) else 0.0

        val warningText = when {
            !reachableWithoutCharge ->
                "UYARI (TAHMİNİ): Mevcut batarya (%$socPercent) ile bu hedefe tek şarjla ulaşılamaz. En az ${"%.1f".format(deficitKwh)} kWh ek şarj gereklidir."
            requiresCharge ->
                "DİKKAT (TAHMİNİ): Varış bataryası (%${arrivalSocPercent.toInt()}) belirlediğiniz %${config.safetyReserveSocPercent} güvenlik rezervinin altına düşüyor. Rota üzerinde şarj durağı önerilir."
            else ->
                "TAHMİNİ: Mevcut batarya (%$socPercent) ile güvenlik rezervi (%${config.safetyReserveSocPercent}) korunarak hedefe ulaşılabilir."
        }

        return EVRouteEnergyEstimate(
            config = config,
            socSource = socSource,
            initialSocPercent = socPercent,
            routeDistanceKm = distanceKm,
            routeDurationMinutes = durationMin,
            elevationGainMeters = elevationGainMeters,
            elevationLossMeters = elevationLossMeters,
            outsideTempC = realOutsideTempC,
            isTempFromRealSensor = realOutsideTempC != null,
            isClimateActive = isClimateActive,
            targetClimateTempC = targetClimateTempC,
            trafficMultiplier = trafficMultiplier,
            estimatedConsumptionKwhPer100Km = effectiveRateKwhPer100Km,
            estimatedTotalEnergyKwh = totalEstimatedEnergyKwh,
            estimatedArrivalSocPercent = arrivalSocPercent,
            estimatedRemainingRangeKm = remainingRangeKm,
            safetyReservePercent = config.safetyReserveSocPercent,
            requiresChargingStop = requiresCharge,
            isReachableWithoutCharge = reachableWithoutCharge,
            minRequiredChargeKwh = deficitKwh,
            summaryWarningTr = warningText
        )
    }
}
