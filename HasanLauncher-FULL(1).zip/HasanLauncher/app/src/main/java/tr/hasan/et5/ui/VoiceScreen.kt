package tr.hasan.et5.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus
import tr.hasan.et5.service.VoiceAssistant

@Composable
fun VoiceScreen() {
    val context = LocalContext.current
    val assistant = remember { VoiceAssistant(context) }
    var transcript by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("") }
    var hasPerm by remember {
        mutableStateOf(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPerm = it }

    assistant.onResult = { cmd ->
        transcript = cmd
        response = processCmd(context, cmd)
        assistant.speak(response)
    }

    DisposableEffect(Unit) { onDispose { assistant.stopListening() } }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Sesli Asistan", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(24.dp))
        if (!hasPerm) {
            Button(onClick = { perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Mikrofon Izni Ver") }
        } else {
            Button(onClick = { assistant.startListening() }, enabled = !assistant.isListening) {
                Text(if (assistant.isListening) "Dinleniyor..." else "Konusmaya Basla")
            }
        }
        Spacer(Modifier.height(24.dp))
        if (transcript.isNotEmpty()) {
            Text("Komut: $transcript", style = MaterialTheme.typography.titleMedium)
            Text("Yanit: $response", style = MaterialTheme.typography.bodyLarge)
        }
        Spacer(Modifier.height(16.dp))
        Text("Ornek komutlar:", style = MaterialTheme.typography.bodySmall)
        Text("klima 22, koltuk ileri, radyo 95.5, sarj 80, navigasyon ac", style = MaterialTheme.typography.bodySmall)
    }
}

private fun processCmd(context: android.content.Context, cmd: String): String {
    val lower = cmd.lowercase(java.util.Locale("tr"))
    return when {
        lower.contains("klima") -> {
            val num = Regex("\d+").find(lower)?.value?.toFloatOrNull() ?: 22f
            VehicleBus.setTemperature(context, "0", num)
            "Klima sicakligi $num dereceye ayarlandi"
        }
        lower.contains("radyo") -> {
            val num = Regex("\d+\.?\d*").find(lower)?.value?.toDoubleOrNull() ?: 88.0
            "Radyo frekansi $num MHz olarak ayarlandi (tuner servise gonderildi)"
        }
        lower.contains("sarj") || lower.contains("şarj") -> {
            val num = Regex("\d+").find(lower)?.value?.toIntOrNull() ?: 80
            VehicleBus.writeSetting(context, "sarj_limit", num.toString())
            "Sarj limiti %$num olarak ayarlandi"
        }
        lower.contains("navigasyon") -> {
            context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse("https://maps.google.com")).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            "Navigasyon aciliyor"
        }
        lower.contains("koltuk") -> "Koltuk komutu (ileri/geri/yukari/asagi) secenekleri ayarlardan yapilabilir"
        else -> "Komut anlasilmadi. Ornek: klima 22, radyo 95.5"
    }
}
