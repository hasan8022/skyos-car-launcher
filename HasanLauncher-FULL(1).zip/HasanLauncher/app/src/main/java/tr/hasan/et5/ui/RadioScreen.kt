package tr.hasan.et5.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

// SkyOS B00.smali'den cikarilan gercek radyo servisi
private const val RADIO_PKG = "com.skyworth.car.carradio"
private const val RADIO_SERVICE = "com.coocaa.radio.service.impl.RadioAppService"

class RadioBinder(ctx: Context) {
    var iface: android.os.IBinder? = null
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) { iface = service }
        override fun onServiceDisconnected(name: ComponentName?) { iface = null }
    }
    init {
        try {
            val i = Intent().apply {
                component = ComponentName(RADIO_PKG, RADIO_SERVICE)
                `package` = RADIO_PKG
            }
            ctx.bindService(i, conn, Context.BIND_AUTO_CREATE)
        } catch (_: Exception) {}
    }
    fun unbind(ctx: Context) { ctx.unbindService(conn) }

    // AIDL uzerinden basit cagri (transact kodu 1 = frekans ayar, varsayim)
    fun tune(freq: Double) {
        val b = iface ?: return
        try {
            val data = android.os.Parcel.obtain()
            val reply = android.os.Parcel.obtain()
            data.writeInterfaceToken("com.coocaa.radio.service.IRadio")
            data.writeDouble(freq)
            b.transact(1, data, reply, 0)
            reply.readException()
            data.recycle(); reply.recycle()
        } catch (_: Exception) {}
    }
}

@Composable
fun RadioScreen() {
    val context = LocalContext.current
    var freq by remember { mutableDoubleStateOf(88.0) }
    var preset by remember { mutableStateOf(listOf(88.0, 92.0, 96.0, 100.0, 104.0)) }
    var band by remember { mutableStateOf("FM") } // FM / AM
    var connected by remember { mutableStateOf(false) }

    val binder = remember { RadioBinder(context) }
    DisposableEffect(Unit) {
        val h = Handler(Looper.getMainLooper())
        val r = object : Runnable {
            override fun run() {
                connected = binder.iface?.isBinderAlive == true
                h.postDelayed(this, 1000)
            }
        }
        h.post(r)
        onDispose { binder.unbind(context); h.removeCallbacks(r) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Radyo", style = MaterialTheme.typography.headlineMedium)
        Text(if (connected) "Tuner bagli" else "Tuner bagli degil (sistem radyo servisi calisiyor mu?)",
            style = MaterialTheme.typography.bodySmall,
            color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = band == "FM", onClick = { band = "FM" }, label = { Text("FM") })
            FilterChip(selected = band == "AM", onClick = { band = "AM" }, label = { Text("AM") })
        }

        Spacer(Modifier.height(16.dp))
        Text("%.1f MHz".format(freq), style = MaterialTheme.typography.displayLarge)
        Slider(value = freq.toFloat(), onValueChange = { freq = it.toDouble() },
            valueRange = if (band == "FM") 87.5f..108.0f else 530f..1700f,
            steps = if (band == "FM") 204 else 1169)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { freq -= if (band == "FM") 0.1 else 10 }) { Text("-") }
            Button(onClick = { binder.tune(freq); toast(context, "Frekans ayarlandi: %.1f".format(freq)) }) { Text("Ayarla") }
            Button(onClick = { freq += if (band == "FM") 0.1 else 10 }) { Text("+") }
        }

        Spacer(Modifier.height(16.dp))
        Text("Presetler", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            preset.forEach { p ->
                AssistChip(onClick = { freq = p; binder.tune(p) }, label = { Text("%.1f".format(p)) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            preset = preset.toMutableList().apply { add(freq) }
        }) { Text("Mevcut Frekansi Preset Kaydet") }

        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            context.packageManager.getLaunchIntentForPackage(RADIO_PKG)?.let {
                context.startActivity(it)
            } ?: toast(context, "Sistem radyo uygulamasi bulunamadi")
        }) { Text("Sistem Radyosunu Ac") }
    }
}
