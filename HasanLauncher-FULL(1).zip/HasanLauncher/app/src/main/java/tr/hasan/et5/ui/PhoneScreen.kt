package tr.hasan.et5.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// SkyOS phone ozellikleri esdegeri: arama kaydi + kisiler + arama yapma
data class CallEntry(val number: String, val name: String, val date: Long)

@SuppressLint("MissingPermission", "Range")
fun loadCallLog(context: Context): List<CallEntry> {
    val list = mutableListOf<CallEntry>()
    val c = context.contentResolver.query(
        CallLog.Calls.CONTENT_URI,
        arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE),
        null, null, CallLog.Calls.DATE + " DESC LIMIT 30"
    ) ?: return list
    while (c.moveToNext()) {
        list.add(CallEntry(
            c.getString(0) ?: "",
            c.getString(1) ?: c.getString(0) ?: "",
            c.getLong(2)
        ))
    }
    c.close()
    return list
}

@Composable
fun PhoneScreen() {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(
            context.checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED &&
            context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        )
    }
    var calls by remember { mutableStateOf(if (granted) loadCallLog(context) else emptyList()) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res -> if (res.values.all { it }) { granted = true; calls = loadCallLog(context) } }

    var digits by remember { mutableStateOf("") }

    if (!granted) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Arama kaydi ve kisiler icin izin gerekli.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                permLauncher.launch(arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS))
            }) { Text("Izin Ver") }
        }
        return
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Telefon", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            TextField(
                value = digits, onValueChange = { digits = it },
                label = { Text("Numara") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (digits.isNotBlank()) context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + digits.trim())))
            }) { Text("Ara") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(calls, key = { it.number + it.date }) { call ->
                ListItem(
                    headlineContent = { Text(call.name) },
                    supportingContent = {
                        Text(call.number + " - " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr")).format(Date(call.date)))
                    },
                    modifier = Modifier.clickable {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + call.number)))
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
