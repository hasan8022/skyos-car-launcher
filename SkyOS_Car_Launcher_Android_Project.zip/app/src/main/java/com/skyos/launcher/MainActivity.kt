package com.skyos.launcher

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.skyos.launcher.adbsoc.Adbsoc
import com.skyos.launcher.obd.ObdManager
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * SkyOS Car Launcher - MainActivity
 *
 * Android HOME Launcher aktivitesi.
 * - İlk açılışta `Adbsoc(applicationContext).ensureRsaKeys()` çağırarak
 *   `filesDir/adbkey` ve `filesDir/adbkey.pub` anahtarlarını üretir.
 * - `127.0.0.1:5555` portuna ADB bağlantısını başlatır.
 * - Paylaş > SkyOS (`Intent.ACTION_SEND`) ile gelen Google Haritalar konumlarını yakalar
 *   ve doğrudan navigasyon rota önizlemesine aktarır.
 */
class MainActivity : ComponentActivity() {

    private lateinit var adbsoc: Adbsoc
    private lateinit var obdManager: ObdManager
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adbsoc = Adbsoc(applicationContext, Adbsoc.DEFAULT_HOST, Adbsoc.DEFAULT_PORT)
        obdManager = ObdManager(applicationContext)

        // İlk çalışmada RSA anahtarlarını üret (filesDir/adbkey, filesDir/adbkey.pub)
        val keyInfo = adbsoc.ensureRsaKeys()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    request.grant(request.resources)
                }
            }
            addJavascriptInterface(SkyOsNativeBridge(keyInfo), "SkyOsAndroid")
            loadUrl("file:///android_asset/skyos_launcher.html")
        }

        setContentView(webView)

        // Arka planda 127.0.0.1:5555 ADB bağlantısını başlat
        lifecycleScope.launch {
            adbsoc.connect()
        }

        handleSharedLocationIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleSharedLocationIntent(intent)
    }

    private fun handleSharedLocationIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val escaped = JSONObject.quote(sharedText)
            webView.post {
                webView.evaluateJavascript("window.onSharedLocationReceived && window.onSharedLocationReceived($escaped);", null)
            }
        }
    }

    inner class SkyOsNativeBridge(private val keyInfo: Adbsoc.AdbKeyInfo) {
        @JavascriptInterface
        fun getAdbKeyStatusJson(): String {
            val obj = JSONObject()
            obj.put("host", Adbsoc.DEFAULT_HOST)
            obj.put("port", Adbsoc.DEFAULT_PORT)
            obj.put("privateKeyPath", keyInfo.privateKeyFile.absolutePath)
            obj.put("publicKeyPath", keyInfo.publicKeyFile.absolutePath)
            obj.put("publicKeyPayload", keyInfo.publicKeyPayload)
            obj.put("fingerprintSha256", keyInfo.fingerprintSha256)
            obj.put("newlyGenerated", keyInfo.newlyGenerated)
            obj.put("state", adbsoc.connectionState.value.name)
            obj.put("lastError", adbsoc.lastError.value ?: "")
            return obj.toString()
        }

        @JavascriptInterface
        fun connectAdb() {
            lifecycleScope.launch {
                adbsoc.connect()
            }
        }

        @JavascriptInterface
        fun execAdbShell(cmd: String) {
            lifecycleScope.launch {
                val res = adbsoc.execShell(cmd)
                val out = res.getOrElse { "HATA: ${it.message}" }
                val escaped = JSONObject.quote(out)
                webView.post {
                    webView.evaluateJavascript("window.onNativeAdbOutput && window.onNativeAdbOutput($escaped);", null)
                }
            }
        }
    }
}
