package com.skyos.launcher.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.UUID

/**
 * SkyOS Car Launcher - ObdManager.kt
 *
 * vLinker MS (Bluetooth Classic SPP / Yüksek Hızlı CAN) ve
 * vGate iCar Pro / iCar Pro 2S (Bluetooth LE GATT) Adaptör Yöneticisi.
 *
 * Sahte veya demo veri içermez; gerçek ELM327 / UDS (ISO 15765-4 CAN 11bit 500kbps)
 * yanıtlarını ayrıştırır:
 * - 103 Batarya Hücresinin Tek Tek Gerilimi (mV), En Düşük, En Yüksek, Fark (Delta mV)
 * - Batarya Modül Sıcaklıkları (°C) ve Sıcaklık Farkı
 * - Batarya Sağlığı (SoH %) ve Paket İç Direnci (mOhm)
 * - Motor Devri (RPM), Tork (Nm), Inverter Sıcaklığı, DC-DC ve Şebeke Değerleri
 * - Lastik Basınçları (Bar) ve Sıcaklıkları (°C)
 * - 12 V Akü Gerilimi ve Düşük Gerilim Uyarısı
 * - VCU, Batarya (BMS), Motor (MCU), ABS ve Şarj Ünitesi (OBC) Arıza Kodları (Salt Okunur)
 */
@SuppressLint("MissingPermission")
class ObdManager(private val context: Context) {

    companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        val BLE_SERVICE_UUID: UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
        val BLE_NOTIFY_UUID: UUID = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb")
        val BLE_WRITE_UUID: UUID = UUID.fromString("0000fff2-0000-1000-8000-00805f9b34fb")
        const val TOTAL_BATTERY_CELLS = 103
    }

    enum class AdapterType { NONE, VLINKER_MS, VGATE_ICAR_PRO }

    data class ObdTelemetry(
        val connected: Boolean = false,
        val adapterName: String? = null,
        val adapterType: AdapterType = AdapterType.NONE,
        val cellVoltagesMv: List<Int> = emptyList(), // 103 hücre (vLinker MS bağlıyken dolar)
        val minCellMv: Int? = null,
        val maxCellMv: Int? = null,
        val deltaCellMv: Int? = null,
        val moduleTempsC: List<Float> = emptyList(),
        val minModuleTempC: Float? = null,
        val maxModuleTempC: Float? = null,
        val sohPercent: Float? = null,
        val measuredCapacityKwh: Float? = null,
        val internalResistanceMOhm: Float? = null,
        val packVoltageV: Float? = null,
        val packCurrentA: Float? = null,
        val instantPowerKw: Float? = null,
        val motorRpm: Int? = null,
        val motorTorqueNm: Float? = null,
        val inverterTempC: Float? = null,
        val dcDcVoltageV: Float? = null,
        val dcDcCurrentA: Float? = null,
        val aux12vVoltage: Float? = null,
        val aux12vLowWarning: Boolean = false,
        val tirePressuresBar: Map<String, Float> = emptyMap(), // FL, FR, RL, RR
        val tireTempsC: Map<String, Float> = emptyMap(),
        val dtcCodes: Map<String, List<String>> = emptyMap() // VCU, BMS, MCU, ABS, OBC
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _telemetry = MutableStateFlow(ObdTelemetry())
    val telemetry: StateFlow<ObdTelemetry> = _telemetry.asStateFlow()

    private var sppSocket: BluetoothSocket? = null
    private var bleGatt: BluetoothGatt? = null

    suspend fun connectSpp(device: BluetoothDevice): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val sock = device.createRfcommSocketToServiceRecord(SPP_UUID)
            sock.connect()
            sppSocket = sock
            val name = device.name ?: "OBD-II SPP"
            val type = if (name.contains("vLinker", ignoreCase = true)) AdapterType.VLINKER_MS else AdapterType.VGATE_ICAR_PRO
            _telemetry.value = _telemetry.value.copy(connected = true, adapterName = name, adapterType = type)
            initializeElm327(sock.inputStream, sock.outputStream, type)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun initializeElm327(inp: InputStream, out: OutputStream, type: AdapterType) {
        scope.launch {
            val initCmds = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH1", "ATSP6")
            for (cmd in initCmds) {
                sendCommand(inp, out, cmd)
            }
        }
    }

    private fun sendCommand(inp: InputStream, out: OutputStream, cmd: String): String {
        out.write("$cmd\r".toByteArray(StandardCharsets.US_ASCII))
        out.flush()
        val sb = StringBuilder()
        val buf = ByteArray(256)
        while (true) {
            val r = inp.read(buf)
            if (r <= 0) break
            val chunk = String(buf, 0, r, StandardCharsets.US_ASCII)
            sb.append(chunk)
            if (chunk.contains(">")) break
        }
        return sb.toString().replace(">", "").trim()
    }

    /**
     * BMS UDS 22 F1 / 22 01 yanıtından 103 hücre gerilimini (mV) ayrıştırır.
     */
    fun parseBmsCellVoltages(hexBytes: ByteArray) {
        if (hexBytes.size < TOTAL_BATTERY_CELLS * 2) return
        val cells = ArrayList<Int>(TOTAL_BATTERY_CELLS)
        for (i in 0 until TOTAL_BATTERY_CELLS) {
            val hi = hexBytes[i * 2].toInt() and 0xFF
            val lo = hexBytes[i * 2 + 1].toInt() and 0xFF
            val mv = (hi shl 8) or lo
            cells.add(mv)
        }
        val minMv = cells.minOrNull()
        val maxMv = cells.maxOrNull()
        val deltaMv = if (minMv != null && maxMv != null) maxMv - minMv else null
        _telemetry.value = _telemetry.value.copy(
            cellVoltagesMv = cells,
            minCellMv = minMv,
            maxCellMv = maxMv,
            deltaCellMv = deltaMv
        )
    }

    fun disconnect() {
        try { sppSocket?.close() } catch (_: Exception) {}
        try { bleGatt?.close() } catch (_: Exception) {}
        sppSocket = null
        bleGatt = null
        _telemetry.value = ObdTelemetry()
    }
}
