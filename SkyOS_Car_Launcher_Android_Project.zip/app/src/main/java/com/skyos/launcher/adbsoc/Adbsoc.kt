package com.skyos.launcher.adbsoc

import android.content.Context
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.atomic.AtomicInteger
import javax.crypto.Cipher

/**
 * SkyOS Car Launcher - Adbsoc.kt
 *
 * Yerel ADB (127.0.0.1:5555) Soket ve RSA Kimlik Doğrulama Kütüphanesi.
 *
 * Özellikler:
 * 1. İlk çalışmada 2048-bit RSA anahtar çifti üretir ve uygulamanın özel klasörüne kaydeder:
 *    - `context.filesDir/adbkey` (PKCS#8 Private Key)
 *    - `context.filesDir/adbkey.pub` (Android ADB Binary RSAPublicKey struct Base64 + " skyos@localhost\u0000")
 * 2. 127.0.0.1:5555 portuna doğrudan TCP soketi ile bağlanır (Dadb / yerel ADB protokolü uyumlu).
 * 3. CNXN, AUTH (TOKEN -> SIGNATURE -> RSAPUBLICKEY), OPEN, WRTE, OKAY, CLSE paketlerini işler.
 * 4. Araç CAN/MCU servisleri, ekran parlaklığı, Wi-Fi/Bluetooth, ADAS kamera APK kurulumu ve
 *    donanım komutlarını gerçek zamanlı çalıştırır.
 */
class Adbsoc(
    private val context: Context,
    private val host: String = DEFAULT_HOST,
    private val port: Int = DEFAULT_PORT
) {
    companion object {
        private const val TAG = "SkyOS_Adbsoc"
        const val DEFAULT_HOST = "127.0.0.1"
        const val DEFAULT_PORT = 5555

        // ADB Protokol Sabitleri (Little-Endian Komut İmzaları)
        private const val A_SYNC = 0x434e5953
        private const val A_CNXN = 0x4e584e43
        private const val A_OPEN = 0x4e45504f
        private const val A_OKAY = 0x59414b4f
        private const val A_CLSE = 0x45534c43
        private const val A_WRTE = 0x45545257
        private const val A_AUTH = 0x48545541

        private const val A_VERSION = 0x01000000
        private const val MAX_PAYLOAD = 4096

        // ADB AUTH Alt Türleri
        private const val ADB_AUTH_TOKEN = 1
        private const val ADB_AUTH_SIGNATURE = 2
        private const val ADB_AUTH_RSAPUBLICKEY = 3

        // RSA 2048 bit (64 adet 32-bit word)
        private const val KEY_BITS = 2048
        private const val KEY_WORDS = KEY_BITS / 32

        // SHA-1 ASN.1 DigestInfo Öneki (ADB_AUTH_SIGNATURE için PKCS#1 v1.5)
        private val SHA1_DIGEST_INFO_PREFIX = byteArrayOf(
            0x30.toByte(), 0x21.toByte(), 0x30.toByte(), 0x09.toByte(),
            0x06.toByte(), 0x05.toByte(), 0x2b.toByte(), 0x0e.toByte(),
            0x03.toByte(), 0x02.toByte(), 0x1a.toByte(), 0x05.toByte(),
            0x00.toByte(), 0x04.toByte(), 0x14.toByte()
        )
    }

    data class AdbKeyInfo(
        val privateKeyFile: File,
        val publicKeyFile: File,
        val publicKeyPayload: String,
        val fingerprintSha256: String,
        val newlyGenerated: Boolean
    )

    enum class ConnectionState {
        DISCONNECTED,
        KEYS_READY,
        CONNECTING,
        AUTHENTICATING,
        AWAITING_USER_AUTH_PROMPT,
        CONNECTED,
        ERROR
    }

    data class AdbPacket(
        val command: Int,
        val arg0: Int,
        val arg1: Int,
        val payload: ByteArray
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val socketMutex = Mutex()
    private val localIdCounter = AtomicInteger(1)

    private var socket: Socket? = null
    private var inputStream: DataInputStream? = null
    private var outputStream: DataOutputStream? = null
    private var keyPair: KeyPair? = null
    private var adbPublicKeyBytes: ByteArray? = null

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    /**
     * İlk çalışmada uygulamanın kendi RSA anahtarını üretir ve
     * `filesDir/adbkey` ile `filesDir/adbkey.pub` dosyalarına kaydeder.
     * Sonraki çalışmalarda mevcut anahtarları doğrudan yükler.
     */
    fun ensureRsaKeys(): AdbKeyInfo {
        val privFile = File(context.filesDir, "adbkey")
        val pubFile = File(context.filesDir, "adbkey.pub")
        val privX509MetaFile = File(context.filesDir, "adbkey.x509")

        var newlyCreated = false

        if (!privFile.exists() || !pubFile.exists() || privFile.length() == 0L || pubFile.length() == 0L) {
            Log.i(TAG, "İlk çalışma tespit edildi: Yeni 2048-bit ADB RSA anahtar çifti üretiliyor...")
            val kpg = KeyPairGenerator.getInstance("RSA")
            kpg.initialize(KEY_BITS)
            val generatedPair = kpg.generateKeyPair()
            val rsaPub = generatedPair.public as RSAPublicKey

            // 1. Özel anahtarı filesDir/adbkey dosyasına kaydet (PKCS#8)
            FileOutputStream(privFile).use { fos ->
                fos.write(generatedPair.private.encoded)
                fos.flush()
            }
            privFile.setReadable(false, false)
            privFile.setReadable(true, true)

            // X.509 public key referansını da hızlı yeniden yükleme için sakla
            FileOutputStream(privX509MetaFile).use { fos ->
                fos.write(rsaPub.encoded)
                fos.flush()
            }

            // 2. Android ADB formatında (524-byte binary struct -> Base64) adbkey.pub oluştur
            val formattedPub = encodeAndroidAdbPublicKey(rsaPub, "skyos@skywell")
            FileOutputStream(pubFile).use { fos ->
                fos.write(formattedPub.toByteArray(StandardCharsets.UTF_8))
                fos.flush()
            }

            keyPair = generatedPair
            adbPublicKeyBytes = (formattedPub + "\u0000").toByteArray(StandardCharsets.UTF_8)
            newlyCreated = true
        } else {
            val privBytes = privFile.readBytes()
            val kf = KeyFactory.getInstance("RSA")
            val privateKey: PrivateKey = kf.generatePrivate(PKCS8EncodedKeySpec(privBytes))
            val publicKey: PublicKey = if (privX509MetaFile.exists()) {
                kf.generatePublic(X509EncodedKeySpec(privX509MetaFile.readBytes()))
            } else {
                val kpg = KeyPairGenerator.getInstance("RSA")
                kpg.initialize(KEY_BITS)
                kpg.generateKeyPair().public
            }
            keyPair = KeyPair(publicKey, privateKey)
            val pubText = pubFile.readText(StandardCharsets.UTF_8).trim()
            adbPublicKeyBytes = (pubText + "\u0000").toByteArray(StandardCharsets.UTF_8)
        }

        val pubContent = pubFile.readText(StandardCharsets.UTF_8).trim()
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(privFile.readBytes())
            .joinToString(":") { "%02X".format(it) }

        if (_connectionState.value == ConnectionState.DISCONNECTED) {
            _connectionState.value = ConnectionState.KEYS_READY
        }

        return AdbKeyInfo(
            privateKeyFile = privFile,
            publicKeyFile = pubFile,
            publicKeyPayload = pubContent,
            fingerprintSha256 = digest,
            newlyGenerated = newlyCreated
        )
    }

    /**
     * Android adbd守护 (daemon) tarafından beklenen 524 baytlık RSAPublicKey C yapısını üretir:
     * struct RSAPublicKey {
     *   uint32_t len;           // 64 (2048 bit / 32)
     *   uint32_t n0inv;         // -1 / n[0] mod 2^32
     *   uint32_t n[64];         // little-endian modulus
     *   uint32_t rr[64];        // (2^(2048*2)) mod n (little-endian)
     *   uint32_t exponent;      // 65537
     * }
     */
    private fun encodeAndroidAdbPublicKey(pubKey: RSAPublicKey, identity: String): String {
        val n = pubKey.modulus
        val e = pubKey.publicExponent.toInt()

        val twoPow32 = BigInteger.ONE.shiftLeft(32)
        val r = BigInteger.ONE.shiftLeft(KEY_BITS)
        val rr = r.multiply(r).mod(n)

        val n0 = n.mod(twoPow32)
        val n0inv = n0.modInverse(twoPow32).negate().mod(twoPow32).toLong()

        val nWords = IntArray(KEY_WORDS)
        val rrWords = IntArray(KEY_WORDS)

        var tempN = n
        var tempRR = rr
        for (i in 0 until KEY_WORDS) {
            val nDivRem = tempN.divideAndRemainder(twoPow32)
            tempN = nDivRem[0]
            nWords[i] = nDivRem[1].toInt()

            val rrDivRem = tempRR.divideAndRemainder(twoPow32)
            tempRR = rrDivRem[0]
            rrWords[i] = rrDivRem[1].toInt()
        }

        val buffer = ByteBuffer.allocate(4 + 4 + (KEY_WORDS * 4) + (KEY_WORDS * 4) + 4)
            .order(ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(KEY_WORDS)
        buffer.putInt(n0inv.toInt())
        for (w in nWords) buffer.putInt(w)
        for (w in rrWords) buffer.putInt(w)
        buffer.putInt(e)

        val base64Key = Base64.encodeToString(buffer.array(), Base64.NO_WRAP)
        return "$base64Key $identity"
    }

    /**
     * 20 baytlık ADB AUTH TOKEN verisini PKCS#1 v1.5 (SHA-1 DigestInfo) ile imzalar.
     */
    private fun signAdbToken(token: ByteArray): ByteArray {
        val priv = keyPair?.private ?: throw IllegalStateException("RSA anahtarı yüklenmedi")
        val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        cipher.init(Cipher.ENCRYPT_MODE, priv)
        val digestInfo = ByteArray(SHA1_DIGEST_INFO_PREFIX.size + token.size)
        System.arraycopy(SHA1_DIGEST_INFO_PREFIX, 0, digestInfo, 0, SHA1_DIGEST_INFO_PREFIX.size)
        System.arraycopy(token, 0, digestInfo, SHA1_DIGEST_INFO_PREFIX.size, token.size)
        return cipher.doFinal(digestInfo)
    }

    /**
     * 127.0.0.1:5555 portuna bağlanır ve ADB el sıkışmasını (CNXN / AUTH) tamamlar.
     */
    suspend fun connect(timeoutMs: Int = 5000): Result<Unit> = withContext(Dispatchers.IO) {
        socketMutex.withLock {
            try {
                ensureRsaKeys()
                closeInternal()
                _connectionState.value = ConnectionState.CONNECTING
                _lastError.value = null

                val sock = Socket()
                sock.tcpNoDelay = true
                sock.connect(InetSocketAddress(host, port), timeoutMs)
                sock.soTimeout = 10000

                val din = DataInputStream(sock.getInputStream())
                val dout = DataOutputStream(sock.getOutputStream())
                socket = sock
                inputStream = din
                outputStream = dout

                // CNXN paketi gönder
                val banner = "host::features=shell_v2,cmd\u0000".toByteArray(StandardCharsets.UTF_8)
                writePacket(A_CNXN, A_VERSION, MAX_PAYLOAD, banner)

                _connectionState.value = ConnectionState.AUTHENTICATING
                var packet = readPacket()

                if (packet.command == A_AUTH && packet.arg0 == ADB_AUTH_TOKEN) {
                    // İlk AUTH_TOKEN geldi: Özel anahtarımızla (filesDir/adbkey) imzala
                    val signature = signAdbToken(packet.payload)
                    writePacket(A_AUTH, ADB_AUTH_SIGNATURE, 0, signature)
                    packet = readPacket()

                    if (packet.command == A_AUTH && packet.arg0 == ADB_AUTH_TOKEN) {
                        // Anahtar henüz adbd tarafından tanınmıyor: filesDir/adbkey.pub gönder
                        _connectionState.value = ConnectionState.AWAITING_USER_AUTH_PROMPT
                        val pubPayload = adbPublicKeyBytes
                            ?: throw IllegalStateException("adbkey.pub okunamadı")
                        writePacket(A_AUTH, ADB_AUTH_RSAPUBLICKEY, 0, pubPayload)
                        sock.soTimeout = 30000 // Kullanıcının ekranda onaylaması için 30 sn bekle
                        packet = readPacket()
                    }
                }

                if (packet.command != A_CNXN) {
                    throw IllegalStateException("Beklenmeyen ADB yanıtı: 0x${packet.command.toString(16)}")
                }

                sock.soTimeout = 8000
                _connectionState.value = ConnectionState.CONNECTED
                Log.i(TAG, "127.0.0.1:5555 ADB bağlantısı başarıyla kuruldu.")
                Result.success(Unit)
            } catch (e: Exception) {
                Log.e(TAG, "ADB bağlantı hatası ($host:$port): ${e.message}", e)
                _lastError.value = e.message ?: "Bilinmeyen ADB hatası"
                _connectionState.value = ConnectionState.ERROR
                closeInternal()
                Result.failure(e)
            }
        }
    }

    /**
     * ADB üzerinden tek seferlik shell komutu çalıştırır ve çıktısını döndürür.
     */
    suspend fun execShell(command: String): Result<String> = withContext(Dispatchers.IO) {
        if (_connectionState.value != ConnectionState.CONNECTED) {
            val connRes = connect()
            if (connRes.isFailure) {
                return@withContext Result.failure(
                    connRes.exceptionOrNull() ?: IllegalStateException("ADB bağlı değil")
                )
            }
        }

        socketMutex.withLock {
            try {
                val localId = localIdCounter.getAndIncrement()
                val dest = "shell:$command\u0000".toByteArray(StandardCharsets.UTF_8)
                writePacket(A_OPEN, localId, 0, dest)

                var remoteId = 0
                val outputBuilder = StringBuilder()

                while (true) {
                    val pkt = readPacket()
                    when (pkt.command) {
                        A_OKAY -> {
                            remoteId = pkt.arg0
                        }
                        A_WRTE -> {
                            remoteId = pkt.arg0
                            outputBuilder.append(String(pkt.payload, StandardCharsets.UTF_8))
                            writePacket(A_OKAY, localId, remoteId, ByteArray(0))
                        }
                        A_CLSE -> {
                            writePacket(A_CLSE, localId, pkt.arg0, ByteArray(0))
                            break
                        }
                        else -> break
                    }
                }
                Result.success(outputBuilder.toString().trim())
            } catch (e: Exception) {
                _lastError.value = e.message
                _connectionState.value = ConnectionState.ERROR
                Result.failure(e)
            }
        }
    }

    /**
     * Araç sistem ayarlarını ve donanım komutlarını ADB üzerinden uygular.
     */
    suspend fun setScreenBrightness(level0to255: Int): Result<String> =
        execShell("settings put system screen_brightness ${level0to255.coerceIn(0, 255)}")

    suspend fun setWifiEnabled(enabled: Boolean): Result<String> =
        execShell("svc wifi ${if (enabled) "enable" else "disable"}")

    suspend fun setBluetoothEnabled(enabled: Boolean): Result<String> =
        execShell("svc bluetooth ${if (enabled) "enable" else "disable"}")

    suspend fun installApkSilently(apkFilePath: String): Result<String> =
        execShell("pm install -r \"$apkFilePath\"")

    suspend fun sendVehicleCanCommand(canInterface: String, frameIdHex: String, dataHex: String): Result<String> =
        execShell("cansend $canInterface $frameIdHex#$dataHex")

    private fun writePacket(command: Int, arg0: Int, arg1: Int, payload: ByteArray) {
        val out = outputStream ?: throw IllegalStateException("Soket kapalı")
        val checksum = payload.fold(0) { acc, b -> acc + (b.toInt() and 0xFF) }
        val magic = command xor -0x1

        val header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        header.putInt(command)
        header.putInt(arg0)
        header.putInt(arg1)
        header.putInt(payload.size)
        header.putInt(checksum)
        header.putInt(magic)

        out.write(header.array())
        if (payload.isNotEmpty()) {
            out.write(payload)
        }
        out.flush()
    }

    private fun readPacket(): AdbPacket {
        val inp = inputStream ?: throw IllegalStateException("Soket kapalı")
        val headerBytes = ByteArray(24)
        inp.readFully(headerBytes)

        val header = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
        val command = header.int
        val arg0 = header.int
        val arg1 = header.int
        val dataLength = header.int
        val dataChecksum = header.int
        val magic = header.int

        val payload = ByteArray(dataLength.coerceIn(0, MAX_PAYLOAD * 16))
        if (dataLength > 0) {
            inp.readFully(payload)
        }
        return AdbPacket(command, arg0, arg1, payload)
    }

    fun close() {
        scope.launch {
            socketMutex.withLock {
                closeInternal()
                _connectionState.value = ConnectionState.DISCONNECTED
            }
        }
    }

    private fun closeInternal() {
        try { inputStream?.close() } catch (_: Exception) {}
        try { outputStream?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        inputStream = null
        outputStream = null
        socket = null
    }
}
