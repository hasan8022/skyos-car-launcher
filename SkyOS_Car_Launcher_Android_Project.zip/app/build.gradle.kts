plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.skyos.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.skyos.launcher"
        minSdk = 28
        targetSdk = 34
        versionCode = 24
        versionName = "2.4.0-SkyOS"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    // Dadb ADB client library compatibility alongside native Adbsoc.kt
    implementation("dev.mobile:dadb:1.2.7")
}
