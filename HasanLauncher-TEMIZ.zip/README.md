# HasanLauncher (tr.hasan.et5)

SkyOS tarzı araç head-unit launcher'ının özgün, sıfırdan yazılmış eşdeğeri.
Lisans kontrolü yoktur, kodun tamamı bu projededir.

## Menüler
- **Ekran** : Saat/tarih, WiFi & Bluetooth düğmeleri, yüklü uygulamalar ızgarası
- **Araç**  : Skyworth sistem uygulamalarına bağlantı (radyo, EV/batarya, klima, BT müzik, yerel medya, telefon)
- **3D Araç**: Three.js + et5.glb yerel 3D araç görünümü (assets/car)
- **Radyo** : FM frekans arayüzü + preset (gerçek tuner için Skyworth API bağlantı noktası işaretli)
- **Medya** : Önceki/Çal-Dur/Sonraki medya tuşları + ses slider'ı
- **Telefon**: Arama kaydı + numara çevirme (izinler runtime'da istenir)
- **Harita** : Leaflet çevrimdışı harita (assets/map-lite)
- **Ayarlar**: Güvenlik kilidi PIN'i (SkyOS HomeGate eşdeğeri), WiFi/Bluetooth/Android ayarları

## Diğer bileşenler
- `BootReceiver`: cihaz açılınca launcher otomatik başlar
- `RadioService`: arka plan radyo servisi iskeleti
- `PanelGuardService`: systemui pencere izleme servisi (Ayarlar > Erişilebilirlik'ten açılır)

## Derleme
1. Android Studio (Hedgehog veya üzeri) ile bu klasörü açın.
2. SDK 35 ve JDK 17 yüklü olsun (Android Studio varsayılanları yeterli).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

Cihazda "Ana ekran uygulaması" olarak seçince varsayılan launcher olur.

## Notlar
- Gerçek radyo tuner kontrolü ve CAN verisi için Skyworth sistem API/broadcast
  bağlantısı gerekir; ilgili fonksiyonlar RadioScreen.kt ve RadioService.kt içinde
  TODO olarak işaretlenmiştir. Cihazdaki smali/dex çıktısını paylaşırsanız tam entegrasyon yapılabilir.
- Harita çevrimdışı çalışır; internet izni yalnızca gelecekteki online tile katmanı içindir.
