package tr.hasan.et5.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import tr.hasan.et5.car.VehicleBus

// SkyOS Mg0.smali'den cikarilan sarj abonelik ve kontrol mekanizmalari
@Composable
fun ChargeScreen() {
    val context = LocalContext.current
    var values by remember { mutableStateOf(VehicleBus.readHvac(context)) }
    var limit by remember { mutableIntStateOf(80) }
    var scheduled by remember { mutableStateOf(false) }
    var scheduleTime by remember { mutableStateOf("08:00") }
    var status by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            values = VehicleBus.readHvac(context)
            delay(3000)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sarj & Batarya", style = MaterialTheme.typography.headlineMedium)
        Text("SkyOS arac onbellek anahtarlari: pil, menzil, sarj", style = MaterialTheme.typography.bodySmall)

        // Pil & Menzil gostergesi
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Batarya: ${values["pil"] ?: "--"}%", style = MaterialTheme.typography.titleLarge)
                Text("Menzil: ${values["menzil"] ?: "--"} km", style = MaterialTheme.typography.titleMedium)
                Text("Sarj Durumu: ${values["sarj"] ?: "--"}", style = MaterialTheme.typography.bodyMedium)
                Text("Ic Sicaklik: ${values["ic"] ?: "--"} C", style = MaterialTheme.typography.bodySmall)
                Text("Dis Sicaklik: ${values["dis"] ?: "--"} C", style = MaterialTheme.typography.bodySmall)
            }
        }

        HorizontalDivider()

        Text("Sarj Limiti (SkyOS: aracin siniri %)", style = MaterialTheme.typography.titleMedium)
        Slider(value = limit.toFloat(), onValueChange = { limit = it.toInt() }, valueRange = 50f..100f, steps = 49)
        Text("Limit: %$limit")
        Button(onClick = {
            status = VehicleBus.writeSetting(context, "sarj_limit", limit.toString()).toString()
        }) { Text("Limiti Araçtaya Yaz") }

        HorizontalDivider()

        Text("Randevulu Sarj (SkyOS: sarj_randevu)", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = scheduled, onCheckedChange = { scheduled = it })
            Spacer(Modifier.width(8.dp))
            Text(if (scheduled) "Aktif" else "Kapali")
        }
        if (scheduled) {
            TextField(value = scheduleTime, onValueChange = { scheduleTime = it }, label = { Text("Saat (ornek: 08:00)") })
            Button(onClick = {
                status = VehicleBus.writeSetting(context, "sarj_randevu", scheduleTime).toString()
            }) { Text("Randevuyu Kaydet") }
        } else {
            Button(onClick = {
                status = VehicleBus.writeSetting(context, "sarj_randevu", "").toString()
            }) { Text("Randevuyu Kaldir") }
        }

        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
