package tr.hasan.et5.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import tr.hasan.et5.MainActivity

class QuickControlsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "tr.hasan.et5.QUICK_CONTROLS") {
            val i = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("quick_controls", true)
            }
            context.startActivity(i)
        }
    }
}
