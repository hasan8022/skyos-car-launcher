package tr.hasan.et5.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus

@Composable
fun MirrorScreen() {
    val context = LocalContext.current
    var left by remember { mutableFloatStateOf(50f) }
    var right by remember { mutableFloatStateOf(50f) }
    var up by remember { mutableFloatStateOf(50f) }
    var status by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ayna Kontrolu", style = MaterialTheme.typography.headlineMedium)
        Text("SkyOS: ayna hafiza paketi + pozisyon", style = MaterialTheme.typography.bodySmall)

        Text("Sol/Aynaya: ${left.toInt()}")
        Slider(value = left, onValueChange = { left = it }, valueRange = 0f..100f)
        Text("Sag/Yukari: ${right.toInt()}")
        Slider(value = right, onValueChange = { right = it }, valueRange = 0f..100f)
        Text("Katlanma: ${up.toInt()}")
        Slider(value = up, onValueChange = { up = it }, valueRange = 0f..100f)

        Button(onClick = {
            val json = """{"sol":${left.toInt()},"sag":${right.toInt()},"katlanma":${up.toInt()}}"""
            status = VehicleBus.writeSetting(context, "ayna_pozisyon", json).toString()
        }) { Text("Pozisyonu Gonder") }

        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
