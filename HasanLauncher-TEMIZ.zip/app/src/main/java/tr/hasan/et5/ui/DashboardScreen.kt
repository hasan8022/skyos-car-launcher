package tr.hasan.et5.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus

@Composable
fun DashboardScreen() {
    val context = LocalContext.current
    var navFlag by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Gosterge & Kadran", style = MaterialTheme.typography.headlineMedium)
        Text("SkyOS: dashboard_service + navigasyon bayragi", style = MaterialTheme.typography.bodySmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Navigasyon Kadran Gosterimi", style = MaterialTheme.typography.titleLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = navFlag, onCheckedChange = { navFlag = it })
                    Spacer(Modifier.width(8.dp))
                    Text(if (navFlag) "Acik" else "Kapali")
                }
                Button(onClick = {
                    status = VehicleBus.writeSetting(context, "navigasyon_bayragi", if (navFlag) "1" else "0").toString()
                }) { Text("Bayragi Araçtaya Yaz") }
            }
        }

        Button(onClick = {
            context.sendBroadcast(Intent("tr.hasan.et5.QUICK_CONTROLS"))
        }, modifier = Modifier.fillMaxWidth()) { Text("Hizli Kontrolleri Ac (QUICK_CONTROLS)") }

        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
