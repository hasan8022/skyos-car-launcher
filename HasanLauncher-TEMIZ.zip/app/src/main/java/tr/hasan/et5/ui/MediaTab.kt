package tr.hasan.et5.ui

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun MediaTab() {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    var volume by remember { mutableStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC)) }

    fun key(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Medya Kontrol", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Button(onClick = { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }) { Text("Onceki") }
            Button(onClick = { key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }) { Text("Cal / Dur") }
            Button(onClick = { key(KeyEvent.KEYCODE_MEDIA_NEXT) }) { Text("Sonraki") }
        }
        Spacer(Modifier.height(32.dp))
        Text("Ses: " + volume + " / " + maxVol)
        Slider(
            value = volume.toFloat(),
            onValueChange = {
                volume = it.toInt()
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0)
            },
            valueRange = 0f..maxVol.toFloat(),
            modifier = Modifier.fillMaxWidth(0.7f)
        )
    }
}

// YouTube + Spotify baglantisi (MediaAppsScreen'den)
fun openAppOrWeb(context: android.content.Context, pkg: String, webUrl: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(pkg)
    if (launch != null) context.startActivity(launch)
    else context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(webUrl)))
}
