package tr.hasan.et5.service

import android.app.Service
import android.content.Intent
import android.os.IBinder

// SkyOS RadioService esdegeri (iskelet): arka planda radyo durumunu tutar.
// Gercek tuner entegrasyonu icin Skyworth radyo API/broadcast baglantisi buraya eklenir.
class RadioService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
}
