package tr.hasan.et5.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.service.HomeGate

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    var pin by remember { mutableStateOf(HomeGate.pin(context)) }
    var input by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ayarlar", style = MaterialTheme.typography.headlineMedium)

        Text("Guvenlik Kilidi PIN", style = MaterialTheme.typography.titleMedium)
        Text("Aktif PIN: " + (if (pin.isEmpty()) "ayarlanmadi" else "*".repeat(pin.length)))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(value = input, onValueChange = { input = it.filter { ch -> ch.isDigit() }.take(8) }, label = { Text("Yeni PIN") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(onClick = { HomeGate.setPin(context, input); pin = input; input = "" }) { Text("Kaydet") }
        }
        Button(onClick = { HomeGate.setPin(context, ""); pin = "" }) { Text("PIN'i Kaldir") }

        HorizontalDivider()

        Text("Sistem", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { context.startActivity(Intent(Settings.Panel.ACTION_WIFI)) }, modifier = Modifier.fillMaxWidth()) { Text("WiFi Ayarlari") }
        Button(onClick = { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Bluetooth Ayarlari") }
        Button(onClick = { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Android Ayarlari") }

        HorizontalDivider()
        Text("HasanLauncher v1.0 - paket: tr.hasan.et5", style = MaterialTheme.typography.bodySmall)
    }
}
