package tr.hasan.et5.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus

@Composable
fun ThemeScreen() {
    val context = LocalContext.current
    var theme by remember { mutableStateOf("koyu") }
    var tone by remember { mutableStateOf("mavi") }
    var bright by remember { mutableFloatStateOf(80f) }
    var status by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Tema & Kadran", style = MaterialTheme.typography.headlineMedium)
        Text("SkyOS anahtarlar: gosterge_tema, gosterge_ton, gosterge_parlak", style = MaterialTheme.typography.bodySmall)

        Text("Kadran Temasi", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("koyu", "acik", "spor", "klasik").forEach { t ->
                FilterChip(selected = theme == t, onClick = { theme = t }, label = { Text(t) })
            }
        }
        Button(onClick = {
            status = VehicleBus.writeSetting(context, "gosterge_tema", theme).toString()
        }) { Text("Temayi Uygula") }

        HorizontalDivider()

        Text("Kadran Tonu", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("mavi", "kirmizi", "yesil", "turuncu", "beyaz").forEach { t ->
                FilterChip(selected = tone == t, onClick = { tone = t }, label = { Text(t) })
            }
        }
        Button(onClick = {
            status = VehicleBus.writeSetting(context, "gosterge_ton", tone).toString()
        }) { Text("Tonu Uygula") }

        HorizontalDivider()

        Text("Parlaklik: ${bright.toInt()}%", style = MaterialTheme.typography.titleMedium)
        Slider(value = bright, onValueChange = { bright = it }, valueRange = 10f..100f, steps = 89)
        Button(onClick = {
            status = VehicleBus.writeSetting(context, "gosterge_parlak", bright.toInt().toString()).toString()
        }) { Text("Parlakligi Yaz") }

        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
