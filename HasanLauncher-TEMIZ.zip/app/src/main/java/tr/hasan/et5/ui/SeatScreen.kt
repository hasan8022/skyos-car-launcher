package tr.hasan.et5.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus

@Composable
fun SeatScreen() {
    val context = LocalContext.current
    var pkg by remember { mutableIntStateOf(1) }
    var fwd by remember { mutableFloatStateOf(50f) }
    var up by remember { mutableFloatStateOf(50f) }
    var recline by remember { mutableFloatStateOf(50f) }
    var status by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Koltuk & Ayna", style = MaterialTheme.typography.headlineMedium)
        Text("SkyOS: hafiza paketi + P vites korumasi", style = MaterialTheme.typography.bodySmall)

        Text("Hafiza Paketi", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..3).forEach { n ->
                FilterChip(selected = pkg == n, onClick = { pkg = n }, label = { Text("Paket $n") })
            }
        }
        Button(onClick = {
            status = VehicleBus.writeSetting(context, "koltuk_hafiza", pkg.toString()).toString()
        }) { Text("Paketi Araçtaya Yaz") }

        HorizontalDivider()

        Text("Koltuk Ayari (P vitesinde calisir)", style = MaterialTheme.typography.titleMedium)
        Text("Ileri/Geri: ${fwd.toInt()}")
        Slider(value = fwd, onValueChange = { fwd = it }, valueRange = 0f..100f)
        Text("Yukseklik: ${up.toInt()}")
        Slider(value = up, onValueChange = { up = it }, valueRange = 0f..100f)
        Text("Sirt Egimi: ${recline.toInt()}")
        Slider(value = recline, onValueChange = { recline = it }, valueRange = 0f..100f)

        Button(onClick = {
            val json = """{"ileri":${fwd.toInt()},"yukseklik":${up.toInt()},"egim":${recline.toInt()}}"""
            status = VehicleBus.writeSetting(context, "koltuk_pozisyon", json).toString()
        }) { Text("Pozisyonu Gonder") }

        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
