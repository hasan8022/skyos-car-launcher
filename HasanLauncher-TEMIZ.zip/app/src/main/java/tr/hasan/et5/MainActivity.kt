package tr.hasan.et5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import tr.hasan.et5.ui.HomeScreen
import tr.hasan.et5.ui.theme.HasanLauncherTheme

class MainActivity : ComponentActivity() {
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("quick_controls", false)) {
            // Hizli kontroller paneli acilabilir
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HasanLauncherTheme {
                HomeScreen()
            }
        }
    }
}
