package tr.hasan.et5.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// Ana ekran uygulama grid'i
@Composable
fun HomeTab() {
    val context = LocalContext.current
    val apps = listOf(
        Triple("Telefon", "\u260e") { context.startActivity(Intent(Intent.ACTION_DIAL)) },
        Triple("Radyo", "\u265b") { /* go radio tab */ },
        Triple("Muzik", "\u266b") { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://spotify.com"))) },
        Triple("Harita", "\u2630") { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
        Triple("Klima", "\u2600") { /* go climate tab */ },
        Triple("Sarj", "\u26a1") { /* go charge tab */ },
        Triple("YouTube", "YT") { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com"))) },
        Triple("Spotify", "SP") { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://spotify.com"))) },
        Triple("Ayarlar", "\u2699") { /* go settings tab */ },
        Triple("Tema", "\u2728") { /* go theme tab */ },
        Triple("Sesli", "\u1f3a7") { /* go voice tab */ }
    )

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("HasanLauncher", style = MaterialTheme.typography.headlineMedium)
        Text("tr.hasan.et5 - Ozgun arac launcher", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))

        val rows = apps.chunked(4)
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { (name, icon, onClick) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
                        Button(onClick = onClick, modifier = Modifier.size(64.dp)) {
                            Text(icon, style = MaterialTheme.typography.titleLarge)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(name, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
