package tr.hasan.et5.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import tr.hasan.et5.car.VehicleBus

@Composable
fun ClimateScreen() {
    val context = LocalContext.current
    var values by remember { mutableStateOf(VehicleBus.readHvac(context)) }
    var targetTemp by remember { mutableFloatStateOf(21f) }
    var fan by remember { mutableIntStateOf(2) }
    var acOn by remember { mutableStateOf(true) }
    var auto by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            values = VehicleBus.readHvac(context)
            kotlinx.coroutines.delay(3000)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Klima", style = MaterialTheme.typography.headlineMedium)
        Text("SkyOS: hvac + sicaklik ContentProvider", style = MaterialTheme.typography.bodySmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Mevcut: Ic ${values["ic"] ?: "--"} C / Dis ${values["dis"] ?: "--"} C", style = MaterialTheme.typography.titleMedium)
                Text("Hedef Sicaklik: %.1f C".format(targetTemp), style = MaterialTheme.typography.titleLarge)
                Slider(value = targetTemp, onValueChange = { targetTemp = it }, valueRange = 15f..30f, steps = 29)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        status = VehicleBus.setTemperature(context, "0", targetTemp).toString()
                    }) { Text("Surucuye Yaz") }
                    Button(onClick = {
                        status = VehicleBus.setTemperature(context, "1", targetTemp).toString()
                    }) { Text("Yolcuya Yaz") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Fan: $fan", style = MaterialTheme.typography.titleMedium)
                Slider(value = fan.toFloat(), onValueChange = { fan = it.toInt() }, valueRange = 0f..7f, steps = 6)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("AC")
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = acOn, onCheckedChange = { acOn = it })
                    Spacer(Modifier.width(16.dp))
                    Text("Oto")
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = auto, onCheckedChange = { auto = it })
                }
                Button(onClick = {
                    status = VehicleBus.writeSetting(context, "fan_hizi", fan.toString()).toString()
                }) { Text("Klima Ayarlarini Gonder") }
            }
        }

        if (status.isNotEmpty()) Text("Durum: $status", style = MaterialTheme.typography.bodySmall)
    }
}
